"""Linearize complete gate observations at the fixed-attitude optical fit."""

import numpy as np
from scipy.linalg import cho_factor, cho_solve

from mapped import CAMERA_FROM_BODY, K, translation
from rednose_model import pixel_factor, pose_at, project
from rednose_replay import corner_noise, visible
from relock import ORDER, candidates


def with_aperture_anchor(fallback, metrics, *, bounded=False):
    def gate_update(observer, image, gates, rim, recover=False, gap_safe=False, range_pixels=0.,
                    range_quality=False, landmarks=None, observed=None, outlines=None,
                    measured_pair=None, apertures_used=None, bearings=None):
        if not observer.N and outlines and not landmarks:
            result = anchor(observer, gates, outlines, range_pixels, bounded=bounded)
            if result is not None:
                openings, residual, fraction = result
                if fraction < 1.:
                    metrics.setdefault('bounded_anchors', []).append(float(fraction))
                if observed is not None:
                    observed.update(openings)
                if apertures_used is not None:
                    apertures_used.update(openings)
                metrics.setdefault('aperture_anchors', []).append([len(openings), float(residual)])
                return len(openings), True
        return fallback(observer, image, gates, rim, recover, gap_safe, range_pixels, range_quality,
                        landmarks, observed, outlines, measured_pair, apertures_used, bearings)

    return gate_update


def anchor(observer, gates, outlines, range_pixels, *, bounded=False):
    position, attitude = pose_at(observer.x[:, 0], 0)
    camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
    matches = candidates(position, attitude, gates, outlines)
    geometry = dict(gates)
    openings = {}
    for match in matches:
        if any(other is not match and other.cost < match.cost+1.5
               and (other.outline == match.outline or other.index == match.index) for other in matches):
            continue
        quad = geometry[match.index]
        origin = position+match.offset
        if visible(origin, quad, match.index, gates):
            projected, _ = project(quad, origin, attitude)
            ordered = np.asarray(outlines[match.outline])[ORDER]
            pixels = ordered[np.argmin(np.sum((ordered-projected)**2, axis=(1, 2)))]
            openings[match.index] = match.index, quad, pixels
    if not openings:
        return None

    points = np.concatenate([quad for _, quad, _ in openings.values()])
    pixels = np.concatenate([corners for _, _, corners in openings.values()])
    fitted = translation(points, pixels, camera)
    expected, depth = project(points, fitted, attitude)
    residual = pixels-expected
    rms = np.sqrt(np.mean(residual**2))
    if depth.min() <= .6 or rms > 2.8 or np.linalg.norm(fitted-position) > 2.:
        return None

    prior = project(points, position, attitude)[0]
    H = np.zeros((pixels.size, observer.dim_err))
    H[:, :6] = np.vstack([pixel_factor(point, fitted, attitude)[1] for point in points])
    deviations = np.empty(pixels.size)
    range_noise = np.zeros((pixels.size, pixels.size))
    for i, (_, quad, corners) in enumerate(openings.values()):
        span = np.median(np.linalg.norm(corners-np.roll(corners, 1, axis=0), axis=1))
        rows = slice(8*i, 8*i+8)
        deviations[rows] = corner_noise(span)
        ray = quad.mean(axis=0)-fitted
        width = np.linalg.norm(quad[1]-quad[0])
        depth = ray @ camera[2]
        sigma = range_pixels*depth**2/(K[0, 0]*width)
        scale_error = H[rows, :3] @ (sigma*ray/np.linalg.norm(ray))
        range_noise[rows, rows] = np.outer(scale_error, scale_error)

    noise = np.diag(deviations**2)+range_noise
    P = observer.P
    projected = H@P
    gain = cho_solve(cho_factor(projected@H.T+noise, check_finite=False), projected, check_finite=False).T
    gain[3:6] = 0.
    linear_residual = residual.ravel()+H[:, :3]@(fitted-position)
    fraction = 1.
    if bounded:
        step = gain@linear_residual
        # Stay inside the observer's position and velocity rejection bounds.
        fraction = 1./max(1., np.linalg.norm(step[:3])/.58, np.linalg.norm(step[6:9])/.78)
        gain *= fraction
    corrected = observer.x.copy()
    observer.err_function(observer.x, (gain@linear_residual)[:, None], corrected)
    retained = np.eye(observer.dim_err)-gain@H
    covariance = retained@P@retained.T+gain@noise@gain.T
    observer.last_gate_factor = ((pixels-prior).ravel(), H, deviations, range_noise)
    observer.x, observer.P = corrected, .5*(covariance+covariance.T)
    return openings, rms, fraction
