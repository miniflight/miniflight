"""Fly a trained G&CNet through the public VQ2 camera, IMU and motor interfaces."""

import json
from time import monotonic

import numpy as np
from scipy.spatial.transform import Rotation

from miniflight import MotorControls, vehicle
from monorace_policy import GateObservations, GuidanceControlNet, motor_inputs
from motor_drive import MOTOR_MOTION_TIMEOUT, install_motor_history, motor_imu_observer, predict_motor_state, project_at_control_time
from motor_response import AXES, MOTOR_IMU_TIMEOUT, MOTOR_LAG, MOTOR_TRANSPORT, MotorResponse
from refine_gate_map import read_packet_map
from vertical_tracking import digest


FINISH_STATUS_WAIT = .60
AIRBORNE_BLEND_HEIGHT = 1.
AIRBORNE_BLEND_S = .35


def install(pilot, source, gate_map, counts, motion_drag=None, *, bridge_s=None, angular_fit=None,
            gate_switch='delayed', runner_guards_feedback=False, transport_lead=False,
            airborne_policy=None, imu_clock=None):
    with np.load(source,allow_pickle=False) as data:
        metadata = json.loads(str(data['metadata']))
    if digest(gate_map)!=metadata['map_sha256']:
        raise ValueError('Live trial must use the same carried map as the training evaluation')
    if motion_drag is not None and 'motion_drag_per_m' in metadata:
        motion_drag = np.asarray(metadata['motion_drag_per_m'],dtype=float)
        if motion_drag.shape!=(3,) or not np.isfinite(motion_drag).all() or (motion_drag<0.).any():
            raise ValueError('Expected three finite nonnegative drag coefficients')
    actor = GuidanceControlNet.from_numpy(source)
    flight_actor = None
    if airborne_policy is not None:
        with np.load(airborne_policy,allow_pickle=False) as data:
            flight_metadata = json.loads(str(data['metadata']))
        shared = ('map_sha256','motor','motion_drag_per_m','rate_support_rad_s','rate_support_window_s')
        if any(flight_metadata.get(key)!=metadata.get(key) for key in shared):
            raise ValueError('Launch and flight policies require the same map and motor calibration')
        flight_actor = GuidanceControlNet.from_numpy(airborne_policy)
    baseline_map = read_packet_map(gate_map)
    motor = MotorResponse.from_report(metadata['motor'])
    if angular_fit is not None:
        fitted = json.loads(angular_fit.read_text())
        if (fitted['lag_s'] != MOTOR_LAG or fitted['delay_s'] != MOTOR_TRANSPORT
                or tuple(axis['axis'] for axis in fitted['axes']) != AXES):
            raise ValueError('The angular fit must match the stock motor timing and axis order')
        motor = MotorResponse(motor.force, fitted['axes'], motor.idle)
        if not (np.isfinite(motor.gain).all() and np.isfinite(motor.damping).all()
                and (motor.gain > 0.).all() and (motor.damping >= 0.).all()):
            raise ValueError('The angular fit needs positive gains and nonnegative damping')
    upper = metadata['motor']['observed_motor_bounds'][1]
    rate_support = metadata.get('rate_support_rad_s')
    rate_support_window = metadata.get('rate_support_window_s')
    ground_start = metadata.get('ground_start',False)
    initial_motor = np.zeros(4) if ground_start else motor.motors(9.81,np.zeros(3))
    launch_height = metadata['airborne_height_m']
    transport = MOTOR_TRANSPORT
    motion_timeout = MOTOR_MOTION_TIMEOUT if bridge_s is None else bridge_s
    install_motor_history(pilot,send_to_observer=imu_clock is not None)
    if imu_clock is not None:
        client = pilot.CourseClient
        client.observer_type = motor_imu_observer(client.observer_type,imu_clock,motor,initial_motor,counts)
    baseline = pilot.FollowCourse

    class Learned(baseline):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.action_clock.command_delay = transport if transport_lead else 0.
            self.observed_course = None
            self.last_policy_command = None
            self.airborne_at = None

        def update(self,telemetry,frames,race):
            if race is not None and race.completed:
                return None
            if race is not None and race.started and self.client().observer.active>=len(baseline_map):
                return self.terminal_command()
            if gate_switch == 'firmware':
                return self.firmware_update(race)
            return super().update(telemetry,frames,race)

        def crossed_plane(self, center, plane, stamp, position, velocity, seen, index, exit_distance,
                          close_view, lock_stamp, *, client=None):
            if gate_switch == 'confirmed':
                exit_distance = 0.
            return super().crossed_plane(center, plane, stamp, position, velocity, seen, index, exit_distance,
                                         close_view, lock_stamp, client=client)

        def course_encoder(self, client):
            course = client.prediction.source[4].course
            if course is not self.observed_course:
                geometry = baseline_map.copy()
                for i,(center,rotation) in enumerate(course[:len(geometry)]):
                    geometry[i] = np.r_[center,rotation.as_quat()]
                self.gate_encoder = GateObservations(geometry)
                self.observed_course = course
            return self.gate_encoder

        def firmware_update(self, race):
            state = vehicle.state
            if race is None or not race.started or state.motion is None or state.attitude is None:
                return None
            began = monotonic()
            client = self.client()
            geometry = client.prediction.source[4]
            if not self.ready_to_fly and began - geometry.received_at > MOTOR_IMU_TIMEOUT:
                return None
            self.ready_to_fly = True
            attitude = state.attitude
            position, velocity, angles = self.control_state(
                np.asarray(state.motion.position), np.asarray(state.motion.velocity),
                (attitude.roll, attitude.pitch, attitude.yaw), client, state, began)
            observer = client.observer
            index = observer.active
            encoder = self.course_encoder(client)
            local = (position - encoder.centers[index]) @ encoder.world_from_gate[index]
            # The released G&CNet firmware switches as soon as estimated position passes this plane.
            if local[0] > 0.:
                self.crossings.append((self.control_stamp, index, *local))
                observer.active = index + 1
            command = self.direct_motor_command(position, velocity, angles, client, state)
            if command is not None:
                self.plan_times.append((state.motion.time, monotonic() - began))
            return command

        def terminal_command(self):
            if self.last_policy_command is None:
                return None
            # Public score packets arrive at about 3.5 Hz.
            if monotonic()-self.last_policy_at > FINISH_STATUS_WAIT:
                raise TimeoutError('Final gate estimate advanced without a native finish')
            counts['terminal_motor_holds'] = counts.get('terminal_motor_holds',0)+1
            return self.last_policy_command

        def control_state(self,position,velocity,angles,client,state,host_now):
            first = counts.get('first_command_host_s')
            self.motor_forecast = None
            self.use_motor_motion = motion_drag is not None and first is not None and host_now-first>=.25
            if self.use_motor_motion:
                self.action_clock.max_projection = motion_timeout
            return super().control_state(position,velocity,angles,client,state,host_now)

        def predict_action(self,client,state,reading,host_now):
            if not self.use_motor_motion:
                return super().predict_action(client,state,reading,host_now)
            return self.predict_motors(client,state,reading)

        def predict_camera_action(self,client,reading,camera,host_now):
            if not self.use_motor_motion:
                return super().predict_camera_action(client,reading,camera,host_now)
            counts['early_motor_estimates'] = counts.get('early_motor_estimates',0)+1
            return self.predict_motors(client,camera[1][:16],reading,state_time=camera[0])

        def predict_motors(self,client,state,reading,state_time=None):
            forecast,rate,rotors = project_at_control_time(
                motor, client, self.action_clock, self.control_stamp, state, reading, motion_drag,
                initial_motor, state_time=state_time)
            self.motor_forecast = rate,rotors
            counts['motor_motion_predictions'] = counts.get('motor_motion_predictions',0)+1
            return forecast

        def direct_motor_command(self,position,velocity,angles,client,state):
            active = client.observer.active
            if active>=len(baseline_map):
                return self.terminal_command()
            feedback = state.rate_feedback
            pose = client.prediction.state
            received = monotonic()
            if not hasattr(self,'ground'):
                self.ground = float(position[2])
            motors = client.motor_history
            if not ground_start and self.ground-position[2]<launch_height and not motors:
                return None
            freshness = motion_timeout if self.motor_forecast is not None else MOTOR_IMU_TIMEOUT
            stale = feedback is not None and received - feedback.received_at > freshness
            if feedback is None or (stale and not runner_guards_feedback) or not self.action_clock.offsets:
                if motors:
                    raise TimeoutError('G&CNet lost recent IMU feedback')
                return None
            if stale:
                counts['held_feedback_ticks'] = counts.get('held_feedback_ticks',0)+1
                return self.last_policy_command
            if received-feedback.received_at>MOTOR_IMU_TIMEOUT:
                counts['bridged_imu_ticks'] = counts.get('bridged_imu_ticks',0)+1
            encoder = self.course_encoder(client)
            quaternion = Rotation.from_euler('xyz',angles).as_quat()
            if self.motor_forecast is None:
                rate = np.asarray(feedback.gyro)-pose[13:16]
                sample = min(feedback.received_at,feedback.time+self.action_clock.offset())
                decision = sample+max(0.,self.control_stamp-feedback.time)
                rate,estimated = predict_motor_state(motor,motors,sample,decision,rate,transport,initial_motor)
            else:
                rate,estimated = self.motor_forecast
            observation = encoder.encode(position,velocity,quaternion,rate,motor.rotor_speed(estimated),active)
            action = actor(observation)
            if flight_actor is not None:
                if self.airborne_at is None and self.ground-position[2] >= AIRBORNE_BLEND_HEIGHT:
                    self.airborne_at = received
                    counts['airborne_blend_host_s'] = received
                if self.airborne_at is not None:
                    blend = min(1., (received-self.airborne_at)/AIRBORNE_BLEND_S)
                    weight = blend*blend*(3.-2.*blend)
                    action += weight*(flight_actor(observation)-action)
                    counts['blended_commands'] = counts.get('blended_commands',0)+int(weight>0.)
            output = motor_inputs(action,upper)
            if rate_support is not None:
                supported = motor.limit_rate_support(output,rate_support,rate,rate_support_window)
                counts['limited_actions'] = counts.get('limited_actions',0)+int(np.any(abs(output-supported)>1.e-8))
                output = supported
            counts['network_commands'] += 1
            counts.setdefault('first_command_host_s',received)
            counts.setdefault('policy_trace',[]).append([
                received,float(self.control_stamp),int(active),*observation.tolist(),*action.tolist(),*output.tolist()])
            self.last_policy_command = MotorControls(tuple(map(float,output)))
            self.last_policy_at = received
            return self.last_policy_command

    return Learned
