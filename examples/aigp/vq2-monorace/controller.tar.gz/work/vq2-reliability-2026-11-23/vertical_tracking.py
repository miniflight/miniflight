"""Locate vertical tracking error in the planned, requested and measured motion."""

from argparse import ArgumentParser
from hashlib import file_digest
import json
from pathlib import Path

import numpy as np
from scipy.interpolate import BPoly
from scipy.spatial.transform import Rotation, Slerp

from actuator_state_witness import signals
from command_projection import CommandProjection
from flown_sections import read_wire
from measure import HERE
from miniflight.position import GRAVITY


def digest(path):
    with Path(path).open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def hold(time, stamps):
    return (np.searchsorted(time, stamps, side='right')-1).clip(0)


def reference_at(curve, crossings, stage, position):
    rows = np.empty((len(stage), 3))
    for leg in np.unique(stage):
        selected = stage == leg
        edges = np.r_[curve.x[0], crossings]
        grid = np.linspace(edges[leg], edges[leg+1], 201)
        offsets = curve(grid)[None]-position[selected,None]
        stamp = grid[np.argmin(np.sum(offsets**2, axis=2), axis=1)]
        rows[selected] = np.column_stack([curve(stamp, derivative)[:,2] for derivative in range(3)])
    return rows


def flight(folder, model, thrust):
    outcome = json.loads((folder/'result.json').read_text())
    with np.load(folder/'learned-course.npz', allow_pickle=False) as source:
        pose, request, camera = (source[k] for k in ('pose','approach_commands','applied_camera_states'))
    time, unique = np.unique(pose[:,0], return_index=True)
    pose = pose[unique]
    epoch = float(np.median(pose[:,12]-time))
    imu, wire = signals(folder, epoch)
    if len(imu)<10 or len(wire)<5 or len(request)<5:
        return None
    start = outcome['wire']['race_start_boot_time_ms']
    splits, _, _, first_power, impact, _ = read_wire(folder, start, epoch)
    if first_power is None:
        return None
    if impact is not None:
        recent = imu[(imu[:,1]>=impact-1.) & (imu[:,1]<=impact)]
        if len(recent):
            impact -= float(np.quantile(recent[:,1]-recent[:,0], .1))
        else:
            impact -= epoch
    positive = wire[wire[:,4]>0.]
    stop = min(time[-1], positive[-1,0]-epoch+.05, impact if impact is not None else np.inf)
    imu = imu[(imu[:,0]>=max(time[0], first_power-epoch)) & (imu[:,0]<=stop)]
    if len(imu)<8:
        return None
    stamps, host = imu[:,:2].T
    # Use per-flight receipt offsets to align sent commands with device samples.
    offset = float(np.quantile(host-stamps, .1))
    wire = wire.copy()
    wire[:,0] -= offset
    grid = np.arange(stamps[0]-.10, stamps[-1]+model.step, model.step)
    response = model.response(wire, grid)
    expected = -np.interp(stamps, grid, response[:,3])
    manifest = json.loads((folder/'manifest.json').read_text())
    path = Path(manifest['inputs']['plan']['path'])
    if digest(path)!=manifest['inputs']['plan']['sha256']:
        raise ValueError(f'Changed plan for {folder}')
    with np.load(path, allow_pickle=False) as archive:
        curve = BPoly.from_derivatives(archive['launch_time_s'], archive['launch_states'].tolist())
        crossings = archive['launch_time_s'][archive['launch_gate_indexes']]
        config = json.loads(str(archive['config']))
    rotation = Slerp(time, Rotation.from_quat(pose[:,4:8]))(stamps)
    down = rotation.as_matrix()[:,2,:]
    bias = camera[hold(camera[:,0], stamps),12:15] if len(camera) else 0.
    measured = imu[:,5:8]-bias
    position = np.column_stack([np.interp(stamps, time, value) for value in pose[:,1:4].T])
    velocity = np.column_stack([np.interp(stamps, time, value) for value in pose[:,8:11].T])
    speed = velocity[:,2]
    prior_request = request[hold(request[:,0], stamps)]
    ref = reference_at(curve, crossings, prior_request[:,1].astype(int), position)
    control = wire[hold(wire[:,0], stamps-thrust['delay_s'])]
    clipped = np.clip(prior_request[:,8], -config['max_acceleration'], config['max_acceleration'])
    nominal_force = GRAVITY + config['thrust_acceleration']*(control[:,4]-config['hover_thrust'])
    cross_force = np.sum(down[:,:2]*measured[:,:2], axis=1)
    local_velocity = rotation.inv().apply(velocity)[:,:2]
    drag = -np.asarray(config['body_resistance_per_m'][:2])*local_velocity*abs(local_velocity)
    predicted_cross_force = np.sum(down[:,:2]*drag, axis=1)
    measured_down = GRAVITY+cross_force+down[:,2]*measured[:,2]
    naive_down = GRAVITY-down[:,2]*nominal_force
    modeled_down = GRAVITY-down[:,2]*expected
    dt = np.diff(stamps)
    adjacent = dt<=.10
    rows = []
    for index in np.unique(prior_request[:,1]).astype(int):
        same = prior_request[:,1]==index
        edges = np.flatnonzero(same[1:] & same[:-1] & adjacent)
        if len(edges)<3:
            continue

        def integral(values):
            return float(.5*(values[edges]+values[edges+1])@dt[edges])

        i, j = edges[0], edges[-1]+1
        rows.append(dict(gate=int(index)+1, duration_s=float(dt[edges].sum()),
                         start_v_down_error_m_s=float(speed[i]-ref[i,1]),
                         end_v_down_error_m_s=float(speed[j]-ref[j,1]),
                         plan_v_change_m_s=integral(ref[:,2]),
                         requested_v_change_m_s=integral(prior_request[:,8]),
                         clipped_v_change_m_s=integral(clipped),
                         wire_v_change_m_s=integral(naive_down),
                         modeled_v_change_m_s=integral(modeled_down),
                         measured_v_change_m_s=integral(measured_down),
                         body_xy_v_change_m_s=integral(cross_force),
                         body_drag_v_change_m_s=integral(predicted_cross_force),
                         estimator_v_change_m_s=float(speed[j]-speed[i]),
                         above_limit_fraction=float(np.mean(prior_request[same,8]>config['max_acceleration']))))
    traces = np.column_stack((stamps-start*.001, prior_request[:,1]+1, position[:,2], ref[:,0],
                              speed, ref[:,1], ref[:,2], prior_request[:,8], clipped,
                              naive_down, modeled_down, measured_down, control[:,4], down[:,2],
                              cross_force, predicted_cross_force))
    return dict(lap=outcome['attempt'], source=str(folder.resolve()), splits=splits,
                gates=outcome['active_gate_index'], contacts=outcome['contacts'],
                plan_sha256=manifest['inputs']['plan']['sha256'], estimates=rows), traces


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('campaigns', nargs='+', type=Path)
    args = parser.parse_args()
    path = HERE/'recent-rate-authority.json'
    force_path = HERE/'force-model-holdout.json'
    axes = json.loads(path.read_text())['axes']
    thrust = json.loads(force_path.read_text())
    model = CommandProjection(axes, thrust)
    runs, traces = [], {}
    for campaign in args.campaigns:
        for folder in sorted(campaign.glob('practice-*')):
            if not (folder/'learned-course.npz').is_file() or not (folder/'result.json').is_file():
                continue
            result = flight(folder, model, thrust)
            if result is not None:
                report, trace = result
                runs.append(report)
                key = f'{campaign.name}-{report["lap"]}'
                traces[key] = trace
                print(key, 'credited', report['gates'], 'contacts', report['contacts'], flush=True)
    columns = ('race_s','target','down_m','ref_down_m','v_down_m_s','ref_v_down_m_s',
               'ref_a_down_m_s2','requested_a_down_m_s2','clipped_a_down_m_s2',
               'wire_a_down_m_s2','model_a_down_m_s2','imu_a_down_m_s2','thrust','body_down_cosine',
               'measured_body_xy_a_down_m_s2','predicted_body_drag_a_down_m_s2')
    record = dict(rate_sha256=digest(path), thrust_sha256=digest(force_path), columns=columns, laps=runs)
    args.output.with_suffix('.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    np.savez_compressed(args.output, **traces)


if __name__=='__main__':
    main()
