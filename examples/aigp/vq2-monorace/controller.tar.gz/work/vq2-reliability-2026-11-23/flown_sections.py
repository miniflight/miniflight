"""Bound repeatable pace using witnessed transitions between flown gate sections."""

from argparse import ArgumentParser
from base64 import b64decode
import gzip
import json
from pathlib import Path
from struct import unpack_from

import numpy as np
from pymavlink.dialects.v20 import common
from scipy.spatial.transform import Rotation


HERE = Path(__file__).resolve().parent
NATIVE = HERE.parent/'checkpoints/vq2-2026-11-23/native'
LIVE = HERE/'thrust-priority-go'
LIMITS = (.20,.80,np.deg2rad(7.),.85)


def read_wire(folder, start_ms, epoch):
    rx,tx=common.MAVLink(None),common.MAVLink(None)
    rx.robust_parsing=True
    go=arm=power=impact=None
    split={0:0.}
    imu=[]
    armed=False
    with gzip.open(folder/'flight.jsonl.gz','rt') as source:
        for row in map(json.loads,source):
            kind,host=row['event'],row['host_time']
            if row.get('name')=='arm':
                armed=row['arguments']['armed']
            if kind=='telemetry' and armed and row['message']['mavpackettype']=='COLLISION' and impact is None:
                impact=host
            if kind=='mavlink_datagram':
                for message in rx.parse_buffer(b64decode(row['wire'])) or ():
                    name=message.get_type()
                    if name=='ENCAPSULATED_DATA' and message.data[0]==1:
                        _, boot, start, _, gate, last=unpack_from('<BQqqIq',bytes(message.data))
                        if start==start_ms and boot>=start and abs(host-boot*.001-epoch)<.25:
                            if go is None:
                                go=host,(boot-start)*.001
                            if gate and last>=0:
                                split.setdefault(gate,last*1.e-9)
                    if name=='HIGHRES_IMU':
                        imu.append((host,message.time_usec*1.e-6,-message.xgyro,-message.ygyro,-message.zgyro))
            elif kind=='outgoing':
                for message in tx.parse_buffer(b64decode(row['wire'])) or ():
                    name=message.get_type()
                    if name=='COMMAND_LONG' and arm is None and message.command==400 and message.param1==1:
                        arm=host
                    if name=='SET_ATTITUDE_TARGET' and power is None and message.thrust>0.:
                        power=host
    return split,go,arm,power,impact,np.asarray(imu).reshape(-1,5)


def gate_state(stamp, pose, imu):
    i=np.searchsorted(pose[:,0],stamp,side='right')-1
    if i<0 or stamp-pose[i,0]>.105:
        return None
    state=pose[i]
    index=np.searchsorted(imu[:,1],stamp,side='right')-1
    if index<0 or stamp-imu[index,1]>.105:
        return None
    rate=imu[index,2:]
    dt=stamp-state[0]
    orientation=Rotation.from_quat(state[4:8])*Rotation.from_rotvec(dt*rate)
    return np.r_[state[1:4]+dt*state[8:11],state[8:11],orientation.as_quat(),rate]


def read_lap(folder, outcome, name):
    start=outcome['wire']['race_start_boot_time_ms']
    with np.load(folder/'learned-course.npz',allow_pickle=False) as data:
        pose=data['pose']
    if not len(pose):
        return None
    _,unique=np.unique(pose[:,0],return_index=True)
    pose=pose[unique]
    epoch=pose[0,12]-pose[0,0]
    split,go,arm,power,impact,imu=read_wire(folder,start,epoch)
    if go is None or power is None:
        return None
    imu=imu[abs(imu[:,0]-imu[:,1]-epoch)<.25]
    imu=imu[np.unique(imu[:,1],return_index=True)[1]]
    deadline=outcome['time_seconds']+1.e-6
    if outcome['contacts']:
        if impact is not None:
            deadline=min(deadline,impact-go[0]+go[1])
        deadline-=.10
    gates={gate:gate_state(start*.001+value,pose,imu) for gate,value in split.items()
           if gate<=outcome['active_gate_index'] and value<=deadline}
    sections=[]
    for gate in range(1,18):
        if gates.get(gate-1) is not None and gates.get(gate) is not None and split[gate]>split[gate-1]:
            sections.append(dict(gate=gate,seconds=split[gate]-split[gate-1],source=name,
                                 start=gates[gate-1],end=gates[gate]))
    return dict(source=name,go_confirmed=arm is not None and min(arm,power)>=go[0],
                before_go_ms=None if arm is None else 1000.*(min(arm,power)-go[0]),
                finish_s=outcome['time_seconds'] if outcome['clean_full'] else None,contacts=outcome['contacts'],
                credited=outcome['active_gate_index'],sections=sections)


def joins(previous, following):
    end=np.array([item['end'] for item in previous])
    start=np.array([item['start'] for item in following])
    difference=end[:,None,:]-start[None,:,:]
    position=np.linalg.norm(difference[:,:,:3],axis=2)
    velocity=np.linalg.norm(difference[:,:,3:6],axis=2)
    attitude=2.*np.arccos(abs(end[:,6:10]@start[:,6:10].T).clip(0.,1.))
    rate=np.linalg.norm(difference[:,:,10:],axis=2)
    same=np.equal.outer([row['source'] for row in previous],[row['source'] for row in following])
    return np.stack((position,velocity,attitude,rate),axis=-1),same


def shortest(groups, limits):
    if not all(groups):
        return None
    costs=np.array([row['seconds'] for row in groups[0]])
    paths=[]
    for previous,following in zip(groups[:-1],groups[1:],strict=True):
        error,same=joins(previous,following)
        admissible=(error <= limits).all(axis=-1)|same
        options=np.where(admissible,costs[:,None],np.inf)
        paths.append(options.argmin(axis=0))
        costs=options.min(axis=0)+np.array([row['seconds'] for row in following])
    index=int(costs.argmin())
    if not np.isfinite(costs[index]):
        return None
    schedule=[groups[-1][index]]
    for gate,ancestry in reversed(list(enumerate(paths))):
        index=ancestry[index]
        schedule.append(groups[gate][index])
    return list(reversed(schedule))


def analyze(flights):
    groups=[[row for flight in flights for row in flight['sections'] if row['gate']==gate]
            for gate in range(1,18)]
    fastest=[flight for flight in flights if flight['finish_s'] is not None]
    schedules={}
    for name,limits in [('independent',np.inf),('nearby',LIMITS),('tight',np.array(LIMITS)*.5)]:
        route=shortest(groups,limits)
        schedules[name]=None if route is None else dict(seconds=sum(r['seconds'] for r in route),
            route=[{k:r[k] for k in ('gate','seconds','source')} for r in route],
            switches=sum(a['source']!=b['source'] for a,b in zip(route[:-1],route[1:],strict=True)))
    return dict(laps=len(flights),completed=len(fastest),sections=list(map(len,groups)),
                best=min((flight['finish_s'] for flight in fastest),default=None),schedules=schedules)


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument('--last-lap',type=int,required=True)
    args=parser.parse_args()
    initial=json.loads((LIVE/'practice-789/manifest.json').read_text())
    binding=initial['observer_map']['sha256']
    sources={}
    exclusions={}
    for name,root,span in [('archive',NATIVE,range(1390,1674)),('current',LIVE,range(755,args.last_lap+1))]:
        flights=[]
        counts=dict(missing=0,other_map=0,unpowered_or_interrupted=0,matching=0)
        for lap in span:
            folder=root/f'practice-{lap}'
            if any(not (folder/key).is_file() for key in ('manifest.json','result.json')):
                counts['missing']+=1
                continue
            manifest=json.loads((folder/'manifest.json').read_text())
            match=((manifest.get('observer_map') or {}).get('sha256')==binding)
            if name=='current':
                match &= manifest['inputs']['plan']['sha256']==initial['inputs']['plan']['sha256']
            if not match:
                counts['other_map']+=1
                continue
            counts['matching']+=1
            outcome=json.loads((folder/'result.json').read_text())
            if (outcome['interrupted'] or not outcome['wire'] or outcome['time_seconds'] is None
                    or not (folder/'learned-course.npz').is_file() or not (folder/'flight.jsonl.gz').is_file()):
                counts['unpowered_or_interrupted']+=1
                continue
            row=read_lap(folder,outcome,f'{name}-{lap}')
            if row is not None:
                flights.append(row)
            else:
                counts['unpowered_or_interrupted']+=1
        sources[name]=flights
        exclusions[name]=counts
    total=sources['archive']+sources['current']
    cohorts=dict(current=analyze(sources['current']),
                 confirmed_go=analyze([flight for flight in total if flight['go_confirmed']]),
                 every_scored_lap=analyze(total))
    report=dict(observer_map_sha256=binding,limits=list(LIMITS),sources=exclusions,cohorts=cohorts,
                flights=[dict((k,v) for k,v in row.items() if k!='sections') for row in total])
    (HERE/'flown-sections.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    for key,group in cohorts.items():
        print(key,group['laps'],group['completed'],group['best'],
              {arm:None if evidence is None else (evidence['seconds'],evidence['switches'])
               for arm,evidence in group['schedules'].items()})


if __name__=='__main__':
    main()
