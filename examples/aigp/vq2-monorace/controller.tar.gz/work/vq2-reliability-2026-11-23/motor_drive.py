"""Close the identified motor rate loop below the existing flight controller."""

from collections import deque
from itertools import chain
from math import ceil, exp
from time import monotonic

import numpy as np
from scipy.spatial.transform import Rotation

from miniflight import BodyRates, MotorControls
from miniflight.position import GRAVITY
from miniflight.state import ImuSample
from motor_response import MOTOR_IMU_TIMEOUT, MOTOR_LAG, MOTOR_TRANSPORT


MOTOR_MOTION_TIMEOUT = .16


def predict_motor_state(model, history, start, end, rate, delay, initial):
    """Use the same lagged drive for the gyro forecast and rotor-speed estimate."""
    if not history:
        return rate,initial
    first_time,first_command = history[0]
    time = first_time+delay
    command = first_command if len(history)==history.maxlen else initial
    motor = command
    events = ((sent+delay,outputs) for sent,outputs in history)
    for effect,next_command in chain(events,((end,None),)):
        stop = min(effect,end)
        duration = stop-time
        if duration>0.:
            projected = stop-max(time,start)
            if projected>0.:
                middle = stop-.5*projected
                drive = command+(motor-command)*exp(-(middle-time)/MOTOR_LAG)
                rate = model.hold(drive,rate,projected)
            motor = command+(motor-command)*exp(-duration/MOTOR_LAG)
        if stop>=end:
            break
        time,command = stop,next_command
    return rate,motor


def rotor_samples(history, times, initial):
    """Sample the applied motor inputs from the already-sent motor packets."""
    if not history:
        return np.broadcast_to(initial,(len(times),4))
    events = iter(history)
    sent,following = next(events)
    change = sent+MOTOR_TRANSPORT
    time = min(times[0],change)
    order = following if len(history)==history.maxlen else initial
    motor = order
    samples = []
    for stamp in times:
        while change<=stamp:
            motor = order+(motor-order)*exp(-(change-time)/MOTOR_LAG)
            time,order = change,following
            event = next(events,None)
            change,following = (event[0]+MOTOR_TRANSPORT,event[1]) if event else (np.inf,None)
        motor = order+(motor-order)*exp(-(stamp-time)/MOTOR_LAG)
        time = stamp
        samples.append(motor)
    return np.asarray(samples)


def predict_motor_motion(model, history, start, end, state, acceleration, rate, drag, initial, *, force_memory=.05):
    """Advance the last measured pose using motor history and a decaying force residual."""
    projected = state.copy()
    elapsed = end-start
    if elapsed<=0.:
        return projected,rate,rotor_samples(history,[start],initial)[0]
    intervals = ceil(elapsed/MOTOR_LAG)
    step = elapsed/intervals
    midpoints = (np.arange(intervals)+.5)*step
    motors = rotor_samples(history,start+np.r_[0.,midpoints,elapsed],initial)
    wrench = model.wrench(motors[:-1])
    decay,impulse = model.transfer(step)
    position,velocity = projected[:3],projected[7:10]
    attitude = Rotation.from_quat(projected[3:7])
    local = attitude.inv().apply(velocity)
    residual = acceleration+drag*local*abs(local)+[0.,0.,wrench[0,0]]
    for stamp,force in zip(midpoints,wrench[1:],strict=True):
        after = decay*rate+impulse*model.gain*force[1:]
        half = Rotation.from_rotvec(.25*step*(rate+after))
        middle = attitude*half
        local = middle.inv().apply(velocity)
        body = residual*np.exp(-stamp/force_memory)-drag*local*abs(local)-[0.,0.,force[0]]
        world = middle.apply(body)+[0.,0.,GRAVITY]
        position += step*(velocity+.5*step*world)
        velocity += step*world
        attitude,rate = middle*half,after
    projected[3:7] = attitude.as_quat()
    return projected,rate,motors[-1]


def project_at_control_time(model, client, clock, stamp, state, reading, drag, initial, state_time=None):
    receipt = client.state.rate_feedback.received_at
    start = min(receipt, reading[0]+clock.offset())
    stop = start+max(0., stamp-reading[0])
    rate = reading[4:7]-state[13:16]
    if state_time is not None and state_time > reading[0]:
        exposure = start+state_time-reading[0]
        rate,_ = predict_motor_state(model, client.motor_history, start, exposure, rate, MOTOR_TRANSPORT, initial)
        start = exposure
    return predict_motor_motion(model, client.motor_history, start, stop, state,
                                reading[1:4]-state[10:13], rate, drag, initial)


def install_motor_history(pilot, *, send_to_observer=False):
    class MotorClient(pilot.CourseClient):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.motor_history = deque(maxlen=24)

        def send(self,command):
            result = super().send(command)
            if isinstance(command,MotorControls):
                self.motor_history.append((self.last_send,np.asarray(command.outputs)))
                if send_to_observer:
                    self.queue.put((self.last_send,command))
            return result

    pilot.CourseClient = MotorClient


def motor_gyro_shape(model, history, start, end, query, rate, initial):
    """Recover the rate profile between two samples without changing either endpoint."""
    grid = np.unique(np.r_[0.,query,end-start,np.linspace(0.,end-start,ceil((end-start)/.005)+1)])
    motors = rotor_samples(history,start+.5*(grid[:-1]+grid[1:]),initial)
    prediction = [rate]
    for dt, drive in zip(np.diff(grid),motors,strict=True):
        prediction.append(model.hold(drive,prediction[-1],dt))
    straight = rate + (query/(end-start))[:,None]*(prediction[-1]-rate)
    return np.asarray(prediction)[np.searchsorted(grid,query)]-straight


def motor_imu_observer(base, clock_type, model, initial, counts):
    from rednose_replay import inertial_intervals

    class MotorImuObserver(base):
        def __init__(self,*args,**kwargs):
            super().__init__(*args,**kwargs)
            self.command_clock = clock_type()
            self.sent = deque(maxlen=24)

        def observe(self,host,observation):
            if isinstance(observation,MotorControls):
                self.sent.append((host,np.asarray(observation.outputs)))
                return
            if isinstance(observation,ImuSample):
                self.command_clock.observe(observation.time,host)
            super().observe(host,observation)

        def advance_frame(self,stamp):
            if not self.command_clock.offsets or len(self.sent)<4:
                return super().advance_frame(stamp)
            imu = np.asarray(self.imu)
            offset = self.command_clock.offset()
            for end,reading,gap in inertial_intervals(self.filter.filter_time,stamp,imu):
                middle = .5*(reading[0]+end)
                if .055<=gap<=.085:
                    upper = np.searchsorted(imu[:,0],middle)
                    left,right = imu[upper-1:upper+1]
                    if self.sent[0][0] <= left[0]+offset-.10:
                        query = np.linspace(reading[0],end,7)[1::2]-left[0]
                        bias = self.filter.x[13:16,0]
                        shape = motor_gyro_shape(model,self.sent,left[0]+offset,right[0]+offset,query,
                                                 left[4:7]-bias,initial)
                        reading[4:7] += shape.mean(axis=0)
                        counts['conditioned_imu_intervals'] = counts.get('conditioned_imu_intervals',0)+1
                self.filter.move(end,reading,imu_gap=gap)

    return MotorImuObserver


def motor_pose_target(gain, acceleration, velocity, angles, nominal, rates, drag, tilt, maximum):
    """Match the requested acceleration within the measured thrust cone."""
    from planned_launch import pose_rate

    observed = Rotation.from_euler("xyz",angles)
    local = observed.inv().apply(velocity)
    force = np.array([0.,0.,GRAVITY])-acceleration-observed.apply(drag*local*abs(local))
    up = float(np.clip(force[2],0.,maximum))
    lateral = min(up*np.tan(tilt),np.sqrt(max(0.,maximum**2-up**2)))
    force[:2] *= min(1.,lateral/max(1.e-9,np.linalg.norm(force[:2])))
    force[2] = up
    return pose_rate(observed,nominal,force,rates,gain),max(0.,force@observed.as_matrix()[:,2])


def drive_variants(pilot, motors, rate_limits, upper, axial_drag, stats, envelope=None, schedule=None):
    install_motor_history(pilot)
    baseline = pilot.FollowCourse
    initial = np.zeros(4)
    maximum = motors.wrench(np.full(4,upper))[0]
    grounded_start = schedule is not None and envelope is not None and envelope.get("grounded_start", False)
    if envelope is not None:
        maximum = min(maximum,envelope["collective_m_s2"])

    class MotorPilot(baseline):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.action_clock.command_delay = MOTOR_TRANSPORT
            self.action_clock.max_projection = MOTOR_MOTION_TIMEOUT
            self.launch_down = None
            self.schedule_airborne = False
            self.drag = np.array([*(self.config.body_resistance_per_m or (0.,0.,0.))[:2], axial_drag])
            if envelope is not None:
                self.drag = np.asarray(envelope["drag_per_m"])

        def predict_action(self, client, state, reading, now):
            if not client.motor_history:
                return super().predict_action(client, state, reading, now)
            forecast, self.predicted_rate, self.predicted_rotors = project_at_control_time(
                motors, client, self.action_clock, self.control_stamp, state, reading, self.drag, initial)
            stats['motor_motion_predictions'] += 1
            return forecast

        def predict_camera_action(self, client, reading, camera, host_now):
            if not client.motor_history:
                return super().predict_camera_action(client, reading, camera, host_now)
            forecast, self.predicted_rate, self.predicted_rotors = project_at_control_time(
                motors, client, self.action_clock, self.control_stamp, camera[1][:16], reading, self.drag,
                initial, state_time=camera[0])
            stats['early_motor_estimates'] += 1
            return forecast

        def update(self,telemetry,frames,race):
            self.predicted_rate = None
            self.predicted_rotors = None
            command = super().update(telemetry,frames,race)
            if not isinstance(command,BodyRates) or command.thrust<=0.:
                return command
            throttle = command.thrust
            if self.config.thrust_curve is None:
                force = GRAVITY+self.config.thrust_acceleration*(throttle-self.config.hover_thrust)
            else:
                linear, quadratic = self.config.thrust_curve
                force = throttle*(linear+quadratic*throttle)
            motor = self.motor_command((command.roll_rate, command.pitch_rate, command.yaw_rate),force)
            return command if motor is None and envelope is None else motor

        def pose_command(self, request, velocity, angles, nominal, feedthrough, allocate):
            from planned_launch import pose_target

            if grounded_start and not self.schedule_airborne:
                client = self.client()
                attitude = Rotation.from_euler('xyz',angles)
                lift = GRAVITY/max(.1, attitude.as_matrix()[2,2])
                stationary = motors.motors(lift, np.zeros(3))
                fill = np.minimum(upper, stationary/(1.-exp(-2.5)))
                upward = -attitude.apply(client.history[-1][1:4]-client.prediction.state[10:13])[2]-GRAVITY
                force = 0. if self.predicted_rotors is None else motors.wrench(self.predicted_rotors)[0]
                if force < lift or upward <= 0.:
                    if client.motor_history and monotonic()-client.motor_history[0][0] > .35:
                        raise TimeoutError('Ground launch did not confirm lift')
                    return self.motor_command(np.zeros(3), motors.wrench(fill)[0], fill)
                self.schedule_airborne = True
                self.action_clock.command_delay = 0.
                stats['ground_release'] = [float(self.pose_phase), float(upward), float(force)]

            output = None
            if schedule is not None and self.schedule_airborne and self.predicted_rotors is not None:
                from trajectory_feedback import scheduled_command

                client = self.client()
                attitude = Rotation.from_euler('xyz',angles).as_quat()
                state = np.concatenate((self.planned_state[0],velocity,attitude,self.predicted_rate,
                                        self.predicted_rotors,client.motor_history[-1][1]))
                desired = np.concatenate((*self.pose_motion,nominal.as_quat(),feedthrough))
                output = scheduled_command(schedule,self.pose_phase,state,desired,upper)
                rate,force = feedthrough,motors.wrench(output)[0]
            elif envelope is None:
                rate,force = pose_target(self.config,request,velocity,angles,nominal,feedthrough,
                                         body_drag=self.body_drag,climb_thrust=self.climb_thrust,lift=self.measured_lift)
            else:
                rate,force = motor_pose_target(self.config.attitude_gain,request,velocity,angles,nominal,
                                               feedthrough,self.drag,envelope["tilt_rad"],maximum)
            command = self.motor_command(rate,force,output)
            if command is not None:
                stats['pose_motor_commands'] = stats.get('pose_motor_commands',0)+1
                stats['scheduled_commands'] += int(output is not None)
                if envelope is not None:
                    position = self.planned_state[0]
                    stats['pose_samples'].append((stats['targets'][-1][0],self.pose_phase,*position,*velocity,*angles))
                    if schedule is not None and not self.schedule_airborne:
                        from rim import CHASSIS_RADIUS

                        if self.launch_down is None:
                            self.launch_down = position[2]
                        rise = self.launch_down-position[2]
                        if (rise>=CHASSIS_RADIUS and self.predicted_rotors is not None
                                and np.all(self.predicted_rotors>motors.idle)):
                            self.schedule_airborne = True
                            self.action_clock.command_delay = 0.
                            stats['schedule_lift_off'] = [float(self.pose_phase),float(rise)]
                return command
            if envelope is None:
                return super().pose_command(request,velocity,angles,nominal,feedthrough,allocate)

        def motor_command(self, target, force, output=None):
            client = self.client()
            feedback = client.state.rate_feedback
            if feedback is None or not self.action_clock.offsets:
                return None
            now = monotonic()
            age = now-feedback.received_at
            stats['max_receipt_age_s'] = max(age,stats['max_receipt_age_s'])
            freshness = MOTOR_MOTION_TIMEOUT if self.predicted_rate is not None else MOTOR_IMU_TIMEOUT
            if not 0.<=age<=freshness:
                stats['aged_samples'] += 1
                if client.motor_history:
                    raise TimeoutError('Motor control lost fresh gyro feedback')
                return None
            if age>MOTOR_IMU_TIMEOUT:
                stats['bridged_imu_ticks'] += 1
            rate = self.predicted_rate
            if rate is None:
                rate = np.asarray(feedback.gyro)-client.prediction.state[13:16]
            target = np.clip(target, -rate_limits, rate_limits)
            force = np.clip(force, 0., maximum)
            if output is None:
                output = motors.rate_command(force, rate, target, .10, upper)
            else:
                wrench = motors.wrench(output)
                if wrench[0]>maximum:
                    output = motors.motors(maximum,wrench[1:]*(maximum/wrench[0]))
            output = motors.limit_rate_support(output, rate_limits, rate, MOTOR_IMU_TIMEOUT)
            stats['motors'] += 1
            stats['targets'].append((now,*target,float(force),*rate,*output))
            return MotorControls(tuple(map(float, output)))

    return baseline,MotorPilot
