"""Replay a saved pilot configuration on stock VQ2 with a fresh results directory."""
from argparse import ArgumentParser
from functools import partial
from hashlib import file_digest
from importlib.util import module_from_spec, spec_from_file_location
import json
import os
from pathlib import Path
import shutil
import sys
from time import perf_counter
import numpy as np


def verify(path, expected):
    with path.open('rb') as stream:
        if file_digest(stream, 'sha256').hexdigest() != expected:
            raise ValueError(f'Archived input hash changed for {path}')


def load_module(name, path):
    spec = spec_from_file_location(name, path)
    module = module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main():
    here = Path(__file__).resolve().parent
    checkpoint = here.parent / 'checkpoints/vq2-2026-11-23'
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('native_lap', type=int)
    parser.add_argument('out', type=Path)
    parser.add_argument('--laps', type=int, default=6)
    parser.add_argument('--wait-for-race', action='store_true')
    parser.add_argument('--capture-camera', action='store_true')
    parser.add_argument('--capture-camera-window', action='store_true')
    parser.add_argument('--plan', type=Path)
    comparison = parser.add_mutually_exclusive_group()
    comparison.add_argument('--compare-launch-preview', action='store_true')
    comparison.add_argument('--compare-direct-launch', action='store_true')
    comparison.add_argument('--compare-blended-launch', action='store_true')
    comparison.add_argument('--compare-command-projection', action='store_true')
    comparison.add_argument('--compare-action-clock-limit', action='store_true')
    comparison.add_argument('--compare-plane-progress', action='store_true')
    comparison.add_argument('--compare-horizon-tracker', action='store_true')
    comparison.add_argument('--compare-camera-batch', action='store_true')
    comparison.add_argument('--compare-imu-gap', action='store_true')
    comparison.add_argument('--compare-imu-interpolation', action='store_true')
    comparison.add_argument('--compare-causal-camera', action='store_true')
    comparison.add_argument('--compare-crossing-bracket', action='store_true')
    comparison.add_argument('--repeat-crossing-bracket', action='store_true')
    comparison.add_argument('--compare-rate-horizon', action='store_true')
    comparison.add_argument('--compare-flown-continuation', type=Path)
    comparison.add_argument('--compare-camera-force', action='store_true')
    comparison.add_argument('--compare-rate-force-budget', type=Path)
    comparison.add_argument('--compare-body-drag', action='store_true')
    comparison.add_argument('--compare-terminal-tracking', type=Path)
    comparison.add_argument('--compare-linked-apertures', action='store_true')
    comparison.add_argument('--compare-climb-limit', type=Path)
    comparison.add_argument('--compare-measured-lift', type=Path)
    comparison.add_argument('--compare-held-rates', action='store_true')
    comparison.add_argument('--compare-experience-pose', type=Path)
    comparison.add_argument('--compare-attitude', action='store_true')
    comparison.add_argument('--compare-plan', type=Path)
    comparison.add_argument('--compare-occlusion', action='store_true')
    comparison.add_argument('--compare-observer', action='store_true')
    comparison.add_argument('--compare-vision-schedule', action='store_true')
    comparison.add_argument('--compare-thrust', type=Path)
    comparison.add_argument('--compare-gate-translation', action='store_true')
    comparison.add_argument('--compare-mapped-rim', action='store_true')
    comparison.add_argument('--compare-recovery-distance', action='store_true')
    comparison.add_argument('--compare-action-clock', action='store_true')
    comparison.add_argument('--compare-reference-projection', action='store_true')
    comparison.add_argument('--compare-crossing-correction', action='store_true')
    comparison.add_argument('--compare-predicted-crossing', action='store_true')
    comparison.add_argument('--compare-rate-allocation', action='store_true')
    comparison.add_argument('--probe-collective', action='store_true')
    comparison.add_argument('--probe-pitch-authority', action='store_true')
    comparison.add_argument('--probe-motor-authority', nargs='?', const='pitch',
                            choices=('pitch','axes-low','axes','axes-high','envelope'))
    comparison.add_argument('--probe-motor-feedback', type=Path)
    comparison.add_argument('--compare-motor-drive', type=Path)
    comparison.add_argument('--motor-drive', type=Path, help='Run only the fitted direct motor controller')
    comparison.add_argument('--monorace-policy', type=Path)
    parser.add_argument('--monorace-airborne-policy', type=Path)
    parser.add_argument('--monorace-vision', action='store_true')
    parser.add_argument('--monorace-partial-bearing', action='store_true')
    parser.add_argument('--monorace-gatenet', type=Path)
    apertures = parser.add_mutually_exclusive_group()
    apertures.add_argument('--compare-aperture-anchor', action='store_true')
    apertures.add_argument('--aperture-anchor', action='store_true')
    apertures.add_argument('--bounded-aperture-anchor', action='store_true')
    parser.add_argument('--monorace-motor-motion', type=Path, help='Predict motion using the motor and measured drag model')
    parser.add_argument('--monorace-imu-bridge-s', type=float)
    parser.add_argument('--monorace-angular-fit', type=Path)
    parser.add_argument('--monorace-imu-wait', action='store_true')
    parser.add_argument('--monorace-imu-interpolation', action='store_true')
    parser.add_argument('--monorace-transport-lead', action='store_true')
    parser.add_argument('--monorace-hz', type=float)
    gate_switch = parser.add_mutually_exclusive_group()
    gate_switch.add_argument('--monorace-gate-switch', choices=('delayed','confirmed','firmware'), default='delayed')
    gate_switch.add_argument('--monorace-firmware-cursor', dest='monorace_gate_switch',
                             action='store_const', const='firmware')
    parser.add_argument('--motor-early-camera', action='store_true')
    parser.add_argument('--action-clock', action='store_true')
    parser.add_argument('--only-extend-clipped', action='store_true')
    parser.add_argument('--thrust-priority', action='store_true')
    parser.add_argument('--planned-launch', action='store_true')
    parser.add_argument('--direct-pose', action='store_true')
    parser.add_argument('--trpy-trial', action='store_true')
    parser.add_argument('--trpy-continuous-phase', action='store_true')
    parser.add_argument('--body-axis-drag', action='store_true')
    parser.add_argument('--terminal-feedback', type=Path)
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--resume-reference', nargs='?', choices=('matching', 'joint'), const='matching',
                        help='Resume continuous practice after the batch, optionally with the joint reference')
    args = parser.parse_args()
    if args.planned_launch and not (args.plan and args.thrust_priority and args.action_clock):
        parser.error('--planned-launch requires --plan, --thrust-priority and --action-clock')
    if args.direct_pose and not args.planned_launch:
        parser.error('--direct-pose requires --planned-launch')
    if args.trpy_trial and not args.direct_pose:
        parser.error('--trpy-trial requires --direct-pose')
    if args.trpy_continuous_phase and not args.trpy_trial:
        parser.error('--trpy-continuous-phase requires --trpy-trial')
    if (args.compare_rate_force_budget is not None or args.compare_body_drag or args.body_axis_drag) and not args.direct_pose:
        parser.error('Actuator comparisons require --direct-pose')
    if (args.terminal_feedback or args.compare_terminal_tracking or args.compare_climb_limit) and not args.direct_pose:
        parser.error('Terminal tracking requires --direct-pose')
    if args.compare_measured_lift and not args.direct_pose:
        parser.error('The measured lift comparison requires --direct-pose')
    if args.compare_held_rates and not args.direct_pose:
        parser.error('The held-rate comparison requires --direct-pose')
    if (args.compare_direct_launch or args.compare_blended_launch) and not args.direct_pose:
        parser.error('The launch actuation comparison requires --direct-pose')
    if args.terminal_feedback and (args.compare_terminal_tracking or args.compare_climb_limit):
        parser.error('Select either constant terminal feedback or a comparison that varies it')
    if args.compare_linked_apertures and not args.terminal_feedback:
        parser.error('The linked-aperture comparison requires --terminal-feedback')
    motor_model = args.motor_drive or args.compare_motor_drive
    anchor_enabled = args.compare_aperture_anchor or args.aperture_anchor or args.bounded_aperture_anchor
    if anchor_enabled and not (args.motor_drive or args.monorace_policy or args.trpy_trial):
        parser.error('Aperture anchoring requires direct motor, MonoRace or TRPY trial control')
    if args.compare_aperture_anchor and not args.motor_drive:
        parser.error('The alternating aperture comparison requires --motor-drive')
    if motor_model and not (args.action_clock and args.thrust_priority and args.plan):
        parser.error('Motor feedback requires the bound plan and action clock')
    if args.motor_early_camera and not (args.motor_drive or args.monorace_motor_motion):
        parser.error('Early camera projection requires direct motor motion prediction')
    direct_reference = None
    if args.plan:
        with np.load(args.plan,allow_pickle=False) as plan:
            if 'direct_motor' in plan:
                direct_reference = json.loads(str(plan['direct_motor']))
    if direct_reference is not None:
        if not args.motor_drive or not args.direct_pose:
            parser.error('This trajectory requires --motor-drive and --direct-pose')
        verify(args.motor_drive,direct_reference['response_sha256'])
        resistance = np.asarray(direct_reference['drag_per_m'],dtype=float)
        tilt,collective = (float(direct_reference[key]) for key in ('tilt_rad','collective_m_s2'))
        if (resistance.shape!=(3,) or not np.isfinite(resistance).all() or (resistance<0.).any()
                or not 0.<tilt<np.pi/2 or not 0.<collective<float('inf')):
            parser.error('The bound direct motor trajectory needs a finite flight envelope')
    if args.monorace_policy and not (args.action_clock and args.thrust_priority and args.plan):
        parser.error('G&CNet needs the bound map and projected visual-inertial state')
    if args.monorace_airborne_policy and not args.monorace_policy:
        parser.error('--monorace-airborne-policy requires the launch G&CNet policy')
    if args.monorace_motor_motion and not args.monorace_policy:
        parser.error('--monorace-motor-motion requires a G&CNet policy')
    if args.monorace_vision and not (args.monorace_policy or args.trpy_trial):
        parser.error('--monorace-vision requires G&CNet or a TRPY trial')
    if args.monorace_gatenet and not args.monorace_vision:
        parser.error('--monorace-gatenet requires --monorace-vision')
    if args.monorace_partial_bearing and not args.monorace_vision:
        parser.error('--monorace-partial-bearing requires --monorace-vision')
    if args.monorace_angular_fit and not args.monorace_motor_motion:
        parser.error('--monorace-angular-fit requires motor-motion prediction')
    if args.monorace_gate_switch != 'delayed' and not args.monorace_policy:
        parser.error('MonoRace gate switching requires a G&CNet policy')
    if args.monorace_imu_wait and not args.monorace_policy:
        parser.error('--monorace-imu-wait requires a G&CNet policy')
    if args.monorace_imu_interpolation and not (args.monorace_policy and args.motor_early_camera):
        parser.error('Motor-conditioned IMU interpolation requires G&CNet and --motor-early-camera')
    if args.monorace_transport_lead and not args.monorace_motor_motion:
        parser.error('--monorace-transport-lead requires motor-motion prediction')
    if args.monorace_hz is not None and (not args.monorace_policy or not 0. < args.monorace_hz < 100.):
        parser.error('--monorace-hz requires G&CNet and must be above zero and below 100 Hz')
    if args.monorace_imu_bridge_s is not None and (not args.monorace_motor_motion or not
                                                   .16<=args.monorace_imu_bridge_s<=.24):
        parser.error('The measured MonoRace bridge needs motor prediction and a window of 0.16–0.24 s')
    horizon_study=args.compare_rate_horizon or args.compare_flown_continuation is not None or args.compare_camera_force
    crossing_study=args.compare_crossing_bracket or args.repeat_crossing_bracket or horizon_study
    if args.compare_action_clock and args.action_clock:
        parser.error('The clock comparison requires the original controller in one arm')
    if (args.compare_command_projection or args.compare_action_clock_limit) and not args.action_clock:
        parser.error('The command projection comparison requires --action-clock')
    if args.only_extend_clipped and not args.compare_action_clock_limit:
        parser.error('The clipped-only variant requires --compare-action-clock-limit')
    if args.compare_plane_progress and not args.action_clock:
        parser.error('The plane progress comparison requires --action-clock')
    if args.compare_horizon_tracker and not args.action_clock:
        parser.error('The horizon tracker comparison requires --action-clock')
    if args.compare_experience_pose and not (args.action_clock and args.thrust_priority and args.plan):
        parser.error('The experience pose comparison requires --action-clock, --thrust-priority and --plan')
    if args.compare_imu_interpolation and not (args.action_clock and args.thrust_priority and args.plan):
        parser.error('The IMU interpolation comparison requires the projected geometric controller')
    if (args.compare_causal_camera or crossing_study) and not (args.action_clock and args.thrust_priority and args.plan):
        parser.error('The causal camera comparison requires the projected geometric controller')
    if (args.compare_crossing_correction or args.compare_predicted_crossing) and not args.action_clock:
        parser.error('Use --action-clock to compare against the current racing controller')
    if args.compare_rate_allocation and not args.thrust_priority:
        parser.error('The rate allocation comparison requires the joint attitude controller')
    if (args.probe_collective or args.probe_pitch_authority or args.probe_motor_authority or args.probe_motor_feedback) and (
            not args.action_clock or not args.plan or not 0 < args.laps <= 16):
        parser.error('The collective probe requires --plan, --action-clock and a finite batch of at most 16 laps')
    if (args.compare_attitude or args.compare_plan or args.thrust_priority) and not args.plan:
        parser.error('Specify the reference trajectory with --plan')
    if args.resume_reference and args.laps <= 0:
        parser.error('--resume-reference requires a finite batch')
    spec = spec_from_file_location('frozen_vq2', checkpoint / 'controller/run.py')
    ck = module_from_spec(spec)
    sys.modules[spec.name] = ck
    spec.loader.exec_module(ck)
    frozen = json.loads((checkpoint / 'controller/checkpoint.json').read_text())
    ck.verify(frozen)

    lap = checkpoint / 'native' / f'practice-{args.native_lap}'
    manifest = json.loads((lap / 'manifest.json').read_text())
    inputs = args.out.resolve() / 'archived-inputs'
    inputs.mkdir(parents=True, exist_ok=True)
    binding = {**manifest['inputs'], 'gate-map-in': manifest['observer_map']}
    for key, item in binding.items():
        original = Path(item['path'])
        source = lap / 'gate-map-in.json' if key == 'gate-map-in' else checkpoint / 'native/inputs' / original.parent.name / original.name
        verify(source, item['sha256'])
        copy = inputs / (key + source.suffix)
        if not copy.exists():
            shutil.copyfile(source, copy)
        verify(copy, item['sha256'])
    if args.plan:
        with np.load(args.plan,allow_pickle=False) as plan:
            if 'observer_map_sha256' in plan:
                verify(inputs/'gate-map-in.json',str(plan['observer_map_sha256']))

    calibration = next((data for path in sorted(lap.glob('*trial.json'))
                        if {'collective', 'correction'} <= (data := json.loads(path.read_text())).keys()),
                       {'collective': 0., 'correction': 0.})
    configuration = {**frozen, 'pace_m_s': manifest['pace_m_s'],
                     'collective_strength': calibration['collective'],
                     'acceleration_feedback': calibration['correction']}
    race_source = here.parent.parent / 'target/aigp/experiments/public_race.py'
    public_race = load_module('practice_public_race', race_source)
    ck.practice.PublicRace = public_race.PublicRace
    if args.monorace_hz is not None:
        ck.practice.AIGPSimulator = partial(ck.practice.AIGPSimulator,hz=args.monorace_hz)
    ck.practice.watch_timing = load_module('practice_timing_reader', race_source.with_name('practice_timing.py')).watch_timing
    if args.capture_camera_window:
        from camera_capture import capture_rollout

        ck.practice.stock_rollout = capture_rollout(ck.practice.stock_rollout)
        args.out.mkdir(parents=True,exist_ok=True)
        ck.practice.write_json(args.out.resolve()/'camera-window-source.json',
                               {'sha256':ck.practice.digest(here/'camera_capture.py')})
    if args.monorace_imu_wait:
        from motor_drive import MOTOR_MOTION_TIMEOUT
        from motor_response import MOTOR_IMU_TIMEOUT

        stock_rollout = ck.practice.stock_rollout
        feedback_age = MOTOR_IMU_TIMEOUT
        if args.monorace_motor_motion:
            feedback_age = args.monorace_imu_bridge_s or MOTOR_MOTION_TIMEOUT

        def guarded_rollout(*options, timeout, **settings):
            return stock_rollout(*options, timeout=min(timeout,feedback_age), **settings)

        ck.practice.stock_rollout = guarded_rollout
    if (args.capture_camera or args.plan or args.port != 8765 or args.compare_observer
            or args.compare_vision_schedule or args.compare_thrust or args.compare_gate_translation
            or args.compare_action_clock or args.action_clock or args.compare_reference_projection
            or args.compare_mapped_rim or args.compare_recovery_distance or args.compare_launch_preview
            or args.compare_camera_batch or args.compare_imu_gap or args.compare_occlusion):
        practice_main = ck.practice.main

        def run_with_options(arguments, **kwargs):
            arguments.extend(('--port', str(args.port)))
            if args.plan:
                arguments[arguments.index('--plan') + 1] = str(args.plan.resolve())
            if args.capture_camera:
                arguments.append('--capture-camera')
            if args.thrust_priority:
                with np.load(args.plan, allow_pickle=False) as plan:
                    if not bool(plan.get('geometric_control', False)):
                        raise ValueError('Thrust priority requires a joint attitude plan')
                source = here.parent.parent / 'miniflight/position.py'
                controller = load_module('trial_position', source)
                sys.modules['inverse'].acceleration_control = controller.acceleration_control
                ck.practice.write_json(args.out.resolve()/'attitude-source.json',
                                       {'path': str(source), 'sha256': ck.practice.digest(source)})
            if args.compare_attitude:
                source = args.plan.resolve()
                euler = args.out.resolve() / 'same-plan-euler.npz'
                with np.load(source, allow_pickle=False) as archive:
                    data = dict(archive)
                if not bool(data.get('geometric_control', False)):
                    raise ValueError('Expected a geometric controller plan')
                np.savez_compressed(euler, **(data | {'geometric_control': np.array(False)}))
                kwargs['evolution_type'] = matched_plans(ck.practice, kwargs['evolution_type'],
                                                          (euler, source), ('euler', 'geometric'), 'tracker')
            if args.compare_plan:
                kwargs['evolution_type'] = matched_plans(
                    ck.practice, kwargs['evolution_type'], (args.plan.resolve(), args.compare_plan.resolve()),
                    ('reference', 'candidate'), 'plan_arm')
            if args.compare_occlusion:
                pilot = ck.practice.pilot_module()
                source = here.parent/'pose-odometry'/'rednose_replay.py'
                batched = load_module('trial_gate_occlusion', source)
                def select(i, updates=(pilot.gate_update, batched.gate_update)):
                    pilot.gate_update = updates[i]
                ck.practice.write_json(args.out.resolve()/'occlusion-source.json', {'sha256':ck.practice.digest(source)})
                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                    ('scalar', 'batched'), 'occlusion')
            if args.compare_observer or args.compare_vision_schedule or args.compare_gate_translation:
                pilot = ck.practice.pilot_module()
                baseline = pilot.CourseClient.observer_type
                observers = (pilot.CourseObserver, baseline)
                names = ('original', 'checkpoint')
                if args.compare_vision_schedule:
                    source = here.parent / 'pose-odometry' / 'fly_rednose.py'
                    observers = scheduled_observers(baseline, source)
                    names = ('scene-first', 'gate-first')
                if args.compare_gate_translation:
                    observers = (baseline, gate_translation_observer(baseline, pilot.CoursePoseFilter))
                    names = ('checkpoint', 'gate-translation')
                select = lambda i: setattr(pilot.CourseClient, 'observer_type', observers[i])
                kwargs['evolution_type'] = matched_variants(
                    ck.practice, kwargs['evolution_type'], select, names, 'observer')
            if args.compare_camera_batch:
                pilot = ck.practice.pilot_module()
                source = here.parent/'pose-odometry'/'fly_rednose.py'
                observer = load_module('trial_camera_batch', source).Observer
                counts = {}

                class ReadyFrames(pilot.CourseClient.observer_type):
                    ready_frame_limit = 1
                    visual_updates = observer.visual_updates

                    def correct_ready_frames(self):
                        paired = len(self.frames)>1 and self.capture_time(self.frames[1])<=self.imu[-1][0]
                        before = len(self.camera_stats)
                        observer.correct_ready_frames(self)
                        counts['paired_batches'] += int(paired)
                        counts['processed_pairs'] += int(len(self.camera_stats)-before>1)

                class TwoReadyFrames(ReadyFrames):
                    ready_frame_limit = 2

                def select(i):
                    pilot.CourseClient.observer_type = (ReadyFrames, TwoReadyFrames)[i]
                    counts.update(paired_batches=0, processed_pairs=0)

                ck.practice.write_json(args.out.resolve()/'camera-batch-source.json', {'sha256':ck.practice.digest(source)})
                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                    ('one-frame', 'two-frames'), 'camera_batch', lambda:dict(counts))
            if args.compare_imu_interpolation:
                from command_projection import CommandProjection
                from response_observer import observer_variants

                pilot = ck.practice.pilot_module()
                directory = here.parent/'pose-odometry'
                source, clock = directory/'fly_rednose.py', directory/'actuation_clock.py'
                observer = load_module('trial_response_source', source).Observer
                clock_type = load_module('trial_response_clock', clock).ActuationClock
                rates, force = here/'rate-authority.json', here/'force-model-holdout.json'
                fitted = here/'imu-interpolation-holdout.json'
                holdout = json.loads(fitted.read_text())
                used = rates, force, here/'response_observer.py', here/'command_projection.py'
                if any(ck.practice.digest(p)!=holdout['source_model_sha256'][p.name] for p in used):
                    raise ValueError('The interpolation model differs from the withheld-sample test')
                model = CommandProjection(json.loads(rates.read_text())['axes'], json.loads(force.read_text()))
                counts = {}
                client, observers = observer_variants(pilot.CourseClient, observer, clock_type, model,
                    holdout['fitted_gyro_thrust_gain'], counts)
                pilot.CourseClient = client

                def select(i):
                    client.observer_type = observers[i]
                    counts.update(conditioned_intervals=0, conditioned_frames=0)

                ck.practice.write_json(args.out.resolve()/'imu-interpolation-sources.json', {
                    str(p):ck.practice.digest(p) for p in (source,clock,fitted,*used)})
                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                    ('linear', 'command-conditioned'), 'imu_interpolation', lambda:dict(counts))
            if args.compare_causal_camera or crossing_study or args.motor_early_camera or args.trpy_trial:
                from fly_rednose import VisionClient

                pilot = ck.practice.pilot_module()
                source = here.parent/'pose-odometry'/'fly_rednose.py'
                code = load_module('trial_causal_camera',source)
                active = {}

                class Bracketed(pilot.CourseClient.observer_type):
                    ready_frame_limit = 1
                    camera_prediction_limit = 0.
                    camera_ahead_frames = 0
                    early_control_requests = 0
                    correct_ready_frames = code.Observer.correct_ready_frames
                    visual_updates = code.Observer.visual_updates
                    advance_frame = code.Observer.advance_frame

                    def __init__(self,*args,**kwargs):
                        super().__init__(*args,**kwargs)
                        self.snapshots = ()
                        active['observer'] = self

                    def publish(self):
                        super().publish()
                        self.snapshots = (*self.snapshots[-7:], self.snapshot)

                class ForwardCamera(Bracketed):
                    camera_prediction_limit = .055

                class CameraClockClient(pilot.CourseClient):
                    fuse_packets = code.VisionClient.fuse_packets

                    def read(self,timeout=1.):
                        return self.fuse_packets(super(VisionClient,self).read(timeout))

                pilot.CourseClient = CameraClockClient

                def select(i):
                    CameraClockClient.observer_type = (Bracketed,ForwardCamera)[i]
                    active.clear()

                def camera_counts():
                    observer = active.get('observer')
                    return dict(ahead_frames=getattr(observer,'camera_ahead_frames',0),
                                early_control_requests=getattr(observer,'early_control_requests',0))

                ck.practice.write_json(args.out.resolve()/'causal-camera-sources.json', {
                    str(p):ck.practice.digest(p) for p in (source,source.with_name('actuation_clock.py'),Path(__file__))})
                if args.compare_causal_camera:
                    kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                        ('bracketed', 'causal'), 'causal_camera', camera_counts)
                else:
                    select(1)
            if args.compare_imu_gap:
                pilot = ck.practice.pilot_module()
                source = here.parent/'pose-odometry'/'fly_rednose.py'
                module = load_module('trial_imu_gap', source)
                baseline = pilot.CourseClient.observer_type
                module.NoVisualAnchor = baseline.observe.__globals__['NoVisualAnchor']
                counts = {}

                class FixedGap(baseline):
                    gap_periods = 0.
                    ready_frame_limit = 2
                    observe = module.Observer.observe
                    initialize = module.Observer.initialize
                    visual_updates = module.Observer.visual_updates

                    def __init__(self, *args, **kwargs):
                        super().__init__(*args, **kwargs)
                        self.imu_gap_limit = .07

                    def correct_ready_frames(self):
                        before = len(self.camera_stats)
                        module.Observer.correct_ready_frames(self)
                        measured = self.camera_stats[before:]
                        counts['frames'] += len(measured)
                        counts['imu_gap_frames'] += int(sum(row[0]<self.gap_until for row in measured))
                        counts['gap_limit_s'] = self.imu_gap_limit

                class CadenceGap(FixedGap):
                    gap_periods = 2.

                def select(i):
                    pilot.CourseClient.observer_type = (FixedGap, CadenceGap)[i]
                    counts.update(frames=0, imu_gap_frames=0, gap_limit_s=None)

                ck.practice.write_json(args.out.resolve()/'imu-gap-source.json', {
                    'sha256':ck.practice.digest(source), 'ready_frame_limit':FixedGap.ready_frame_limit})
                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                    ('fixed-gap', 'cadence-gap'), 'imu_gap', lambda:dict(counts))
            if args.compare_mapped_rim:
                pilot = ck.practice.pilot_module()
                baseline = pilot.CourseClient.observer_type
                source = here.parent/'pose-odometry/fly_learned_course.py'
                observer = load_module('trial_mapped_rim', source).CourseObserver
                counters = {}

                class MappedRim(baseline):
                    gate_measurements = observer.gate_measurements

                    def recover_position(self, stamp, index, outlines, gates, partials=(), outer=None):
                        error = super().recover_position(stamp, index, outlines, gates, partials, outer)
                        if outer is not None and index not in self.identity_bounds:
                            counters['outer_offers'] += 1
                            counters['outer_updates'] += int(error is not None)
                            counters['outer_support'] += int(error is not None and error <= 3.)
                        return error

                def select(i):
                    pilot.CourseClient.observer_type = (baseline, MappedRim)[i]
                    counters.update(outer_offers=0, outer_updates=0, outer_support=0)

                ck.practice.write_json(args.out.resolve()/'mapped-rim-source.json', {'sha256': ck.practice.digest(source)})
                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                                                           ('reference', 'mapped-rim'), 'observer', lambda: dict(counters))
            if args.compare_recovery_distance:
                pilot = ck.practice.pilot_module()
                baseline = pilot.CourseClient.observer_type
                source = here.parent/'pose-odometry/fly_learned_course.py'
                observer = load_module('trial_recovery_distance', source).CourseObserver
                counters = {}
                response_s = .21

                class MeasuredRecovery(baseline):
                    recovery_response_s = None

                    def recover_position(self, stamp, index, outlines, gates, partials=(), outer=None):
                        if not partials and outer is None:
                            center, plane = self.course[index]
                            remaining = (center-self.filter.x[:3, 0]) @ plane.apply([1., 0., 0.])
                            counters['full_offers'] += 1
                            result = observer.recover_position(self, stamp, index, outlines, gates)
                            if result is not None:
                                counters['full_updates'] += 1
                                counters['updates_inside_5m'] += int(remaining <= 5.)
                            return result
                        return super().recover_position(stamp, index, outlines, gates, partials, outer)

                def select(i):
                    MeasuredRecovery.recovery_response_s = response_s if i else None
                    pilot.CourseClient.observer_type = MeasuredRecovery
                    counters.update(full_offers=0, full_updates=0, updates_inside_5m=0)

                ck.practice.write_json(args.out.resolve()/'recovery-distance-source.json', {
                    'sha256': ck.practice.digest(source), 'response_s': response_s})
                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                                                           ('five-metres', 'reaction-distance'), 'observer', lambda: dict(counters))
            if args.compare_thrust:
                response = json.loads(args.compare_thrust.read_text())
                coef = np.asarray(response['coefficients'], float)
                if coef.shape != (8,) or not np.isfinite(coef).all() or response['lag_s'] != 0:
                    raise ValueError('Expected a finite static eight-coefficient thrust model')
                inverse = sys.modules['inverse']
                models = (inverse.C, coef.tolist())
                select = lambda i: setattr(inverse, 'C', models[i])
                ck.practice.write_json(args.out.resolve()/'thrust-models.json',
                                       {'archive': models[0], 'refitted': models[1],
                                        'source_sha256': ck.practice.digest(args.compare_thrust)})
                kwargs['evolution_type'] = matched_variants(
                    ck.practice, kwargs['evolution_type'], select, ('archive', 'refitted'), 'thrust')
            if args.compare_action_clock or args.action_clock:
                pilot = ck.practice.pilot_module()
                source = here.parent / 'pose-odometry'
                variants = (pilot.FollowCourse, action_clock_pilot(pilot, source))
                ck.practice.write_json(args.out.resolve()/'action-clock-sources.json', {
                    name: ck.practice.digest(source / name)
                    for name in ('actuation_clock.py', 'fly_learned_course.py')})
                if args.compare_action_clock:
                    select = lambda i: setattr(pilot, 'FollowCourse', variants[i])
                    kwargs['evolution_type'] = matched_variants(
                        ck.practice, kwargs['evolution_type'], select, ('observed', 'projected'), 'action-clock')
                else:
                    pilot.FollowCourse = variants[1]
            if args.probe_collective or args.probe_pitch_authority or args.probe_motor_authority or args.probe_motor_feedback:
                from collective_authority import HOLD, LEVELS, MOTOR_AXES, MOTOR_COLLECTIVE, MOTOR_EFFORTS, collective_pulse

                rate_pilot = ck.practice.pilot_module()
                pulse = {}
                ordinary_pilot = rate_pilot.FollowCourse
                feedback = None
                if args.probe_motor_feedback:
                    from motor_response import MotorResponse

                    identified = json.loads(args.probe_motor_feedback.read_text())
                    feedback = (MotorResponse.from_report(identified),
                                identified['observed_motor_bounds'][1])
                    cases = [(axis,rate,MOTOR_COLLECTIVE) for axis,rate in zip(MOTOR_AXES,(4.,4.,3.),strict=True)]
                elif args.probe_motor_authority=='envelope':
                    cases = [(axis,.08,level) for level in (.72,.84) for axis in MOTOR_AXES]
                elif args.probe_motor_authority in ('axes-low','axes','axes-high'):
                    level = {'axes-low':.18,'axes':MOTOR_COLLECTIVE,'axes-high':.55}[args.probe_motor_authority]
                    doses = (.04,.075) if args.probe_motor_authority=='axes-low' else (.055,.090)
                    cases = [(axis,effort,level) for axis in MOTOR_AXES for effort in doses]
                elif args.probe_motor_authority:
                    cases = [('pitch',effort,MOTOR_COLLECTIVE) for effort in MOTOR_EFFORTS]
                else:
                    cases = [('pitch',None,boost) for boost in LEVELS]
                names = [f'{axis} {effort:g}' if effort is not None else str(level) for axis,effort,level in cases]

                def select_collective(index):
                    pulse.clear()
                    axis,effort,level = cases[index]
                    pulse['level'] = level
                    if effort is not None:
                        key = 'motor_rate_target_rad_s' if feedback is not None else 'motor_torque_effort'
                        pulse.update({key:effort,'motor_axis':axis})
                    rate_pilot.FollowCourse = collective_pulse(ordinary_pilot,pulse,args.probe_pitch_authority,
                                                               effort,axis,feedback)

                ck.practice.write_json(args.out.resolve()/'collective-source.json', {
                    'source_sha256': ck.practice.digest(here/'collective_authority.py'),
                    'hold_s':HOLD,'cases':cases,'pitch_pulse':args.probe_pitch_authority,
                    'feedback_sha256':ck.practice.digest(args.probe_motor_feedback) if feedback else None})
                order = tuple(range(len(cases)))
                kwargs['evolution_type'] = matched_variants(
                    ck.practice, kwargs['evolution_type'], select_collective,
                    names, 'collective', lambda: dict(pulse),order=order+order[::-1])
            if crossing_study:
                tracker = pilot.FollowCourse
                ordinary = tracker.crossed_plane
                bracket_crossing = sys.modules['trial_fly_learned_course'].FollowCourse.crossed_plane
                retained_checks = 0

                def retain(self,center,plane,stamp,position,*args,**kwargs):
                    nonlocal retained_checks
                    anchor = self.approach_sample
                    passed = bracket_crossing(self,center,plane,stamp,position,*args,**kwargs)
                    if (anchor is not None and self.approach_sample is anchor and self.passage is None
                            and stamp>anchor[0] and plane.apply(position-center)[0]>=0.):
                        retained_checks += 1
                    return passed

                def select(i):
                    nonlocal retained_checks
                    tracker.crossed_plane = (ordinary,retain)[i]
                    retained_checks = 0
                    active.clear()

                if horizon_study:
                    select(1)
                else:
                    kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                        ('latest', 'retained'), 'crossing_bracket',
                        lambda:dict(retained_checks=retained_checks,**camera_counts()),
                        order=(1,) if args.repeat_crossing_bracket else (0,1,1,0))
            if horizon_study:
                from command_projection import CommandProjection
                from rate_horizon import RateHorizon, controlled_variants

                rate_fit,force_fit=here/'recent-rate-authority.json',here/'force-model-holdout.json'
                witness=here/'actuator-state-witness.json'
                evidence=json.loads(witness.read_text())
                if any(ck.practice.digest(p)!=evidence['fit_inputs'][p.name] for p in (rate_fit,force_fit)):
                    raise ValueError('The actuator model differs from the held-out motion test')
                if evidence['methods'][evidence['selected']]!='0.04 s residual memory':
                    raise ValueError('The horizon uses the validated 40 ms residual memory')
                bound=evidence['summary']['later'][0]['calibrated'][0]
                look=here/'view-calibration.json'
                model=CommandProjection(json.loads(rate_fit.read_text())['axes'],json.loads(force_fit.read_text()))
                look_model=json.loads(look.read_text())['model']
                sources=[rate_fit,force_fit,witness,look,here/'rate_horizon.py',here/'command_projection.py',here/'horizon_tracker.py']
                trial_name,key='rate-horizon','rate_horizon'
                if args.compare_flown_continuation:
                    from flown_continuation import FlownContinuation

                    atlas=args.compare_flown_continuation.resolve()
                    with np.load(atlas,allow_pickle=False) as data:
                        hashes={path.name:ck.practice.digest(path) for path in (rate_fit,force_fit,look)}
                        if (json.loads(str(data['actuator_inputs']))!=hashes
                                or str(data['plan_sha256'])!=ck.practice.digest(args.plan)
                                or str(data['map_sha256'])!=binding['gate-map-in']['sha256']):
                            raise ValueError('Command clips require the matching plan, map and actuator model')
                        policy=FlownContinuation(data,model,look_model,float(data['reserve_m']))
                    sources.extend((atlas,here/'flown_continuation.py'))
                    trial_name,key='flown-continuation','flown_continuation'
                elif args.compare_camera_force:
                    from camera_force import CameraForce

                    camera_data=here/'continuation-witness.json'
                    report=json.loads(camera_data.read_text())
                    if any(report['actuator_inputs'][p.name]!=ck.practice.digest(p) for p in (rate_fit,force_fit)):
                        raise ValueError('Camera preview requires the tested command response')
                    tested=report['reports']['later reference']['forecast_comparison']
                    reserves=[tested[h]['modeled command']['imu_displacement_error_m_p90'] for h in ('0.12','0.24')]
                    policy=CameraForce(model,reserves)
                    sources.extend((camera_data,here/'camera_force.py'))
                    trial_name,key='camera-force','camera_force'
                else:
                    policy=RateHorizon(model,look_model,bound)
                counters={}
                modes=controlled_variants(pilot,policy,counters,thrust_context=args.compare_camera_force)

                def choose_controller(i):
                    nonlocal retained_checks
                    pilot.FollowCourse=modes[i]
                    counters.update(durations=[],used=0)
                    retained_checks=0
                    active.clear()
                    if args.compare_flown_continuation or args.compare_camera_force:
                        policy.reset()

                def controls_used():
                    times=counters['durations']
                    extra=(dict(recognized=policy.recognized,supported=policy.supported,wins=policy.wins)
                           if args.compare_flown_continuation else {})
                    if args.compare_camera_force:
                        extra=dict(offers=policy.offers,horizon_checks=policy.horizon_checks,changes=policy.applied)
                    return dict(evaluations=len(times),used=counters['used'],retained_checks=retained_checks,
                                rollout_p95_ms=1000.*float(np.quantile(times,.95)) if times else None,
                                **camera_counts(),**extra)

                ck.practice.write_json(args.out.resolve()/f'{trial_name}-sources.json', {
                    str(p):ck.practice.digest(p) for p in sources})
                kwargs['evolution_type']=matched_variants(ck.practice,kwargs['evolution_type'],choose_controller,
                    ('geometric',trial_name),key,controls_used)
            if args.compare_command_projection or args.compare_action_clock_limit:
                from collections import deque
                from command_projection import CommandProjection
                from miniflight import BodyRates

                pilot = ck.practice.pilot_module()
                extended = args.compare_action_clock_limit
                rates = here/('recent-rate-authority.json' if extended else 'rate-authority.json')
                thrust = here/'force-model-holdout.json'
                sources = [rates,thrust,here/'command_projection.py']
                if extended:
                    validation = here/'projection-extension.json'
                    evidence = json.loads(validation.read_text())['tested_sources']
                    tested = [*sources,here.parent/'pose-odometry'/'actuation_clock.py']
                    if any(ck.practice.digest(path)!=evidence[path.name] for path in tested):
                        raise ValueError('The actuation-time model differs from the 120 ms validation')
                    sources = [*tested,validation]
                model = CommandProjection(json.loads(rates.read_text())['axes'], json.loads(thrust.read_text()))
                baseline = pilot.FollowCourse
                counters = {}

                class CommandHistory(pilot.CourseClient):
                    def __init__(self, *args, **kwargs):
                        super().__init__(*args, **kwargs)
                        self.sent_rates = deque(maxlen=20)

                    def send(self, command):
                        result = super().send(command)
                        if isinstance(command, BodyRates):
                            self.sent_rates.append((self.last_send,command.roll_rate,command.pitch_rate,
                                                    command.yaw_rate,command.thrust))
                        return result

                class CommandDriven(baseline):
                    limit = .07

                    def predict_action(self, client, state, reading, host_now):
                        clock = self.action_clock
                        original = clock.max_projection
                        clock.max_projection = self.limit
                        try:
                            horizon = clock.horizon(host_now)
                            estimate = None
                            if not args.only_extend_clipped or horizon>.070001:
                                estimate = model.predict(clock,state,reading,host_now,client.sent_rates)
                        finally:
                            clock.max_projection = original
                        if estimate is None:
                            return super().predict_action(client,state,reading,host_now)
                        counters['command_projections'] += 1
                        counters['extended_projections'] += int(horizon>.070001)
                        return estimate

                def select(i):
                    if extended:
                        CommandDriven.limit = (.07,.12)[i]
                        pilot.FollowCourse = baseline if args.only_extend_clipped and i==0 else CommandDriven
                    else:
                        pilot.FollowCourse = (baseline, CommandDriven)[i]
                    counters.update(command_projections=0,extended_projections=0)

                pilot.CourseClient = CommandHistory
                ck.practice.write_json(args.out.resolve()/'command-projection-sources.json', {
                    path.name:ck.practice.digest(path) for path in sources})
                names = ('70 ms','120 ms') if extended else ('held-imu','sent-commands')
                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                                                           names,'projection',lambda:dict(counters))
            if args.compare_plane_progress:
                pilot = ck.practice.pilot_module()
                baseline = pilot.FollowCourse
                events = []

                class MappedPlaneProgress(baseline):
                    def crossed_plane(self, center, plane, stamp, position, velocity, seen, index,
                                      exit_distance, close_view, lock_stamp, *, client=None):
                        before = len(self.crossing_checks)
                        passed = super().crossed_plane(center, plane, stamp, position, velocity, seen,
                                                      index, exit_distance, close_view, lock_stamp, client=client)
                        if passed or self.passage is not None or len(self.crossing_checks) == before:
                            return passed
                        line = self.racing_line
                        if line is None or not line.map_first or client is None or index >= len(client.observer.saved_course):
                            return False
                        event = self.crossing_checks[-1]
                        _, _, interval, _, continuity, *_ = event
                        if not (0. < interval <= pilot.IMU_TIMEOUT and 0. <= stamp-lock_stamp <= pilot.IMU_TIMEOUT
                                and continuity <= .10 and plane.apply(velocity)[0] > 0.):
                            return False
                        normal = plane.as_matrix()[0]
                        self.passage = center.copy(), normal, exit_distance, position[2]
                        events.append(dict(gate=index+1, stamp=stamp, offset_m=list(event[5:7]),
                                           estimated_clearance_m=event[7]))
                        return (position-center)@normal > exit_distance

                def select(i):
                    pilot.FollowCourse = (baseline, MappedPlaneProgress)[i]
                    events.clear()

                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                    ('aperture-confirmed', 'mapped-plane'), 'progress', lambda:dict(unconfirmed_passages=list(events)))
            if args.compare_horizon_tracker:
                from scipy.spatial.transform import Rotation
                from horizon_tracker import DOWN, HorizonTracker

                pilot = ck.practice.pilot_module()
                baseline = pilot.FollowCourse
                authority = here/'recent-rate-authority.json'
                axes = json.loads(authority.read_text())['axes']
                counts = {}

                class PredictiveTracker(baseline):
                    def __init__(self, *args, **kwargs):
                        super().__init__(*args, **kwargs)
                        self.horizon = HorizonTracker(self.config, axes)

                    def control_state(self, position, velocity, angles, client, state, host_now):
                        state_now = super().control_state(position, velocity, angles, client, state, host_now)
                        self.horizon_state = None
                        self.horizon_used = False
                        if client.history and client.prediction.time == state.motion.time == client.history[-1][0]:
                            rotation = Rotation.from_euler('xyz', state_now[2])
                            force = client.history[-1][1:4]-client.prediction.state[10:13]
                            measured = rotation.apply(force)+DOWN
                            coefficients = self.config.body_resistance_per_m or (0., 0., 0.)
                            airspeed = rotation.inv().apply(state_now[1])
                            drag = rotation.apply(np.asarray(coefficients)*airspeed*abs(airspeed))
                            geometry = client.prediction.source[4]
                            self.horizon_state = (geometry, measured, drag, rotation.as_matrix()[:, 2])
                        return state_now

                    def corridor_velocity(self, index, origin, center, position, motion, speed):
                        line = self.racing_line
                        if (self.horizon_state is not None and line is not None and line.map_first
                                and index < len(line.gates) and line.rate_feedforward is None):
                            geometry, measured, drag, down = self.horizon_state
                            if len(geometry.course) == len(line.gates):
                                _, velocity, _, station = line.reference(index, origin, center, position, with_progress=True)
                                pace = min(1., speed/max(.01, np.linalg.norm(velocity)))
                                centers = np.array([point for point, _ in geometry.course])
                                centers[index-1:index+1] = origin, center
                                gate = center, geometry.course[index][1], geometry.cross_sigma[index]
                                action, constrained = self.horizon.request(line, centers, station, pace, position,
                                                                           motion, measured, drag, down, gate)
                                if action is not None:
                                    self.pose_heading = float(line.pose_heading(station))
                                    self.horizon_used = True
                                    counts['horizon_requests'] += 1
                                    counts['aperture_constraints'] += int(constrained)
                                    return motion + action/self.config.velocity_gain
                        return super().corridor_velocity(index, origin, center, position, motion, speed)

                    def intercept_acceleration(self, acceleration, *args):
                        return acceleration if self.horizon_used else super().intercept_acceleration(acceleration, *args)

                def select(i):
                    pilot.FollowCourse = (baseline, PredictiveTracker)[i]
                    counts.update(horizon_requests=0, aperture_constraints=0)

                ck.practice.write_json(args.out.resolve()/'horizon-tracker-sources.json', {
                    name:ck.practice.digest(here/name) for name in (authority.name, 'horizon_tracker.py', 'crossing_control.py')})
                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                    ('point-tracking', 'horizon-tracking'), 'tracking', lambda:dict(counts))
            if args.compare_experience_pose:
                from experience_pose import ExperiencePose

                pilot = ck.practice.pilot_module()
                baseline = pilot.FollowCourse
                trace = args.compare_experience_pose.resolve()
                with np.load(trace,allow_pickle=False) as bound:
                    if (str(bound['plan_sha256'])!=binding['plan']['sha256']
                            or str(bound['map_sha256'])!=binding['gate-map-in']['sha256']):
                        raise ValueError('The flown pose must use the same plan and map')
                with np.load(inputs/'plan.npz',allow_pickle=False) as archive, np.load(args.plan,allow_pickle=False) as live:
                    fields = (set(archive.files)|set(live.files))-{'geometric_control'}
                    if any(key not in archive or key not in live or not np.array_equal(archive[key],live[key]) for key in fields):
                        raise ValueError('Only geometric feedback may differ in the archived position plan')
                experiment = ExperiencePose(trace)
                counts = {}
                source = here.parent/'pose-odometry'/'fly_rednose.py'
                observer = load_module('trial_experience_observer', source).Observer

                class TwoReadyFrames(pilot.CourseClient.observer_type):
                    ready_frame_limit = 2
                    correct_ready_frames = observer.correct_ready_frames
                    visual_updates = observer.visual_updates

                class FlownAttitude(baseline):
                    def body_command(self, acceleration, angles, heading, rates):
                        if self.motion_reference is not None:
                            adjusted = experiment.request(self.config,acceleration,self.motion_reference)
                            if adjusted is not None:
                                acceleration, adjusted_heading = adjusted
                                counts['pose_requests'] += 1
                                counts['absolute_yaw_adjustment_rad'] += abs((adjusted_heading-heading+np.pi)%(2.*np.pi)-np.pi)
                                heading = adjusted_heading
                        return super().body_command(acceleration,angles,heading,rates)

                def select(i):
                    pilot.FollowCourse = (baseline, FlownAttitude)[i]
                    counts.update(pose_requests=0,absolute_yaw_adjustment_rad=0.)

                pilot.CourseClient.observer_type = TwoReadyFrames
                ck.practice.write_json(args.out.resolve()/'experience-pose-sources.json', {
                    str(path):ck.practice.digest(path) for path in (trace, here/'experience_pose.py', source)})
                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                    ('planned-pose', 'flown-pose'), 'attitude_reference', lambda:dict(counts))
            if args.compare_launch_preview:
                pilot = ck.practice.pilot_module()
                update_scope = pilot.FollowCourse.update.__globals__
                path = here.parent / 'pose-odometry' / 'launch_reference.py'
                candidate = load_module('trial_launch_reference', path).LaunchReference
                counts = {}

                class ContinuousPreview(candidate):
                    def acceleration_at(self, stamp):
                        counts['queries'] += 1
                        counts['after_join'] += int(stamp > self.duration)
                        return super().acceleration_at(stamp)

                variants = update_scope['LaunchReference'], ContinuousPreview

                def select(i):
                    update_scope['LaunchReference'] = variants[i]
                    counts.update(queries=0, after_join=0)

                ck.practice.write_json(args.out.resolve()/'launch-source.json', {
                    'sha256': ck.practice.digest(path), 'update_module': update_scope['__name__']})
                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                                                           ('clipped', 'continuous'), 'launch', lambda: dict(counts))
            if args.compare_reference_projection:
                pilot = ck.practice.pilot_module()
                projection = here.parent / 'pose-odometry/learned_line.py'
                local = load_module('trial_learned_line', projection).RacingLine.local_reference
                from refine_gate_map import read_packet_map

                centers = read_packet_map(inputs/'gate-map-in.json')[:, :3]
                reference = pilot.RacingLine.reference

                def continuous(line, *args, **kwargs):
                    return local(line, reference, centers, *args, **kwargs)

                modes = (reference, continuous)
                select = lambda i: setattr(pilot.RacingLine, 'reference', modes[i])
                ck.practice.write_json(args.out.resolve()/'reference-source.json',
                                       {'path': str(projection), 'sha256': ck.practice.digest(projection)})
                kwargs['evolution_type'] = matched_variants(
                    ck.practice, kwargs['evolution_type'], select, ('one-leg', 'neighboring-legs'), 'reference-projection')
            if args.compare_crossing_correction:
                pilot = ck.practice.pilot_module()
                ordinary = pilot.FollowCourse

                class FollowLine(ordinary):
                    def intercept_acceleration(self, acceleration, *_):
                        return acceleration

                modes = (ordinary, FollowLine)
                select = lambda i: setattr(pilot, 'FollowCourse', modes[i])
                kwargs['evolution_type'] = matched_variants(
                    ck.practice, kwargs['evolution_type'], select, ('correction', 'line-only'), 'crossing-correction')
            if args.compare_predicted_crossing:
                pilot = ck.practice.pilot_module()
                path = here/'crossing_control.py'
                control = load_module('trial_crossing_control', path)
                from scipy.spatial.transform import Rotation

                axes = json.loads((here/'rate-authority.json').read_text())['axes']
                crossings = json.loads((here/'crossing-prediction.json').read_text())['records']
                train = crossings[:2*len(crossings)//3]
                reserve = float(np.quantile([max(map(abs, row['live_prior_correction_m']))
                                            for lap in train for row in lap['rows'] if row['horizon'] == .24
                                            and row['live_prior_correction_m'] is not None
                                            and row['last_gate_update_s'] is not None
                                            and row['last_gate_update_s'] <= .10], .95))
                delay = max(axis['delay_s']+axis['lag_s'] for axis in axes[:2])
                gain = min(axis['gain'] for axis in axes[:2])
                tilt_rate = min(axis['limit_rad_s'] for axis in axes[:2])
                ordinary = pilot.FollowCourse
                counters = {}

                class PredictedCrossing(ordinary):
                    def control_state(self, position, velocity, angles, client, state, host_now):
                        result = super().control_state(position, velocity, angles, client, state, host_now)
                        self.crossing_state = None
                        if client.history and client.prediction.time == state.motion.time == client.history[-1][0]:
                            rotation = Rotation.from_euler('xyz', result[2])
                            force = client.history[-1][1:4]-client.prediction.state[10:13]
                            measured = rotation.apply(force)+np.array([0., 0., control.GRAVITY])
                            coefficients = self.config.body_resistance_per_m or (0., 0., 0.)
                            airspeed = rotation.inv().apply(result[1])
                            drag = rotation.apply(np.asarray(coefficients)*airspeed*abs(airspeed))
                            self.crossing_state = measured, drag, rotation.apply([0., 0., 1.])
                        return result

                    def intercept_acceleration(self, acceleration, plane, depth, closing, offset, lateral_speed, sigma):
                        if self.crossing_state is not None and depth/closing <= .8:
                            measured, drag, body_down = self.crossing_state
                            counters['attempted'] += 1
                            projected = control.intercept(
                                self.config, plane, depth, offset, np.r_[closing, lateral_speed], measured,
                                acceleration, drag, body_down, delay=delay, lag=1./(self.config.attitude_gain*gain),
                                tilt_rate=tilt_rate, reserve=max(reserve, 2.*sigma))
                            if projected is not None:
                                counters['feasible'] += 1
                                return projected
                        return super().intercept_acceleration(acceleration, plane, depth, closing, offset, lateral_speed, sigma)

                def select(i):
                    pilot.FollowCourse = (ordinary, PredictedCrossing)[i]
                    counters.update(attempted=0, feasible=0)

                ck.practice.write_json(args.out.resolve()/'crossing-model.json', {
                    'source_sha256': ck.practice.digest(path), 'lateral_reserve_m': reserve,
                    'tilt_rate_rad_s': tilt_rate, 'delay_s': delay, 'angular_gain': gain})
                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                                                           ('legacy', 'predicted'), 'crossing', lambda: dict(counters))
            if args.compare_rate_allocation:
                from functools import partial
                from rate_allocation import BodyRateAllocation

                source = here/'rate-authority.json'
                model = json.loads(source.read_text())['axes']
                allocator = BodyRateAllocation(model)
                inverse = sys.modules['inverse']
                ordinary = inverse.acceleration_control
                modes = ordinary, partial(ordinary, rate_allocation=allocator)

                def select(i):
                    inverse.acceleration_control = modes[i]
                    allocator.calls = allocator.limited_tilt = 0

                def metrics():
                    return {'allocated_commands': allocator.calls, 'limited_tilt': allocator.limited_tilt}

                ck.practice.write_json(args.out.resolve()/'rate-allocation.json', {
                    'model_sha256': ck.practice.digest(source),
                    'allocator_sha256': ck.practice.digest(here/'rate_allocation.py'), 'axes': model})
                kwargs['evolution_type'] = matched_variants(ck.practice, kwargs['evolution_type'], select,
                                                           ('wire-sphere', 'body-limits'), 'rate-allocation', metrics)
            if args.planned_launch:
                from planned_launch import install

                rates_source = here/'recent-rate-authority.json'
                rates = json.loads(rates_source.read_text())['axes'] if args.direct_pose else None
                budget = terminal = None
                effects = []
                if args.terminal_feedback or args.compare_terminal_tracking or args.compare_climb_limit:
                    source = (args.terminal_feedback or args.compare_terminal_tracking or here/'terminal-tracking-holdout.json').resolve()
                    fit = json.loads(source.read_text())['summary']['training']['p50_p90_m']
                    lag = float(min((k for k in fit if k.endswith(' s lag')),key=lambda k:fit[k][1]).split()[0])
                    plan_report = args.plan.resolve().with_name('report.json')
                    reserve = json.loads(plan_report.read_text())['clearance_reserve_m']
                    envelope = here/'fast-recovered-cadence/actuator-model-contrast.json'
                    terminal = lag,reserve,json.loads(envelope.read_text())['rate_error_floor']
                    ck.practice.write_json(args.out.resolve()/'terminal-tracking-sources.json', {
                        'lag_s':lag,'reserve_m':reserve,'sha256':{str(p):ck.practice.digest(p)
                            for p in (source,plan_report,envelope,here/'terminal_tracking.py')}})
                if args.compare_rate_force_budget is not None:
                    calibration = args.compare_rate_force_budget.resolve()
                    budget = json.loads(calibration.read_text())['rate_error_floor']
                    if len(budget)!=3 or not all(np.isfinite(x) and x>=0. for x in budget):
                        raise ValueError('Expected three nonnegative force-envelope coefficients')
                    ck.practice.write_json(args.out.resolve()/'rate-force-sources.json', {
                        str(p):ck.practice.digest(p) for p in (rates_source,calibration,here/'planned_launch.py')})
                pose_trace = [] if args.trpy_trial else None
                tracker = install(ck.practice.pilot_module(),args.plan.resolve(),rates,budget,effects,terminal,
                                  pose_trace=pose_trace,continuous_phase=args.trpy_continuous_phase)
                if direct_reference is not None:
                    tracker.direct_launch = True
                if args.body_axis_drag:
                    tracker.body_drag = True
                if args.compare_held_rates:
                    hold = .020  # Nominal BodyRates packet interval.
                    ck.practice.write_json(args.out.resolve()/'held-rate-source.json', {
                        'hold_s':hold,'sha256':{p.name:ck.practice.digest(p) for p in
                                              (rates_source,here/'planned_launch.py',here/'pose_schedule.py')}})
                    select = lambda i: setattr(tracker,'held_rate_interval',hold if i else None)
                    kwargs['evolution_type'] = matched_variants(ck.practice,kwargs['evolution_type'],
                        select,('instantaneous rates','held rates'),'rate_timing')
                if args.compare_direct_launch or args.compare_blended_launch:
                    ck.practice.write_json(args.out.resolve()/'direct-launch-source.json', {
                        'control_sha256':ck.practice.digest(here/'planned_launch.py')})
                    def select_launch(i):
                        tracker.direct_launch = bool(i)
                        tracker.blend_launch = bool(i) and args.compare_blended_launch
                        tracker.launch_updates = 0

                    label = 'blended pose launch' if args.compare_blended_launch else 'direct launch'
                    kwargs['evolution_type'] = matched_variants(ck.practice,kwargs['evolution_type'],
                        select_launch,('velocity launch',label),'launch_actuation',
                        lambda: dict(direct_commands=tracker.launch_updates))
                if args.compare_measured_lift:
                    from types import SimpleNamespace
                    from collective_authority import MeasuredLift

                    evidence = args.compare_measured_lift.resolve()
                    with np.load(args.plan,allow_pickle=False) as plan:
                        config = SimpleNamespace(**json.loads(str(plan['config'])))
                    lift = MeasuredLift(json.loads(evidence.read_text()),config)
                    ck.practice.write_json(args.out.resolve()/'measured-lift.json', {
                        'evidence_sha256':ck.practice.digest(evidence), 'maximum_m_s2':lift.maximum,
                        'control_sha256':ck.practice.digest(here/'planned_launch.py')})
                    select = lambda i: setattr(tracker,'measured_lift',lift if i else None)
                    kwargs['evolution_type'] = matched_variants(ck.practice,kwargs['evolution_type'],
                        select,('linear lift','measured lift'),'lift')
                if args.terminal_feedback:
                    tracker.terminal_tracking = True
                    def select_terminal(i):
                        effects.clear()
                        tracker.linked_apertures = bool(i)

                    names = ('current aperture','linked apertures')
                    order = (0,1,1,0) if args.compare_linked_apertures else (0,)
                    kwargs['evolution_type'] = matched_variants(ck.practice,kwargs['evolution_type'],
                        select_terminal,names,'terminal',lambda:dict(corrections=list(effects)),order=order)
                if args.compare_body_drag:
                    def select(i):
                        tracker.body_drag = bool(i)

                    kwargs['evolution_type'] = matched_variants(ck.practice,kwargs['evolution_type'],select,
                        ('horizontal drag','body-axis drag'),'drag_frame')
                if budget is not None:
                    def select(i):
                        tracker.rate_force_budget = bool(i)
                        effects.clear()

                    kwargs['evolution_type'] = matched_variants(ck.practice,kwargs['evolution_type'],select,
                        ('independent rates','shared thrust budget'),'rate_force',lambda:dict(rate_changes=list(effects)))
                if args.compare_terminal_tracking is not None:
                    def select(i):
                        tracker.terminal_tracking = bool(i)
                        effects.clear()

                    kwargs['evolution_type'] = matched_variants(ck.practice,kwargs['evolution_type'],select,
                        ('path feedback','aperture feedback'),'terminal',lambda:dict(corrections=list(effects)))
                if args.compare_climb_limit is not None:
                    source = args.compare_climb_limit.resolve()
                    force = json.loads(source.read_text())['wire_throttle_percentiles'][2]
                    if not 0.<force<=1.:
                        raise ValueError('The observed upper throttle must be in the command range')
                    lift_changes = []
                    tracker.terminal_tracking,tracker.lift_changes = True,lift_changes

                    def select(i):
                        tracker.climb_thrust = force if i else None
                        effects.clear()
                        lift_changes.clear()

                    ck.practice.write_json(args.out.resolve()/'climb-limit-source.json', {
                        'sha256':ck.practice.digest(source),'upper_throttle':force,'quantile':.99})
                    kwargs['evolution_type'] = matched_variants(ck.practice,kwargs['evolution_type'],select,
                        ('fixed climb limit','measured lift headroom'),'climb',
                        lambda:dict(corrections=list(effects),lift_changes=list(lift_changes)))
                ck.practice.write_json(args.out.resolve()/'planned-launch-sources.json',
                    {'plan_sha256':ck.practice.digest(args.plan),
                     'direct_pose':args.direct_pose,
                     'continuous_phase':args.trpy_continuous_phase,
                     'rate_fit_sha256':ck.practice.digest(rates_source) if rates is not None else None,
                     'launch_sha256':ck.practice.digest(here/'planned_launch.py')})
            if motor_model:
                from motor_drive import drive_variants
                from motor_response import MotorResponse, load_axial_drag

                rates = here/'recent-rate-authority.json'
                drag = here/'live-monorace-tilted-spawn/axial-force-holdout.json'
                model = json.loads(motor_model.read_text())
                motors = MotorResponse.from_report(model)
                limits = model.get('repeated_limits', {}).get('body_rates_rad_s')
                if limits is None:
                    limits = [axis['limit_rad_s'] for axis in json.loads(rates.read_text())['axes']]
                pilot = ck.practice.pilot_module()
                counts = {}
                schedule = None
                with np.load(args.plan,allow_pickle=False) as packet:
                    if 'schedule_time_s' in packet:
                        from trajectory_feedback import read_schedule

                        schedule = read_schedule(packet)
                modes = drive_variants(pilot, motors, np.asarray(limits), model['observed_motor_bounds'][1],
                                       load_axial_drag(drag),counts,direct_reference,schedule)

                base_update = pilot.gate_update
                if anchor_enabled:
                    from aperture_anchor import with_aperture_anchor
                    anchored = with_aperture_anchor(base_update, counts, bounded=args.bounded_aperture_anchor)
                    source = here/'aperture_anchor.py'
                    ck.practice.write_json(args.out.resolve()/'aperture-anchor-source.json',
                                           {'sha256':ck.practice.digest(source)})

                def select(i):
                    counts.update(motors=0, aged_samples=0, bridged_imu_ticks=0, motor_motion_predictions=0,
                                  pose_motor_commands=0, scheduled_commands=0, max_receipt_age_s=0.,
                                  targets=[],pose_samples=[],schedule_lift_off=None,ground_release=None,
                                  aperture_anchors=[],bounded_anchors=[],early_motor_estimates=0)
                    pilot.FollowCourse = modes[1 if args.compare_aperture_anchor else i]
                    if anchor_enabled:
                        pilot.gate_update = anchored if i else base_update

                ck.practice.write_json(args.out.resolve()/'motor-drive-sources.json', {
                    path.name:ck.practice.digest(path) for path in
                    (rates,drag,motor_model,here/'motor_drive.py',here/'motor_response.py',here/'trajectory_feedback.py')})
                order = (1,) if args.motor_drive and not args.compare_aperture_anchor else (0,1,1,0)
                names = ('standard aperture update','aperture anchor') if anchor_enabled else (
                    'native rate loop','direct motor loop')
                if args.bounded_aperture_anchor:
                    names = (names[0], 'bounded aperture anchor')
                kwargs['evolution_type'] = matched_variants(ck.practice,kwargs['evolution_type'],select,
                    names,'motor_drive',lambda:dict(counts),order=order)
            if args.monorace_policy or args.trpy_trial:
                pilot = ck.practice.pilot_module()
                counts = {}
                if anchor_enabled:
                    from aperture_anchor import with_aperture_anchor
                    pilot.gate_update = with_aperture_anchor(pilot.gate_update, counts, bounded=args.bounded_aperture_anchor)
                    ck.practice.write_json(args.out.resolve()/'aperture-anchor-source.json',
                                           {'sha256':ck.practice.digest(here/'aperture_anchor.py')})
                if args.monorace_vision:
                    from monorace_vision import with_monorace_pose
                    source = {'sha256':ck.practice.digest(here/'monorace_vision.py')}
                    segment = None
                    if args.monorace_gatenet:
                        from monorace_gatenet import load_segmenter
                        segment = load_segmenter(args.monorace_gatenet)
                        for path in (here/'monorace_gatenet.py',args.monorace_gatenet):
                            source[path.name] = ck.practice.digest(path)
                    pilot.gate_update = with_monorace_pose(pilot.gate_update,counts,segment,
                                                           partial_bearing=args.monorace_partial_bearing)
                    ck.practice.write_json(args.out.resolve()/'monorace-vision-source.json',source)
                if args.trpy_trial:
                    def start_trpy(_):
                        counts.clear()
                        pose_trace.clear()

                    kwargs['evolution_type'] = matched_variants(ck.practice,kwargs['evolution_type'],start_trpy,
                        ('pose tracking / BodyRates',),'trpy',
                        lambda:dict(counts,pose_trace=list(pose_trace)),order=(0,))
                    practice_main(arguments,**kwargs)
                    return

                from monorace_live import install
                from motor_response import load_axial_drag

                motion_fit = args.monorace_motor_motion
                drag = np.array([.044,.043,load_axial_drag(motion_fit)]) if motion_fit else None
                imu_clock = sys.modules['trial_actuation_clock'].ActuationClock if args.monorace_imu_interpolation else None
                pilot.FollowCourse = install(pilot,args.monorace_policy,inputs/'gate-map-in.json',counts,drag,
                                             bridge_s=args.monorace_imu_bridge_s,angular_fit=args.monorace_angular_fit,
                                             gate_switch=args.monorace_gate_switch,
                                             runner_guards_feedback=args.monorace_imu_wait,
                                             transport_lead=args.monorace_transport_lead,
                                             airborne_policy=args.monorace_airborne_policy,
                                             imu_clock=imu_clock)

                def start(_):
                    counts.clear()
                    counts['network_commands'] = 0
                    counts['motion_bridge_s'] = args.monorace_imu_bridge_s
                    counts['gate_switch'] = args.monorace_gate_switch
                    counts['runner_guards_feedback'] = args.monorace_imu_wait
                    counts['transport_lead'] = args.monorace_transport_lead
                    counts['partial_bearing'] = args.monorace_partial_bearing
                    counts['stock_command_hz'] = args.monorace_hz or 50.
                    counts['imu_interpolation'] = args.monorace_imu_interpolation

                policy_sources = {
                    path.name:ck.practice.digest(path) for path in
                    (args.monorace_policy,here/'monorace_policy.py',here/'monorace_live.py',here/'motor_drive.py',
                     here/'motor_response.py',here.parent/'pose-odometry/fly_learned_course.py',
                     here.parent/'pose-odometry/actuation_clock.py',motion_fit,args.monorace_angular_fit)
                    if path is not None}
                if args.monorace_airborne_policy:
                    policy_sources['airborne/'+args.monorace_airborne_policy.name] = ck.practice.digest(args.monorace_airborne_policy)
                ck.practice.write_json(args.out.resolve()/'monorace-sources.json',policy_sources)
                kwargs['evolution_type'] = matched_variants(ck.practice,kwargs['evolution_type'],start,
                    ('G&CNet direct motors',),'monorace',lambda:dict(counts),order=(0,))
            practice_main(arguments, **kwargs)

        ck.practice.main = run_with_options
    reset = public_race.reset_public_race
    reset_evidence = None

    def wait_for_race(client):
        nonlocal reset_evidence
        notified = False

        def waiting():
            nonlocal notified
            if not notified:
                print('Waiting for VQ2 Track Practice to open a fresh race.', flush=True)
                notified = True

        while True:
            try:
                if args.wait_for_race:
                    reset_evidence = reset(client,timeout=None,on_wait=waiting)
                else:
                    reset_evidence = reset(client)
                return reset_evidence
            except TimeoutError:
                if not args.wait_for_race:
                    raise
                waiting()

    pilot = ck.practice.pilot_module()

    class StockEpochClient(pilot.CourseClient):
        def __init__(self, *options, **settings):
            super().__init__(*options, **settings)
            if reset_evidence is not None:
                public_race.guard_reset_epoch(self,reset_evidence)

        def disconnect(self):
            super().disconnect()
            if args.laps == 0 and not (args.capture_camera or args.capture_camera_window):
                self.observer.recent_images.clear()
                self.observer.handoff_images.clear()

    pilot.CourseClient = StockEpochClient
    ck.practice.reset_public_race = wait_for_race
    ck.INPUTS = inputs
    earlier = set(args.out.glob('practice-*/result.json'))
    ck.fly(args.out, args.laps, configuration)
    if args.resume_reference and batch_finished(args.out, earlier, args.laps):
        print('Trial data saved. Resuming continuous reference practice.', flush=True)
        destination, options = here/'phase-reference', []
        if args.thrust_priority or args.resume_reference == 'joint':
            destination = here/'thrust-priority-go'
            options = ['--plan', str(here/'joint-attitude-plan.npz'), '--thrust-priority']
            if args.action_clock or args.resume_reference == 'joint':
                options.append('--action-clock')
        os.execv(sys.executable, [sys.executable, '-B', __file__, '1392', str(destination),
                                 '--laps', '0', '--wait-for-race', '--port', str(args.port), *options])


def batch_finished(root, earlier, expected):
    results = set(root.glob('practice-*/result.json')) - earlier
    return len(results) == expected and all(not json.loads(path.read_text())['interrupted'] for path in results)


def matched_plans(practice, base, paths, names, key):
    order = (paths[0], paths[1], paths[1], paths[0])
    names = dict(zip(paths, names, strict=True))

    class Matched(base):
        def __init__(self, plan, line, root):
            super().__init__(plan, line, root)
            self.root = root
            self.report = root / ('attitude-comparison.json' if key == 'tracker' else 'plan-comparison.json')
            self.rows = json.loads(self.report.read_text()) if self.report.exists() else []
            self.path = order[len(self.rows) % len(order)]

        def update(self, lap, gain, course=None):
            folder = self.root / f'practice-{lap:02d}'
            manifest = json.loads((folder / 'manifest.json').read_text())
            assert manifest['inputs']['plan']['sha256'] == practice.digest(self.path)
            outcome = json.loads((folder / 'result.json').read_text())
            row = {key: outcome[key] for key in ('attempt', 'active_gate_index', 'contacts', 'time_seconds', 'clean_full', 'error')}
            row[key] = names[self.path]
            row['plan_sha256'] = manifest['inputs']['plan']['sha256']
            self.rows.append(row)
            practice.write_json(self.report, self.rows)
            self.path = order[len(self.rows) % len(order)]
            return {f'next_{key}': names[self.path]}

    return Matched


def matched_variants(practice, base, select, names, key, metrics=None, *, order=(0,1,1,0)):

    class Matched(base):
        def __init__(self, plan, line, root):
            super().__init__(plan, line, root)
            self.root = root
            self.report = root / f'{key}-comparison.json'
            self.rows = json.loads(self.report.read_text()) if self.report.exists() else []
            self.powered = sum(row['powered'] for row in self.rows)

        def pilot_map(self, learned):
            self.arm = order[self.powered % len(order)]
            select(self.arm)
            return super().pilot_map(learned)

        def update(self, lap, gain, course=None):
            folder = self.root / f'practice-{lap:02d}'
            outcome = json.loads((folder / 'result.json').read_text())
            powered = (folder / 'learned-course.npz').is_file()
            measures = {} if metrics is None else metrics()
            self.rows.append({**outcome, key: names[self.arm], 'powered': powered, **measures})
            practice.write_json(self.report, self.rows)
            self.powered += powered
            return {key: names[self.arm]}

    Matched.schedule_reset_failures = True
    return Matched


def action_clock_pilot(pilot, source):
    clock = load_module('trial_actuation_clock', source / 'actuation_clock.py')
    tracker = load_module('trial_fly_learned_course', source / 'fly_learned_course.py')
    tracker.acceleration_control = pilot.acceleration_control

    class Projected(pilot.FollowCourse):
        update = tracker.FollowCourse.update
        intercept_acceleration = tracker.FollowCourse.intercept_acceleration
        corridor_velocity = tracker.FollowCourse.corridor_velocity
        body_command = tracker.FollowCourse.body_command
        direct_motor_command = tracker.FollowCourse.direct_motor_command

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.action_clock = clock.ActuationClock()

        def predict_action(self, client, state, reading, host_now):
            return self.action_clock.predict(state, reading, host_now)

        def predict_camera_action(self, client, reading, camera, host_now):
            return self.action_clock.predict(camera[1][:16],client.history[-1],host_now,state_time=camera[0])

        def control_state(self, position, velocity, angles, client, state, host_now):
            for sample in state.imu_samples:
                self.action_clock.observe(sample.time, sample.received_at)
            feedback = state.rate_feedback
            stamp = state.motion.time
            self.control_stamp = stamp
            if (feedback is None or not client.history
                    or not feedback.time == client.history[-1][0] == client.prediction.time == stamp):
                return position, velocity, angles
            self.action_clock.observe(feedback.time, feedback.received_at)
            self.control_stamp += self.action_clock.horizon(host_now)
            camera = client.observer.snapshot
            if (getattr(client.observer,'camera_prediction_limit',0.) and camera is not None
                    and stamp < camera[0] <= self.control_stamp):
                estimate = self.predict_camera_action(client, client.history[-1], camera, host_now)
                client.observer.early_control_requests += 1
            else:
                estimate = self.predict_action(client, client.prediction.state[:16], client.history[-1], host_now)
            attitude = tracker.Rotation.from_quat(estimate[3:7]).as_euler('xyz')
            return estimate[:3], estimate[7:10], tuple(attitude)

    return Projected


def scheduled_observers(checkpoint, source):
    spec = spec_from_file_location('scheduled_worker', source)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)

    class SceneFirst(checkpoint):
        correct_ready_frames = module.Observer.correct_ready_frames
        visual_updates = module.Observer.visual_updates

    class GateFirst(SceneFirst):
        def visual_updates(self, image, stamp, recovering, scene_recovery):
            if scene_recovery:
                return super().visual_updates(image, stamp, recovering, scene_recovery)
            began = perf_counter()
            count, has_range = self.gate_measurements(image, stamp, recovering)
            matched = perf_counter()
            # A supported gate supplies earlier pose information on this frame.
            # Retain the background estimate when the gate is lost or scene support ages.
            active_supported = has_range and self.visibility[-1][2]
            lines_due = self.lines and (not active_supported or stamp - self.lines.last >= .16)
            n_lines = self.lines.update(self.filter, image, stamp) if lines_due else 0
            return count, has_range, n_lines, perf_counter() - matched, matched - began

    return SceneFirst, GateFirst


def gate_translation_observer(checkpoint, course_filter):
    from scipy.linalg import cho_factor, cho_solve

    class GateTranslation(course_filter):
        def update(self, z, h, H, deviations, He=None, correlated_noise=None):
            if self.N or He is not None or correlated_noise is None:
                return super().update(z, h, H, deviations, He, correlated_noise)
            residual = z-h
            noise = np.diag(deviations**2) + correlated_noise
            self.last_gate_factor = (residual, H, deviations, correlated_noise)
            projected = H@self.P
            gain = cho_solve(cho_factor(projected@H.T+noise, check_finite=False),
                             projected, check_finite=False).T
            # Gate pixels constrain translation; their innovation still carries the uncertain attitude.
            gain[3:6] = 0.
            estimate = self.x.copy()
            self.err_function(self.x, (gain@residual)[:, None], estimate)
            self.x = estimate
            retained = np.eye(self.dim_err)-gain@H
            covariance = retained@self.P@retained.T+gain@noise@gain.T
            self.P = .5*(covariance+covariance.T)
            return residual

    return type('GateTranslationObserver', (checkpoint,), {'filter_type': GateTranslation})


if __name__ == '__main__':
    main()
