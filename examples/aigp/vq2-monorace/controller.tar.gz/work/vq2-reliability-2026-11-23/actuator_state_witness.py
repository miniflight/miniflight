"""Test a command-driven six-degree-of-freedom rollout on later stock laps."""

from base64 import b64decode
import gzip
from hashlib import file_digest
import json

import numpy as np
from pymavlink.dialects.v20 import common
from scipy.spatial.transform import Rotation

from action_forecast import endpoint
from command_projection import CommandProjection
from measure import HERE


HORIZONS=(.24,.45)
DECAY=(0.,.04,.10,.22,np.inf)
DRAG=np.array([.044,.043,0.])


def signals(folder,epoch):
    receive,send=common.MAVLink(None),common.MAVLink(None)
    receive.robust_parsing=True
    imu,wire=[],[]
    with gzip.open(folder/'flight.jsonl.gz','rt') as stream:
        for row in map(json.loads,stream):
            host=row['host_time']
            if row['event']=='mavlink_datagram':
                for msg in receive.parse_buffer(b64decode(row['wire'])) or ():
                    if msg.get_type()!='HIGHRES_IMU':
                        continue
                    stamp=msg.time_usec*1.e-6
                    if abs(host-stamp-epoch)<.25 and (not imu or stamp>imu[-1][0]):
                        imu.append((stamp,host,-msg.xgyro,-msg.ygyro,-msg.zgyro,msg.xacc,msg.yacc,msg.zacc))
            elif row['event']=='outgoing':
                for msg in send.parse_buffer(b64decode(row['wire'])) or ():
                    if msg.get_type()=='SET_ATTITUDE_TARGET':
                        wire.append((host,-msg.body_roll_rate,-msg.body_pitch_rate,-msg.body_yaw_rate,msg.thrust))
    return np.asarray(imu).reshape(-1,8),np.asarray(wire).reshape(-1,5)


def decay(time,width):
    if width==0.:
        return np.zeros((len(time),1))
    return np.exp(-time[:,None]/width)


def errors(folder,outcome,model):
    with np.load(folder/'learned-course.npz',allow_pickle=False) as data:
        pose=data['pose']
    if not len(pose):
        return []
    imu,wire=signals(folder,pose[0,12]-pose[0,0])
    if len(imu)<30 or len(wire)<25:
        return []
    time=imu[:,0]
    go=outcome['wire']['race_start_boot_time_ms']*.001
    terminal=go+outcome['time_seconds']-.18
    rows=[]
    for i in range(5,len(time)-6,6):
        start,host=time[i],imu[i,1]
        if start<go+.40:
            continue
        match=np.flatnonzero((pose[:,0]==start)&(pose[:,12]<=host+.035))
        if not len(match):
            continue
        sample=pose[match[0]]
        rotation=Rotation.from_quat(sample[4:8])
        velocity=sample[8:11]
        first=np.searchsorted(time,start-1.)
        offset=float(np.quantile(imu[first:i+1,1]-time[first:i+1],.10))
        shifted=start+offset
        previous=np.searchsorted(wire[:,0],shifted-.10,side='right')-1
        if previous<0:
            continue
        for length in HORIZONS:
            stop=start+length
            if stop>terminal or stop>=time[-1]:
                continue
            j=np.searchsorted(time,stop,side='left')
            if np.max(np.diff(time[i:j+1]))>.11:
                continue
            exact=np.r_[time[i:j],stop]
            sensed=np.column_stack([np.interp(exact,time[i:j+1],axis) for axis in imu[i:j+1,2:].T])
            known=endpoint(exact,sensed[:,:3],sensed[:,3:],rotation,velocity)
            predicted_time=np.linspace(start,stop,int(np.ceil(length/.02))+1)
            tick=np.arange(shifted-.10,stop+offset+model.step,model.step)
            response=model.response(wire[previous:],tick)
            steady=np.column_stack([np.interp(predicted_time+offset,tick,axis) for axis in response.T])
            rate=steady[:,:3]
            thrust=np.c_[np.zeros((len(steady),2)),steady[:,3]]
            body=rotation.inv().apply(velocity)
            delta_force=imu[i,5:8]-thrust[0]+DRAG*body*abs(body)
            delta_rate=imu[i,2:5]-rate[0]
            t=predicted_time-start
            held=endpoint(predicted_time,np.broadcast_to(imu[i,2:5],rate.shape),
                          np.broadcast_to(imu[i,5:8],thrust.shape),rotation,velocity)
            forecasts=[]
            for memory in DECAY:
                retention=decay(t,memory)
                forecasts.append(endpoint(predicted_time,rate+retention*delta_rate,
                                           thrust+retention*delta_force,rotation,velocity,DRAG))
            difference=[]
            for p,q in (held,*forecasts):
                difference.append([float(np.linalg.norm(p-known[0])),
                                   float(np.degrees((known[1].inv()*q).magnitude()))])
            rows.append(dict(start=float(start-go),horizon=length,errors=difference))
    return rows


def summarize(laps,length):
    buckets=[]
    for lap in laps:
        selected=[row['errors'] for row in lap['rows'] if row['horizon']==length]
        if selected:
            buckets.append(np.quantile(selected,.90,axis=0))
    return np.median(buckets,axis=0),len(buckets)


def main():
    model_path=HERE/'recent-rate-authority.json'
    thrust_path=HERE/'force-model-holdout.json'
    model=CommandProjection(json.loads(model_path.read_text())['axes'],json.loads(thrust_path.read_text()))
    capture=HERE/'thrust-priority-go'
    groups={}
    for name,start,stop in [('calibration',941,982),('later',985,1049)]:
        traces=[]
        for i in range(start,stop+1):
            folder=capture/f'practice-{i}'
            if not (folder/'result.json').is_file() or not (folder/'learned-course.npz').is_file():
                continue
            result=json.loads((folder/'result.json').read_text())
            if not result['wire'] or result['interrupted'] or result['time_seconds'] is None:
                continue
            forecast=errors(folder,result,model)
            if forecast:
                traces.append(dict(lap=i,rows=forecast))
        groups[name]=traces
    calibration,_=summarize(groups['calibration'],.24)
    # Choose the residual memory using the position error on the earlier group.
    selected=int(np.argmin(calibration[1:,0]))+1
    aggregate={}
    for name,laps in groups.items():
        aggregate[name]=[]
        for length in HORIZONS:
            score,n=summarize(laps,length)
            aggregate[name].append(dict(horizon_s=length,laps=n,
                windows=sum(row['horizon']==length for lap in laps for row in lap['rows']),
                median_per_lap_p90=score.tolist(),held_imu=score[0].tolist(),calibrated=score[selected].tolist()))
    hashes={}
    for path in (model_path,thrust_path):
        with path.open('rb') as stream:
            hashes[path.name]=file_digest(stream,'sha256').hexdigest()
    record=dict(fit_inputs=hashes,columns=['position_m','attitude_deg'],
                methods=['held IMU',*[str(value)+' s residual memory' for value in DECAY]],
                selected=selected,summary=aggregate,laps=groups)
    (HERE/'actuator-state-witness.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(memory=record['methods'][selected],summary=aggregate)))


if __name__=='__main__':
    main()
