"""Measure short-horizon motion error given the same recorded command sequence."""

from argparse import ArgumentParser
import json
from pathlib import Path

import numpy as np
from scipy.signal import lfilter
from scipy.spatial.transform import Rotation

from rate_authority import observation, STEP
from thrust_forecast import HERE, features, plant


def predicted_rates(sent, command, imu, axes):
    estimate = []
    for index, axis in enumerate(axes):
        grid, demand, _, stamps, _ = observation((sent,command,imu[:,0],imu[:,2:5]),index,axis['delay_s'])
        predicted = np.clip(axis['gain']*demand+axis['bias_rad_s'],-axis['limit_rad_s'],axis['limit_rad_s'])
        if axis['lag_s']:
            decay = np.exp(-STEP/axis['lag_s'])
            predicted, _ = lfilter([1.-decay],[1.,-decay],predicted,zi=decay*predicted[:1])
        estimate.append(np.interp(stamps,grid,predicted))
    return np.asarray(estimate).T


def integrate_motion(time, gyro, force, rotation, velocity, drag=None):
    position = np.zeros(3)
    for interval, omega, accel in zip(np.diff(time),.5*(gyro[1:]+gyro[:-1]),.5*(force[1:]+force[:-1]),strict=True):
        half_step = Rotation.from_rotvec(.5*interval*omega)
        middle = rotation*half_step
        if drag is not None:
            v = middle.inv().apply(velocity)
            accel = accel-drag*v*abs(v)
        world = middle.apply(accel)+[0.,0.,9.81]
        position += interval*(velocity+.5*interval*world)
        velocity = velocity+interval*world
        rotation = middle*half_step
    return position, rotation, velocity


def endpoint(time, gyro, force, rotation, velocity, drag=None):
    return integrate_motion(time, gyro, force, rotation, velocity, drag)[:2]


def flight(folder, rate_model, force_model, maximum_gap):
    outcome = json.loads((folder/'result.json').read_text())
    if not outcome['wire'] or outcome['interrupted'] or outcome['time_seconds']<2.:
        return []
    if not (folder/'learned-course.npz').is_file():
        return []
    command_time, commands, imu, pose = plant.read(folder.name.removeprefix('practice-'))
    if len(imu)<30 or len(pose)<30:
        return []
    time, gyro, accel = imu[:,0], imu[:,2:5], imu[:,5:8]
    modeled_gyro = predicted_rates(command_time, commands, imu, rate_model)
    force_basis = features((command_time,commands,time,-accel[:,2]),force_model['delay_s'],force_model['lag_s'])
    thrust = -(force_basis@np.asarray(force_model['force_coefficients']))
    drag = np.array([.044,.043,0.])
    rows = []
    for start in np.searchsorted(time,np.arange(time[0],time[-1]-.10,.24)):
        state = np.searchsorted(pose[:,0],time[start],side='right')-1
        if state<0 or time[start]-pose[state,0]>.035:
            continue
        q = Rotation.from_quat(pose[state,4:8])
        v = pose[state,8:11]
        for horizon in (.24,.45,.60):
            target = time[start]+horizon
            stop = np.searchsorted(time,target)
            if stop>=len(time):
                continue
            window = slice(start,stop+1)
            t = time[window].copy()
            if (np.diff(t)>maximum_gap).any():
                continue
            ratio = (target-t[-2])/(t[-1]-t[-2])
            t[-1] = target

            def through(readings):
                values = readings[window].copy()
                values[-1] = values[-2]+ratio*(values[-1]-values[-2])
                return values

            gyro_window, accel_window = through(gyro), through(accel)
            gyro_prediction, thrust_window = through(modeled_gyro), through(thrust)
            measured, orientation = endpoint(t,gyro_window,accel_window,q,v)
            model_z = np.c_[accel_window[:,:2],thrust_window]
            pure_thrust = np.c_[np.zeros((len(t),2)),thrust_window]
            results = (endpoint(t,gyro_prediction,accel_window,q,v),
                       endpoint(t,gyro_window,model_z,q,v),
                       endpoint(t,gyro_prediction,pure_thrust,q,v,drag))
            rows.append(dict(horizon=horizon,stamp_s=float(time[start]),
                             position_m=[float(np.linalg.norm(pos-measured)) for pos,_ in results],
                             attitude_deg=[float(np.rad2deg((orientation.inv()*rot).magnitude())) for _,rot in results]))
    return rows


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('campaign',nargs='+',type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--maximum-imu-gap',type=float,default=.045)
    args = parser.parse_args()
    model = json.loads((HERE/'rate-authority.json').read_text())['axes']
    force = json.loads((HERE/'force-model-holdout.json').read_text())
    results = {}
    for campaign in args.campaign:
        plant.ROOT = campaign.resolve()
        trials = {path.parent.name:flight(path.parent,model,force,args.maximum_imu_gap)
                  for path in sorted(campaign.glob('practice-*/result.json'))}
        report = []
        for h in (.24,.45,.60):
            conditions = [row for rows in trials.values() for row in rows if row['horizon']==h]
            if conditions:
                report.append(dict(horizon_s=h,windows=len(conditions),
                                   position_p90_m=np.quantile([row['position_m'] for row in conditions],.90,axis=0).tolist(),
                                   attitude_p90_deg=np.quantile([row['attitude_deg'] for row in conditions],.90,axis=0).tolist()))
        results[campaign.name] = dict(trials=trials,horizons=report)
        print(campaign.name,report,flush=True)
    args.output.write_text(json.dumps(dict(arms=('gyro model','thrust model','whole plant'),
                                          maximum_imu_gap_s=args.maximum_imu_gap,results=results),
                                     indent=2,allow_nan=False)+'\n')
