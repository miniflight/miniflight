"""Fit delayed thrust response and test causal IMU correction on later whole laps."""

from argparse import ArgumentParser
from itertools import product
import json
from pathlib import Path
import sys

import numpy as np
from scipy.signal import lfilter

HERE = Path(__file__).resolve().parent
CHECKPOINT = HERE.parent / 'checkpoints/vq2-2026-11-23'
sys.path.insert(0, str(CHECKPOINT / 'research/execution-model'))
import plant


def design(commands):
    collective = 4. * (commands[:, 3] - .265)
    roll, pitch, yaw = (commands[:, :3] / 4.).T
    rate_sq = roll**2 + pitch**2 + yaw**2
    return np.column_stack((np.ones(len(commands)), collective, collective**2, rate_sq,
                            collective * rate_sq, collective**2 * rate_sq, roll**2 - pitch**2, yaw**2))


def features(record, delay, lag):
    sent, commands, stamp, _ = record
    if not lag:
        return design(commands[(np.searchsorted(sent, stamp - delay, side='right') - 1).clip(0)])
    step = .005
    grid = np.arange(sent[0] - .10, max(stamp[-1], sent[-1]) + step, step)
    held = commands[(np.searchsorted(sent, grid - delay, side='right') - 1).clip(0)]
    x = design(held)
    memory = np.exp(-step / lag)
    response, _ = lfilter([1. - memory], [1., -memory], x, axis=0, zi=memory*x[:1])
    return np.column_stack([np.interp(stamp, grid, value) for value in response.T])


def smooth(stamp, values, lag):
    filtered = values.copy()
    for i in range(1, len(values)):
        memory = np.exp(-(stamp[i] - stamp[i - 1]) / lag)
        filtered[i] = memory * filtered[i-1] + (1. - memory) * values[i]
    return filtered


def compare(records, idx, delay, lag, coef):
    return [features(records[i], delay, lag) @ coef - records[i][3] for i in idx]


def rms(residuals):
    return float(np.sqrt(np.mean([np.mean(values**2) for values in residuals])))


def read(campaign):
    plant.ROOT = campaign.resolve()
    records = {}
    for folder in sorted(campaign.glob('practice-*')):
        if not (folder/'result.json').is_file() or not (folder/'learned-course.npz').is_file():
            continue
        label = folder.name.removeprefix('practice-')
        score = json.loads((folder/'result.json').read_text())
        if score['interrupted'] or not score['wire'] or score['time_seconds'] < 1.5:
            continue
        with np.load(folder/'learned-course.npz', allow_pickle=False) as log:
            if len(log['send_ages']) < 5:
                continue
        sent, commands, imu, _ = plant.read(label)
        if len(imu) >= 28:
            records[int(label)] = (sent, commands, imu[:, 0], -imu[:, 7])
    return records


def identify(records):
    order = sorted(records)
    train, valid, test = np.split(order, [len(order)*5//10, len(order)*7//10])
    theta = np.array(json.loads((CHECKPOINT/'controller/flight-controls/current-actuators/response.json')
                     .read_text())['selected']['coefficients'])
    best = None
    fit = [records[i] for i in train]
    y = np.concatenate([r[3] for r in fit])
    for delay, lag in product((0., .005, .010, .015, .020, .030), (0., .008, .016, .032, .064)):
        x = np.concatenate([features(r, delay, lag) for r in fit])
        weights = np.ones_like(y)
        for _ in range(3):
            x_w = x * weights[:, None]
            coef = np.linalg.solve(x_w.T @ x + .25*np.eye(x.shape[1]), x_w.T @ y + .25*theta)
            weights = np.minimum(1., 1.5/np.maximum(.01, abs(x @ coef - y)))
        validation = rms(compare(records, valid, delay, lag, coef))
        if best is None or validation < best[0]:
            best = validation, delay, lag, coef
    validation, delay, lag, coef = best
    predictive = {}
    for horizon in (.06, .10):
        # At t, a correction has access to IMU measurements through t-horizon.
        # Future commanded inputs are available to the forecast as the action to score.
        def innovations(ids, residual, decay):
            pairs = []
            for i, error in zip(ids, residual, strict=True):
                stamp = records[i][2]
                previous = np.searchsorted(stamp, stamp-horizon, side='right')-1
                usable = (previous >= 0) & (stamp-stamp[previous] <= horizon+.075)
                pairs.append((error[usable], smooth(stamp, error, decay)[previous[usable]]))
            return pairs
        calibration = compare(records, valid, delay, lag, coef)
        candidates = []
        for decay in (.06, .12, .24, .48):
            pairs = innovations(valid, calibration, decay)
            target, source = map(np.concatenate, zip(*pairs, strict=True))
            gain = float(np.clip((target@source)/(source@source), 0., 1.))
            candidates.append((rms([e - gain*b for e,b in pairs]), decay, gain))
        _, decay, gain = min(candidates)
        pairs = innovations(test, compare(records, test, delay, lag, coef), decay)
        predictive[str(horizon)] = {'residual_lag_s': decay, 'residual_gain': gain,
                                   'open_loop_rms_m_s2': rms([e for e,_ in pairs]),
                                   'causal_rms_m_s2': rms([e-gain*b for e,b in pairs])}
    return {'training_laps': train.tolist(), 'validation_laps': valid.tolist(), 'held_out_laps': test.tolist(),
            'delay_s': delay, 'lag_s': lag, 'coefficients': coef.tolist(), 'validation_rms_m_s2': validation,
            'archived_rms_m_s2': rms(compare(records, test, .005, 0., theta)),
            'refitted_rms_m_s2': rms(compare(records, test, delay, lag, coef)),
            'conditional_horizon': predictive}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('campaign', type=Path)
    args = parser.parse_args()
    records = read(args.campaign)
    if len(records) < 20:
        raise ValueError('Whole-lap train, selection and holdout require at least 20 runs')
    result = identify(records)
    (HERE/'thrust-forecast-holdout.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps({key: result[key] for key in ('delay_s', 'lag_s', 'archived_rms_m_s2',
                                                  'refitted_rms_m_s2', 'conditional_horizon')}))
