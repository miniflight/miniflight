"""Compare saved and current VQ2 flights using public telemetry and aperture images."""
from argparse import ArgumentParser
from base64 import b64decode
import gzip
import json
from pathlib import Path
import struct
import sys

import cv2
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from pymavlink.dialects.v20 import common as mavlink
from scipy.spatial.transform import Rotation, Slerp

HERE = Path(__file__).resolve().parent
CHECKPOINT = HERE.parent / 'checkpoints/vq2-2026-11-23'
FROZEN = CHECKPOINT / 'controller'
sys.path[:0] = [
    str(FROZEN / 'repo'),
    str(FROZEN / 'repo/work/pose-odometry'),
    str(FROZEN / 'dependencies/rednose_repo'),
    str(FROZEN / 'flight-controls/partial-relock'),
]
from fly_learned_course import APERTURE, gate_masks
from mapped import CAMERA_FROM_BODY, K, apertures
from refine_gate_map import read_packet_map
from relock import candidates
from rim import CHASSIS_RADIUS


def wire(folder, go):
    incoming = mavlink.MAVLink(None)
    outgoing = mavlink.MAVLink(None)
    samples, commands, ticks, splits = [], [], [], {}
    with gzip.open(folder / 'flight.jsonl.gz', 'rt') as stream:
        for row in map(json.loads, stream):
            if row.get('name') == 'poll':
                for packet in row['result']:
                    if packet['camera']:
                        continue
                    for msg in incoming.parse_buffer(b64decode(packet['wire'])) or ():
                        if msg.get_type() == 'HIGHRES_IMU':
                            stamp = msg.time_usec * 1e-6
                            if not samples or stamp > samples[-1][0]:
                                samples.append((stamp, packet['received_at'],
                                                -msg.xgyro, -msg.ygyro, -msg.zgyro))
                        elif msg.get_type() == 'ENCAPSULATED_DATA' and msg.data[0] == 1:
                            _, _, start, _, gates, last = struct.unpack_from('<BQqqIq', bytes(msg.data))
                            if start == round(go * 1000) and gates and last >= 0:
                                splits.setdefault(gates, last * 1e-9)
            elif row['event'] == 'outgoing':
                for msg in outgoing.parse_buffer(b64decode(row['wire'])) or ():
                    if msg.get_type() == 'SET_ATTITUDE_TARGET':
                        commands.append((row['host_time'], -msg.body_roll_rate,
                                         -msg.body_pitch_rate, -msg.body_yaw_rate, msg.thrust))
            elif row['event'] == 'update':
                status = row.get('native_race') or {}
                if status.get('started'):
                    ticks.append((row['host_time'], status['active_gate_index']))
    if not (samples and commands and ticks):
        raise ValueError(f'Missing IMU, commands or race ticks in {folder}')
    samples, commands, ticks = map(np.asarray, (samples, commands, ticks))
    rate, _ = np.polyfit(samples[:, 0], samples[:, 1], 1)
    origin = np.quantile(samples[:, 1] - rate * samples[:, 0], .10)
    host_to_race = lambda times: (times - origin) / rate - go
    sent = host_to_race(commands[:, 0])
    # Use commands in the wire trace. The final disarm packet is out of flight.
    armed = sent >= 0.
    for stamp, gate in zip(host_to_race(ticks[:, 0]), ticks[:, 1].astype(int), strict=True):
        if gate > 0 and gate not in splits:
            splits[gate] = float(stamp)
    return samples[:, 0] - go, samples[:, 2:5], sent[armed], commands[armed, 1:], splits


def coverage(z, go, start, end, target):
    views = z['visibility']
    camera = z['camera']
    mask = (views[:, 0] >= go + start) & (views[:, 0] <= go + end) & (views[:, 1] == target)
    good = views[mask & (views[:, 2] > 0), 0] - go
    detections = z['detections']
    detectable = detections[mask, 1] > 0
    return {
        'frames': int(mask.sum()),
        'with_full_opening': int(detectable.sum()),
        'with_active_metric_update': int(len(good)),
        'last_metric_age_s': float(end - good[-1]) if len(good) else None,
        'frame_processing_p95_ms': float(1000 * np.quantile(camera[mask, 4], .95)) if mask.any() else None,
    }


def visual_witness(folder, z, course, gate, go):
    keyframes = next((folder / name for name in ('scene-keyframes.npz', 'failure-frames.npz')
                      if (folder / name).is_file()), None)
    if keyframes is None:
        return []
    sample_time, idx = np.unique(z['pose'][:, 0], return_index=True)
    poses = z['pose'][idx]
    attitude = Slerp(sample_time, Rotation.from_quat(poses[:, 4:8]))
    plane = Rotation.from_quat(course[gate, 3:])
    center = course[gate, :3]
    choices = [(i, Rotation.from_quat(course[i, 3:]).apply(APERTURE) + course[i, :3])
               for i in range(max(0, gate - 2), min(len(course), gate + 3))]
    rows = []
    with np.load(keyframes, allow_pickle=False) as raw:
        jpeg, offsets, times = raw['jpeg'], raw['offsets'], raw['time']
        for t, a, b in zip(times, offsets[:-1], offsets[1:], strict=True):
            if t <= max(go, sample_time[0]) or t >= sample_time[-1]:
                continue
            p, v = np.array([np.interp(t, sample_time, col) for col in poses[:, [1, 2, 3, 8, 9, 10]].T]).reshape(2, 3)
            local, velocity = plane.inv().apply([p - center, v])
            if not .45 < -local[0] < 12. or velocity[0] < 3.:
                continue
            image = cv2.imdecode(jpeg[a:b], cv2.IMREAD_COLOR)
            mask, color = gate_masks(image)
            outlines = list(apertures(image, mask=mask, color=color))
            hypotheses = candidates(p, attitude(t), choices, outlines)
            match = next((h for h in hypotheses if h.index == gate), None)
            if match is None or match.rms > 2.3 or any(
                    h.index != gate and h.outline == match.outline and h.cost < match.cost + 1.5
                    for h in hypotheses):
                continue
            correction = plane.inv().apply(match.offset)
            fit = local + correction
            transverse = velocity[1:] / velocity[0]
            onboard = local[1:] - local[0] * transverse
            optical = fit[1:] - fit[0] * transverse
            rows.append({
                'seconds': float(t - go), 'depth_m': float(-local[0]),
                'visual_offset_m': correction.tolist(),
                'onboard_intercept_m': onboard.tolist(), 'optical_intercept_m': optical.tolist(),
                'fit_px': float(match.rms), 'before_px': float(match.before),
            })
    return rows


def measure(folder, label, gate=None, figure=False):
    result = json.loads((folder / 'result.json').read_text())
    if not (result.get('wire') and (folder / 'learned-course.npz').is_file()):
        return None
    manifest = json.loads((folder / 'manifest.json').read_text())
    plan = Path(manifest['inputs']['plan']['path'])
    with np.load(plan, allow_pickle=False) as n:
        cap = json.loads(str(n['config']))['max_rate']
    go = .001 * result['wire']['race_start_boot_time_ms']
    t, rates, sent, u, credited = wire(folder, go)
    target = gate - 1 if gate is not None else min(16, result['active_gate_index'])
    if target and target not in credited:
        return None
    start = credited.get(target, 0.)
    end = credited.get(target + 1, float(result['time_seconds']))
    commands = (sent >= start) & (sent <= end)
    sensed = (t >= start) & (t <= end)
    model = np.column_stack([np.interp(t[sensed] - delay, sent, col)
                             for delay, col in zip((.01, .01, .02), u[:, :3].T, strict=True)])
    course = read_packet_map(folder / 'gate-map-in.json')
    with np.load(folder / 'learned-course.npz', allow_pickle=False) as z:
        supports = coverage(z, go, start, end, target)
        check = z['crossing_checks']
        check = check[check[:, 1] == target]
        accepted = check[check[:, -1] > 0]
        estimate = float(accepted[-1, 7]) if len(accepted) else None
        witness = visual_witness(folder, z, course, target, go)
        innovations = z['pixel_innovations']
        i = (innovations[:, 0] >= start + go) & (innovations[:, 0] <= end + go)
        innovation_p90 = float(np.quantile(innovations[i, 1], .9)) if i.any() else None
        prediction = z['plan_times']
        k = (prediction[:, 0] >= start + go) & (prediction[:, 0] <= end + go)
        plan_p95 = float(1000 * np.quantile(prediction[k, 1], .95)) if k.any() else None
        age = z['send_ages']
        s = (age[:, 0] >= age[0, 0] + start) & (age[:, 0] <= age[0, 0] + end)
        imu_age = float(1000 * np.quantile(age[s, 1], .95)) if s.any() else None
    native_finish_ns = result['wire']['race_finish_time_ns']
    clean = (result['clean_full'] and result['completed'] and result['contacts'] == 0
             and result['wire']['active_gate_index'] == 17
             and abs(native_finish_ns * 1e-9 - result['time_seconds']) < 1e-6)
    track_rms = np.sqrt(np.mean((rates[sensed] - model) ** 2, axis=0)).tolist() if sensed.any() else None
    norms = np.linalg.norm(u[commands, :3], axis=1)
    observed = np.array([r['visual_offset_m'][1:] for r in witness])
    row = {
        'series': label, 'lap': int(folder.name.removeprefix('practice-')), 'gate': target + 1,
        'native_gates': result['active_gate_index'], 'completed_clean': clean,
        'contacts': result['contacts'], 'result_s': result['time_seconds'],
        'window_s': [start, end], 'estimated_clearance_m': estimate,
        'vision': supports, 'fitted_apertures': witness,
        'optical_cross_axis_offset_median_m': float(np.median(np.linalg.norm(observed, axis=1))) if len(observed) else None,
        'pixel_innovation_p90_px': innovation_p90,
        'plan_compute_p95_ms': plan_p95, 'imu_receipt_age_p95_ms': imu_age,
        'body_rate_cap': cap, 'rate_cap_duty': float(np.mean(norms >= cap - .001)) if len(norms) else None,
        'gyro_tracking_rms_rad_s': track_rms,
    }
    if figure:
        row['_figure'] = (t[sensed], rates[sensed], sent[commands], u[commands])
    return row


def plot(rows, out):
    picked = [r for r in rows if '_figure' in r]
    if not picked:
        return
    fig, ax = plt.subplots(3, len(picked), figsize=(4 * len(picked), 6.5), squeeze=False, layout='constrained')
    for column, row in enumerate(picked):
        left, right = row['window_s']
        ax[0, column].set_title(f'{row["series"]} {row["lap"]} · gate {row["gate"]}\n'
                               f'{row["native_gates"]}/17 · {row["contacts"]} contacts', fontsize=9)
        for r in row['fitted_apertures']:
            time = r['seconds'] - right
            ax[0, column].scatter(time, np.linalg.norm(r['visual_offset_m'][1:]), c='#007969', s=14)
            ax[1, column].scatter(time, np.max(np.abs(r['onboard_intercept_m'])), c='#5f606b', s=14)
            ax[1, column].scatter(time, np.max(np.abs(r['optical_intercept_m'])), c='#af5721', s=14)
        t, rates, sent, cmd = row.pop('_figure')
        ax[1, column].axhline(.75 - CHASSIS_RADIUS, color='#a43939', lw=.8, ls=':')
        ax[2, column].plot(t - right, np.linalg.norm(rates, axis=1), color='#007969', lw=1.)
        ax[2, column].step(sent - right, np.linalg.norm(cmd[:, :3], axis=1), where='post', color='#af5721', lw=.9)
        ax[2, column].axhline(row['body_rate_cap'], color='#a43939', lw=.8, ls=':')
        for axis in ax[:, column]:
            axis.set_xlim(left - right, 0.)
            axis.grid(alpha=.2)
        ax[2, column].set_xlabel('Seconds to end of approach')
    for axis, label in zip(ax[:, 0], ('Aperture-fit lateral offset (m)', 'Projected crossing error (m)',
                                     'Body rate magnitude (rad/s)'), strict=True):
        axis.set_ylabel(label)
    fig.suptitle('Independent aperture fit · estimated intercept and optical intercept · requested and measured rates')
    fig.savefig(out, dpi=160)
    plt.close(fig)


def plot_projections(flights):
    offsets = np.array([-.80, -.58, -.38, -.20, -.07])
    fig, grid = plt.subplots(len(flights), len(offsets), figsize=(12, 2.0 * len(flights)),
                             squeeze=False, layout='constrained')
    for axes, (folder, label, gate) in zip(grid, flights, strict=True):
        result = json.loads((folder / 'result.json').read_text())
        go = .001 * result['wire']['race_start_boot_time_ms']
        *_, splits = wire(folder, go)
        end = splits.get(gate, result['time_seconds'])
        course = read_packet_map(folder / 'gate-map-in.json')
        center = course[gate - 1, :3]
        opening = Rotation.from_quat(course[gate - 1, 3:]).apply(APERTURE) + center
        with np.load(folder / 'learned-course.npz', allow_pickle=False) as z:
            times, idx = np.unique(z['pose'][:, 0], return_index=True)
            pose = z['pose'][idx]
            attitude = Slerp(times, Rotation.from_quat(pose[:, 4:8]))
            visibility = z['visibility']
        with np.load(folder / 'scene-keyframes.npz', allow_pickle=False) as z:
            image_time, jpeg, indices = z['time'], z['jpeg'], z['offsets']
            available = (image_time >= times[0]) & (image_time <= times[-1]) & (image_time <= end + go)
            for ax, offset in zip(axes, offsets, strict=True):
                ax.axis('off')
                error = np.where(available, np.abs(image_time - end - go - offset), np.inf)
                i = np.argmin(error)
                if error[i] > .23:
                    continue
                stamp = image_time[i]
                camera = cv2.imdecode(jpeg[indices[i]:indices[i + 1]], cv2.IMREAD_COLOR)
                position = np.array([np.interp(stamp, times, col) for col in pose[:, 1:4].T])
                points = (opening - position) @ (CAMERA_FROM_BODY @ attitude(stamp).as_matrix().T).T
                ax.imshow(cv2.cvtColor(camera, cv2.COLOR_BGR2RGB))
                if points[:, 2].min() > .05:
                    px = points[:, :2] / points[:, 2:] * np.diag(K)[:2] + K[:2, 2]
                    quad = np.r_[px, px[:1]]
                    ax.plot(*quad.T, c='#a7f4ca', lw=1.25)
                    ax.set_xlim(0, camera.shape[1])
                    ax.set_ylim(camera.shape[0], 0)
                obs = visibility[np.argmin(abs(visibility[:, 0] - stamp))]
                ax.set_title(f'{label} · {stamp - go - end:+.2f} s · target {int(obs[1])+1}\n'
                             f'active gate metric update {int(obs[2])}', fontsize=7)
    fig.suptitle('Gate 8 approach · aperture projected using onboard pose in green', fontsize=10)
    fig.savefig(HERE / 'gate-8-images.png', dpi=160)
    plt.close(fig)


def main():
    p = ArgumentParser(description=__doc__)
    p.add_argument('--fast', default='baseline')
    p.add_argument('--reference', default='phase-reference')
    args = p.parse_args()
    cv2.setNumThreads(1)
    K[:2, 2] = (319.5, 179.5)
    requests = [
        (CHECKPOINT / 'native/practice-1658', 'archive', 8, False),
        (CHECKPOINT / 'native/practice-1671', 'archive', 8, True),
        (CHECKPOINT / 'native/practice-1664', 'archive', 8, False),
        (CHECKPOINT / 'native/practice-1667', 'archive', 8, False),
        (CHECKPOINT / 'native/practice-1668', 'archive', 8, False),
        (CHECKPOINT / 'native/practice-1673', 'archive', 8, False),
    ]
    for tag in [args.fast, args.reference]:
        for lap in sorted((HERE / tag).glob('practice-*')):
            if (lap / 'result.json').is_file():
                requests.append((lap, tag, None, tag == args.fast and lap.name in ('practice-06', 'practice-08', 'practice-10')))
    rows = [result for request in requests if (result := measure(*request)) is not None]
    plot(rows, HERE / 'crossing-diagnosis.png')
    plot_projections([
        (CHECKPOINT / 'native/practice-1671', '19.928 s finish', 8),
        (HERE / args.fast / 'practice-08', 'Fast lap 8', 8),
        (HERE / args.fast / 'practice-10', 'Fast lap 10', 8),
    ])
    (HERE / 'crossing-diagnosis.json').write_text(json.dumps(rows, indent=2, allow_nan=False) + '\n')
    for row in rows:
        print(row['series'], row['lap'], 'gate', row['gate'], row['native_gates'], row['contacts'],
              'metric frames', row['vision']['with_active_metric_update'],
              'optical offset', row['optical_cross_axis_offset_median_m'],
              'rate cap duty', row['rate_cap_duty'])


if __name__ == '__main__':
    main()
