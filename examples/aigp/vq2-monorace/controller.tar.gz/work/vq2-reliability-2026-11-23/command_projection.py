"""Propagate the latest IMU observation with the response to sent commands."""

import numpy as np
from scipy.signal import lfilter

from rednose_model import integrate


class CommandProjection:
    step = .005

    def __init__(self, axes, thrust):
        self.rate_gain = np.array([axis['gain'] for axis in axes])
        self.rate_bias = np.array([axis['bias_rad_s'] for axis in axes])
        self.rate_limit = np.array([axis['limit_rad_s'] for axis in axes])
        self.delay = np.array([*(axis['delay_s'] for axis in axes), thrust['delay_s']])
        lag = np.array([*(axis['lag_s'] for axis in axes), thrust['lag_s']])
        self.decay = np.exp(-self.step/lag.clip(1e-5))
        self.thrust = np.asarray(thrust['force_coefficients'])

    def equilibrium(self, request):
        body = request[...,:3,:3].diagonal(axis1=-2,axis2=-1)
        rate = np.clip(body*self.rate_gain+self.rate_bias,-self.rate_limit,self.rate_limit)
        roll,pitch,yaw=np.moveaxis(request[...,3,:3],-1,0)/4.
        collective = 4.*(request[...,3,3]-.265)
        norm = roll**2+pitch**2+yaw**2
        design = np.stack((np.ones_like(norm),collective,collective**2,norm,
                           collective*norm,collective**2*norm,roll**2-pitch**2,yaw**2),axis=-1)
        return np.concatenate((rate,(-design@self.thrust)[...,None]),axis=-1)

    def response(self, history, time):
        sent = np.asarray(history)
        request = sent[(np.searchsorted(sent[:,0],time[:,None]-self.delay,side='right')-1).clip(0),1:]
        steady = self.equilibrium(request)
        for i, decay in enumerate(self.decay):
            steady[:,i], _ = lfilter([1.-decay],[1.,-decay],steady[:,i],zi=decay*steady[:1,i])
        return steady

    def anchored_response(self, history, start, end, stamps, offset):
        grid = np.arange(start+offset-.10, end+offset+self.step, self.step)
        response = self.response(history, grid)
        time = np.r_[start, stamps, end]
        values = np.column_stack([np.interp(time+offset, grid, axis) for axis in response.T])
        fraction = ((time[1:-1]-start)/(end-start))[:, None]
        return values[1:-1]-values[0]-fraction*(values[-1]-values[0])

    def predict(self, clock, state, reading, now, history):
        duration = clock.horizon(now)
        if duration<=0. or len(history)<3:
            return None
        first = reading[0]+clock.offset()
        if history[0][0]>first-.025 or history[-1][0]<first-.06:
            return None
        elapsed = np.arange(-.075,duration+self.step,self.step)
        response = self.response(history,first+elapsed)
        edges = np.linspace(0.,duration,int(np.ceil(duration/.02))+1)
        middle = .5*(edges[1:]+edges[:-1])
        changes = np.array([np.interp(middle,elapsed,values)-np.interp(0.,elapsed,values) for values in response.T]).T
        state = state.copy()
        sample = np.asarray(reading).copy()
        for step, delta in zip(np.diff(edges),changes,strict=True):
            sample[3] = reading[3]+delta[3]
            sample[4:7] = reading[4:7]+delta[:3]
            integrate(state,step,sample)
        return state
