"""Fit actual body-rate authority from public command and IMU pairs."""

from argparse import ArgumentParser
import json
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares
from scipy.signal import lfilter

from measure import HERE
from target.aigp.experiments.flight_response import describe, evidence, signals, STEP


def observation(flight, axis, delay):
    sends, commands, stamps, measured = flight
    grid = np.arange(sends[0]-.10, stamps[-1]+STEP, STEP)
    held = commands[(np.searchsorted(sends, grid-delay, side='right')-1).clip(0), :3]
    return grid, held[:, axis], (held**2).sum(axis=1), stamps, measured[:, axis]


def residuals(records, predict, lag):
    answer = []
    for grid, request, rate_squared, stamps, observed in records:
        prediction = predict(request, rate_squared)
        if lag:
            pole = np.exp(-STEP/lag)
            prediction, _ = lfilter([1.-pole], [1., -pole], prediction, zi=pole*prediction[:1])
        answer.append(np.interp(stamps, grid, prediction)-observed)
    return np.concatenate(answer)


def fit_axis(training, held_out, axis, prior):
    delay, lag = prior['delay_s'], prior['time_constant_s']
    train = [observation(f, axis, delay) for f in training]
    check = [observation(f, axis, delay) for f in held_out]

    def saturating(parameters):
        gain, bias, limit = parameters
        return lambda command, _: np.clip(gain*command+bias, -limit, limit)

    fitted = least_squares(lambda parameters: residuals(train, saturating(parameters), lag),
                           [1., 0., 3.], bounds=([.2, -.6, 1.], [1.8, .6, 8.]),
                           loss='soft_l1', f_scale=.22, max_nfev=40)
    gain, bias, limit = fitted.x
    previous = lambda command, squared: prior['bias']+command*(prior['gain']+prior['gain_per_rate_squared']*squared)
    old, new = (residuals(check, model, lag) for model in (previous, saturating(fitted.x)))
    samples = np.concatenate([np.interp(row[3], row[0], row[1]) for row in check])
    rms = lambda values: float(np.sqrt(np.mean(values**2)))
    return {'axis': prior['axis'], 'delay_s': delay, 'lag_s': lag,
            'gain': float(gain), 'bias_rad_s': float(bias), 'limit_rad_s': float(limit),
            'old_rms_rad_s': rms(old), 'saturating_rms_rad_s': rms(new),
            'holdout_samples': len(samples), 'saturation_samples': int(np.sum(np.abs(gain*samples+bias) > limit))}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('campaign', type=Path)
    parser.add_argument('output', type=Path, nargs='?', default=HERE/'rate-authority.json')
    args = parser.parse_args()
    folders = sorted((item.parent for item in args.campaign.glob('practice-*/result.json')),
                     key=lambda p: int(p.name.split('-')[-1]))
    flights = []
    for folder in folders:
        trace = folder/'flight.jsonl.gz'
        if trace.is_file() and (sample := signals(trace)) is not None:
            flights.append((folder.name, sample))
    if len(flights) < 52:
        raise ValueError('Need at least 36 training laps and 16 later laps')
    train = [flight for _, flight in flights[:36]]
    check = [flight for _, flight in flights[36:52]]
    baseline = describe(sum(map(evidence, train)))
    result = {'training': [name for name, _ in flights[:36]],
              'held_out': [name for name, _ in flights[36:52]],
              'axes': [fit_axis(train, check, axis, prior) for axis, prior in enumerate(baseline[:3])]}
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps(result['axes']))
