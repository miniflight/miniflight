"""Identify direct motor force and angular response from held commands and IMU."""

from argparse import ArgumentParser
from base64 import b64decode
from collections import defaultdict
from dataclasses import dataclass
import gzip
import json
from pathlib import Path

import numpy as np
from pymavlink.dialects.v20 import common
from scipy.optimize import nnls

from actuator_state_witness import signals
from go_audit import start_trace
from target.aigp import MOTOR_MIX
from vertical_tracking import digest


AXES = ('roll','pitch','yaw')
MIX = np.asarray(MOTOR_MIX,dtype=float)
MOTOR_LAG = .020
MOTOR_TRANSPORT = .005
MOTOR_IMU_TIMEOUT = .12


def load_axial_drag(path):
    gain = float(json.loads(path.read_text())['signed_drag_at_fixed_thrust']['quadratic']['gain'])
    if not np.isfinite(gain) or gain<0.:
        raise ValueError('Expected a nonnegative axial drag coefficient')
    return gain


class MotorResponse:
    def __init__(self, force, axes, idle=0.):
        self.force = np.asarray(force)
        self.idle = idle
        self.gain,self.damping = (np.array([axis[key] for axis in axes]) for key in
                                  ('angular_acceleration_gain','damping_per_s'))

    @classmethod
    def from_report(cls, report):
        return cls(report['force_coefficients'],report['axes'],report.get('motor_idle_input',0.))

    def wrench(self, motors):
        motors = np.maximum(0.,np.asarray(motors)-self.idle)
        forces = (self.force[0]+self.force[1]*motors)*motors
        return (forces@MIX)*.25

    def rotor_speed(self, motors):
        active = np.maximum(0.,np.asarray(motors)-self.idle)
        force = (self.force[0]+self.force[1]*active)*active
        top = self.wrench(np.ones(4))[0]
        return 2.*np.sqrt(force/top)-1.

    def transfer(self, elapsed):
        time = np.asarray(elapsed)[...,None]
        decay = np.exp(-time*self.damping)
        integral = np.divide(-np.expm1(-time*self.damping),self.damping,
                             out=np.broadcast_to(time,decay.shape).copy(),where=self.damping>0.)
        return decay,integral

    def hold(self, motors, rate, elapsed):
        decay,integral = self.transfer(elapsed)
        return decay*rate+integral*self.gain*self.wrench(motors)[...,1:]

    def torque(self, before, after, elapsed):
        decay,integral = self.transfer(elapsed)
        return (after-decay*before)/(integral*self.gain)

    def motors(self, force, torque):
        """Invert the mixer in force space. The caller checks the command bounds."""
        requested = np.concatenate((np.asarray(force)[...,None],torque),axis=-1)
        thrust = requested@MIX.T
        linear,quadratic = self.force
        scale = linear+np.sqrt(linear**2+4.*quadratic*abs(thrust))
        return self.idle+np.divide(2.*thrust,scale,out=np.zeros_like(thrust),where=scale>0.)

    def rate_command(self, force, measured, wanted, horizon, upper):
        torque = self.torque(measured,wanted,horizon)
        difference = torque@MIX[:,1:].T
        maximum = self.wrench(np.full(4,upper))[0]
        if not 0.<=force<=maximum:
            raise ValueError('Collective force exceeds the measured motor range')
        available = np.where(difference>0.,maximum-force,force)
        scale = min(1.,np.min(available/np.maximum(abs(difference),1.e-12)))
        return self.motors(force,scale*torque)

    def limit_rate_support(self, motors, rates, body_rates=None, window=None):
        """Reduce motor force differences while preserving collective force."""
        wrench = self.wrench(motors)
        torque = wrench[...,1:]
        if window is None:
            free = np.zeros_like(torque)
            change = torque*self.gain/self.damping
        else:
            decay,impulse = self.transfer(window)
            free = decay*body_rates
            change = impulse*self.gain*torque
        headroom = np.maximum(rates,abs(free))-np.sign(change)*free
        scale = np.divide(headroom,abs(change),out=np.ones_like(change),where=abs(change)>0.)
        scale = np.minimum(1.,np.min(scale,axis=-1))[...,None]
        projected = self.motors(wrench[...,0],torque*scale)
        return np.where(scale<1.,projected,motors)


def motor_packets(path):
    decoder = common.MAVLink(None)
    decoder.robust_parsing = True
    packets = []
    with gzip.open(path,'rt') as stream:
        for event in map(json.loads,stream):
            if event['event']=='outgoing':
                packets.extend((event['host_time'],*message.controls[:4]) for message in
                               decoder.parse_buffer(b64decode(event['wire'])) or ()
                               if message.get_type()=='SET_ACTUATOR_CONTROL_TARGET')
    return np.asarray(packets).reshape(-1,5)


@dataclass
class Pulse:
    key: tuple
    wire: np.ndarray
    time: np.ndarray
    imu: np.ndarray
    entry: dict

    @classmethod
    def measured(cls, folder, experiment):
        path = folder/'flight.jsonl.gz'
        packets = motor_packets(path)
        axis = experiment.get('motor_axis','pitch')
        delivered = start_trace(folder)
        entry = dict(campaign=folder.parent.name,attempt=experiment['attempt'],axis=axis,
                     effort=experiment['motor_torque_effort'],collective=experiment['level'],contacts=experiment['contacts'],
                     powered_after_go_ms=delivered.get('power_after_go_ms'),trace_sha256=digest(path),motor_packets=len(packets))
        if not len(packets):
            return None,entry
        if not np.allclose(packets[:,1:],packets[0,1:]) or not (0.<=packets[:,1:]).all() or not (packets[:,1:]<=1.).all():
            raise ValueError(f'Expected one bounded motor command in {folder}')
        with np.load(folder/'learned-course.npz',allow_pickle=False) as source:
            pose = source['pose']
        if not len(pose):
            return None,entry
        imu,_ = signals(folder,np.median(pose[:,12]-pose[:,0]))
        if len(imu)<3:
            return None,entry
        offset = float(np.quantile(imu[:,1]-imu[:,0],.1))
        spent = imu[:,0]+offset-packets[0,0]
        keep = (spent>=.025)&(spent<=packets[-1,0]-packets[0,0])
        spent,imu = spent[keep],imu[keep,2:]
        entry.update(usable_imu_samples=len(spent),wire=packets[0,1:].tolist(),
                     hold_s=float(packets[-1,0]-packets[0,0]))
        if len(spent)<3:
            return None,entry
        channel = AXES.index(axis)
        sign = experiment.get('motor_torque_sign',np.sign(experiment.get('pitch_request_rad_s',1.)))
        late = spent>=spent[-1]-.10
        entry.update(peak_rate_rad_s=float((sign*imu[:,channel]).max()),
                     late_rate_rad_s=float(np.median(sign*imu[late,channel])),force_m_s2=float(np.median(-imu[late,5])))
        return cls((axis,entry['effort'],entry['collective']),packets[0,1:],spent,imu,entry),entry


def identify_force(pulses, fit_idle):
    motor = np.array([pulse.wire for pulse in pulses])
    force = [pulse.entry['force_m_s2'] for pulse in pulses]
    candidates = np.linspace(0.,.21,85) if fit_idle else [0.]
    best = None
    for idle in candidates:
        active = np.maximum(0.,motor-idle)
        design = np.column_stack((active.mean(axis=1),(active**2).mean(axis=1)))
        coefficient,residual = nnls(design,force)
        if best is None or residual<best[0]:
            best = residual,coefficient,float(idle)
    return best[1:]


def identify_axis(pulses, force, idle, index):
    name = AXES[index]
    previous = np.concatenate([p.imu[:-1,index] for p in pulses])
    measured = np.concatenate([p.imu[1:,index] for p in pulses])
    elapsed = np.concatenate([np.diff(p.time) for p in pulses])
    motors = np.maximum(0.,np.array([p.wire for p in pulses])-idle)
    moments = ((force[0]+force[1]*motors)*motors)@MIX[:,index+1]*.25
    torque = np.repeat(moments,[len(p.time)-1 for p in pulses])
    best = None
    for damping in np.r_[0.,np.geomspace(.08,1./.015,180)]:
        retain = np.exp(-elapsed*damping)
        design = torque*(-np.expm1(-elapsed*damping)/damping if damping else elapsed)
        gain = (design@(measured-retain*previous))/(design@design)
        error = retain*previous+design*gain-measured
        score = float(np.mean(error**2))
        if gain>0. and (best is None or score<best[0]):
            best = score,dict(axis=name,angular_acceleration_gain=float(gain),damping_per_s=float(damping),intervals=len(elapsed))
    if best is None:
        raise ValueError(f'No positive motor response for {name}')
    return best[1]


def summarize(model, data):
    error = []
    force = []
    for pulse in data:
        intervals = np.diff(pulse.time)
        before,after = pulse.imu[:-1,:3],pulse.imu[1:,:3]
        error.extend(model.hold(pulse.wire,before,intervals)-after)
        force.append(float(model.wrench(pulse.wire)[0]-pulse.entry['force_m_s2']))
    return dict(laps=len(data),gyro_intervals=len(error),
                gyro_rms_rad_s=np.sqrt(np.mean(np.square(error),axis=0)).tolist(),
                force_mae_m_s2=float(np.mean(np.abs(force))))


def run(campaigns, output, fit_idle):
    groups = defaultdict(list)
    entries = []
    for root in campaigns:
        for row in json.loads((root/'collective-comparison.json').read_text()):
            pulse,entry = Pulse.measured(root/f"practice-{row['attempt']:02d}",row)
            entries.append(entry)
            if pulse is not None and not entry['contacts'] and (entry['powered_after_go_ms'] or 0.)>0.:
                groups[pulse.key].append(pulse)
    train = [p for rows in groups.values() for p in rows[:1]]
    test = [p for rows in groups.values() for p in rows[1:]]
    if not train or not test:
        raise ValueError('Need both identification and separate validation pulses')
    force,idle = identify_force(train,fit_idle)
    axes = [identify_axis(train,force,idle,i) for i in range(3)]
    model = MotorResponse(force,axes,idle)
    result = dict(force_coefficients=force.tolist(),motor_idle_input=idle,axes=axes,training=summarize(model,train),
                  held_out=summarize(model,test),pulses=entries,
                  observed_motor_bounds=[min(min(p.wire) for p in train+test),max(max(p.wire) for p in train+test)],
                  sources={str(root/'collective-source.json'):digest(root/'collective-source.json') for root in campaigns})
    repeated = [(key,rows) for key,rows in groups.items() if len(rows)>=2]
    rates = [max((min(p.entry['peak_rate_rad_s'] for p in rows) for key,rows in repeated if key[0]==axis),
                 default=0.) for axis in AXES]
    if min(rates)>0.:
        result['repeated_limits'] = dict(body_rates_rad_s=rates,
                                        collective_m_s2=max(min(p.entry['force_m_s2'] for p in rows)
                                                            for _,rows in repeated))
    output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({key:result[key] for key in
                      ('force_coefficients','motor_idle_input','axes','training','held_out','observed_motor_bounds')}))


if __name__=='__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('output',type=Path)
    parser.add_argument('campaign',type=Path,nargs='+')
    parser.add_argument('--fit-idle',action='store_true')
    args = parser.parse_args()
    run(args.campaign,args.output,args.fit_idle)
