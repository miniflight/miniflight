"""Bridge the TU Delft G&CNet observation and motor ordering to VQ2."""

import json
import re

import numpy as np
from scipy.spatial.transform import Rotation


LAYER_SIZES = (20,64,64,64,4)
# TU Delft's model orders the rear-right motor first. VQ2 orders front-left first.
MOTOR_ORDER = (3,1,2,0)


def wrap_angle(values):
    return (values+np.pi)%(2.*np.pi)-np.pi


class GateObservations:
    def __init__(self, course, loop=False):
        course = np.asarray(course)
        if course.ndim!=2 or course.shape[1]!=7 or not len(course) or not np.isfinite(course).all():
            raise ValueError('Expected ordered gate centers and xyzw rotations')
        self.centers = course[:,:3].copy()
        normals = Rotation.from_quat(course[:,3:]).as_matrix()[:,:,0]
        self.yaw = np.arctan2(normals[:,1],normals[:,0])
        cosine,sine = np.cos(self.yaw),np.sin(self.yaw)
        unit = np.ones_like(cosine)
        zero = np.zeros_like(cosine)
        self.world_from_gate = np.stack((cosine,-sine,zero,sine,cosine,zero,zero,zero,unit),axis=1).reshape(-1,3,3)
        advance = np.roll(self.centers,-1,axis=0)-self.centers
        relative = np.einsum('ni,nij->nj',advance,self.world_from_gate)
        heading = wrap_angle(np.roll(self.yaw,-1)-self.yaw)
        self.following = np.c_[relative,heading]
        if not loop:
            self.following[-1] = 0.

    def encode(self, position, velocity, quaternion, body_rates, rotor_speed, active):
        position,velocity = np.asarray(position),np.asarray(velocity)
        active = np.asarray(active)
        frame = self.world_from_gate[active]
        relative = np.einsum('...i,...ij->...j',position-self.centers[active],frame)
        movement = np.einsum('...i,...ij->...j',velocity,frame)
        attitude = Rotation.from_quat(quaternion).as_euler('xyz')
        attitude[...,2] -= self.yaw[active]
        parts = relative,movement,wrap_angle(attitude),body_rates,np.asarray(rotor_speed)[...,list(MOTOR_ORDER)],self.following[active]
        return np.concatenate(parts,axis=-1,dtype=np.float32)


def motor_inputs(action, maximum=1.):
    applied = .5*(np.asarray(action)+1.)
    return np.clip(applied[...,list(MOTOR_ORDER)],0.,maximum)


class GuidanceControlNet:
    def __init__(self, weights, biases, activation):
        self.weights = tuple(np.asarray(layer,dtype=np.float32) for layer in weights)
        self.biases = tuple(np.asarray(layer,dtype=np.float32) for layer in biases)
        self.activation = activation
        expected = tuple(zip(LAYER_SIZES[1:],LAYER_SIZES[:-1],strict=True))
        if (tuple(layer.shape for layer in self.weights)!=expected
                or tuple(len(layer) for layer in self.biases)!=LAYER_SIZES[1:]
                or activation not in ('tanh','relu')
                or any(not np.isfinite(layer).all() for layer in (*self.weights,*self.biases))):
            raise ValueError('Expected the released 20→64→64→64→4 G&CNet architecture')

    @classmethod
    def from_c(cls, path):
        """Read numeric arrays from the authors' C export without loading a pickle."""
        source = path.read_text()

        def array(name):
            match = re.search(rf'static const float {name}\[\]\s*=\s*\{{([^}}]+)\}}',source)
            if not match:
                raise ValueError(f'Missing actor array {name}')
            return np.array([float(value) for value in match[1].split(',') if value.strip()],dtype=np.float32)

        activations = set(re.findall(r'nn_neuron_(relu|tanh)',source))
        if len(activations)!=1:
            raise ValueError('Expected one activation type for the hidden layers')
        weights = [array(f'weights_fc{i}').reshape(out,inside) for i,(inside,out) in
                   enumerate(zip(LAYER_SIZES[:-1],LAYER_SIZES[1:],strict=True),1)]
        return cls(weights,[array(f'biases_fc{i}') for i in range(1,5)],activations.pop())

    def __call__(self, state):
        result = np.asarray(state,dtype=np.float32)
        for weights,biases in zip(self.weights[:-1],self.biases[:-1],strict=True):
            result = result@weights.T+biases
            result = np.tanh(result) if self.activation=='tanh' else np.maximum(0.,result)
        return result@self.weights[-1].T+self.biases[-1]

    @classmethod
    def from_numpy(cls, path):
        with np.load(path,allow_pickle=False) as source:
            return cls([source[f'weight_{i}'] for i in range(4)],
                       [source[f'bias_{i}'] for i in range(4)],str(source['activation']))

    def save_numpy(self, path, metadata):
        arrays = {f'weight_{i}':layer for i,layer in enumerate(self.weights)}
        arrays.update({f'bias_{i}':layer for i,layer in enumerate(self.biases)})
        np.savez_compressed(path,**arrays,activation=self.activation,metadata=json.dumps(metadata,allow_nan=False))
