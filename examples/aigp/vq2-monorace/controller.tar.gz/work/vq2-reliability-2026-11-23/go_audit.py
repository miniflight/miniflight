"""Check the first arm and powered packet against confirmed GO in saved laps."""

from argparse import ArgumentParser
from base64 import b64decode
import gzip
import json
from pathlib import Path
from struct import unpack_from

from pymavlink.dialects.v20 import common as mavlink


def start_trace(folder):
    result = json.loads((folder / 'result.json').read_text())
    if not result['wire']:
        return {'lap': result['attempt'], 'armed': False, 'powered': False}
    expected = result['wire']['race_start_boot_time_ms']
    incoming, outgoing = mavlink.MAVLink(None), mavlink.MAVLink(None)
    confirmed = arm = power = boot_at_power = last_boot = None
    power_kind = None
    notices = []
    with gzip.open(folder / 'flight.jsonl.gz', 'rt') as stream:
        for row in map(json.loads, stream):
            if row.get('name') == 'poll':
                for packet in row['result']:
                    if packet['camera']:
                        continue
                    for msg in incoming.parse_buffer(b64decode(packet['wire'])) or ():
                        if msg.get_type() == 'ENCAPSULATED_DATA' and msg.data[0] == 1:
                            _, boot, start = unpack_from('<BQq', bytes(msg.data))
                            if start == expected and start >= 0:
                                last_boot = boot
                                if boot >= start and confirmed is None:
                                    confirmed = packet['received_at']
                        if msg.get_type() == 'STATUSTEXT':
                            notices.append(str(msg.text))
            elif row['event'] == 'outgoing':
                for msg in outgoing.parse_buffer(b64decode(row['wire'])) or ():
                    if (msg.get_type() == 'COMMAND_LONG' and arm is None
                            and msg.command == mavlink.MAV_CMD_COMPONENT_ARM_DISARM and msg.param1 == 1):
                        arm = row['host_time']
                    body = msg.get_type() == 'SET_ATTITUDE_TARGET' and msg.thrust > 0
                    motors = msg.get_type() == 'SET_ACTUATOR_CONTROL_TARGET' and max(msg.controls[:4]) > 0
                    if power is None and (body or motors):
                        power, boot_at_power = row['host_time'], last_boot
                        power_kind = 'MotorControls' if motors else 'BodyRates'
    return {'lap': result['attempt'], 'clean': result['clean_full'], 'armed': arm is not None,
            'powered': power is not None, 'confirmed_go': confirmed is not None,
            'first_power_kind': power_kind,
            'arm_after_go_ms': 1000. * (arm - confirmed) if arm is not None and confirmed is not None else None,
            'power_after_go_ms': 1000. * (power - confirmed) if power is not None and confirmed is not None else None,
            'race_packet_at_power_ms': boot_at_power - expected if boot_at_power is not None else None,
            'status_text': notices}


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('campaign', type=Path)
    args = parser.parse_args()
    rows = [start_trace(path.parent) for path in args.campaign.glob('practice-*/result.json')
            if (path.parent / 'flight.jsonl.gz').is_file()]
    print(json.dumps(sorted(rows, key=lambda row: row['lap']), indent=2, allow_nan=False))
