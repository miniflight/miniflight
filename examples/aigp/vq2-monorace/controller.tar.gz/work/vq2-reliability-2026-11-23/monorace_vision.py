"""MonoRace's line-corner, descriptor and joint-PnP path for mapped VQ2 gates."""

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

from mapped import CAMERA_FROM_BODY, K, gate_masks, translation
from rednose_model import pixel_factor, pose_at, project
from rednose_replay import corner_noise

# Median ratio from rectified stock color boundaries and recorded inner corners.
OUTER_SCALE = 1.95
DESCRIPTOR_OFFSETS = np.array([[-1.,-1.],[1.,-1.],[1.,1.],[-1.,1.]])
LSD = cv2.createLineSegmentDetector(cv2.LSD_REFINE_STD, .8, .8, 25., 30.)


def sample_directions(first,second):
    horizontal = abs(first[:,0])>=abs(second[:,0])
    across = np.where(horizontal[:,None],first,second)
    down = np.where(horizontal[:,None],second,first)
    across *= np.where(across[:,0:1]>=0.,1.,-1.)
    down *= np.where(down[:,1:2]>=0.,1.,-1.)
    return 5.*(DESCRIPTOR_OFFSETS[:,0][None,:,None]*across[:,None,:]
              +DESCRIPTOR_OFFSETS[:,1][None,:,None]*down[:,None,:])


def line_corners(mask):
    segments=LSD.detect(mask)[0]
    if segments is None:
        return np.empty((0,2)),np.empty((0,4),dtype=bool)
    start,stop=segments.reshape(-1,2,2).transpose(1,0,2)
    vector=stop-start
    length=np.linalg.norm(vector,axis=1)
    good=length>=7.
    start,vector,length=start[good],vector[good],length[good]
    i,j=np.triu_indices(len(start),1)
    cross=lambda a,b: a[:,0]*b[:,1]-a[:,1]*b[:,0]
    denominator=cross(vector[i],vector[j])
    good=abs(denominator)>.36*length[i]*length[j]
    i,j,denominator=i[good],j[good],denominator[good]
    separation=start[j]-start[i]
    a,b=cross(separation,vector[j])/denominator,cross(separation,vector[i])/denominator
    good=(a>=-1./3)&(a<=4./3)&(b>=-1./3)&(b<=4./3)
    i,j,a=i[good],j[good],a[good]
    point=start[i]+a[:,None]*vector[i]
    sample=point[:,None,:]+sample_directions(vector[i]/length[i,None],vector[j]/length[j,None])
    x,y=np.rint(sample).astype(int).transpose(2,0,1)
    valid=((x>=0)&(x<mask.shape[1])&(y>=0)&(y<mask.shape[0])).all(axis=1)
    return point[valid],mask[y[valid],x[valid]]>0


def prior_descriptors(inner,outer):
    start=np.vstack((inner,outer))
    neighbors=lambda step: np.vstack((np.roll(inner,step,axis=0),np.roll(outer,step,axis=0)))-start
    a,b=neighbors(1),neighbors(-1)
    samples=start[:,None,:]+sample_directions(a/np.linalg.norm(a,axis=1)[:,None],
                                              b/np.linalg.norm(b,axis=1)[:,None])
    inside=lambda poly,p:cv2.pointPolygonTest(poly.astype(np.float32),tuple(map(float,p)),False)>=0.
    return np.array([[inside(outer,p) and not inside(inner,p) for p in row] for row in samples])


def matches(image,gates,position,attitude,segment=None):
    camera=CAMERA_FROM_BODY@attitude.as_matrix().T
    up=camera@np.array([0.,0.,-1.])
    angle=np.rad2deg(np.arctan2(up[0],-up[1]))
    centre=K[:2,2]
    rot=cv2.getRotationMatrix2D(tuple(centre),angle,1.)
    size=np.asarray(image.shape[1::-1])
    priors=[]
    for gate,inner in gates:
        outer=inner.mean(axis=0)+OUTER_SCALE*(inner-inner.mean(axis=0))
        world=np.vstack((inner,outer))
        projected,depth=project(world,position,attitude)
        projected=projected@rot[:,:2].T+rot[:,2]
        if depth.min()<=.6 or not np.any(((projected>=6.)&(projected<=size-6.)).all(axis=1)):
            continue
        width=np.median(np.linalg.norm(inner-np.roll(inner,1,axis=0),axis=1))*K[0,0]/depth.mean()
        if width>=15.:
            priors.append((float(depth.mean()),gate,world,projected,width))
    priors=sorted(priors,key=lambda item:item[0])[:2]
    if not priors:
        return []
    if segment is None:
        mask,color=gate_masks(image)
        mask=(mask & cv2.dilate(color.astype(np.uint8),np.ones((3,3),np.uint8)))*255
    else:
        mask=segment(image)
    pixels=np.concatenate([p[3] for p in priors])
    margin=max(min(100.,1.15*p[4]) for p in priors)
    low=np.maximum(0,np.floor(pixels.min(axis=0)-margin).astype(int))
    high=np.minimum(size,np.ceil(pixels.max(axis=0)+margin).astype(int))
    if np.any(high-low<12):
        return []
    transform=rot.copy()
    transform[:,2]-=low
    crop=cv2.warpAffine(mask,transform,tuple(high-low),flags=cv2.INTER_NEAREST)
    points,descriptors=line_corners(crop)
    if not len(points):
        return []
    inv=cv2.invertAffineTransform(transform)
    selected=[]
    used=set()
    for depth,gate,world,prior,width in priors:
        prior=prior-low
        descriptor=prior_descriptors(prior[:4],prior[4:])
        distance=np.linalg.norm(prior[:,None,:]-points[None,:,:],axis=2)
        # Classify inner and outer corners by the four neighbouring mask values.
        legal=np.all(descriptor[:,None,:]==descriptors[None,:,:],axis=2)
        distance[~legal]=np.inf
        if used:
            distance[:,list(used)]=np.inf
        i,j=np.array(np.unravel_index(np.argsort(distance.ravel()),distance.shape))
        a,b=[],[]
        for k,l in zip(i,j,strict=True):
            if distance[k,l]>min(100.,max(12.,1.15*width)):
                break
            if k not in a and l not in b:
                a.append(k)
                b.append(l)
        if len(a)<2:
            continue
        src,dst=prior[a],points[b]
        transform_fit,inliers=cv2.estimateAffinePartial2D(src,dst,method=cv2.RANSAC,ransacReprojThreshold=5.)
        if transform_fit is None or np.max(abs(transform_fit[:,2]))>150.:
            continue
        keep=inliers[:,0]!=0
        if not keep.any():
            continue
        used.update(np.asarray(b)[keep].tolist())
        raw=dst[keep]@inv[:,:2].T+inv[:,2]
        selected.append((gate,world[np.asarray(a)[keep]],raw,depth))
    return selected


def pose_measurement(image,gates,position,attitude,segment=None):
    return solve_pose(matches(image,gates,position,attitude,segment),position,attitude)


def solve_pose(joined,position,attitude):
    if not joined:
        return None
    points=np.vstack([m[1] for m in joined])
    pixels=np.vstack([m[2] for m in joined])
    if len(points)<4:
        return None
    depth=float(np.mean([m[3] for m in joined]))
    allow_attitude=len(joined)>=2 or (2.<=depth<=5. and len(points)>6)
    camera=CAMERA_FROM_BODY@attitude.as_matrix().T
    rotation=attitude
    if allow_attitude:
        guess=cv2.Rodrigues(camera)[0]
        ok,r,t=cv2.solvePnP(np.ascontiguousarray(points),np.ascontiguousarray(pixels),K,None,guess,
                             (-camera@position).reshape(3,1),useExtrinsicGuess=True,flags=cv2.SOLVEPNP_ITERATIVE)
        if not ok:
            return None
        optical=cv2.Rodrigues(r)[0]
        origin=-optical.T@t[:,0]
        rotation=Rotation.from_matrix(optical.T@CAMERA_FROM_BODY)
    else:
        origin=translation(points,pixels,camera)
    prediction,distance=project(points,origin,rotation)
    error=float(np.sqrt(np.mean((prediction-pixels)**2)))
    if min(distance)<=.45 or not np.isfinite(error) or error>4.:
        return None
    return origin,rotation,joined,points,pixels,depth,allow_attitude,error


def bearing_update(observer,group,position,attitude):
    gate,points,pixels,_=group
    span=np.linalg.norm(np.ptp(pixels,axis=0))
    if span<25. or np.linalg.norm(np.ptp(points,axis=0))<.65:
        return None
    optical=CAMERA_FROM_BODY@attitude.as_matrix().T
    origin=translation(points,pixels,optical)
    fitted,depth=project(points,origin,attitude)
    error=np.sqrt(np.mean((fitted-pixels)**2))
    difference=origin-position
    if depth.min()<=.45 or not np.isfinite(error) or error>2.5 or np.linalg.norm(difference)>.8:
        return None
    ray=points.mean(axis=0)-position
    distance=np.linalg.norm(ray)
    _,_,transverse=np.linalg.svd(ray[None,:],full_matrices=True)
    side=transverse[1:]
    H=np.zeros((2,observer.dim_err))
    H[:,:3]=side
    direction_uncertainty=np.sqrt(np.trace(observer.P[3:6,3:6])/3.)
    sigma=distance*np.hypot(max(corner_noise(span),error)/K[0,0],direction_uncertainty)
    correction=side@difference
    observer.update(correction,np.zeros(2),H,np.full(2,sigma))
    pixel_H=np.zeros((pixels.size,observer.dim_err))
    pixel_H[:,:6]=np.vstack([pixel_factor(point,position,attitude)[1] for point in points])
    pixel_H[:,:3]=pixel_H[:,:3]@side.T@side
    residual=(pixels-project(points,position,attitude)[0]).ravel()
    observer.last_gate_factor=(residual,pixel_H,np.full(pixels.size,corner_noise(span)),
                               np.zeros((pixels.size,pixels.size)))
    return gate+1,len(points),float(error),float(np.linalg.norm(correction))


def with_monorace_pose(fallback,metrics,segment=None,*,partial_bearing=False):
    def gate_update(observer,image,gates,rim,recover=False,gap_safe=False,range_pixels=0.,
                    range_quality=False,landmarks=None,observed=None,outlines=None,
                    measured_pair=None,apertures_used=None,bearings=None):
        # Keep the complete-aperture path when it is available.
        if not outlines and not observer.N and not landmarks:
            position,attitude=pose_at(observer.x[:,0],0)
            joined=matches(image,gates,position,attitude,segment)
            if partial_bearing and measured_pair is None and len(joined)==1 and 2<=len(joined[0][1])<=3:
                measurement=bearing_update(observer,joined[0],position,attitude)
                if measurement is not None:
                    metrics.setdefault('monorace_bearing_updates',[]).append(measurement)
                    return 1,False
            result=solve_pose(joined,position,attitude)
            if result is not None:
                origin,rotation,joined,points,pixels,depth,angle,error=result
                displacement=origin-position
                if displacement@displacement<16.*len(points)**2*np.trace(observer.P[:3,:3]):
                    tangent=(rotation*attitude.inv()).as_rotvec()
                    residual=np.r_[displacement,tangent] if angle else displacement
                    n=len(residual)
                    H=np.eye(observer.dim_err)[:n]
                    sigma=np.sqrt(np.repeat([.02,.01] if angle else [.02],3))*depth/(len(points)*np.sqrt(len(joined)))
                    observer.update(residual,np.zeros(n),H,sigma)
                    pixel_H=np.zeros((pixels.size,observer.dim_err))
                    pixel_H[:,:6]=np.vstack([pixel_factor(point,position,attitude)[1] for point in points])
                    image_prior=project(points,position,attitude)[0]
                    aperture_px=float(K[0,0]*np.median([np.ptp(row[1],axis=0).max() for row in joined])/depth)
                    observer.last_gate_factor=((pixels-image_prior).ravel(),pixel_H,
                                               np.full(pixels.size,corner_noise(aperture_px)),
                                               np.zeros((pixels.size,pixels.size)))
                    if observed is not None:
                        observed.update(row[0] for row in joined)
                    metrics.setdefault('monorace_visual_updates',[]).append([len(joined),len(points),float(error),angle])
                    return len(joined),True
        return fallback(observer,image,gates,rim,recover,gap_safe,range_pixels,range_quality,
                        landmarks,observed,outlines,measured_pair,apertures_used,bearings)
    return gate_update
