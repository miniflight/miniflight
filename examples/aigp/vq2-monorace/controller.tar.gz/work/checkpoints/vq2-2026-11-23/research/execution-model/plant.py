"""Fit command-to-body-rate and collective response using public IMU data."""
import gzip
from base64 import b64decode
import json
from pathlib import Path

import numpy as np
from pymavlink.dialects.v20 import common
from scipy.signal import lfilter
from scipy.spatial.transform import Rotation,Slerp

HERE=Path(__file__).resolve().parent
ROOT=HERE/"native-recordings"
DT=.005
G=np.array([0.,0.,9.81])


def read(lap):
    folder=ROOT/f"practice-{lap}"
    incoming,outgoing=common.MAVLink(None),common.MAVLink(None)
    imu,commands=[],[]
    with gzip.open(folder/"flight.jsonl.gz","rt") as stream:
        for row in map(json.loads,stream):
            if row.get("name")=="poll":
                for p in row["result"]:
                    if p["camera"]:
                        continue
                    for m in incoming.parse_buffer(b64decode(p["wire"])) or ():
                        if m.get_type()!="HIGHRES_IMU":
                            continue
                        t=m.time_usec*1.e-6
                        if not imu or t>imu[-1][0]:
                            imu.append((t,p["received_at"],-m.xgyro,-m.ygyro,-m.zgyro,m.xacc,m.yacc,m.zacc))
            elif row["event"]=="outgoing":
                for m in outgoing.parse_buffer(b64decode(row["wire"])) or ():
                    if m.get_type()=="SET_ATTITUDE_TARGET":
                        commands.append((row["host_time"],-m.body_roll_rate,-m.body_pitch_rate,-m.body_yaw_rate,m.thrust))
    imu,command=np.asarray(imu),np.asarray(commands)
    scale,_=np.polyfit(imu[:,0],imu[:,1],1)
    offset=np.quantile(imu[:,1]-scale*imu[:,0],.10)
    sent=(command[:,0]-offset)/scale
    use=(imu[:,0]>=sent[0]+.55)&(imu[:,0]<=sent[-1]-.36)&np.isfinite(imu).all(axis=1)
    with np.load(folder/"learned-course.npz",allow_pickle=False) as z:
        pose=z["pose"]
    t,idx=np.unique(pose[:,0],return_index=True)
    return sent,command[:,1:],imu[use],pose[idx]


def predict_axes(u,kind):
    r=u[:,:3]
    t=(u[:,3]-.265)*4.
    n=np.sum(r*r,axis=1)/16.
    if kind=="angular":
        return np.stack((r,np.ones_like(r),r*n[:,None],r*t[:,None],
                         r*(t*t)[:,None],r*(t*n)[:,None]),axis=-1)
    return np.stack((np.ones_like(t),t,t*t,n,t*n,t*t*n),axis=1)


def timed_inputs(sent,u,t):
    grid=np.arange(sent[0]-.10,max(sent[-1],t[-1])+.04,DT)
    layers=[]
    for axis,delay in enumerate((.010,.010,.020,.010)):
        command=u[(np.searchsorted(sent,grid-delay,side="right")-1).clip(0)]
        features=(predict_axes(command,"angular")[:,axis] if axis<3
                  else predict_axes(command,"collective"))
        if axis<3:
            a=np.exp(-DT/.010)
            features=lfilter([1.-a],[1.,-a],features,axis=0)
        layers.append(np.column_stack([np.interp(t,grid,col) for col in features.T]))
    return np.stack(layers,axis=1)


def fit(packed,terms):
    X,Y=map(np.concatenate,zip(*packed,strict=True))
    cols=6 if terms=="coupled" else 3
    chosen=np.arange(cols)
    coef=np.zeros((4,6))
    for axis in range(4):
        x=X[:,axis,chosen]
        regular=np.diag(np.r_[.01,.01,np.full(cols-2,.8)])
        coef[axis,chosen]=np.linalg.solve(x.T@x+regular,x.T@Y[:,axis])
    return coef


def score(coef,record):
    X,Y=record
    predicted=np.einsum("ncf,cf->nc",X,coef)
    return predicted, np.mean((Y-predicted)**2,axis=0)


if __name__=="__main__":
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    training=(908,909,912,913,914,915,916,917,918,919,920,921,922,943,944,945,946,947,948)
    validation=(966,967,968,969,970,971,972,973,978,979,980,982,983,999,1000,1001,1003,1004,
                1011,1012,1013,1014,1015,1016)
    packed={}
    for lap in (*training,*validation):
        t,u,imu,pose=read(lap)
        x=timed_inputs(t,u,imu[:,0])
        y=np.c_[imu[:,2:5],-imu[:,7]]
        packed[lap]=(x,y,t,u,imu,pose)
    model={k:fit([packed[l][:2] for l in training],k) for k in ("separate","coupled")}
    rms={}
    for name,coef in model.items():
        squared=[]
        for l in validation:
            _,e=score(coef,packed[l][:2])
            squared.append(e)
        rms[name]=np.sqrt(np.mean(squared,axis=0)).tolist()
    report=dict(train_laps=len(training),heldout_laps=len(validation),holdout_lap_equal_weight_rms=rms,
                coefficients={k:v.tolist() for k,v in model.items()})
    (HERE/"plant-fit.json").write_text(json.dumps(report,indent=2)+"\n")
    np.savez_compressed(HERE/"plant.npz",**model)
    fig,axes=plt.subplots(2,1,figsize=(9,6.4),layout="constrained")
    z=np.linspace(.19,.65,190)
    a=np.zeros((len(z),4))
    a[:,3]=z
    for rate in (0.,2.,4.,6.):
        a[:,0]=rate
        collect=predict_axes(a,"collective")@model["coupled"][3]
        axes[0].plot(z,collect,label=f"{rate:.0f} rad/s request")
    axes[0].set(xlabel="Collective command",ylabel="Modeled thrust accel (m/s²)")
    axes[0].legend(fontsize=8)
    x=np.arange(3)
    axes[1].bar(x-.19,rms["separate"][:3],width=.38,label="Rate only")
    axes[1].bar(x+.19,rms["coupled"][:3],width=.38,label="Rate and collective")
    axes[1].set(xticks=x,xticklabels=["Roll","Pitch","Yaw"],ylabel="Held-out angular RMS (rad/s)")
    axes[1].legend(fontsize=8)
    for ax in axes:ax.grid(alpha=.16)
    fig.savefig(HERE/"coupled-response.png",dpi=155)
    print(json.dumps(report))
