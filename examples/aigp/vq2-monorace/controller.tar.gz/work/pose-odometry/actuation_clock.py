"""Predict the physical state at the time a command can take effect."""

from collections import deque

import numpy as np

from rednose_model import integrate


class ActuationClock:
    def __init__(self, command_delay=.015, max_projection=.070):
        self.command_delay = command_delay
        self.max_projection = max_projection
        self.offsets = deque()

    def observe(self, device_stamp, received_at):
        if self.offsets:
            if device_stamp == self.offsets[-1][0]:
                return
            if device_stamp < self.offsets[-1][0]:
                self.offsets.clear()
        self.offsets.append((device_stamp, received_at-device_stamp))
        while self.offsets[0][0] < device_stamp-1.:
            self.offsets.popleft()

    def offset(self):
        # Keep the clock offset and excess message latency distinct.
        offsets = np.fromiter((offset for _, offset in self.offsets), float, count=len(self.offsets))
        low = int(.1*(len(offsets)-1))
        return np.partition(offsets, low)[low]

    def horizon(self, host_now):
        if not self.offsets:
            return 0.
        device_stamp = self.offsets[-1][0]
        return float(np.clip(host_now-self.offset()-device_stamp+self.command_delay, 0., self.max_projection))

    def predict(self, state, reading, host_now, *, state_time=None):
        output = state.copy()
        duration = self.horizon(host_now)
        if state_time is not None:
            duration = max(0., reading[0]+duration-state_time)
        integrate(output, duration, reading)
        return output
