"""Verify or launch the frozen 18.181 s stock VQ2 controller."""
import argparse
from hashlib import file_digest
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import subprocess
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work/vq2-reliability-2026-11-23"
CHECKPOINT = ROOT / "work/checkpoints/vq2-2026-11-23/controller"
WEIGHTS = WORK / "monorace-stock-adapted-v2/candidate.npz"


def verify():
    hashes = json.loads((ROOT / "files.json").read_text())
    for name, expected in hashes.items():
        with (ROOT / name).open("rb") as stream:
            if file_digest(stream, "sha256").hexdigest() != expected:
                raise ValueError(f"Checkpoint file changed: {name}")

    sys.path.insert(0, str(WORK))
    spec = spec_from_file_location("frozen_vq2", CHECKPOINT / "run.py")
    frozen = module_from_spec(spec)
    spec.loader.exec_module(frozen)
    frozen.verify(json.loads((CHECKPOINT / "checkpoint.json").read_text()))
    from monorace_policy import GuidanceControlNet, motor_inputs
    from motor_response import MotorResponse

    actor = GuidanceControlNet.from_numpy(WEIGHTS)
    with np.load(WEIGHTS, allow_pickle=False) as source:
        metadata = json.loads(str(source["metadata"]))
    model = MotorResponse.from_report(metadata["motor"])
    bound = metadata["motor"]["observed_motor_bounds"][1]
    with np.load(ROOT / "actor-replay.npz", allow_pickle=False) as trace:
        observation = trace["observation"]
        action = np.asarray([actor(row) for row in observation])
        outputs = model.limit_rate_support(motor_inputs(action, bound),
            metadata["rate_support_rad_s"], observation[:, 9:12], metadata["rate_support_window_s"])
        np.testing.assert_allclose(action, trace["policy_output"], rtol=0, atol=1e-6)
        np.testing.assert_allclose(outputs, trace["motors"], rtol=0, atol=1e-6)
    print(f"Verified checkpoint and replayed {len(observation)} motor decisions.", flush=True)


def command(output, starts):
    return [sys.executable, "-B", str(WORK / "fly_reference.py"), "1392", str(output),
            "--laps", str(starts), "--plan", str(WORK / "joint-warped-stock-export/plan.npz"),
            "--action-clock", "--thrust-priority", "--monorace-policy", str(WEIGHTS),
            "--monorace-motor-motion", str(WORK / "live-monorace-tilted-spawn/axial-force-holdout.json"),
            "--monorace-vision", "--monorace-partial-bearing", "--monorace-imu-wait",
            "--aperture-anchor", "--monorace-gate-switch", "confirmed", "--motor-early-camera",
            "--port", "8766", "--wait-for-race"]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, help="Attach to open stock VQ2 Track Practice")
    parser.add_argument("--starts", type=int, default=1)
    args = parser.parse_args()
    if args.starts < 1:
        parser.error("--starts must be positive")
    if args.run is not None and args.run.exists():
        parser.error("--run requires a new output directory")
    verify()
    if args.run is not None:
        subprocess.run(command(args.run.resolve(), args.starts), cwd=ROOT, check=True)
