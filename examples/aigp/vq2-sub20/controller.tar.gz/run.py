"""Verify or run the frozen camera/IMU checkpoint against stock VQ2 Practice."""

from argparse import ArgumentParser, Namespace
from hashlib import file_digest
from pathlib import Path
import json
import runpy
import signal
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'repo'
CONTROLS = ROOT / 'flight-controls'
INPUTS = ROOT / 'inputs'
sys.path[:0] = [
    str(REPO), str(REPO / 'work/pose-odometry'),
    str(ROOT / 'dependencies/rednose_repo'),
    str(CONTROLS / 'partial-relock'), str(CONTROLS / 'current-actuators'),
]

import numpy as np
from scipy.interpolate import CubicSpline

from inverse import command
from target.aigp.experiments import practice


def verify(report):
    for filename, expected in report['sources'].items():
        with (ROOT / filename).open('rb') as f:
            if file_digest(f, 'sha256').hexdigest() != expected:
                raise ValueError(f'Source hash differs for {filename}')
    for filename, expected in report['inputs'].items():
        if practice.digest(INPUTS / filename) != expected:
            raise ValueError(f'Input hash differs for {filename}')
    with tempfile.TemporaryDirectory() as tmp:
        paths = Namespace(map=INPUTS / 'map.json', line=INPUTS / 'line.npz',
                          plan=INPUTS / 'plan.npz', pace=report['pace_m_s'])
        practice.freeze_inputs(practice.pilot_module(), paths, Path(tmp))


def fly(out, attempts, report):
    pilot = practice.pilot_module()
    p = runpy.run_path(str(CONTROLS / 'partial-relock/observer.py'))
    g = runpy.run_path(str(CONTROLS / 'timing-isolation/observer.py'))

    class Observer(g['EfficientGeometry'], p['PartialObserver']):
        pass

    pilot.CourseClient.observer_type = Observer
    with np.load(CONTROLS / 'learned-feedforward/correction.npz', allow_pickle=False) as data:
        correction = CubicSpline(data['station'], data['acceleration'])
    original = pilot.RacingLine.reference

    def reference(self, *args, with_progress=False, **kwargs):
        position, velocity, acceleration, progress = original(self, *args, with_progress=True, **kwargs)
        value = position, velocity, acceleration + report['acceleration_feedback'] * correction(progress)
        return (*value, progress) if with_progress else value

    def control(*args, **kwargs):
        return command(*args, strength=report['collective_strength'], **kwargs)

    pilot.RacingLine.reference = reference
    pilot.acceleration_control = control

    class Frozen:
        def __init__(self, plan, *_):
            self.path = plan
            self.packet = json.loads((INPUTS / 'gate-map-in.json').read_text())

        def pilot_map(self, _):
            p['EVENTS'].clear()
            p['ATTEMPTS'].clear()
            return self.packet

        def update(self, *_):
            return {'mode': 'frozen sub-20 checkpoint'}

    signal.signal(signal.SIGTERM, practice.interrupt)
    practice.main([
        'run', '--out', str(out), '--map', str(INPUTS / 'map.json'),
        '--line', str(INPUTS / 'line.npz'), '--plan', str(INPUTS / 'plan.npz'),
        '--pace', str(report['pace_m_s']), '--evolve-line', '--attempts', str(attempts),
    ], evolution_type=Frozen, freeze_map=True)


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, help='Run against an already-open stock VQ2 Practice session')
    parser.add_argument('--attempts', type=int, default=1)
    args = parser.parse_args()
    report = json.loads((ROOT / 'checkpoint.json').read_text())
    verify(report)
    print('Checkpoint hashes and plan binding verified', flush=True)
    if args.run:
        if args.attempts < 1:
            parser.error('--attempts must be positive')
        fly(args.run, args.attempts, report)
