"""Joint gate/vehicle error-state filter. No simulator or transport imports."""
from copy import deepcopy
import numpy as np
from scipy.spatial.transform import Rotation

NIS={1:10.828,2:13.816,3:16.266,4:18.467,5:20.515,6:22.458,7:24.322,8:26.125}


def skew(x):
    a,b,c=x
    return np.array([[0.,-c,b],[c,0.,-a],[-b,a,0.]])


def upright_seed(pixels,camera_down,intrinsics,height=1.5):
    """Metric translation from observed vertical edges and gravity, without planar pose ambiguity."""
    rays=np.c_[pixels,np.ones(4)] @ np.linalg.inv(intrinsics).T;points=np.zeros((4,3));residual=[]
    for top,bottom in [(0,3),(1,2)]:
        design=np.column_stack((-rays[top],rays[bottom]));depth=np.linalg.lstsq(design,height*np.asarray(camera_down),rcond=None)[0]
        if min(depth)<=0:return None
        points[top]=depth[0]*rays[top];points[bottom]=depth[1]*rays[bottom]
        residual.append(np.linalg.norm(design @ depth-height*np.asarray(camera_down)))
    if max(residual)>.15:return None
    left=(points[0]+points[3])/2;right=(points[1]+points[2])/2;edge=right-left
    if not .5*height<np.linalg.norm(edge)<1.5*height:return None
    return (left+right)/2,edge/np.linalg.norm(edge)


class GateFilter:
    """Error coordinates: p,v,right attitude error,gyro bias,force bias,gate(xyz,yaw)."""
    def __init__(self,rotation,gyro_bias,thrust_curve,drag,camera_from_body,intrinsics,*,supported=False):
        self.p=np.zeros(3);self.v=np.zeros(3);self.R=np.array(rotation)
        self.bg=np.array(gyro_bias);self.ba=np.zeros(3);self.gates={};self.rim=None;self.size=1.5
        self.proposals={};self.retargets=0;self.last_visual={};self.last_full_visual={}
        self.last_force_time=-np.inf;self.force_accepted=0;self.force_rejected=0
        self.last_force_result=None
        self.P=np.diag(np.r_[np.full(3,1e-8),np.full(3,.05**2),np.r_[np.full(2,np.radians(.5)**2),1e-8],
            np.full(3,.001**2),np.full(3,.5**2),.03**2])
        self.thrust_curve=np.array(thrust_curve);self.drag=np.asarray(drag)
        self.C=np.array(camera_from_body);self.K=np.array(intrinsics)
        self.acceleration_noise=.5;self.gyro_noise=.001
        self.gyro_bias_walk=.0001;self.force_bias_walk=.05
        self.airborne=not supported
        self.attitude_corrections=True
        self.broad_rim=False
        self.partial_gate_births=True
        self.image_time_sigma=0.;self.image_time_index=None;self.image_time_offset=0.
        self.angular_velocity=np.zeros(3)
        self.upright_attitude=False;self.last_gravity_time=-np.inf;self.gravity_accepted=0
        self.localization=False

    def copy(self):return deepcopy(self)

    def map_state(self):
        gates=[dict(id=k,center=g.tolist(),yaw=float(y)) for k,(i,g,y) in sorted(self.gates.items()) if k>0]
        indices=[15]+[i+j for k,(i,g,y) in sorted(self.gates.items()) if k>0 for j in range(4)]
        if self.rim is not None:indices+=list(range(self.rim[0],self.rim[0]+2))
        return dict(gates=gates,rim=None if self.rim is None else self.rim[1].tolist(),covariance=self.P[np.ix_(indices,indices)].tolist())

    def restore_map(self,prior):
        """Retain joint map/size uncertainty; a fresh flight supplies its own p/v prior."""
        if self.gates or self.rim is not None or len(self.P)!=16:raise ValueError('Map restoration requires a fresh filter')
        if set(prior)!={'gates','rim','covariance'} or any(set(r)!={'id','center','yaw'} for r in prior['gates']):raise ValueError('Unexpected map prior fields')
        gates=prior['gates'];rim=prior['rim'];covariance=np.asarray(prior['covariance'],float)
        n=4*len(gates)+(0 if rim is None else 2);ids=[r['id'] for r in gates]
        values=np.array([[*r['center'],r['yaw']] for r in gates],float)
        if (not gates or len(set(ids))!=len(ids) or any(type(k) is not int or k<=0 for k in ids)
                or values.shape!=(len(gates),4) or not np.isfinite(values).all()
                or covariance.shape!=(n+1,n+1) or not np.isfinite(covariance).all()
                or not np.allclose(covariance,covariance.T,atol=1e-10) or np.linalg.eigvalsh(covariance)[0]<-1e-8
                or not np.isclose(covariance[0,0],self.P[15,15])
                or (rim is not None and (np.shape(rim)!=(2,) or not np.isfinite(rim).all() or min(rim)<=0))):raise ValueError('Invalid joint map prior')
        self.P=np.pad(self.P,((0,n),(0,n)));indices=[15]+list(range(16,16+n))
        self.P[np.ix_(indices,indices)]=covariance
        self.gates={r['id']:(16+4*j,np.array(r['center'],float),float(r['yaw'])) for j,r in enumerate(gates)}
        if rim is not None:self.rim=(16+4*len(gates),np.array(rim,float))

    def inject(self,dx):
        self.p+=dx[:3];self.v+=dx[3:6];self.R=self.R @ Rotation.from_rotvec(dx[6:9]).as_matrix()
        self.bg+=dx[9:12];self.ba+=dx[12:15]
        self.size+=dx[15]
        for key,(index,center,yaw) in list(self.gates.items()):
            self.gates[key]=(index,center+dx[index:index+3],yaw+dx[index+3])
        if self.rim is not None:
            index,dimensions=self.rim;self.rim=(index,dimensions+dx[index:index+2])
        if self.image_time_index is not None:self.image_time_offset+=dx[self.image_time_index]

    def begin_image(self):
        """All contours in this image share one uncertain exposure epoch."""
        if self.image_time_index is not None:raise RuntimeError('Image timing state already active')
        if self.image_time_sigma<=0:return
        n=len(self.P);self.P=np.pad(self.P,((0,1),(0,1)));self.P[n,n]=self.image_time_sigma**2
        self.image_time_index=n;self.image_time_offset=0.

    def end_image(self):
        index=self.image_time_index
        if index is None:return
        self.P=np.delete(np.delete(self.P,index,axis=0),index,axis=1)
        self.gates={k:(i-int(i>index),g,yaw) for k,(i,g,yaw) in self.gates.items()}
        if self.rim is not None:
            i,d=self.rim;self.rim=(i-int(i>index),d)
        self.image_time_index=None;self.image_time_offset=0.

    def predict(self,dt,gyro,motors,angle_uncertainty=None):
        if not 0.<dt<=.15:raise ValueError('Process interval must be positive elapsed public time, <=150ms')
        n=len(self.P);F=np.eye(n);Q=np.zeros((n,n));omega=np.asarray(gyro)-self.bg
        self.angular_velocity=omega.copy()
        rotation_step=Rotation.from_rotvec(omega*dt).as_matrix()
        if not self.airborne:motors=None
        if motors is None:
            # Before our first command, the disarmed stationary prior supplies support.
            acceleration=np.zeros(3);Av=np.zeros((3,3));At=np.zeros((3,3))
        else:
            u=np.asarray(motors);a,b=self.thrust_curve;thrust=np.mean(a*u+b*u*u)
            local=self.R.T @ self.v;D=np.diag(2*self.drag*abs(local))
            force=np.array([0.,0.,-thrust])-self.drag*abs(local)*local
            acceleration=self.R @ force+[0.,0.,9.81]+self.ba
            Av=-self.R @ D @ self.R.T
            At=-self.R @ (skew(force)+D @ skew(local))
        F[:3,3:6]=np.eye(3)*dt+.5*Av*dt*dt;F[:3,6:9]=.5*At*dt*dt
        F[3:6,3:6]+=Av*dt;F[3:6,6:9]=At*dt
        if motors is not None:
            F[:3,12:15]=np.eye(3)*(.5*dt*dt);F[3:6,12:15]=np.eye(3)*dt
        F[6:9,6:9]=rotation_step.T
        # Exact constant-rate gyro-bias derivative, evaluated once per small interval.
        phi=omega*dt;angle=np.linalg.norm(phi);A=skew(phi)
        Jr=np.eye(3)-.5*A+A@A/6 if angle<1e-5 else np.eye(3)-(1-np.cos(angle))/angle**2*A+(angle-np.sin(angle))/angle**3*A@A
        F[6:9,9:12]=-Jr*dt
        density=self.acceleration_noise**2 if motors is not None else 0.
        Q[:3,:3]=np.eye(3)*density*dt**3/3;Q[:3,3:6]=Q[3:6,:3]=np.eye(3)*density*dt**2/2
        Q[3:6,3:6]=np.eye(3)*density*dt
        Q[6:9,6:9]=np.eye(3)*self.gyro_noise**2*dt
        if angle_uncertainty is not None:Q[6:9,6:9]+=np.diag(np.asarray(angle_uncertainty)**2)
        Q[9:12,9:12]=np.eye(3)*self.gyro_bias_walk**2*dt
        Q[12:15,12:15]=np.eye(3)*self.force_bias_walk**2*dt
        self.p+=self.v*dt+.5*acceleration*dt*dt;self.v+=acceleration*dt;self.R=self.R @ rotation_step
        self.P=F @ self.P @ F.T+Q;self.P=.5*(self.P+self.P.T)
        return F

    def add_gate(self,key,relative_camera,right_camera):
        if key in self.gates:return
        world_camera=self.R @ self.C.T;center=self.p+world_camera @ relative_camera*(self.size/1.5)
        right=world_camera @ right_camera;yaw=float(np.arctan2(-right[0],right[1]))
        n=len(self.P);P=np.zeros((n+4,n+4));P[:n,:n]=self.P
        # PnP seeds the nonlinear mean only. A broad prior avoids counting the pixels twice.
        P[n:,n:]=np.diag([100.**2]*3+[np.pi**2]);self.P=P
        self.gates[key]=(n,center,yaw)

    def add_rim(self,width,height,fractional_spread):
        if self.rim is not None:return
        n=len(self.P);P=np.zeros((n+2,n+2));P[:n,:n]=self.P
        # P90-P10 spread is about2.563 standard deviations for a Gaussian.
        scale_derivative=np.array([width,height])/1.5;dimensions=scale_derivative*self.size
        sigma=dimensions*max(.01,fractional_spread/2.563)
        if self.broad_rim:sigma=np.maximum(dimensions,.75)
        P[:n,n:]=self.P[:,15,None]*scale_derivative;P[n:,:n]=P[:n,n:].T
        P[n:,n:]=np.diag(sigma**2)+np.outer(scale_derivative,scale_derivative)*self.P[15,15]
        self.P=P;self.rim=(n,dimensions)

    def consider_nearer(self,key,identity,stamp,seed):
        """Mission slots can bind a new visual landmark; the old one remains distinct."""
        relative=self.R @ self.C.T @ seed[0]*(self.size/1.5)
        distance=np.linalg.norm(relative);predicted=np.linalg.norm(self.gates[key][1]-self.p)
        if not 3.<distance<predicted-5.:return False
        center=self.p+relative;old=self.proposals.get(key,[])
        if old and (stamp-old[-1][1]>.3 or np.linalg.norm(center-old[-1][2])>max(1.5,.06*distance)):old=[]
        if not any(r[0]==identity for r in old):old.append((identity,stamp,center))
        self.proposals[key]=old
        if len(old)<3:return False
        index=self.gates[key][0];self.gates[-index-1]=self.gates.pop(key)
        self.add_gate(key,*seed);self.proposals.pop(key);self.retargets+=1
        return True

    def measurement(self,key,points,rim=False):
        if rim:
            width,height=self.rim[1];points=np.array([[0.,-width/2,-height],[0.,width/2,-height]])
        else:points=np.asarray(points)*(self.size/1.5)
        index,center,yaw=self.gates[key];gate=Rotation.from_euler('z',yaw).as_matrix()
        directions=np.asarray(points) @ gate.T;world=directions+center
        body=(world-self.p) @ self.R;camera=body @ self.C.T
        if np.min(camera[:,2])<=.1:return None
        h=camera @ self.K.T;pixels=h[:,:2]/h[:,2,None];H=np.zeros((2*len(points),len(self.P)))
        for i,(xyz,b,offset) in enumerate(zip(camera,body,directions)):
            x,y,z=xyz;J=np.array([[self.K[0,0]/z,0.,-self.K[0,0]*x/z**2],[0.,self.K[1,1]/z,-self.K[1,1]*y/z**2]])
            rows=slice(2*i,2*i+2);world_J=J @ self.C @ self.R.T
            H[rows,:3]=-world_J;H[rows,6:9]=J @ self.C @ skew(b)
            H[rows,index:index+3]=world_J;H[rows,index+3]=world_J @ np.cross([0.,0.,1.],offset)
            if rim:
                H[rows,self.rim[0]]=world_J @ gate @ [0.,-.5 if i==0 else .5,0.]
                H[rows,self.rim[0]+1]=world_J @ [0.,0.,-1.]
            else:H[rows,15]=world_J @ (offset/self.size)
        if self.image_time_index is not None:
            rate=H[:,:3] @ self.v+H[:,6:9] @ self.angular_velocity
            pixels=pixels+rate.reshape(-1,2)*self.image_time_offset
            H[:,self.image_time_index]=rate
        return pixels,H

    def observe(self,key,points,pixels,sigma_px=1.,noise=None,rim=False):
        gravity=None;split=None
        V=np.eye(np.asarray(pixels).size)*sigma_px**2 if noise is None else np.asarray(noise)
        if self.upright_attitude and not rim:
            from miniflight.upright import split_upright
            split=split_upright(pixels,self.R,self.C,self.K,V,self.angular_velocity,self.image_time_offset)
            H=np.zeros((len(split['residual']),len(self.P)));H[:,6:9]=split['attitude']
            if self.image_time_index is not None:H[:,self.image_time_index]=split['time']
            gravity=self.correct(split['residual'],H,np.eye(len(H)),NIS[len(H)],gravity=True)
            if gravity['accepted']:self.gravity_accepted+=1
        prediction=self.measurement(key,points,rim)
        if prediction is None:return dict(accepted=False,reason='behind_camera',**({} if gravity is None else dict(gravity=gravity)))
        expected,H=prediction;residual=(np.asarray(pixels)-expected).ravel()
        if split is not None:
            Q=split['remaining'];result=self.correct(Q @ residual,Q @ H,np.eye(len(Q)),NIS[len(Q)])
            result['gravity']=gravity
        else:result=self.correct(residual,H,V,NIS[len(residual)],position_only=rim and self.localization)
        result['innovation_rms_px']=float(np.sqrt(np.mean(residual**2)))
        result['gate_index']=self.gates[key][0]
        result['rim_index']=None if self.rim is None else self.rim[0]
        if self.image_time_index is not None:
            result.update(image_time_offset_s=float(self.image_time_offset),image_time_sigma_s=float(self.image_time_sigma))
        return result

    def correct(self,residual,H,V,threshold,*,gravity=False,position_only=False):
        S=H @ self.P @ H.T+V
        solved=np.linalg.solve(S,residual);nis=float(residual @ solved)
        result=dict(accepted=nis<=threshold,nis=nis,dof=len(residual))
        if not result['accepted']:return result
        K=np.linalg.solve(S,H @ self.P).T
        if not self.attitude_corrections:
            down=self.R.T @ [0.,0.,1.]
            K[6:9]=(np.eye(3)-np.outer(down,down)) @ K[6:9] if gravity else 0.
        # Weak planar views cannot separate real yaw from gyro bias. Keep the calibration prior.
        K[9:12]=0.
        # Known nominal size is a consider parameter: carry its correlations, never fit its mean.
        K[15]=0.
        if self.localization:K[16:]=0.
        if position_only:K[6:9]=0.
        if self.localization:
            angle=K[6:9] @ residual;K[6:9]*=min(1.,.05/max(np.linalg.norm(angle),1e-12))
            if (self.R @ Rotation.from_rotvec(K[6:9] @ residual).as_matrix())[2,2]<.2:K[6:9]=0.
        dx=K @ residual;A=np.eye(len(self.P))-K @ H
        covariance=A @ self.P @ A.T+K @ V @ K.T
        self.inject(dx);reset=np.eye(len(self.P));reset[6:9,6:9]-=.5*skew(dx[6:9])
        self.P=reset @ covariance @ reset.T;self.P=.5*(self.P+self.P.T)
        result['delta_state']=dx.tolist()
        return result

    def acceleration_measurement(self,motors):
        u=np.asarray(motors);a,b=self.thrust_curve;local=self.R.T @ self.v;bias=self.R.T @ self.ba
        D=np.diag(2*self.drag*abs(local));expected=np.array([0.,0.,-np.mean(a*u+b*u*u)])-self.drag*abs(local)*local+bias
        H=np.zeros((3,len(self.P)));H[:,3:6]=-D @ self.R.T;H[:,6:9]=-D @ skew(local)+skew(bias);H[:,12:15]=self.R.T
        return expected,H

    def observe_acceleration(self,measurement,motors,sigma):
        expected,H=self.acceleration_measurement(motors)
        result=self.correct(np.asarray(measurement)-expected,H,np.eye(3)*sigma**2,16.266)
        self.last_force_result=result
        if result['accepted']:self.force_accepted+=1
        else:self.force_rejected+=1
        return result

    def relative(self,key):
        index,center,_=self.gates[key];relative=center-self.p;J=np.zeros((3,len(self.P)))
        J[:,:3]=-np.eye(3);J[:,index:index+3]=np.eye(3)
        camera=self.C @ self.R.T @ relative;D=self.C @ self.R.T @ J
        D[:,6:9]=self.C @ skew(self.R.T @ relative)
        return relative,J @ self.P @ J.T,camera,D @ self.P @ D.T


class GateHistory:
    """Rewind image updates and replay every subsequent process and pixel event."""
    def __init__(self,filter,stamp,gyro,seconds=1.):
        self.filter=filter;self.time=stamp;self.seconds=seconds
        self.gyros=[(stamp,np.asarray(gyro))];self.commands=[];self.observations=[]
        self.accelerations=[]
        self.snapshots=[(stamp,filter.copy())];self.rejected_late=0;self.repropagated=0
        self.results={}

    def _rate(self,stamp):
        t=np.array([r[0] for r in self.gyros]);w=np.array([r[1] for r in self.gyros])
        return np.array([np.interp(stamp,t,w[:,i]) for i in range(3)])

    def _motor(self,stamp):
        index=np.searchsorted([r[0] for r in self.commands],stamp,side='right')-1
        return None if index<0 else self.commands[index][1]

    def _advance(self,stamp):
        if stamp>self.time:
            steps=max(1,int(np.ceil((stamp-self.time)/.02)))
            for end in np.linspace(self.time,stamp,steps+1)[1:]:
                middle=(self.time+end)/2
                first,last=self._rate(self.time),self._rate(end);dt=end-self.time
                self.filter.predict(dt,.5*(first+last),self._motor(middle),(last-first)*dt/np.sqrt(12));self.time=end

    def _observe(self,row,stamp):
        estimator = self.filter
        gate = row['key']
        rim = row.get('rim', False)
        known_gate = gate in estimator.gates
        needs_seed = not known_gate or not estimator.localization
        seed = row.get('seed')
        if rim:
            if estimator.rim is None:
                estimator.add_rim(*row['rim_prior'])
            if needs_seed and estimator.partial_gate_births:
                camera_from_world = estimator.C @ estimator.R.T
                homogeneous_pixels = np.c_[row['pixels'], np.ones(2)]
                camera_rays = homogeneous_pixels @ np.linalg.inv(estimator.K).T
                world_rays = camera_rays @ estimator.C @ estimator.R.T
                down = world_rays[:, 2]
                width, center_to_top = estimator.rim[1]
                edge = down[0]*world_rays[1] - down[1]*world_rays[0]
                edge_length = np.linalg.norm(edge)
                steep_enough = np.min(abs(down)/np.linalg.norm(world_rays, axis=1)) > .04
                if np.prod(down) > 0 and steep_enough and edge_length > 1e-9:
                    top = world_rays * (width/edge_length*abs(down[::-1]))[:, None]
                    center = top.mean(axis=0) + [0., 0., center_to_top]
                    right = (top[1]-top[0])/width
                    seed = (camera_from_world @ center*(1.5/estimator.size), camera_from_world @ right)
        elif needs_seed:
            camera_down = estimator.C @ estimator.R.T @ [0., 0., 1.]
            constrained = upright_seed(row['pixels'], camera_down, estimator.K)
            if constrained is not None:
                seed = constrained
        if not known_gate:
            if seed is None:
                self.results[row['id']] = dict(accepted=False, reason='missing_full_landmark')
                return
            estimator.add_gate(gate, *seed)
        pixels, points = row['pixels'], row['points']
        sigma = row.get('sigma_px', 1.)
        result = estimator.observe(gate, points, pixels, sigma, rim=rim)
        if not result['accepted'] and seed is not None and not estimator.localization:
            image = row.get('image_id', row['id'])
            if estimator.consider_nearer(gate, image, stamp, seed):
                result = estimator.observe(gate, points, pixels, sigma, rim=rim)
                result['nearer_landmark_bound'] = True
        if result['accepted']:
            estimator.last_visual[gate] = stamp
            if not rim:
                estimator.last_full_visual[gate] = stamp
        if result.get('gravity', {}).get('accepted'):
            estimator.last_gravity_time = stamp
        self.results[row['id']] = result

    def _replay(self,changed):
        choices=[i for i,(t,_) in enumerate(self.snapshots) if t<changed]
        if not choices:self.rejected_late+=1;return
        index=choices[-1];self.time,self.filter=self.snapshots[index][0],self.snapshots[index][1].copy()
        self.snapshots=self.snapshots[:index+1];end=self.gyros[-1][0]
        nodes=sorted({t for t,_ in self.gyros if self.time<t<=end}|{t for t,_ in self.commands if self.time<t<=end}|
            {o['time'] for o in self.observations if self.time<o['time']<=end})
        for stamp in nodes:
            self._advance(stamp)
            for at,acceleration in self.accelerations:
                if at==stamp:
                    motors=self._motor(stamp-1e-9)
                    # A command is not proof of liftoff. Support force is not an IMU bias.
                    upward=-float((self.filter.R @ acceleration+[0.,0.,9.81])[2])
                    if motors is not None and upward>1.5 and np.linalg.norm(acceleration)>9.81+1.5:self.filter.airborne=True
                    if not self.filter.airborne or stamp-self.filter.last_force_time<.05:continue
                    if motors is not None:
                        recent=[u for t,u in self.commands if stamp-.08<=t<stamp]
                        spread=max((float(np.max(abs(u-motors))) for u in recent),default=0.)
                        slope=self.filter.thrust_curve[0]+2*self.filter.thrust_curve[1]*float(np.mean(motors))
                        self.filter.observe_acceleration(acceleration,motors,float(np.hypot(.5,slope*spread)))
                        self.filter.last_force_time=stamp
            images={}
            for row in self.observations:
                if row['time']==stamp:images.setdefault(row.get('image_id',row['id']),[]).append(row)
            for rows in images.values():
                self.filter.begin_image()
                for row in rows:self._observe(row,stamp)
                self.filter.end_image()
            self.snapshots.append((stamp,self.filter.copy()));self.repropagated+=1
        boundary=end-self.seconds;keep=max(0,np.searchsorted([t for t,_ in self.snapshots],boundary)-1)
        self.snapshots=self.snapshots[keep:];oldest=self.snapshots[0][0]
        self.observations=[o for o in self.observations if o['time']>oldest]
        self.accelerations=[r for r in self.accelerations if r[0]>oldest]
        i=max(0,np.searchsorted([r[0] for r in self.gyros],oldest)-1);self.gyros=self.gyros[i:]
        i=max(0,np.searchsorted([r[0] for r in self.commands],oldest)-1);self.commands=self.commands[i:]

    def imu(self,stamp,gyro,acceleration=None):
        if stamp<=self.gyros[-1][0]:return
        self.gyros.append((stamp,np.asarray(gyro)))
        if acceleration is not None:self.accelerations.append((stamp,np.asarray(acceleration)))
        self._replay(stamp)

    def command(self,stamp,motors):
        self.commands.append((stamp,np.asarray(motors)));self.commands.sort(key=lambda r:r[0])
        if stamp<=self.time:self._replay(stamp)

    def observe(self,row):
        if row['time']<=self.snapshots[0][0]:self.rejected_late+=1;return
        self.observations.append(deepcopy(row));self.observations.sort(key=lambda o:(o['time'],o['id']))
        if row['time']<=self.time:self._replay(row['time'])
