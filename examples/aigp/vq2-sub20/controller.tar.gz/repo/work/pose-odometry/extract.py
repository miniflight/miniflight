"""Split the native acquisition into public observations and scoring reference."""

import base64
import gzip
import json
from pathlib import Path
import sys

import numpy as np
from pymavlink.dialects.v20 import common

from target.aigp.client import _Camera, _Track


def scoring_samples(msg, stamp):
    match msg.get_type():
        case 'HIGHRES_IMU':
            yield 'imu', (msg.time_usec*1e-6, stamp, msg.xacc, msg.yacc, msg.zacc,
                          -msg.xgyro, -msg.ygyro, -msg.zgyro)
        case 'LOCAL_POSITION_NED':
            yield 'position', (msg.time_boot_ms*.001, stamp, msg.x, msg.y, msg.z, msg.vx, msg.vy, msg.vz)
        case 'ATTITUDE':
            yield 'attitude', (msg.time_boot_ms*.001, stamp, msg.roll, -msg.pitch, -msg.yaw)
            yield 'attitude_rates', (msg.time_boot_ms*.001, -msg.rollspeed, -msg.pitchspeed, -msg.yawspeed)
        case 'ODOMETRY':
            yield 'odometry', (msg.time_usec*1e-6, msg.x, msg.y, msg.z, *msg.q, msg.vx, msg.vy, msg.vz,
                               -msg.rollspeed, -msg.pitchspeed, -msg.yawspeed, msg.frame_id, msg.child_frame_id)


def extract(trace, scoring_only=False):
    camera, course, decoder = _Camera(), _Track(), common.MAVLink(None)
    imu, jpeg, frames, position, attitude = [], [], [], [], []
    attitude_rates, odometry = [], []
    samples = dict(imu=imu, position=position, attitude=attitude, attitude_rates=attitude_rates, odometry=odometry)
    armed, impacts = [], []
    opened = gzip.open(trace, 'rt') if trace.suffix == '.gz' else trace.open()
    with opened as source:
        for row in map(json.loads, source):
            if row.get('event') != 'call':
                continue
            if row['name'] == 'arm':
                armed.append(row['host_time'])
            if row['name'] != 'poll':
                continue
            for packet in row.get('result', []):
                wire = base64.b64decode(packet['wire'])
                stamp = packet['received_at']
                if packet['camera']:
                    if scoring_only:
                        continue
                    frame = camera.receive(wire, stamp)
                    if frame is not None:
                        frames.append((frame.id, frame.time_ns, stamp))
                        jpeg.append(camera.jpeg)
                    continue
                for msg in decoder.parse_buffer(wire) or ():
                    for name, values in scoring_samples(msg, stamp):
                        samples[name].append(values)
                    match msg.get_type():
                        case 'COLLISION' if len(armed) == 1:
                            impacts.append((msg.id, msg.threat_level, msg.horizontal_minimum_delta))
                        case 'DATA_TRANSMISSION_HANDSHAKE':
                            course.start(msg)
                        case 'ENCAPSULATED_DATA' if msg.data[0] == 2:
                            course.receive(msg, stamp)
    output = trace.parent
    if len(armed) != 2:
        raise ValueError('Missing native arm/disarm boundary')
    if scoring_only:
        gates = [dict(id=g.id, position=g.position, orientation=g.orientation, width=g.width, height=g.height)
                 for g in (course.gates or ())]
        saved = output.parent/'scoring-gates.json'
        if not gates and saved.is_file():
            gates = json.loads(saved.read_text())
        np.savez_compressed(output/'truth.npz', position=position, attitude=attitude, armed=armed,
                            imu=imu, attitude_rates=attitude_rates, odometry=odometry,
                            gate_ids=[g['id'] for g in gates], gate_pivots=[g['position'] for g in gates],
                            gate_quaternions=[g['orientation'] for g in gates],
                            gate_dimensions=[[g['width'], g['height']] for g in gates])
        return dict(armed_collision_reports=len(impacts),
                    severe_collision_reports=sum(severity >= 2 for _, severity, _ in impacts),
                    peak_collision_impulse_kg_m_s=max((impulse for _, _, impulse in impacts), default=0.))
    if not frames or not imu or not course.gates or not position or not attitude:
        raise ValueError('Missing camera, IMU, map or native scoring poses')
    frame_id, camera_time, receipt = zip(*frames)
    gates = [dict(id=g.id, position=g.position, orientation=g.orientation, width=g.width, height=g.height) for g in course.gates]
    np.savez_compressed(output/'public.npz', imu=imu, frame_id=frame_id, camera_ns=np.array(camera_time, dtype=np.int64),
                        receipt=receipt, image=np.frombuffer(b''.join(jpeg), np.uint8), offsets=np.r_[0, np.cumsum(list(map(len, jpeg)))])
    (output/'map.json').write_text(json.dumps(gates, indent=2)+'\n')
    np.savez_compressed(output/'truth.npz', position=position, attitude=attitude, armed=armed)
    print(f'{len(frames)} camera frames, {len(imu)} IMU samples, {len(gates)} wire gates', flush=True)


if __name__ == '__main__':
    extract(Path(sys.argv[1]), scoring_only='--score-only' in sys.argv)
