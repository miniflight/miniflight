"""Score the measured motion and the resulting gate map on recorded VQ1 flights."""

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.transform import Rotation

from fly_one_gate import APERTURE
from gate_links import fit_links, motion_integrals, read_evidence
from mapped import translation
from refine_gate_map import MESH_FROM_GATE, legacy_opening_offset, interpolate, packet_map
from score import monotone


def reference(path):
    with np.load(path/'truth.npz', allow_pickle=False) as truth:
        mesh = Rotation.from_quat(truth['gate_quaternions'], scalar_first=True)
        pivots = truth['gate_pivots']
        trajectory = monotone(truth['position'])
    world = (mesh[0]*MESH_FROM_GATE).inv()
    opening_offset = legacy_opening_offset()
    origin = pivots[0]+mesh[0].apply(opening_offset)
    center = world.apply(pivots+mesh.apply(opening_offset)-origin)
    position = world.apply(trajectory[:, 2:5]-origin)
    return center, world.apply(pivots-origin), world*mesh, trajectory[:, 0], position


def close_errors(path, flight):
    centers, _, _, time, truth = reference(path)
    with np.load(path/'learned-course.npz', allow_pickle=False) as data:
        history, images = data['gates'], data['image_poses']
    errors = []
    for t, gate, camera, pixels, _, _, _ in flight.views:
        poses = history[history[:, 1] == gate]
        orientation = Rotation.from_quat(poses[np.argmin(np.abs(poses[:, 0]-t)), 5:9])
        relative = -translation(orientation.apply(APERTURE), pixels, camera)
        if 3. < np.linalg.norm(relative) < 12.:
            actual = interpolate(time, truth, [t])[0]
            onboard = images[np.argmin(np.abs(images[:, 0]-t)), 1:4]
            errors.append((gate, onboard[0]-actual[0], relative[0]-(centers[gate, 0]-actual[0])))
    return errors


def leg_errors(path, calibration):
    with np.load(path/'learned-course.npz', allow_pickle=False) as data:
        poses = monotone(data['pose'])
    time, odometry, transverse, forward, _ = motion_integrals(path, poses)
    corrected = transverse+forward/np.sqrt(calibration)
    centers, _, _, ref_time, position = reference(path)
    crossings = []
    for gate in centers:
        x = position[:, 0]-gate[0]
        indices = np.flatnonzero((x[:-1] < 0.) & (x[1:] >= 0.))
        if not len(indices):
            raise ValueError(f'{path}: final scoring bracket unavailable')
        j = indices[0]
        crossings.append(np.interp(0., x[j:j+2], ref_time[j:j+2]))
    if crossings[0] < time[0] or crossings[-1] > time[-1]+.05:
        raise ValueError(f'{path}: insufficient IMU coverage for distance comparison')
    expected = np.diff(centers[:, 0])
    return [np.diff(np.interp(crossings, time, values[:, 0]))-expected for values in (odometry, corrected)]


def analyze(root, output):
    paths = sorted(root.glob('flight-[0-9][0-9]'))
    flights, history, components = [], [], []
    prior = None
    for path in paths:
        flight = read_evidence(path)
        flights.append(flight)
        course, sizes, evidence = fit_links(flights, prior)
        prior = course
        packet = packet_map(course, sizes, evidence['pivot_below_opening_m'])
        center, pivot, mesh, _, _ = reference(path)
        native = json.loads((path/'map-score.json').read_text())
        learned = len(course)
        coordinates = np.asarray([gate['position'] for gate in packet['gates']])
        quaternions = Rotation.from_quat([gate['orientation'] for gate in packet['gates']], scalar_first=True)
        history.append(dict(flight=path.name, count=learned, native_gates=native['active_gate_index'],
                            center_errors_m=np.linalg.norm(course[:, :3]-center[:learned], axis=1).tolist(),
                            pivot_errors_m=np.linalg.norm(coordinates-pivot[:learned], axis=1).tolist(),
                            rotation_errors_deg=np.degrees((mesh[:learned].inv()*quaternions).magnitude()).tolist(),
                            recorded_pivot_mae_m=native.get('pivot_m'), recorded_count=native.get('map_gates'),
                            mapper=native.get('map_estimator', 'bundle adjustment'), **evidence))
        if native.get('completed') and native.get('map_estimator') != 'gate_links':
            components.extend(close_errors(path, flight))

    calibration = float(np.median([f.launch_drag for f in flights[:5] if f.launch_drag is not None]))
    holdout = np.asarray([leg_errors(root/f'flight-{i:02}', calibration) for i in (8, 9)])
    components = np.asarray(components)
    groups = [components[components[:, 0] == i, 1:] for i in range(6)]
    signed = np.asarray([g.mean(axis=0) for g in groups])
    output.mkdir(parents=True, exist_ok=True)
    (output/'results.json').write_text(json.dumps(dict(
        calibration_first_five_per_m=calibration, heldout_flights=[8, 9],
        longitudinal_leg_errors_m=holdout.tolist(), close_view_counts=[len(g) for g in groups],
        close_view_mean_camera_and_relative_error_m=signed.tolist(), history=history), indent=2)+'\n')

    fig, axes = plt.subplots(2, 2, figsize=(11, 7.5), layout='constrained')
    camera, relative = signed.T
    gates = np.arange(1, 7)
    navy, green, orange = '#305479', '#00786f', '#d17a26'
    ax = axes[0, 0]
    ax.bar(gates-.16, camera, .32, color=navy, label='Camera position')
    ax.bar(gates+.16, relative, .32, color=orange, label='Gate relative to camera')
    ax.set(title='What places a close gate too far downtrack?', ylabel='Mean signed error (m)', xlabel='Gate')
    ax.legend(frameon=False)
    ax = axes[0, 1]
    leg = np.arange(1, 6)
    original, drag = np.mean(np.abs(holdout), axis=0)
    ax.bar(leg-.17, original, .34, color=navy, label='Integrated onboard velocity')
    ax.bar(leg+.17, drag, .34, color=green, label='Forward speed from drag')
    ax.set_xticks(leg, [f'{i}–{i+1}' for i in leg])
    ax.set(title='Independent flights 8 and 9', ylabel='Mean absolute downtrack error (m)', xlabel='Gate pair')
    ax.set_ylim(0., 1.32*max(original.max(), drag.max()))
    ax.legend(frameon=False, loc='upper left')
    ax = axes[1, 0]
    n = np.arange(1, len(history)+1)
    archived = [h['recorded_pivot_mae_m'] if h['recorded_count'] == 6 and h['mapper'] != 'gate_links' else np.nan
                for h in history]
    links = [np.mean(h['pivot_errors_m'][1:]) if h['count'] == 6 else np.nan for h in history]
    deployed = [h['recorded_pivot_mae_m'] if h['recorded_count'] == 6 and h['mapper'] == 'gate_links' else np.nan
                for h in history]
    ax.semilogy(n, archived, '.-', color=navy, label='Original saved map')
    ax.semilogy(n, links, '.-', color=green, label='Gate links, prefix replay')
    ax.scatter(n, deployed, color=orange, zorder=3, label='Gate links, native flight')
    ax.axhline(.10, ls=':', color='0.4', lw=1)
    ax.set(title='Complete maps in the frame of gate 1', xlabel='Flight attempt', ylabel='Mean pivot error (m)')
    ax.set_xticks(np.arange(1, len(history)+1, max(1, len(history)//8)))
    ax.set_yticks([.1, .25, .5, 1., 2., 5.], ['0.10', '0.25', '0.50', '1', '2', '5'])
    ax.legend(frameon=False, fontsize=8)
    ax = axes[1, 1]
    last = json.loads((paths[-1]/'map-score.json').read_text())
    ax.bar(gates[1:]-.16, [g['center_m'] for g in last['gates'][1:]], .32, color=navy, label='Opening center')
    ax.bar(gates[1:]+.16, [g['pivot_m'] for g in last['gates'][1:]], .32, color=green, label='Packet pivot')
    ax.axhline(.10, ls=':', color='0.4', lw=1, label='10 cm')
    ax.set(title=f'Saved map after flight {len(paths)}', xlabel='Gate', ylabel='3D position error (m)')
    ax.legend(frameon=False)
    for ax in axes.ravel():
        ax.grid(axis='y', alpha=.18)
        ax.set_axisbelow(True)
    fig.savefig(output/'gate-map-diagnosis.png', dpi=160)
    plt.close(fig)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('flights', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    analyze(args.flights, args.output)
