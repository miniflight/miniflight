"""Track static optical landmarks while following gates in the order seen."""

import argparse
import base64
from collections import deque
from dataclasses import asdict, replace
from hashlib import sha256
from inspect import getsourcefile
import json
from pathlib import Path
import sys
from time import monotonic, time
from typing import NamedTuple

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

from miniflight import vehicle
from miniflight.diagnostics import write_snapshot
from miniflight.position import GRAVITY, acceleration_control
from target.aigp.controllers.r1_motors import Controller as MotorPilot
from target.aigp.experiments.flight import rollout
from target.aigp.experiments.gate_pose import estimate, fit_outline
from target.aigp.native import TARGETS, RaceStateReader

from fly_one_gate import APERTURE, Client, GateObserver, SQUARE_FROM_GATE
from target.aigp.controllers.r1_beautiful import CONFIG
from mapped import ANGLE, CAMERA_FROM_BODY, K, apertures, colored_rim, gate_masks, opening_range_sigma, translation
from plan_corridor import leg_reference, thrust_demand
from launch_reference import LaunchReference
from learned_line import RacingLine
from rednose_model import PoseFilter, cross, integrate, pixel_factor, pose_at, project
from rednose_replay import corner_noise, gate_update, inertial_intervals, reacquire
from rim import CHASSIS_RADIUS, GATE_DEPTH, GATE_HALF_WIDTH, crossing_clearance, edges, probes
from vanishing import Vanishing


PILOT_SHA256 = sha256(Path(__file__).read_bytes()).hexdigest()
IMU_TIMEOUT = .30
GATE_VIEW_AGE = 1.6

def width(pixels):
    return float(np.median(np.linalg.norm(np.roll(pixels, 1, axis=0)-pixels, axis=1)))


def carried_opening_error(expected, center, position):
    if expected is None:
        return np.inf
    prior, radius = expected
    measurement_radius = opening_range_sigma(np.linalg.norm(center-position))
    return np.linalg.norm(center-prior)/min(radius, measurement_radius)


def fit_openings(quad, span, camera, attitude, position, previous_center, yaw_hint):
    """Keep both square-pose branches until the observations distinguish them."""
    prior = Rotation.from_euler('z', yaw_hint)
    if span < 24.:
        models = [(prior, -translation(prior.apply(APERTURE), quad, camera))]
    else:
        models = []
        for solution in estimate(quad, 1.5, K):
            if not np.isfinite(solution['reprojection_coordinate_rmse_px']):
                continue
            plane = camera.T@Rotation.from_rotvec(solution['rotation_vector_rad']).as_matrix()@SQUARE_FROM_GATE
            models.append((Rotation.from_matrix(plane), camera.T@solution['translation_camera_m']))
    fits = []
    for rotation, relative in models:
        center, depth = position+relative, np.linalg.norm(relative)
        if depth <= 3. or np.linalg.norm(center-previous_center) <= 3.:
            continue
        if opening_range_sigma(depth) > 3.:
            continue
        pixels, depths = project(rotation.apply(APERTURE)+relative, np.zeros(3), attitude)
        residual = np.mean((pixels-quad)**2)
        if min(depths) > 0. and residual < max(2., .08*span)**2:
            cost = residual+.25*(prior.inv()*rotation).magnitude()**2
            fits.append((cost, depth, center, rotation, span))
    return [row[1:] for row in sorted(fits, key=lambda row: row[0])]


def fit_opening(*args):
    return next(iter(fit_openings(*args)), None)


def partial_opening(image, index, center, plane, position, attitude, *, metric=False):
    """Update from rim lines. Require independent range evidence for a metric fit."""
    camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
    aperture = plane.apply(APERTURE)+center
    depth = (center-position)@camera[2]
    tolerance = np.clip(3.*(.8+K[0, 0]*.075/max(1., depth)), 7., 20.)
    basis = np.eye(3) if metric else camera.T[:, :2]
    jacobian, innovation = [], []
    for _, edge, measured in probes(image, edges([(index, aperture)], GATE_DEPTH),
                                    position, camera, dark_opening=True, tolerance=tolerance):
        pixels, _ = project(edge, position, attitude)
        direction = pixels[1]-pixels[0]
        normal = np.array([-direction[1], direction[0]])/np.linalg.norm(direction)
        predicted, _, spatial = pixel_factor(edge.mean(axis=0), position, attitude)
        jacobian.append(normal@spatial@basis)
        innovation.append(normal@(measured.mean(axis=0)-predicted))
    dimension = basis.shape[1]
    if len(jacobian) < dimension:
        return None
    shift, _, rank, _ = np.linalg.lstsq(jacobian, innovation, rcond=.06 if metric else .15)
    limit = 2.*opening_range_sigma(depth) if metric else tolerance*max(1., depth)/K[0, 0]
    if rank < dimension or np.linalg.norm(shift) > limit:
        return None
    residual = np.asarray(jacobian)@shift-innovation
    error = np.linalg.norm(np.r_[residual, np.asarray(jacobian)@shift])/tolerance
    return center+basis@shift, len(jacobian), error


def clipped_edges(contours, image_shape, exterior=False):
    """Return three measured sides of a gate square cut by one image boundary."""
    rows, cols = image_shape[:2]
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        cuts = [(axis, edge) for hit, axis, edge in (
            (x <= 1, 0, 0), (x+w >= cols-1, 0, w-1), (y <= 1, 1, 0), (y+h >= rows-1, 1, h-1)) if hit]
        if not cuts or (exterior and len(cuts) != 1) or cv2.contourArea(contour) < 80:
            continue
        origin = np.array([x, y], dtype=np.int32)
        if exterior:
            hull = cv2.convexHull(contour)
            if cv2.contourArea(contour) >= .85*cv2.contourArea(hull):
                continue
        else:
            component = np.zeros((h, w), np.uint8)
            cv2.drawContours(component, [contour-origin], -1, 1, cv2.FILLED)
        for axis, boundary in cuts:
            if exterior:
                squares = [hull-origin]
            else:
                closed = component.copy()
                np.moveaxis(closed, 1-axis, 0)[boundary] = 1
                holes, tree = cv2.findContours(closed, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
                squares = [cv2.convexHull(hole) if len(cuts) > 1 else hole
                           for hole, node in zip(holes, tree[0], strict=True) if node[3] >= 0]
            for square in squares:
                quad = cv2.approxPolyDP(square, max(1.5, .035*cv2.arcLength(square, True)), True).reshape(-1, 2)
                if len(quad) != 4 or not cv2.isContourConvex(quad):
                    continue
                # Start at a clipped endpoint and follow the three measured sides.
                cut = np.abs(quad[:, axis]-boundary) <= 2
                starts = np.flatnonzero(cut & ~np.roll(cut, -1))
                if cut.sum() == 2 and len(starts) == 1:
                    rails = np.roll(quad, -starts[0], axis=0)+origin
                    lengths = np.linalg.norm(np.diff(rails, axis=0), axis=1)
                    if lengths[1] >= 14. and min(lengths[0], lengths[2]) >= 5.:
                        yield rails


def rim_look_point(rails):
    across = rails[2]-rails[1]
    span = np.linalg.norm(across)
    inward = np.array([-across[1], across[0]])/span
    inward *= np.sign(inward@(rails[0]-rails[1]))
    pixel = (rails[1]+rails[2])/2.+inward*span/2.
    return np.linalg.solve(K, np.r_[pixel, 1.])*(K[0, 0]*1.50/span)


def fit_clipped_opening(rails, camera, attitude, position, side=1.50):
    """Fit an upright aperture from two measured corners and three visible sides."""
    pixels = rails[1:3]
    rays = np.c_[(rails-K[:2, 2])/np.diag(K)[:2], np.ones(4)]@camera
    normals = np.cross(rays[:-1], rays[1:])
    normals /= np.maximum(1.e-9, np.linalg.norm(normals, axis=1, keepdims=True))
    vertical = np.abs(normals[:, 2]) < .08
    # A horizontal rim edge fixes the gate normal when its ray plane is tilted.
    if vertical[0] and vertical[2]:
        normal, vertical_edge = normals[1, :2], False
    elif vertical[1]:
        first, last = normals[[0, 2], :2]
        normal, vertical_edge = first+np.sign(first@last)*last, True
    else:
        return None
    view = rays[1:3, :2].mean(axis=0)
    if np.linalg.norm(normal) < .15:
        normal = view
    if normal@view < 0.:
        normal = -normal
    plane = Rotation.from_euler('z', np.arctan2(normal[1], normal[0]))
    corners = plane.apply(APERTURE*(side/1.50))
    measured_sides = rails[[0, 3]]-pixels
    span = np.linalg.norm(pixels[1]-pixels[0])
    fits = []
    for first in range(4):
        for step in (-1, 1):
            second = (first+step)%4
            edge_is_vertical = APERTURE[first, 2] != APERTURE[second, 2]
            if edge_is_vertical != vertical_edge:
                continue
            pair = [first, second]
            relative = -translation(corners[pair], pixels, camera)
            whole, depth = project(corners+relative, np.zeros(3), attitude)
            if min(depth) <= .25:
                continue
            sides = whole[[(first-step)%4, (second+step)%4]]-whole[pair]
            fraction = np.sum(measured_sides*sides, axis=1)/np.maximum(1.e-6, np.sum(sides**2, axis=1))
            residual = np.r_[np.linalg.norm(whole[pair]-pixels, axis=1),
                             np.linalg.norm(measured_sides-fraction[:, None]*sides, axis=1)]
            if fraction.min() > 0. and fraction.max() <= 1.10 and residual.max() <= max(2.5, .03*span):
                fits.append((np.linalg.norm(residual), np.linalg.norm(relative), position+relative, plane, span))
    if fits:
        return min(fits, key=lambda fit: fit[0])[1:]


def measure_clipped_square(rails, camera, side):
    """Recover a square from one complete edge and two visible adjacent sides."""
    rays = np.c_[(rails-K[:2, 2])/np.diag(K)[:2], np.ones(4)]
    normals = np.cross(rays[:-1], rays[1:])
    normals /= np.maximum(1.e-9, np.linalg.norm(normals, axis=1, keepdims=True))
    inward = np.cross(normals[0], normals[2])
    length = np.linalg.norm(inward)
    if length < .05:
        return None
    inward /= length
    across = np.cross(inward, normals[1])
    across /= max(1.e-9, np.linalg.norm(across))
    depths = np.linalg.lstsq(np.stack((-rays[1], rays[2]), axis=1), side*across, rcond=None)[0]
    if depths.mean() < 0.:
        depths, across = -depths, -across
    if depths.min() <= .25:
        return None
    vertices = rays[1:3]*depths[:, None]
    direction = inward[:2]-rays[1:3, :2]*inward[2]
    if np.sum(direction*(rails[[0, 3]]-rails[1:3])) < 0.:
        inward = -inward
    for ray, vertex in zip(rays[[0, 3]], vertices, strict=True):
        depth, run = np.linalg.lstsq(np.stack((ray, -inward), axis=1), vertex, rcond=None)[0]
        if depth <= .25 or not 0. < run < 1.10*side:
            return None
    centre = vertices.mean(axis=0)+.5*side*inward
    down = camera.T @ inward
    right = camera.T @ across
    if abs(right[2]) > abs(down[2]):
        down = right
    if abs(down[2]) < 1.e-6:
        return None
    down *= np.sign(down[2])
    forward = camera.T @ np.cross(across, inward)
    forward *= np.sign(forward @ (camera.T @ centre))
    rotation = Rotation.from_matrix(np.stack((forward, np.cross(down, forward), down), axis=1))
    return camera.T @ centre, rotation, (vertices-centre) @ camera


def match_inner_corners(partials, gate, position, attitude, position_error_m=None):
    """Associate the two measured corners and both side directions with the locked gate."""
    ident, world = gate
    pixels, depth = project(world, position, attitude)
    if position_error_m is None and min(depth) <= .25:
        return None
    camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
    matches = []
    for rails in partials:
        measured = rails[1:3]
        sides = rails[[0, 3]]-measured
        span = np.linalg.norm(measured[1]-measured[0])
        tolerance = np.clip(.14*span, 5., 20.)
        for step in (1, -1):
            for first in range(4):
                pair = np.array([first, (first+step)%4])
                fitted = pixels
                minimum_cosine = .85
                if position_error_m is not None:
                    if span < 30.:
                        continue
                    shifted = translation(world[pair], measured, camera)
                    if np.linalg.norm(shifted-position) > position_error_m:
                        continue
                    fitted, depths = project(world, shifted, attitude)
                    if depths.min() <= .8:
                        continue
                    minimum_cosine = .95
                error = np.max(np.linalg.norm(fitted[pair]-measured, axis=1))
                if error > (3. if position_error_m is not None else tolerance):
                    continue
                expected = fitted[(pair+[-step, step])%4]-fitted[pair]
                cosine = np.sum(expected*sides, axis=1)/np.maximum(1., np.linalg.norm(expected,axis=1)*np.linalg.norm(sides,axis=1))
                if min(cosine) > minimum_cosine:
                    matches.append((ident, world[pair], measured))
    return matches[0] if len(matches) == 1 else None


def yaw_of(rotation):
    forward = rotation.apply([1., 0., 0.])
    return np.arctan2(forward[1], forward[0])


def orient_gate(rotation, toward):
    """Point the signed normal from the approach side through the opening."""
    return rotation if rotation.apply([1., 0., 0.])@toward >= 0. else rotation*Rotation.from_euler('z', np.pi)


def trajectory_travel(velocity, acceleration, jerk, snap, seconds):
    return seconds*(velocity+seconds*(acceleration/2.+seconds*(jerk/6.+seconds*snap/24.)))


def camera_axes(down, yaw):
    heading = np.stack((np.cos(yaw), np.sin(yaw), np.zeros_like(yaw)), axis=-1)
    right = np.cross(down, heading)
    right /= np.maximum(.01, np.linalg.norm(right, axis=-1, keepdims=True))
    down = np.broadcast_to(down, right.shape)
    return CAMERA_FROM_BODY @ np.stack((np.cross(right, down), right, down), axis=-2)


def plan_traverse(config, plane, offset, velocity, speed, attitude=None, *, after_gate=None, lock_age=np.inf,
                  exit_limit=None):
    """Find a feasible short trajectory to the aperture with normal exit velocity."""
    earliest = max(.35, np.linalg.norm(offset)/speed)
    latest = 4.8
    if earliest > latest:
        return None
    horizons = np.linspace(earliest, latest, 32)[:, None, None]
    axes = plane.as_matrix()
    world_offset = offset@axes.T
    floor_angle = np.arctan(K[1, 2]/K[1, 1])-ANGLE
    below_frame = world_offset[2]-np.linalg.norm(world_offset[:2])*np.tan(floor_angle)
    dips = [0., .5*below_frame, below_frame] if attitude is not None and below_frame > 0. else [0.]
    bend = np.tile(dips, 4)[:, None]*axes[2]
    terminal_speeds = (speed if exit_limit is None else min(speed, exit_limit))*np.repeat([1., .8, .625, .45], len(dips))
    terminal = terminal_speeds[None, :, None]*np.array([1., 0., 0.])
    cubic_start = 6.*offset/horizons**2-(4.*velocity+2.*terminal)/horizons
    cubic_end = -6.*offset/horizons**2+(2.*velocity+4.*terminal)/horizons
    # 16*b*u²*(1-u)² moves the midpoint by b and leaves both endpoint states intact.
    start = cubic_start+32.*bend/horizons**2
    jerk = (cubic_end-cubic_start)/horizons-192.*bend/horizons**3
    snap = 384.*bend/horizons**4
    limit = config.max_horizontal_acceleration or config.max_acceleration
    def reachable(a):
        horizontal = np.minimum(limit, (GRAVITY-a[..., 2])*np.tan(config.max_tilt))
        return (np.linalg.norm(a[..., :2], axis=-1) <= horizontal) & (np.abs(a[..., 2]) <= config.max_acceleration)
    fractions = np.linspace(0., 1., 9)[:, None, None, None]
    times = fractions*horizons
    velocities = velocity+times*(start+times*(jerk/2.+times*snap/6.))
    net = thrust_demand(config, (start+times*(jerk+.5*times*snap))@axes.T, velocities@axes.T)
    forward = np.min(velocities[..., 0], axis=0)
    peak_speed = np.max(np.linalg.norm(velocities, axis=-1), axis=0)
    fits = reachable(net).all(axis=0) & (forward >= -1.e-6)
    fits &= peak_speed <= max(speed, np.linalg.norm(velocity))
    rows, options = np.nonzero(fits)
    if not len(rows):
        return None

    start, jerk, snap = (coefficient[rows, options] for coefficient in (start, jerk, snap))
    duration = horizons[rows, 0, 0]
    view_loss = np.zeros_like(duration)
    last_view = np.full_like(duration, -lock_age)
    if attitude is not None:
        # Convert planned thrust and gaze into the physical camera axes.
        times, net = times[:, rows, 0], net[:, rows, options]
        relative = (offset-trajectory_travel(velocity, start, jerk, snap, times))@axes.T
        # Close clipping does not count as lost view.
        ticks, plans = np.nonzero(np.linalg.norm(relative, axis=-1) > 2.*GATE_HALF_WIDTH)
        if len(ticks):
            relative = relative[ticks, plans]
            seconds = times[ticks, plans]
            down = np.array([0., 0., GRAVITY])-net[ticks, plans]
            down /= np.linalg.norm(down, axis=-1, keepdims=True)
            current_down = Rotation.from_euler('xyz', attitude).apply([0., 0., 1.])
            blend = 1.-np.exp(-config.attitude_gain*seconds)
            down = current_down+blend*(down-current_down)
            down /= np.linalg.norm(down, axis=-1, keepdims=True)
            yaw = np.arctan2(relative[:, 1], relative[:, 0])
            yaw_error = (yaw-attitude[2]+np.pi)%(2.*np.pi)-np.pi
            yaw_limit = config.max_rate*seconds[:, 0]
            yaw = attitude[2]+np.clip(yaw_error, -yaw_limit, yaw_limit)
            opening = relative[:, None, :]+plane.apply(APERTURE)
            rays = opening @ camera_axes(down, yaw).swapaxes(-1, -2)
            depth = rays[..., 2:3]
            inside = (depth[..., 0] > .25) & np.all(np.abs(rays[..., :2])*np.diag(K)[:2] <= depth*K[:2, 2], axis=-1)
            visible = inside.sum(axis=1) >= 3
            lost = plans[~visible]
            view_loss = np.bincount(lost, minlength=len(duration))/len(times)
            np.maximum.at(last_view, plans[visible], seconds[visible, 0])
    # Find where each candidate enters the final metre of the approach.
    alignment_distance = 1.
    lower = np.zeros_like(duration)
    upper = duration.copy()
    for _ in range(9):
        seconds = (lower+upper)/2.
        distance = trajectory_travel(velocity[0], start[..., 0], jerk[..., 0], snap[..., 0], seconds)
        before = distance < offset[0]-alignment_distance
        lower, upper = np.where(before, seconds, lower), np.where(before, upper, seconds)

    span = duration-upper
    near_time = (upper+np.linspace(0., 1., 7)[:, None]*span)[..., None]
    near_velocity = velocity+near_time*(start+near_time*(jerk/2.+near_time*snap/6.))
    slope = (.75-2.*CHASSIS_RADIUS)/alignment_distance
    excess = np.maximum(0., np.linalg.norm(near_velocity[..., 1:], axis=-1)-slope*near_velocity[..., 0])
    sideways = span*np.mean(.5*(excess[1:]+excess[:-1]), axis=0)
    best = np.lexsort((duration, view_loss, sideways))[0]
    exit_speeds = terminal_speeds[options]
    if after_gate is not None:
        finish_time = duration+np.interp(exit_speeds, *after_gate)
        usable = (sideways == sideways[best]) & (duration-last_view <= GATE_VIEW_AGE) & np.isfinite(finish_time)
        if usable.any():
            best = np.argmin(np.where(usable, finish_time, np.inf))
    return start[best]@axes.T, jerk[best]@axes.T, snap[best]@axes.T, duration[best], exit_speeds[best]


def plan_exit_view(config, angles, heading, corners, velocity, acceleration, turn, successor, traverse):
    """Aim through the view shared by the locked aperture and the next look point."""
    aim = heading+turn*np.linspace(0., 1., 5)
    delta = (aim-angles[2]+np.pi)%(2.*np.pi)-np.pi
    acceleration = np.array(acceleration, copy=True)
    acceleration[2] = np.clip(acceleration[2], -config.max_acceleration, config.max_acceleration)
    horizontal = config.max_horizontal_acceleration or config.max_acceleration
    horizontal = min(horizontal, (GRAVITY-acceleration[2])*np.tan(config.max_tilt))
    acceleration[:2] *= min(1., horizontal/max(.01, np.linalg.norm(acceleration[:2])))
    if traverse is None:
        time = np.array([.5, 1., 2.])/config.attitude_gain
        travel = time[:, None]*velocity+.5*time[:, None]**2*acceleration
        net = acceleration[None]
    else:
        start, jerk, snap, duration, _ = traverse
        time = np.linspace(min(.12,.2*duration), duration, 9)
        seconds = time[:, None]
        travel = trajectory_travel(velocity, start, jerk, snap, seconds)
        net = start+seconds*(jerk+.5*seconds*snap)
    blend = 1.-np.exp(-config.attitude_gain*time)
    yaw = angles[2]+np.clip(blend[:, None]*delta, -config.max_rate*time[:, None], config.max_rate*time[:, None])
    down = np.array([0., 0., GRAVITY])-net
    down /= np.linalg.norm(down, axis=-1, keepdims=True)
    initial_down = Rotation.from_euler('xyz', angles).apply([0., 0., 1.])
    down = initial_down+blend[:, None]*(down-initial_down)
    down /= np.linalg.norm(down, axis=1, keepdims=True)
    centre = corners.mean(axis=0)
    points = np.vstack((corners, centre, successor))
    rays = (points-travel[:, None])[:, None] @ camera_axes(down[:, None], yaw).swapaxes(-1, -2)
    depth = rays[..., 2]
    px = rays[..., :2]*np.diag(K)[:2]/depth[..., None].clip(.01)+K[:2, 2]
    margin = np.where(depth > .25, np.minimum(px-8., 2.*K[:2, 2]-8.-px).min(axis=-1), -320.)
    inside = margin[..., :4] >= 0.
    edge = np.any(inside & np.roll(inside, -1, axis=-1), axis=-1)
    locked = edge & (margin[..., 4] >= 0.)
    useful = np.linalg.norm(centre-travel, axis=1) > .75+CHASSIS_RADIUS
    keeps_lock = np.all(~(locked[:, :1] & useful[:, None]) | locked, axis=0)
    useful_lock = np.any(locked & useful[:, None], axis=0)
    eligible = keeps_lock & useful_lock
    eligible[0] = True
    overlap = (locked & useful[:, None] & (margin[..., 5] >= 0.)).sum(axis=0)
    strength = np.clip(margin[-1, :, 5], -200., 40.)
    best = np.argmax(np.where(eligible, overlap*250.+strength, -np.inf))
    return aim[best]


class CoursePoseFilter(PoseFilter):
    # A gate whose pose we just learned cannot recalibrate the IMU.
    estimate_bias = False

    def add_landmark(self):
        """Allocate a pose only when an unfamiliar gate has been observed."""
        self.N += 1
        self.msckf = True
        self.dim_x += 7
        self.dim_err += 6
        self.x = np.pad(self.x, ((0, 7), (0, 0)))
        self.x[-1, 0] = 1.
        self.P = np.pad(self.P, ((0, 6), (0, 6)))
        self.mod = np.eye(self.dim_x, self.dim_err)
        self.augment_times.append(self.filter_time)

    def update_orientation(self, residual, jacobian, deviation):
        # Parallel lines measure attitude. Keep their gain out of translation and the map.
        rotation = slice(3, 6)
        P = self.P[rotation, rotation]
        H = jacobian[:, rotation]
        variance = deviation**2
        weighted = H.T/variance
        gain = np.linalg.solve(np.eye(3)+P @ weighted @ H, P @ weighted)
        delta = np.zeros((self.dim_err, 1))
        delta[rotation, 0] = gain @ residual
        result = self.x.copy()
        self.err_function(self.x, delta, result)
        self.x = result

        retained = np.eye(self.dim_err)
        retained[rotation, rotation] -= gain @ H
        self.P = retained @ self.P @ retained.T
        self.P[rotation, rotation] += (gain*variance) @ gain.T
        self.P = .5*(self.P+self.P.T)


class CourseGeometry(NamedTuple):
    course: tuple
    range_sigma: tuple
    cross_sigma: tuple
    metric_seen: dict
    seen: dict
    edge_seen: dict
    confirmed_normal: int | None
    clipped_close_gate: int | None
    position_recovering: tuple | None
    near_plane: tuple | None
    received_at: float


class CourseObserver(GateObserver):
    filter_type = CoursePoseFilter
    confirm_large_corrections = True
    track_pose_branches = False
    mapped_rim_bearings = False
    camera_offset_s = 0.

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.course = ((np.zeros(3), Rotation.identity()),)
        self.saved_course = self.course
        self.range_sigma = (0.,)
        self.cross_sigma = (0.,)
        self.active = 0
        self.pending_openings = []
        self.recovery = []
        self.locked_image = None
        self.near_plane = None
        self.confirmed_normal = None
        self.normal_views = deque(maxlen=12)
        self.landmark_log = []
        self.acquisitions = []
        self.acquisition_support = []
        self.pose_ambiguity = []
        self.successor_views = []
        self.partial_confirmations = []
        self.portal_evidence = []
        self.identity_bounds = {}
        self.reacquisitions = []
        self.rejected = []
        self.rejected_factors = {}
        self.rim_bearing_updates = []
        self.pending_position = None
        self.position_recovering = None
        self.position_recoveries = []
        self.gate_recoveries = []
        self.opening_motion = None
        self.opening_velocity = []
        self.last_image = None
        self.handoff_images = {}
        self.recent_images = deque(maxlen=30)
        self.seen = {}
        self.metric_seen = {}
        self.clipped_close_gate = None
        self.edge_seen = {}
        self.edge_visibility = []
        self.visibility = []
        self.detections = []
        self.pixel_innovations = []
        self.image_corners = []
        self.image_bounds = []
        self.image_poses = []
        self.image_poses_prior = []
        self.last_saved_image = -np.inf
        self.prior = np.empty((0, 7))
        self.preview_course = False
        self.confirmed_gates = 0
        self.rim_hints = ()
        self.border_sighting = None
        self.border_candidate = None
        self.lower_sighting = None
        self.viewed_sector = None
        self.opening_hint = None
        self.rim_tracks = []
        self.rim_evidence = []
        self.video = None
        self.video_time = None
        self.gate_preview = None
        self.last_gate_preview = -np.inf
        self.gate_stages = []
        self.latest_plan = None
        self.actuation = None

    def initial_filter(self, pictures, readings):
        scene = Vanishing(APERTURE, tracking_scale=.5)
        observer = super().initial_filter(pictures, readings, lambda attitude: scene.heading(pictures[-1].bgr, attitude))
        scene.update_orientation = observer.update_orientation
        self.lines = scene
        known = self.prior[1:self.confirmed_gates]
        self.saved_course = (self.course[0], *((row[:3].copy(), Rotation.from_quat(row[3:])) for row in known))
        self.seen[0] = observer.filter_time
        return observer

    def publish(self):
        received_at = self.camera_stats[-1][1] if self.camera_stats else -np.inf
        geometry = CourseGeometry(self.course, self.range_sigma, self.cross_sigma, self.metric_seen.copy(),
                                  self.seen.copy(), self.edge_seen.copy(),
                                  self.confirmed_normal, self.clipped_close_gate, self.position_recovering,
                                  self.near_plane, received_at)
        super().publish(geometry)

    def capture_time(self, frame):
        return super().capture_time(frame)+self.camera_offset_s

    def for_new_clock(self, queue):
        observer = type(self)(queue, self.precision)
        observer.prior, observer.confirmed_gates = self.prior, self.confirmed_gates
        observer.track_pose_branches = self.track_pose_branches
        observer.mapped_rim_bearings = self.mapped_rim_bearings
        observer.camera_offset_s = self.camera_offset_s
        observer.recent_images = deque(maxlen=self.recent_images.maxlen)
        observer.preview_course = self.preview_course
        observer.warmup_seconds = self.warmup_seconds
        observer.video = self.video
        observer.gate_preview = self.gate_preview
        return observer

    def state_offset(self, index):
        return 16+7*(index-len(self.saved_course))

    def error_offset(self, index):
        return 15+6*(index-len(self.saved_course))

    def refresh(self):
        state = self.filter.x[:, 0]
        self.course = self.saved_course+tuple(
            (center.copy(), rotation) for center, rotation in
            (pose_at(state, self.state_offset(i)) for i in self.identity_bounds))
        self.gates = [(i, rotation.apply(APERTURE)+center) for i, (center, rotation) in enumerate(self.course)]
        self.rim = list(edges(self.gates, GATE_DEPTH))
        P = self.filter.P
        ranges = [float(np.sqrt(max(0., P[0, 0])))]
        transverse = [float(np.sqrt(max(0., P[1, 1]+P[2, 2])))]
        for i, (_, rotation) in enumerate(self.course[1:], 1):
            between = P[:3, :3]
            if i in self.identity_bounds:
                j = self.error_offset(i)
                between = between+P[j:j+3, j:j+3]-P[:3, j:j+3]-P[j:j+3, :3]
            forward = rotation.apply([1., 0., 0.])
            axial_variance = float(forward @ between @ forward)
            ranges.append(np.sqrt(max(0., axial_variance)))
            transverse.append(np.sqrt(max(0., np.trace(between)-axial_variance)))
        self.range_sigma = tuple(ranges)
        self.cross_sigma = tuple(transverse)

    def opening_hypotheses(self, image, outlines, clipped, position, attitude, previous):
        last, rotation = self.course[previous]
        forward = rotation.apply([1., 0., 0.])
        if (last-position) @ forward > 11.:
            return []
        expected = []
        for _, world in self.gates:
            image_points, depth = project(world, position, attitude)
            if min(depth) > 1.:
                expected.append((image_points.mean(axis=0), width(image_points)))
        camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
        choices = []
        for quad in outlines:
            span, pixel_center = width(quad), quad.mean(axis=0)
            if span < 10. or any(np.linalg.norm(pixel_center-p) < max(6., .6*w) and .40*w < span < 2.2*w
                                 for p, w in expected):
                continue
            sight = camera.T @ np.linalg.solve(K, np.r_[pixel_center, 1.])
            bearing = np.arctan2(sight[1], sight[0])
            preferred_yaw = yaw_of(rotation) if forward @ sight > .4 else bearing
            fits = fit_openings(quad, span, camera, attitude, position, last, preferred_yaw)
            choices.extend(fits if self.track_pose_branches else fits[:1])
        for fit in clipped:
            distance, center, _, _ = fit
            if distance <= 3. or opening_range_sigma(distance) > 3.:
                continue
            if any(np.linalg.norm(center-known) < 3. for known, _ in self.course):
                continue
            if any(np.linalg.norm(center-match[1]) < max(.55, .12*distance) for match in choices):
                continue
            choices.append(fit)
        choices.sort(key=lambda row: np.linalg.norm(row[1]-last))
        return choices

    def retain_rims(self, stamp, position, points):
        anchor, plane = self.course[-1]
        inverse = plane.inv()
        index = len(self.course)
        used = set()
        for point in points:
            offset = inverse.apply(point-anchor)
            sigma = .25*np.linalg.norm(point-position)
            if np.linalg.norm(offset) <= 3.+sigma:
                continue
            options = [(np.linalg.norm(t[-1][1]-offset), j)
                       for j, t in enumerate(self.rim_tracks) if j not in used]
            error, match = min(options, default=(np.inf, -1))
            if error > sigma:
                self.rim_tracks.append(deque(maxlen=6))
                match = len(self.rim_tracks)-1
            self.rim_tracks[match].append((stamp, offset, sigma))
            self.rim_evidence.append((stamp, index, *point))
            used.add(match)
        valid = []
        rim_radius = np.hypot(np.sqrt(2.)*GATE_HALF_WIDTH, .5*GATE_DEPTH)
        for track in self.rim_tracks:
            seen, _, radius = track[-1]
            offset = np.median([row[1] for row in track], axis=0)
            radius += .35*(stamp-seen)
            if np.linalg.norm(offset) <= rim_radius+radius:
                continue
            valid.append((np.linalg.norm(offset)+radius, track, anchor+plane.apply(offset), radius))
        valid.sort(key=lambda row: row[0])
        self.rim_tracks = [row[1] for row in valid[:6]]
        self.rim_hints = tuple((track[-1][0], index, center, radius, len(track))
                               for _, track, center, radius in valid[:6])

    def carried_opening(self, course):
        slot = len(course)
        if 0 < slot < len(self.prior):
            # Both maps use the first opening's axes. Only the origin needs a correction.
            leg = self.prior[slot, :3]-self.prior[slot-1, :3]
            distance = np.linalg.norm(leg)
            if distance > 3.:
                return course[-1][0]+leg, .35*distance
        return None

    def next_look(self, position, heading, stamp, index, course, half_fov):
        """Only rank look points the pilot can actually bring into view."""
        slot = len(course)
        leg_start = self.acquisitions[-1][0] if self.acquisitions else -np.inf
        cues = [(center, radius) for seen, gate, center, radius, count in self.rim_hints
                if gate == slot and leg_start <= seen <= stamp and stamp-seen <= 1.6 and count >= 3]
        if (self.opening_hint is not None and self.opening_hint[0] == slot
                and 0. <= stamp-self.opening_hint[2] <= 1.6):
            cues.append((self.opening_hint[1], 0.))
        lower = self.lower_sighting
        if lower is not None and lower[0] == slot and lower[3] and 0. <= stamp-lower[1] <= IMU_TIMEOUT:
            cues.append((lower[4], lower[5]))
        if not cues and (carried := self.carried_opening(course)) is not None:
            cues.append(carried)
        options = []
        for center, radius in cues:
            relative = center-position
            turn = (np.arctan2(relative[1], relative[0])-heading+np.pi)%(2.*np.pi)-np.pi
            angular_error = np.arctan2(radius, np.linalg.norm(relative[:2]))
            if abs(turn) < 2.*half_fov and angular_error < half_fov:
                options.append((np.linalg.norm(center-course[-1][0])+radius, turn, relative))
        if options:
            return min(options, key=lambda row: row[0])[1:]

    def observe_border(self, rims, mask, color, position, attitude, stamp, index):
        """A partly visible rim can point the camera before there is a metric fit."""
        sides, lower = [], []
        last, plane = self.course[-1]
        normal_yaw = yaw_of(plane)
        if self.active == index:
            view = attitude.apply(CAMERA_FROM_BODY[2])
            yaw = (np.arctan2(view[1], view[0])-normal_yaw+np.pi)%(2.*np.pi)-np.pi
            previous = self.viewed_sector
            low, high = previous[1:] if previous is not None and previous[0] == index else (yaw, yaw)
            self.viewed_sector = index, min(low, yaw), max(high, yaw)
        for contour in rims:
            x, y, width, height = cv2.boundingRect(contour)
            left, right = x <= 1, x+width >= mask.shape[1]-1
            bottom = y+height >= mask.shape[0]-1 and width >= 32
            side_rim = left != right and width >= 6 and height >= 20
            if not (bottom or side_rim):
                continue
            if not colored_rim(contour, mask, color):
                continue
            ray = attitude.apply(CAMERA_FROM_BODY.T @ np.linalg.solve(K, [x+.5*width,y+.5*height,1.]))
            yaw = np.arctan2(ray[1],ray[0])
            off_axis = (yaw-normal_yaw+np.pi)%(2.*np.pi)-np.pi
            if bottom and abs(off_axis) <= .5*np.arctan(K[0,2]/K[0,0]):
                hull = cv2.convexHull(contour)
                hull = cv2.approxPolyDP(hull, max(1.25, .02*cv2.arcLength(hull, True)), True).reshape(-1, 2)
                for a, b in zip(hull, np.roll(hull, -1, axis=0)):
                    if max(a[1], b[1]) >= mask.shape[0]-1 or abs(a[0]-b[0]) <= .7*width:
                        continue
                    rays = attitude.apply(np.c_[(np.array([a, b])-K[:2,2])/np.diag(K)[:2], np.ones(2)] @ CAMERA_FROM_BODY)
                    if min(rays[:,2]) <= .03:
                        continue
                    # Equal height and a known edge length put both corner rays in metres.
                    rays /= rays[:,2:]
                    edge = rays*(2.*GATE_HALF_WIDTH/np.linalg.norm(rays[1]-rays[0]))
                    relative = edge.mean(axis=0)+[0., 0., GATE_HALF_WIDTH]
                    center = position+relative
                    distance = np.linalg.norm(relative)
                    if (center-last) @ plane.apply([1., 0., 0.]) > 2.*GATE_HALF_WIDTH and distance > 3.:
                        lower.append((width, yaw, center, opening_range_sigma(distance)))
            elif side_rim:
                local = plane.inv().apply(position-last)
                if self.active != index and local[0] < -2.*GATE_HALF_WIDTH:
                    continue
                direction = plane.inv().apply(ray)
                intersection = -local[0]/direction[0] if abs(direction[0]) > 1.e-4 else -1.
                if intersection > 0. and np.max(abs(local[1:]+intersection*direction[1:])) <= GATE_HALF_WIDTH+GATE_DEPTH:
                    continue
                points = contour.reshape(-1,2)
                extreme = points[[points[:,0].argmin(), points[:,0].argmax(), points[:,1].argmin(), points[:,1].argmax()]]
                rays = np.c_[(extreme-K[:2,2])/np.diag(K)[:2], np.ones(4)]
                rays /= np.linalg.norm(rays, axis=1, keepdims=True)
                chord = np.linalg.norm(rays[:,None]-rays[None,:], axis=-1).max()
                # A rim cannot subtend this angle beyond the range set by its diagonal.
                bound = np.sqrt(2.)*GATE_HALF_WIDTH*(1.+2./max(.01,chord))
                sides.append((bound, yaw))
        def track(old, yaw):
            return (old is not None and old[0] == index and 0.<stamp-old[1]<=IMU_TIMEOUT
                    and abs((yaw-old[2]+np.pi)%(2.*np.pi)-np.pi) < .15)
        if sides:
            bound, yaw = min(sides)
            if track(self.border_candidate,yaw):
                self.border_sighting = index, stamp, yaw, True, bound
            self.border_candidate = index, stamp, yaw
        if lower:
            _, yaw, center, uncertainty = max(lower, key=lambda row: row[0])
            self.lower_sighting = index, stamp, yaw, track(self.lower_sighting,yaw), center, uncertainty

    def unseen_sides(self, index, view_edge):
        if self.viewed_sector is None or self.viewed_sector[0] != index:
            return ()
        _, low, high = self.viewed_sector
        return tuple(side for side, angle in ((-1., -low), (1., high)) if angle < view_edge-.06)

    def acquire_next(self, image, outlines, clipped, stamp, active):
        index = len(self.course)
        if active < index-1:
            return
        position, attitude = pose_at(self.filter.x[:, 0], 0)
        choices = self.opening_hypotheses(image, outlines, clipped, position, attitude, index-1)
        previous_center, previous_plane = self.course[-1]
        from_world = previous_plane.inv()

        def supported(track):
            return len(track) >= 2

        # A supported portal is part of this leg's corridor. Missing pixels
        # reduce freshness without discarding its relationship to the last gate.
        self.pending_openings = [track for track in self.pending_openings
                                 if supported(track) or stamp-track[-1][0] <= .80]
        used = set()
        for depth, center, rotation, span in choices:
            self.successor_views.append((stamp, active, index, depth, *center, yaw_of(rotation), active == index))
            offset = from_world.apply(center-previous_center)
            relative_rotation = from_world*rotation
            radius = max(.55, .12*depth)
            candidates = []
            for i, track in enumerate(self.pending_openings):
                if i in used:
                    continue
                score = np.linalg.norm(offset-track[-1][1])/radius
                if self.track_pose_branches:
                    angle = (Rotation.from_quat(track[-1][2]).inv()*relative_rotation).magnitude()
                    score = max(score, angle/np.radians(25.))
                candidates.append((score, i))
            distance, match = min(candidates, default=(np.inf, -1))
            if distance > 1.:
                self.pending_openings.append(deque(maxlen=6))
                match = len(self.pending_openings)-1
            self.pending_openings[match].append((stamp, offset, relative_rotation.as_quat(), span))
            used.add(match)
        self.pending_openings.sort(key=lambda track: np.linalg.norm(track[-1][1]))
        del self.pending_openings[12 if self.track_pose_branches else 6:]
        if active == index and self.track_pose_branches:
            self.pose_ambiguity.append((stamp, index, len(choices), len(self.pending_openings),
                                        sum(supported(track) for track in self.pending_openings)))
        portals = []
        self.opening_hint = None
        for track in self.pending_openings:
            if not supported(track):
                continue
            offset = np.median([row[1] for row in track], axis=0)
            center = previous_center+previous_plane.apply(offset)
            weights = np.square([row[3] for row in track])
            relative_rotation = Rotation.from_quat([row[2] for row in track]).mean(weights=weights)
            rotation = previous_plane*relative_rotation
            seen = track[-1][0]
            footprint = None
            if active == index:
                edges_now = partial_opening(image, index, center, rotation, position, attitude)
                full_now = seen == stamp and len(track) >= 3 and seen-track[0][0] >= .075
                projected, depth = project(rotation.apply(APERTURE)+center, position, attitude)
                if min(depth) > .25:
                    footprint = (projected.mean(axis=0), width(projected))
                self.portal_evidence.append((stamp, index, *center, full_now,
                                             0 if edges_now is None else edges_now[1],
                                             np.nan if edges_now is None else edges_now[2]))
                if edges_now is None and not full_now and stamp-seen > .8:
                    onscreen = np.all((projected >= 8.) & (projected <= [632., 352.]), axis=1)
                    left_behind = offset[0] < -.5*GATE_DEPTH and max(depth) <= .25
                    # Clear predictions can be disconfirmed. A stale opening on
                    # the approach side of the last plane cannot own the exit gaze.
                    if left_behind or np.count_nonzero(onscreen & (depth > .25)) >= 2:
                        continue
            else:
                full_now, edges_now = False, None
            portals.append((np.linalg.norm(offset), seen, center, rotation, full_now, edges_now, footprint))
        if not portals:
            if self.pending_openings:
                # One metric sighting can aim the camera while more evidence is gathered.
                stamp_seen, offset, _, _ = self.pending_openings[0][-1]
                if stamp-stamp_seen <= .8:
                    self.opening_hint = index, previous_center+previous_plane.apply(offset), stamp_seen
            return
        leg_start = self.acquisitions[-1][0] if self.acquisitions else -np.inf
        expected = self.carried_opening(self.course)

        def map_error(row):
            center = row[5][0] if row[5] is not None else row[2]
            return carried_opening_error(expected, center, position)

        if active == index:
            portals.sort(key=lambda row: (not (row[4] or row[5] is not None), map_error(row) > 1., row[0]))
        else:
            portals.sort(key=lambda row: (row[1] < leg_start, row[0]))

        def same_opening(a, b):
            if np.linalg.norm(a[2]-b[2]) < .75:
                return True
            if a[6] is None or b[6] is None:
                return False
            pa, sa = a[6]
            pb, sb = b[6]
            return min(sa, sb) >= .65*max(sa, sb) and np.linalg.norm(pa-pb) <= max(6., .30*min(sa, sb))

        first = portals[0]
        aliases = [row for row in portals if same_opening(row, first)]
        preferred = max(aliases, key=lambda row: (active == index and bool(row[4] or row[5] is not None)
                                                   and map_error(row) <= 1.,
                                                   row[4], row[5][1] if row[5] else 0,
                                                   -row[5][2] if row[5] else -np.inf, row[1]))
        distance, seen, center, rotation, full_now, match, _ = preferred
        self.opening_hint = (index, center, stamp if full_now or match is not None else seen)
        if active != index or (match is None and not full_now):
            return

        candidate_range = np.linalg.norm(center-position)
        range_uncertainty = opening_range_sigma(candidate_range)
        map_agrees = map_error(preferred) <= 1.
        view_edge = np.pi/2.-np.arctan(K[0,2]/K[0,0])
        if not map_agrees and range_uncertainty > 1.50 and self.unseen_sides(index, view_edge):
            return
        side = self.border_sighting
        if (side is not None and side[0] == index and side[3] and 0. <= stamp-side[1] <= IMU_TIMEOUT
                and candidate_range > side[4]+opening_range_sigma(candidate_range)):
            return
        lower = self.lower_sighting
        if lower is not None and lower[0] == index and lower[3] and 0. <= stamp-lower[1] <= IMU_TIMEOUT:
            if candidate_range > np.linalg.norm(lower[4]-position)+lower[5]+opening_range_sigma(candidate_range):
                return
        for seen, gate, point, radius, count in self.rim_hints:
            if (gate == index and count >= 3 and 0. <= stamp-seen <= 1.6
                    and np.linalg.norm(point-previous_center)+radius < distance-opening_range_sigma(candidate_range)):
                return

        # Equal-range, similarly supported portals leave the order unresolved.
        for other in portals:
            if same_opening(other, preferred):
                continue
            other_distance, _, other_center, _, other_full, other_match, _ = other
            if not (other_full or other_match is not None):
                continue
            if map_agrees and map_error(other) > 1.:
                continue
            uncertainty = opening_range_sigma(np.linalg.norm(other_center-position))
            if other_distance-distance > max(.75, uncertainty):
                continue
            if full_now and not other_full:
                continue
            if (match is not None and other_match is not None
                    and match[1] >= other_match[1] and match[2]+.35 < other_match[2]):
                continue
            return
        if match is not None:
            center, matched, _ = match
        depth = np.linalg.norm(center-position)
        rotation = orient_gate(rotation, center-position)
        apparent_width = 1.50*(rotation.apply([1., 0., 0.])@(center-position))/max(.01, depth)
        if not full_now and apparent_width < 2.*CHASSIS_RADIUS:
            return  # A grazing partial edge match cannot establish the crossing plane.
        if match is not None:
            self.partial_confirmations.append((stamp, index, matched))
        self.rebase_openings(previous_center, previous_plane, center, rotation)
        self.set_landmark(index, position, center, rotation, depth)
        self.identity_bounds[index] = (center, max(2., .35*depth))
        self.acquisitions.append((stamp, index, *center, yaw_of(rotation)))
        self.acquisition_support.append((stamp, index, map_error(preferred), len(portals),
                                         sum(bool(row[4] or row[5] is not None) and map_error(row)<=1. for row in portals)))
        self.seen[index] = stamp
        self.refresh()

    def rebase_openings(self, previous_center, previous_plane, center, rotation):
        # Preserve observed world positions while changing the local gate frame.
        new_axes = rotation.inv()*previous_plane
        origin = rotation.inv().apply(previous_center-center)
        remaining = []
        for track in self.pending_openings:
            if len(track) < 2:
                continue
            samples = deque(maxlen=track.maxlen)
            for ts, offset, relative_rotation, span in track:
                samples.append((ts, origin+new_axes.apply(offset),
                                (new_axes*Rotation.from_quat(relative_rotation)).as_quat(), span))
            if np.linalg.norm(np.median([row[1] for row in samples], axis=0)) > 3.:
                remaining.append(samples)
        self.pending_openings = remaining
        self.opening_hint = None
        self.rim_tracks = [deque(((ts, origin+new_axes.apply(offset), sigma)
                                  for ts, offset, sigma in track), maxlen=track.maxlen)
                           for track in self.rim_tracks]
        self.rim_hints = ()

    def set_landmark(self, index, position, center, rotation, depth):
        if index not in self.identity_bounds:
            self.filter.add_landmark()
        state = self.state_offset(index)
        error = self.error_offset(index)
        self.filter.x[state:state+7, 0] = np.r_[center, rotation.as_quat()]
        # A gate first seen from this pose inherits its translation and orientation error.
        arm = center-position
        J = np.eye(6)
        J[:3, 3:6] = -cross(arm)
        covariance = self.filter.P
        cross_covariance = J @ covariance[:6]
        axis = arm/np.linalg.norm(arm)
        range_sigma = opening_range_sigma(depth)
        side_sigma = .075+.8*depth/K[0, 0]
        additive = np.diag(np.r_[np.repeat(side_sigma**2, 3), np.radians([5., 5., 18.])**2])
        additive[:3, :3] += np.outer(axis, axis)*range_sigma**2
        block = slice(error, error+6)
        covariance[block, :] = cross_covariance
        covariance[:, block] = cross_covariance.T
        covariance[block, block] = J @ covariance[:6, :6] @ J.T+additive

    def fit_normal(self, index, stamp, quad, camera, prior, solutions):
        samples = self.normal_views
        if samples and (samples[-1][0] != index or stamp-samples[-1][1] > .5):
            samples.clear()
        if not samples or stamp-samples[-1][1] >= .075:
            rays = (quad-K[:2,2])/np.diag(K)[:2]
            system = camera[:2]-rays[:,:,None]*camera[2]
            rotations = [Rotation.from_matrix(camera.T@Rotation.from_rotvec(m['rotation_vector_rad']).as_matrix()
                                              @ SQUARE_FROM_GATE) for m in solutions]
            samples.append((index, stamp, quad, camera, system, np.linalg.pinv(system.reshape(8,3)), rotations))
        if len(samples) < 4:
            return prior
        candidates = [prior, *(r for view in samples for r in view[-1])]
        corners = np.stack([r.apply(APERTURE) for r in candidates])
        loss = np.zeros(len(candidates))
        for _, _, pixels, camera, system, inverse, _ in samples:
            # The same plane must explain each image. Camera translation is free in each fit.
            shift = np.einsum('ijk,bik->bij', system, corners).reshape(-1,8) @ inverse.T
            rays = (corners-shift[:,None]) @ camera.T
            projected = rays[:,:,:2]*np.diag(K)[:2]/np.maximum(.01,rays[:,:,2:])+K[:2,2]
            loss += np.minimum(5., np.sqrt(np.mean((projected-pixels)**2, axis=(1,2))))
        loss /= len(samples)
        best = int(np.argmin(loss))
        separated = [(candidates[best].inv()*r).magnitude() > np.radians(20.) for r in candidates]
        alternate = np.min(loss[separated], initial=np.inf)
        if loss[best] < 2. and loss[best]+.25 < min(loss[0], alternate):
            return candidates[best]
        return prior

    def recovery_candidate(self, outlines, image_width, stamp, index, position, attitude, color=None):
        prior, rotation = self.course[index]
        seed, radius = self.identity_bounds[index]
        points = rotation.apply(APERTURE)+prior
        pixels, depth = project(points, position, attitude)
        in_front = depth.mean() >= 2.
        predicted_width = width(pixels) if in_front else 0.
        projected = pixels.mean(axis=0)
        world_from_camera = attitude*Rotation.from_matrix(CAMERA_FROM_BODY.T)
        camera = world_from_camera.as_matrix().T
        prior_image = self.locked_image
        bearing = None
        if prior_image is not None and prior_image[0] == index and 0. < stamp-prior_image[1] <= .5:
            _, earlier, ray, previous_span, previous_relative = prior_image
            ray = camera @ ray
            if ray[2] > 0.:
                bearing = K[:2,2]+np.diag(K)[:2]*ray[:2]/ray[2]
                margin = 6.+previous_span*min(.45, (stamp-earlier)*4./1.50)
        measurements = [(quad, 1.50) for quad in outlines]
        if color is not None and in_front and predicted_width >= 22. and min(depth) > .5:
            mask = cv2.morphologyEx(color.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((3,3),np.uint8))
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
            for contour in contours:
                x, y, w, h = cv2.boundingRect(contour)
                if min(w,h) < .75*predicted_width or max(w,h) > 4.*predicted_width:
                    continue
                if np.linalg.norm([x+.5*w-projected[0],y+.5*h-projected[1]]) > max(22., .55*predicted_width):
                    continue
                fit = fit_outline(contour, color.shape)
                if fit is not None and max(fit[1]) < 1.8:
                    measurements.append((fit[0], 2.*GATE_HALF_WIDTH))
        choices = []
        for quad, side in measurements:
            rim = side > 1.50
            span = width(quad)*1.50/side
            pixel = quad.mean(axis=0)
            shift = np.linalg.norm(pixel-projected) if in_front else 0.
            image_distance = np.inf if bearing is None else np.linalg.norm(pixel-bearing)
            continuous = bearing is not None and image_distance <= margin and .65*previous_span <= span <= 1.55*previous_span
            if in_front and not (continuous or (.55*predicted_width <= span <= 1.9*predicted_width and shift <= .36*image_width)):
                continue
            matches = estimate(quad, side, K)
            matches = [m for m in matches if np.isfinite(m['reprojection_coordinate_rmse_px'])]
            if not matches:
                continue
            best = min(matches, key=lambda m: m['reprojection_coordinate_rmse_px'])
            rel = world_from_camera.apply(best['translation_camera_m'])
            length = np.linalg.norm(rel)
            if continuous:
                previous_range = np.linalg.norm(previous_relative)
                range_noise = np.hypot(opening_range_sigma(length), opening_range_sigma(previous_range))
                if np.linalg.norm(rel-previous_relative) > 4.*(stamp-earlier)+2.*range_noise:
                    continue
            center = position+rel
            # A close aperture can contradict a plane that inertial prediction
            # has put behind the camera. Recover only a unique, well-fit view
            # within the locked gate's original identity bounds.
            consistent_side = rel@(prior-position) > 0. if in_front else length < 6.
            error_limit = max(2., (.08 if in_front else .04)*span)
            if length > 1.5 and consistent_side and best['reprojection_coordinate_rmse_px'] < error_limit:
                if np.linalg.norm(center-seed) < radius:
                    camera_plane = Rotation.from_rotvec(best['rotation_vector_rad']).as_matrix()@SQUARE_FROM_GATE
                    measured_rotation = world_from_camera*Rotation.from_matrix(camera_plane)
                    measured_normal = measured_rotation.apply([1., 0., 0.])
                    tracked_normal = rotation.apply([1., 0., 0.])
                    repair_normal = False
                    if rim and span >= 32. and abs(measured_normal@tracked_normal) < np.cos(np.radians(15.)):
                        aperture = rotation.apply(APERTURE*(side/1.50))
                        relative = -translation(aperture, quad, camera)
                        with_old_normal, _ = project(aperture+relative, np.zeros(3), attitude)
                        old_error = np.sqrt(np.mean((quad-with_old_normal)**2))
                        repair_normal = old_error > best['reprojection_coordinate_rmse_px']+1.6
                    if rim and (not repair_normal or best['reprojection_coordinate_rmse_px'] >= 1.8
                                or len(matches) != 2 or max(m['reprojection_coordinate_rmse_px'] for m in matches)
                                < best['reprojection_coordinate_rmse_px']+1.75):
                        continue
                    score = image_distance+span*abs(np.log(span/previous_span)) if continuous else shift
                    choices.append((not rim, not continuous, score, center, length, measured_rotation if repair_normal else rotation,
                                    repair_normal, pixel, span, quad, matches))
        if not in_front and len(choices) != 1:
            return None
        if choices:
            inner, _, _, center, length, measured_rotation, repair_normal, pixel, span, quad, matches = min(
                choices, key=lambda row: row[:3])
            if inner and self.confirmed_normal != index:
                measured_rotation = self.fit_normal(index, stamp, quad, camera, rotation, matches)
                repair_normal = (measured_rotation.inv()*rotation).magnitude() > np.radians(5.)
                if repair_normal:
                    relative = -translation(measured_rotation.apply(APERTURE), quad, camera)
                    center, length = position+relative, np.linalg.norm(relative)
            self.locked_image = index, stamp, camera.T @ np.linalg.solve(K, np.r_[pixel,1.]), span, center-position
            return center, length, measured_rotation, repair_normal, not inner

    def reacquire_active(self, outlines, partials, color, stamp, index):
        if index not in self.identity_bounds:
            self.recovery.clear()
            return
        position, attitude = pose_at(self.filter.x[:, 0], 0)
        prior, rotation = self.course[index]
        camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
        # Allow a nearby clipped fit to disagree by the rim width plus the tracked range error.
        association_radius = 2.*GATE_HALF_WIDTH+min(GATE_HALF_WIDTH, 1.5*self.range_sigma[index])
        nearby = []
        for rails in partials:
            square = measure_clipped_square(rails, camera, 1.50)
            if square is None:
                continue
            relative, measured_rotation, _ = square
            depth = np.linalg.norm(relative)
            center = position+relative
            upright = measured_rotation.apply([0., 0., 1.])[2] >= np.cos(np.radians(18.))
            if .40 < depth < 6. and upright and np.linalg.norm(center-prior) <= association_radius:
                nearby.append((center, depth, measured_rotation))
        if len(nearby) == 1:
            center, depth, measured_rotation = nearby[0]
            repair_normal = (rotation.inv()*measured_rotation).magnitude() >= np.radians(15.)
            normal = rotation if self.confirmed_normal == index else measured_rotation
            self.near_plane = index, stamp, center, normal.apply([1., 0., 0.])
            match = center, depth, measured_rotation if repair_normal else rotation, repair_normal, False
        else:
            match = self.recovery_candidate(outlines, color.shape[1], stamp, index, position, attitude, color)
        if match is None:
            self.recovery.clear()
            return
        center, depth, measured_rotation, repair_normal, from_rim = match
        if self.confirmed_normal == index and not from_rim:
            measured_rotation, repair_normal = rotation, False
        fit_across_frames = len(nearby) != 1 and repair_normal and not from_rim
        rotation = measured_rotation
        shift = np.linalg.norm(center-self.course[index][0])
        if stamp-self.seen.get(index, stamp) < .50 and shift <= max(.25, .08*depth) and not repair_normal:
            self.recovery.clear()
            return
        if fit_across_frames:
            self.recovery.clear()
        if self.recovery:
            last_time, last_index, last_center, last_rotation, _ = self.recovery[-1]
            if (last_index != index or stamp-last_time > .20 or np.linalg.norm(center-last_center) > max(.6, .14*depth)
                    or (rotation.inv()*last_rotation).magnitude() > np.radians(20.)):
                self.recovery.clear()
        self.recovery.append((stamp, index, center, rotation, from_rim))
        if not fit_across_frames and (len(self.recovery) < 3 or stamp-self.recovery[0][0] < .13):
            return
        center = np.median([row[2] for row in self.recovery], axis=0)
        seed, radius = self.identity_bounds[index]
        if np.linalg.norm(center-seed) > radius:
            self.recovery.clear()
            return
        rotation = Rotation.from_quat([row[3].as_quat() for row in self.recovery]).mean()
        rotation = orient_gate(rotation, center-position)
        old, old_rotation = self.course[index]
        # The square is unchanged by quarter turns about its normal. Keep corner identities.
        equivalent = rotation*Rotation.from_rotvec(np.arange(4)[:, None]*[np.pi/2., 0., 0.])
        rotation = equivalent[np.argmin((old_rotation.inv()*equivalent).magnitude())]
        if index == len(self.course)-1:
            self.rebase_openings(old, old_rotation, center, rotation)
        self.set_landmark(index, position, center, rotation, depth)
        if fit_across_frames or sum(row[4] for row in self.recovery) >= 2:
            self.confirmed_normal = index
        self.reacquisitions.append((stamp, index, *old, *center))
        self.seen[index] = stamp
        self.recovery.clear()
        self.refresh()

    def recover_position(self, stamp, index, outlines, gates, partials=(), outer=None):
        position, attitude = pose_at(self.filter.x[:, 0], 0)
        max_position_error = 6.
        opening = dict(gates)[index]
        opening_radius = self.identity_bounds[index][1] if index in self.identity_bounds else 2.*GATE_HALF_WIDTH
        rim_rotation = None
        if outer is not None:
            _, rim_rotation, points = outer
            opening = self.course[index][0]+points
            corners = partials[0][1:3]
            max_position_error = min(2.*GATE_HALF_WIDTH, opening_radius)
        elif partials:
            max_position_error = min(2.*GATE_HALF_WIDTH, opening_radius)
            match = match_inner_corners(partials, (index, opening), position, attitude, max_position_error)
            if match is None:
                return None
            _, opening, corners = match
        else:
            match = reacquire(position, attitude, gates, outlines, position_error_m=max_position_error)
            if match is None or match[2] != index:
                return None
            corners = match[3]
        _, depth = project(opening, position, attitude)
        camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
        measured = translation(opening, corners, camera)
        center, rotation = self.course[index]
        if rim_rotation is not None and self.confirmed_normal != index:
            rotation = rim_rotation
        forward = rotation.apply([1., 0., 0.])
        shift = measured-position
        distance = np.linalg.norm(shift)
        room = GATE_DEPTH if partials else 5.
        remaining = (center-measured) @ forward
        if outer is None:
            remaining = min(remaining, (center-position) @ forward)
        if not (.1 < distance <= max_position_error and remaining > room):
            self.pending_position = None
            return None

        def pixel_error(p):
            pixels, depth = project(opening, p, attitude)
            return np.sqrt(np.mean((pixels-corners)**2)) if min(depth) > (.25 if partials else 1.6) else np.inf

        if not pixel_error(measured) <= 3.:
            return None
        original = pixel_error(position)
        continuing = self.position_recovering is not None and self.position_recovering[0] == index
        # A distant outline can fit a biased map even when the inertial position is already good.
        if not continuing and original <= 2.*corner_noise(width(corners)):
            self.pending_position = None
            return None
        pending = self.pending_position
        if (pending is None or pending[1] != index or stamp-pending[0] > .65
                or np.linalg.norm(shift-pending[2]) > max(.35, .05*np.mean(depth))
                or ((rim_rotation is None) != (pending[3] is None))
                or (rim_rotation is not None and (rim_rotation.inv()*pending[3]).magnitude() > np.radians(15.))):
            self.pending_position = (stamp, index, shift, rim_rotation)
            return None
        earlier, _, previous_shift, _ = pending
        if stamp-earlier < .10:
            return None

        # Predict the current outline from the earlier frame's translation, before using this frame to move.
        confirmed = pixel_error(position+previous_shift)
        applied = position+min(1., .6/distance)*shift
        updated = pixel_error(applied)
        limit = np.inf if partials else 3.
        if self.active != index:
            return None
        if not (confirmed <= min(limit, .65*original, original-1.) and updated < original):
            self.pending_position = (stamp, index, shift, rim_rotation)
            return None
        alternatives = [gate for gate in (self.gates if partials else gates) if gate[0] != index]
        shifted = position+previous_shift
        if outer is not None:
            alternatives = [(i, q.mean(axis=0)+(q-q.mean(axis=0))*(2.*GATE_HALF_WIDTH/1.5)) for i,q in alternatives]
        ambiguous = (any(match_inner_corners(partials, gate, shifted, attitude) is not None for gate in alternatives)
                     if partials else reacquire(shifted, attitude, alternatives, (corners,)) is not None)
        if ambiguous:
            return None
        if index in self.identity_bounds:
            corrected_center = center+position-applied
            seed, radius = self.identity_bounds[index]
            if np.linalg.norm(corrected_center-seed) > radius:
                return None
            if index == len(self.course)-1:
                old_centre, old_rotation = self.course[index]
                self.rebase_openings(old_centre, old_rotation, corrected_center, rotation)
            self.set_landmark(index, position, corrected_center, rotation, np.linalg.norm(corrected_center-position))
            self.gate_recoveries.append((stamp, index, earlier, *center, *corrected_center, original, confirmed, updated))
            self.refresh()
        else:
            self.position_recoveries.append((stamp, index, earlier, *position, *applied, original, confirmed, updated))
            self.filter.x[:3, 0] = applied
        self.pending_position = (stamp, index, measured-applied, rim_rotation)
        self.position_recovering = (index, stamp)
        return updated

    def publish_gate_preview(self, image, pairs, partials, stamp):
        self.last_gate_preview = stamp
        sample = dict(time_ms=1000*time(), jpeg=None, crop=None, origin=[0, 0],
                      size=[image.shape[1], image.shape[0]], openings=[], rims=[])
        state = self.filter.x[:, 0]
        active, course = self.active, self.course
        camera = self.camera_stats[-15:]
        innovation = self.pixel_innovations[-1] if self.pixel_innovations else None
        sample['pipeline'] = dict(
            camera_hz=(len(camera)-1)/(camera[-1][0]-camera[0][0]) if len(camera) > 1 else None,
            camera_pipeline_ms=1000.*(camera[-1][5]-camera[-1][1]) if camera else None,
            full=len(pairs), partial=len(partials), active=active+1, openings=len(course),
            gate_range_m=float(np.linalg.norm(course[active][0]-state[:3])) if active < len(course) else None,
            speed_m_s=float(np.linalg.norm(state[7:10])),
            pixel_rms=float(innovation[1]) if innovation is not None and stamp-innovation[0] < .5 else None,
            plan=self.latest_plan, actuation=self.actuation)
        try:
            bounds = [rim if rim is not None else opening for opening, rim in pairs] or partials
            if bounds:
                largest = max(bounds, key=lambda q: cv2.contourArea(q.astype(np.float32)))
                x, y, w, h = cv2.boundingRect(largest.astype(np.float32))
                pad = max(6, round(.12*max(w, h)))
                left, top = max(0, x-pad), max(0, y-pad)
                crop = image[top:min(image.shape[0], y+h+pad), left:min(image.shape[1], x+w+pad)]
                ok, jpeg = cv2.imencode('.jpg', crop, [cv2.IMWRITE_JPEG_QUALITY, 85])
                if ok:
                    origin = np.array([left, top])
                    sample.update(jpeg=base64.b64encode(jpeg).decode('ascii'),
                                  origin=[left, top],
                                  crop=[0, 0, crop.shape[1], crop.shape[0]],
                                  openings=[(opening-origin).tolist() for opening, _ in pairs],
                                  partials=[(rails-origin).tolist() for rails in partials],
                                  rims=[(rim-origin).tolist() for _, rim in pairs if rim is not None])
            write_snapshot(self.gate_preview, sample)
        except (OSError, cv2.error):
            # The viewer is optional. A failed preview must leave flight updates running.
            pass

    def correct_opening_velocity(self, stamp, active, prediction, match):
        """Measure the change in range to the same opening between two exposures."""
        _, points, pixels = match
        position, attitude = pose_at(prediction, 0)
        center, plane = self.course[active]
        camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
        measured = translation(points, pixels, camera)
        forward = plane.apply([1., 0., 0.])
        residual = (measured-position) @ forward
        distance = np.linalg.norm(center-measured)
        if abs(residual) > .35 or distance <= .40:
            return
        sample = active, stamp, residual, forward, distance
        previous = self.opening_motion
        if previous is None or previous[0] != active or stamp-previous[1] > .65 or forward @ previous[3] < .98:
            self.opening_motion = sample
            return
        dt = stamp-previous[1]
        if dt < .35:
            return
        self.opening_motion = sample
        correction = (residual-previous[2])/dt
        if abs(correction) > 1.5:
            return
        velocity = self.filter.x[7:10, 0] @ forward
        deviation = np.hypot(opening_range_sigma(distance), opening_range_sigma(previous[4]))/dt
        jacobian = np.zeros((1, self.filter.dim_err))
        jacobian[0, 6:9] = forward
        self.filter.update(np.array([velocity+correction]), np.array([velocity]), jacobian, np.array([deviation]))
        self.opening_velocity.append((stamp, active, velocity, correction, deviation))

    def correct_from_openings(self, image, outlines, partials, stamp, active, recovering):
        before = self.filter.x.copy()
        covariance = self.filter.P.copy()
        observed = set()
        apertures_used = {}
        observed_slots = {i for i in range(max(0, active-2), active+3) if i < len(self.saved_course)}
        observed_slots.add(active)
        gates = [gate for gate in self.gates if gate[0] in observed_slots]
        rim = [edge for edge in self.rim if edge[0] in observed_slots]
        landmarks = {active: self.error_offset(active)} if active in self.identity_bounds else {}
        stale_target = stamp-self.metric_seen.get(active, -np.inf) > .22
        bearings = {} if self.mapped_rim_bearings and (recovering or stale_target) else None
        try:
            measured_pair = None
            if partials and active < len(self.gates):
                measured_pair = match_inner_corners(partials, self.gates[active], *pose_at(before[:, 0], 0))
            count, has_range = gate_update(self.filter, image, gates, rim, recovering, True, 3.,
                                           landmarks=landmarks, observed=observed, outlines=outlines,
                                           measured_pair=measured_pair, apertures_used=apertures_used,
                                           bearings=bearings)
        except np.linalg.LinAlgError:
            self.filter.x, self.filter.P = before, covariance
            count, has_range = 0, False
            observed.clear()
            apertures_used.clear()
        change = self.filter.x[:, 0]-before[:, 0]
        jump = np.linalg.norm(change[:3])
        impulse = np.linalg.norm(change[7:10])
        gate_shift = max((np.linalg.norm(self.filter.x[self.state_offset(i):self.state_offset(i)+3, 0]-seed)/radius
                          for i, (seed, radius) in self.identity_bounds.items()), default=0.)
        relative_jump = 0.
        if active in self.identity_bounds:
            slot = self.state_offset(active)
            distance = np.linalg.norm(before[slot:slot+3, 0]-before[:3, 0])
            relative_jump = np.linalg.norm(change[slot:slot+3]-change[:3])/max(.25, .06*distance)
        reject = len(self.course) > 1 and (jump > .6 or impulse > .8 or gate_shift > 1. or relative_jump > 1.)
        if reject:
            # Protect the relative aim point as well as the separate map and drone states.
            cases = self.rejected_factors.setdefault(active, [])
            if count and len(cases) < 4 and (not cases or stamp-cases[-1][0] >= .5):
                # Rollback makes these arrays live again. Preserve their values at this exposure.
                cases.append((stamp, before[:, 0].copy(), covariance.copy(), change, *self.filter.last_gate_factor))
            self.filter.x, self.filter.P = before, covariance
            self.rejected.append((stamp, active, jump, impulse, gate_shift, relative_jump))
            count, has_range = 0, False
            observed.clear()
            apertures_used.clear()
        elif count:
            innovation = self.filter.last_gate_factor[0]
            self.pixel_innovations.append((stamp, np.sqrt(np.mean(innovation**2))))
            if bearings:
                self.rim_bearing_updates.extend((stamp, index, count) for index, count in bearings.items())
        opening = apertures_used.get(active)
        if opening is not None and (opening is measured_pair or width(opening[2]) >= 25.):
            self.correct_opening_velocity(stamp, active, before[:, 0], opening)
        # A rim line can support a bearing while a complete aperture disagrees with position.
        lost_clip = opening is None and bool(partials) and active < len(self.gates)
        lost_map = opening is None and bool(outlines) and active < len(self.saved_course)
        recovered = False
        if self.confirm_large_corrections and not self.resting and (lost_clip or lost_map):
            error = self.recover_position(stamp, active, outlines, gates, partials if not lost_map else ())
            if error is not None:
                count = 1
                if error <= 3.:
                    observed.add(active)
                    has_range = True
                    recovered = True
        if opening is not None or recovered:
            self.pending_position = None
            self.position_recovering = None
        if active not in observed and active < len(self.course) and not reject:
            position, attitude = pose_at(self.filter.x[:, 0], 0)
            center, plane = self.course[active]
            remaining = (center-position) @ plane.apply([1., 0., 0.])
            if 0. < remaining <= 2.*GATE_HALF_WIDTH:
                corners = plane.apply(APERTURE)+center
                pixels, depth = project(corners, position, attitude)
                if min(depth) > .25 and np.any((pixels < 0.) | (pixels > [image.shape[1]-1,image.shape[0]-1])):
                    self.clipped_close_gate = active
                    # Near a clipped gate, 12 cm of lateral error can exceed the usual pixel search.
                    # This confirms a visible rim. The EKF keeps its own measurement rules.
                    tolerance = np.clip(.12*K[0,0]/depth.mean(), 7., 24.)
                    camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
                    if any(np.linalg.norm(points[1]-points[0]) >= 24. for _, _, points in probes(
                            image, edges([(active,corners)], GATE_DEPTH), position, camera,
                            dark_opening=True, tolerance=tolerance)):
                        self.edge_seen[active] = stamp
                        self.edge_visibility.append((stamp, active))
        return count, has_range, observed

    def gate_measurements(self, image, stamp, recovering):
        started = monotonic()
        active = self.active
        self.last_image = image
        if not self.recent_images or stamp-self.recent_images[-1][0] >= .16:
            self.recent_images.append((stamp, image))
        if self.video is not None:
            if self.video_time is None:
                self.video_time = stamp
            if stamp >= self.video_time:
                self.video.write(image)
                self.video_time += (1+int((stamp-self.video_time)*12.))/12.
        if active > 0 and active not in self.handoff_images:
            self.handoff_images[active] = image
        if self.preview_course and active == len(self.course) and (preview := self.carried_opening(self.course)) is not None:
            center, radius = preview
            position = self.filter.x[:3, 0]
            previous, previous_plane = self.course[-1]
            plane = Rotation.from_quat(self.prior[active, 3:])
            self.rebase_openings(previous, previous_plane, center, plane)
            self.set_landmark(active, position, center, plane, np.linalg.norm(center-position))
            self.identity_bounds[active] = center, radius
        self.refresh()
        save_frame = stamp-self.last_saved_image >= .10
        preview_frame = self.gate_preview is not None and stamp-self.last_gate_preview >= .1
        with_bounds = save_frame or preview_frame
        mask, color = gate_masks(image)
        pairs = list(apertures(image, with_bounds=True, mask=mask, color=color)) if with_bounds else []
        outlines = [opening for opening, _ in pairs] if with_bounds else list(apertures(image, mask=mask, color=color))
        rims, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        rows, cols = mask.shape
        border = [r for r in rims if np.any(r == 0) or np.any(r[:, 0, 0] >= cols-2) or np.any(r[:, 0, 1] >= rows-2)]
        partials = list(clipped_edges((r for r in border if colored_rim(r, mask, color)), image.shape))
        detected = monotonic()
        self.detections.append((stamp, len(outlines), len(partials)))
        prior_pose = self.filter.x[:7, 0].copy() if save_frame and outlines else None
        count, has_range, observed = self.correct_from_openings(image, outlines, partials, stamp, active, recovering)
        corrected = monotonic()
        position, attitude = pose_at(self.filter.x[:, 0], 0)
        camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
        clipped = [fit for rails in partials if (fit := fit_clipped_opening(rails, camera, attitude, position)) is not None]
        lost_outer = (active in self.identity_bounds and active not in observed and stamp-self.seen.get(active, stamp) > IMU_TIMEOUT
                      and not self.resting and active == self.active)
        outer_error = None
        if (active >= len(self.course) or lost_outer) and not clipped:
            rim_mask = cv2.morphologyEx(color.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
            outlines_at_border, _ = cv2.findContours(rim_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            rim_shapes = list(clipped_edges((r for r in outlines_at_border if colored_rim(r, rim_mask, color)),
                                            image.shape, exterior=True))
            if active >= len(self.course):
                clipped = [fit for rails in rim_shapes
                           if (fit := fit_clipped_opening(rails, camera, attitude, position, 2.*GATE_HALF_WIDTH)) is not None]
            elif rim_shapes:
                centre, rotation = self.course[active]
                options = []
                for rails in rim_shapes:
                    measurement = measure_clipped_square(rails, camera, 2.*GATE_HALF_WIDTH)
                    if measurement is None:
                        continue
                    relative, measured_rotation, _ = measurement
                    error = np.linalg.norm(position+relative-centre)
                    if error < min(2.*GATE_HALF_WIDTH, self.identity_bounds[active][1]) and (
                            rotation.inv()*measured_rotation).magnitude() < np.radians(35.):
                        options.append((rails, measurement))
                if len(options) == 1:
                    rails, measurement = options[0]
                    outer_error = self.recover_position(stamp, active, (), self.gates, (rails,), measurement)
                    if outer_error is not None:
                        count += 1
                        position, attitude = pose_at(self.filter.x[:, 0], 0)
                        if outer_error <= 3.:
                            observed.add(active)
                            has_range = True
                            self.pending_position = None
                            self.position_recovering = None
        for gate in observed:
            self.seen[gate] = stamp
            self.metric_seen[gate] = stamp
        if active in observed:
            center, plane = self.course[active]
            pixels, depth = project(plane.apply(APERTURE)+center, position, attitude)
            cropped = np.any((pixels < 0.) | (pixels > [image.shape[1]-1,image.shape[0]-1]))
            close = 0. < (center-position)@plane.apply([1., 0., 0.]) <= 2.*GATE_HALF_WIDTH
            self.clipped_close_gate = active if close and cropped and min(depth) > .25 else None
        self.visibility.append((stamp, active, active in observed))
        if active == self.active and outer_error is None:
            self.reacquire_active(outlines, partials, color, stamp, active)
        if outlines and save_frame:
            self.image_corners.extend((stamp, *corners.ravel()) for corners in outlines)
            self.image_bounds.extend(bound.ravel() if bound is not None else np.full(8, np.nan) for _, bound in pairs)
            self.image_poses.append((stamp, *self.filter.x[:7, 0], active))
            self.image_poses_prior.append((stamp, *prior_pose, active))
            self.last_saved_image = stamp
        if active >= len(self.course)-1:
            points = (position+attitude.apply(CAMERA_FROM_BODY.T@rim_look_point(rails)) for rails in partials)
            self.retain_rims(stamp, position, points)
        if active == self.active:
            if active >= len(self.course)-1:
                self.observe_border(rims, mask, color, position, attitude, stamp, len(self.course))
            self.acquire_next(image, outlines, clipped, stamp, active)
        self.refresh()
        self.landmark_log.extend((stamp, i, *center, *rotation.as_quat()) for i, (center, rotation) in enumerate(self.course))
        if preview_frame:
            self.publish_gate_preview(image, pairs, partials, stamp)
        self.gate_stages.append((stamp, detected-started, corrected-detected, monotonic()-corrected))
        return count, has_range


class CourseClient(Client):
    observer_type = CourseObserver

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_send = None
        self.send_ages = []
        if self.preview is not None:
            self.observer.gate_preview = self.preview.with_name('gate-view.json')

    def send(self, command):
        result = super().send(command)
        now = monotonic()
        feedback = self.state.rate_feedback if self.state is not None else None
        snapshot = self.prediction.source
        if feedback is not None and snapshot is not None:
            self.send_ages.append((now, now-feedback.received_at, now-snapshot[3],
                                  feedback.time-snapshot[0], feedback.time-snapshot[2]))
        self.observer.actuation = (
            1000.*(now-self.last_send) if self.last_send is not None else None,
            1000.*(now-feedback.received_at) if feedback is not None else None)
        self.last_send = now
        return result


class FollowCourse:
    def __init__(self, client, speed, offset, motor_calibration=None, pace=None, view_offsets=(), finish_costs=None,
                 corridor_profile=None, racing_line=None):
        self.config = replace(CONFIG, max_speed=speed, **(motor_calibration or {}))
        self.client = client
        self.crossings = []
        self.crossing_checks = []
        self.approach_commands = []
        self.plan_times = []
        self.traverse_plans = []
        self.traverse_dips = []
        self.planner_calls = 0
        self.feasible_plans = 0
        self.ready_to_fly = False
        self.approach_sample = None
        self.course_complete_at = None
        self.passage = None
        self.search_start = None
        self.search_heading = None
        self.exit_view = None
        self.look_down = None
        self.offset = offset
        self.view_offsets = view_offsets
        self.leg_pace = [] if pace is None else pace
        self.finish_costs = finish_costs
        self.corridor_profile = corridor_profile
        self.racing_line = racing_line
        self.planned_exit = None
        self.launch_reference = None
        self.launch_built = False
        self.pose_heading = None
        self.reference_rates = None

    def has_corridor(self, index):
        return self.corridor_profile is not None and 0 < index < len(self.corridor_profile[0])

    def corridor_velocity(self, index, origin, center, position, motion, speed):
        if self.racing_line is not None and index < len(self.racing_line.gates):
            # IMU traces put lateral response near the attitude time constant plus transport.
            lateral_delay = .02+1./self.config.attitude_gain
            vertical_delay = .04
            if self.racing_line.rate_feedforward is not None:
                lateral_delay = .02
            if self.racing_line.acceleration_delay is not None:
                lateral_delay, vertical_delay = self.racing_line.acceleration_delay
            sample = self.racing_line.reference(index, origin, center, position,
                                                acceleration_lead=(lateral_delay, vertical_delay),
                                                with_progress=self.racing_line.pose_heading is not None)
            reference, velocity, acceleration = sample[:3]
            if len(sample) == 4:
                self.pose_heading = float(self.racing_line.pose_heading(sample[3]))
                if self.racing_line.rate_feedforward is not None:
                    self.reference_rates = self.racing_line.rate_feedforward(sample[3])
        else:
            velocities, durations, lengths = self.corridor_profile
            duration = durations[index-1]*np.linalg.norm(center-origin)/lengths[index-1]
            reference, velocity, acceleration = leg_reference(
                origin, center, velocities[index-1], velocities[index], max(.12, duration), position)
            wanted = velocity+self.config.position_gain*(reference-position)+acceleration/self.config.velocity_gain
            return wanted*min(1., speed/max(.01, np.linalg.norm(wanted)))
        pace = min(1., speed/max(.01, np.linalg.norm(velocity)))
        delay = np.array([lateral_delay, lateral_delay, vertical_delay])
        error = reference-position+delay*(pace*velocity-motion)
        return (pace*velocity+self.config.position_gain*error
                +pace**2*acceleration/self.config.velocity_gain)

    def crossed_plane(self, center, plane, stamp, position, velocity, seen, index, exit_distance, close_view, lock_stamp,
                      *, client=None):
        """Check a continuous forward intercept, then clear the same plane."""
        previous = self.approach_sample
        source = None if client is None else client.prediction.source
        if previous is None or stamp > previous[0] or stamp == previous[0] and source is not previous[3]:
            predicted = client.prediction.state[:16].copy() if client is not None else None
            self.approach_sample = stamp, position, velocity, source, predicted
        local = plane.apply(position-center)
        if self.passage is not None:
            crossed_center, crossed_normal, clearance, _ = self.passage
            normal = plane.as_matrix()[0]
            if (local[0] < -GATE_DEPTH or np.linalg.norm(center-crossed_center) > GATE_DEPTH
                    or normal@crossed_normal < .98):
                self.passage = None
            else:
                return (position-crossed_center)@crossed_normal > clearance and local[0] > exit_distance
        if previous is None or local[0] < 0.:
            return False
        earlier, old_position, old_velocity, old_source, old_prediction = previous
        current_depth = local[0]
        if source is not old_source:
            # Camera revisions can arrive without a new IMU sample. Verify only
            # the IMU-covered motion between two states from the same revision.
            if stamp == earlier:
                earlier = client.history[-2][0] if len(client.history) >= 2 else stamp
            if 0. < stamp-earlier <= IMU_TIMEOUT:
                start = client.prediction.sweep_start(earlier, client.history)
                if start is not None:
                    earlier, old_position, old_velocity = start
                    exposure, corrected = source[:2]
                    if exposure < earlier and stamp-exposure <= IMU_TIMEOUT and plane.apply(old_position-center)[0] >= 0.:
                        earlier, old_position, old_velocity = exposure, corrected[:3], corrected[7:10]
                if start is None or plane.apply(old_position-center)[0] >= 0.:
                    # The new exposure may already be past the plane. Verify
                    # the preceding inertial sweep and require both revisions to agree.
                    earlier, old_position, old_velocity = previous[:3]
                    if not client.history[0][0] <= earlier < stamp <= client.history[-1][0]:
                        return False
                    swept = old_prediction.copy()
                    for end, reading, gap in inertial_intervals(earlier, stamp, np.asarray(client.history)):
                        if gap > IMU_TIMEOUT:
                            return False
                        integrate(swept, end-reading[0], reading)
                    if np.linalg.norm(swept[:3]-position) > .10:
                        return False
                    position, velocity = swept[:3], swept[7:10]
                    local = plane.apply(position-center)
        if stamp <= earlier:
            return False
        before = plane.apply(old_position-center)
        if before[0] < 0. <= local[0]:
            dt = stamp-earlier
            travel = position-old_position
            continuity = np.linalg.norm(travel-.5*dt*(old_velocity+velocity))
            intercept, clearance = crossing_clearance(before, local)
            accel_bound = max(np.sqrt(2.)*self.config.max_acceleration, np.linalg.norm(velocity-old_velocity)/dt)
            interpolation_error = accel_bound*dt**2/8.
            clearance -= interpolation_error+continuity
            age = stamp-seen
            # A clipped aperture can disappear while the IMU still carries a centered approach.
            recent = 0. <= age <= GATE_VIEW_AGE or close_view and 0. <= age <= 3.2 and clearance > CHASSIS_RADIUS
            # A projected rim edge can confirm visibility without updating the gate pose.
            localized = 0. <= stamp-lock_stamp <= 3.2
            inside = np.max(np.abs(intercept))+interpolation_error+continuity < .75
            accepted = dt <= IMU_TIMEOUT and recent and localized and continuity <= .10 and inside
            crossing_time = earlier - dt*before[0]/(local[0]-before[0])
            self.crossing_checks.append((crossing_time, index, dt, age, continuity, *intercept, clearance, accepted))
            if accepted:
                self.passage = center.copy(), plane.as_matrix()[0], exit_distance, position[2]
                return current_depth > exit_distance
        return False

    def update(self, telemetry, frames, race_state):
        state = vehicle.state
        if not race_state or not race_state.started or state.motion is None or state.attitude is None:
            return None
        plan_started = monotonic()
        self.pose_heading = None
        self.reference_rates = None
        client = self.client()
        observer = client.observer
        geometry = client.prediction.source[4]
        course, index = geometry.course, observer.active
        map_first = self.racing_line is not None and self.racing_line.map_first
        if map_first and index >= len(course):
            if self.course_complete_at is None:
                self.course_complete_at = plan_started
            if plan_started-self.course_complete_at > 2.:
                raise TimeoutError('Course crossed but no native finish received')
            attitude = state.attitude
            angles = (attitude.roll, attitude.pitch, attitude.yaw)
            return acceleration_control(self.config, -self.config.velocity_gain*np.asarray(state.motion.velocity),
                                        angles, attitude.yaw)
        if index+1 < len(course):
            following = course[index+1][0], geometry.range_sigma[index+1]
        else:
            following = observer.carried_opening(course)
        stamp = state.motion.time
        if not self.ready_to_fly:
            if monotonic()-geometry.received_at > IMU_TIMEOUT:
                return None
            self.ready_to_fly = True
        p, v = np.asarray(state.motion.position), np.asarray(state.motion.velocity)
        attitude = state.attitude
        angles = (attitude.roll, attitude.pitch, attitude.yaw)
        measured_plane = index < len(observer.saved_course) or geometry.confirmed_normal == index
        if self.corridor_profile is not None and index < len(geometry.cross_sigma):
            fresh = 0. <= stamp-geometry.metric_seen.get(index, -np.inf) <= GATE_VIEW_AGE
            measured_plane |= fresh and 2.*geometry.cross_sigma[index] < .75-CHASSIS_RADIUS
        nominal = 3.2 if measured_plane else 2.5
        planned = self.leg_pace[index] if measured_plane and index < len(self.leg_pace) else nominal
        speed = min(self.config.max_speed, planned or nominal)
        traverse = None
        course_direction = None
        corridor_exit = False
        departed = None
        continuous = self.racing_line is not None and self.racing_line.continuous

        if index < len(course):
            self.search_start = None
            center, plane = course[index]
            local = plane.inv().apply(p-center)
            sigma = geometry.range_sigma[index] if index < len(geometry.range_sigma) else 1.
            exit_distance = .5*GATE_DEPTH+CHASSIS_RADIUS+min(2.3, 1.5*sigma)
            recovery = geometry.position_recovering
            recovering = (recovery is not None and recovery[0] == index
                          and 0. <= stamp-recovery[1] <= IMU_TIMEOUT)
            near = geometry.near_plane
            plane_ahead = (near is not None and near[0] == index and 0. <= stamp-near[1] <= IMU_TIMEOUT
                           and (near[2]-p) @ near[3] > GATE_DEPTH and local[0] > -GATE_DEPTH)
            if recovering:
                self.planned_exit = None
            if recovering or plane_ahead:
                self.exit_view = None
            if stamp-geometry.seen.get(index, stamp) > 9.:
                raise TimeoutError(f'gate {index+1} lost visual support for 9 s')
            lock_stamp = geometry.seen.get(index, -np.inf)
            seen = max(lock_stamp, geometry.edge_seen.get(index, -np.inf))
            follow_line = (self.racing_line is not None and 0 < index < len(self.racing_line.gates)
                           and (continuous or measured_plane and 0. <= stamp-lock_stamp <= GATE_VIEW_AGE))
            # Check both samples in the current plane. A position jump fails the continuity test.
            passed = self.crossed_plane(
                center, plane.inv(), stamp, p, v, seen, index, exit_distance, geometry.clipped_close_gate == index,
                lock_stamp, client=client if map_first else None)
            if passed and not plane_ahead:
                self.crossings.append((stamp, index, *local))
                observer.active = index+1
                self.approach_sample = None
                departed = self.passage
                self.passage = None
            elif not plane_ahead and local[0] > exit_distance+.55:
                raise RuntimeError(f'gate {index+1} plane passed without a confirmed crossing')
        else:
            if self.search_start is None:
                self.search_start = stamp
                self.search_heading = yaw_of(course[-1][1])
                if self.exit_view is not None and self.exit_view[0] == index-1 and stamp-self.exit_view[1] <= 1.6:
                    self.search_heading = self.exit_view[2]
            sighting = observer.opening_hint
            fresh_hint = (sighting is not None and sighting[0] == index
                          and 0. <= stamp-sighting[2] <= IMU_TIMEOUT)
            if not fresh_hint and stamp-self.search_start > 2.*np.pi/self.config.max_rate+1.:
                raise TimeoutError(f'next aperture unseen after crossing gate {index}')

        if index >= len(course):
            heading = self.search_heading
            wanted_velocity = np.zeros(3)
            corridor_preview = False
            if self.finish_costs is not None and (carried := observer.carried_opening(course)) is not None:
                center, radius = carried
                relative = center-p
                distance = np.linalg.norm(relative)
                room = max(0., distance-radius-CHASSIS_RADIUS)
                approach = min(self.config.max_speed, np.sqrt(2.*self.config.max_acceleration*room))
                if self.has_corridor(index) and approach > 0.:
                    wanted_velocity = self.corridor_velocity(index, course[-1][0], center, p, v, approach)
                    heading = np.arctan2(relative[1], relative[0])
                    corridor_preview = True
                else:
                    wanted_velocity = approach*relative/max(.01, distance)
            if not corridor_preview and fresh_hint:
                relative = sighting[1]-p
                distance = np.linalg.norm(relative)
                range_margin = 2.*opening_range_sigma(distance)+2.*GATE_HALF_WIDTH
                room = max(0., distance-range_margin)
                approach = min(nominal, np.sqrt(2.*self.config.max_acceleration*room))
                wanted_velocity = approach*relative/max(.01, distance)
                heading = np.arctan2(relative[1], relative[0])
                corridor_preview = True
            lower = observer.lower_sighting
            # Carry the measured rim into the handoff so braking cannot hide it.
            fresh_lower = (not corridor_preview and lower is not None and lower[0] == index
                           and self.search_start-1.6 <= lower[1] <= stamp
                           and stamp-max(lower[1], self.search_start) <= 1.35)
            if fresh_lower:
                heading = self.search_heading = lower[2]
                if self.look_down is None or self.look_down[0] != index:
                    self.look_down = index, stamp, p[:2].copy(), heading, lower[4]
            looking_down = False
            if not corridor_preview and self.look_down is not None and self.look_down[0] == index:
                _, began, origin, aim, target = self.look_down
                look_distance = min(2.*GATE_HALF_WIDTH, np.linalg.norm(target[:2]-origin)/3.)
                if stamp-began < 2./self.config.attitude_gain and np.linalg.norm(p[:2]-origin) < look_distance:
                    heading = aim
                    looking_down = True
                    axis = course[-1][1].apply([1., 0., 0.])[:2]
                    axis /= max(.01, np.linalg.norm(axis))
                    to_gate = target-p
                    elevation = np.arctan2(to_gate[2], np.linalg.norm(to_gate[:2]))
                    tilt = np.clip(ANGLE+elevation-.75*np.arctan(K[1,2]/K[1,1]), 0., self.config.max_tilt)
                    speed_along = max(0., v[:2] @ axis)+GRAVITY*np.tan(tilt)/self.config.velocity_gain
                    wanted_velocity[:2] = min(self.config.max_speed, speed_along)*axis
        else:
            center, plane = course[index]
            origin = course[index-1][0] if index else observer.grid_position
            along = (center-origin)[:2]
            course_direction = along/max(.01, np.linalg.norm(along))
            if not measured_plane and not follow_line:
                # An oblique first sighting can give two plausible planes.
                plane = Rotation.from_euler('z', np.arctan2(along[1], along[0]))
            normal = plane.apply([1., 0., 0.])
            if index == 0 and continuous and not self.launch_built:
                self.launch_reference = LaunchReference.build(self.config, self.racing_line, p, v, center, normal)
                self.launch_built = True
            through_launch = index == 0 and self.launch_reference is not None
            to_opening = center-p
            depth, sideways, down = plane.inv().apply(to_opening)
            exit_limit = None
            if continuous and follow_line:
                speed = self.config.max_speed
            elif not through_launch and self.finish_costs is not None and self.passage is None and depth > 0.:
                # An uncertain plane can be approached at speed while there is room to slow for it.
                exit_limit = speed if measured_plane else nominal
                if self.racing_line is not None and index == 0:
                    initial = self.racing_line.speed_squared(0.)**.5*self.racing_line.curve(0., 1)
                    exit_limit = min(exit_limit, initial@normal)
                room = max(0., depth-GATE_DEPTH-2.*sigma)
                speed = min(self.config.max_speed, np.sqrt(exit_limit**2+2.*self.config.max_acceleration*room))
                if index == 0 and self.racing_line is not None:
                    speed = min(speed, max(nominal, exit_limit))
            side_offset = self.view_offsets[index] if index < len(self.view_offsets) else self.offset
            if index and depth > 0.:
                sideways += side_offset*depth/(3.+depth)
            offset = np.array([sideways, down])
            closing, *transverse = plane.inv().apply(v)
            lateral_speed = np.asarray(transverse)
            accel = self.config.max_acceleration
            if through_launch:
                wanted_velocity = self.launch_reference.velocity_request(self.config, p, v)
            else:
                local_aim = np.r_[depth, offset]
                local_velocity = speed*local_aim/max(.01, np.linalg.norm(local_aim))
                stopping_room = GATE_DEPTH+max(0., closing)/self.config.attitude_gain+max(0., closing)**2/(2.*accel)
                if self.passage is not None:
                    if self.finish_costs is not None and self.planned_exit is not None and self.planned_exit[0] == index:
                        speed = min(speed, self.planned_exit[1])
                    local_velocity = np.r_[speed, self.config.position_gain*offset]
                elif depth <= 0.:
                    local_velocity = np.r_[0., self.config.position_gain*offset]
                elif not follow_line:
                    tail = None
                    if self.finish_costs is not None and index < len(self.finish_costs[1]):
                        tail = (self.finish_costs[0], self.finish_costs[1][index])
                    traverse = plan_traverse(self.config, plane, local_aim, np.r_[closing, lateral_speed], speed, angles,
                                             after_gate=tail, lock_age=max(0., stamp-lock_stamp), exit_limit=exit_limit)
                    self.planner_calls += 1
                    self.feasible_plans += int(traverse is not None)
                    if traverse is None and depth <= stopping_room+.75:
                        stop_offset = lateral_speed*np.abs(lateral_speed)/(2.*accel)
                        clearance = .75-2.*CHASSIS_RADIUS
                        if np.max(np.abs([offset, offset-stop_offset])) <= clearance:
                            forward = speed
                        else:
                            travel = np.clip(stop_offset, offset-.25, offset+.25)
                            direction = np.where(travel >= stop_offset, 1., -1.)
                            peak = np.sqrt(np.maximum(0., .5*lateral_speed**2+direction*accel*travel))
                            align_time = np.max((2.*peak-direction*lateral_speed)/accel)+1./self.config.attitude_gain
                            forward = min(local_velocity[0], max(0., depth-GATE_DEPTH)/align_time)
                        local_velocity = np.r_[forward, self.config.position_gain*offset]
                wanted_velocity = plane.apply(local_velocity)*min(1., speed/max(.01,np.linalg.norm(local_velocity)))
                if self.passage is not None:
                    exit_center, exit_normal, _, crossing_down = self.passage
                    if continuous or (p-exit_center)@exit_normal > .5*GATE_DEPTH+CHASSIS_RADIUS:
                        wanted_velocity[:2] = speed*exit_normal[:2]
                        wanted_velocity[2] = self.config.position_gain*(crossing_down-p[2])
            look = to_opening if depth > GATE_DEPTH else normal
            heading = np.arctan2(look[1], look[0])
            exit_state = self.passage if departed is None else departed
            if self.has_corridor(index+1) and exit_state is not None and following is not None:
                exit_center, exit_normal, _, _ = exit_state
                if (p-exit_center)@exit_normal > .5*GATE_DEPTH+CHASSIS_RADIUS:
                    target, radius = following
                    room = max(0., np.linalg.norm(target-p)-radius-CHASSIS_RADIUS)
                    cap = self.config.max_speed if continuous else min(self.config.max_speed, np.sqrt(2.*accel*room))
                    wanted_velocity = self.corridor_velocity(index+1, exit_center, target, p, v, cap)
                    heading = np.arctan2(target[1]-p[1], target[0]-p[0])
                    course_direction = None
                    corridor_exit = True
        if traverse is not None:
            planned_acceleration, _, snap, duration, exit_speed = traverse
            self.planned_exit = index, exit_speed
            wanted_velocity = v+planned_acceleration/self.config.velocity_gain
            if not self.traverse_plans or stamp-self.traverse_plans[-1][0] >= .10:
                self.traverse_plans.append((stamp, index, duration, exit_speed))
                self.traverse_dips.append(float(snap[2]*duration**4/384.))
        if (index < len(course) and self.has_corridor(index)
                and (self.passage is None or follow_line) and not corridor_exit):
            if follow_line:
                blend = 1.
            else:
                blend = np.clip((depth-stopping_room)/2., 0., 1.)
            reference = self.corridor_velocity(index, origin, center, p, v, speed)
            wanted_velocity += blend*(reference-wanted_velocity)
            if blend > 0.:
                traverse = None
        if course_direction is not None:
            wanted_velocity[:2] -= min(0., wanted_velocity[:2]@course_direction)*course_direction
        acceleration = self.config.velocity_gain*(wanted_velocity-v)
        if index < len(course) and follow_line and self.passage is None and depth > 0. and closing > 0.:
            time_to_plane = depth/closing
            response = time_to_plane-1./self.config.attitude_gain
            if .13 < response < .8:
                sideways_acceleration = plane.inv().apply(acceleration)[1:]
                travel = .5*response**2
                intercept = -offset+time_to_plane*lateral_speed+travel*sideways_acceleration
                margin = .75-CHASSIS_RADIUS-min(.22, 2.*geometry.cross_sigma[index])
                correction = (np.clip(intercept, -margin, margin)-intercept)/travel
                acceleration += plane.apply(np.r_[0., correction])
        if self.config.body_resistance_per_m is not None:
            body = Rotation.from_euler('xyz', angles)
            velocity_body = body.inv().apply(v)
            drag = np.asarray(self.config.body_resistance_per_m)*velocity_body*np.abs(velocity_body)
            acceleration += body.apply(drag)
        half_fov = np.arctan(K[0, 2]/K[0, 0])
        if map_first:
            look = None
            if self.pose_heading is not None:
                heading = self.pose_heading
        elif index+1 < len(course):
            successor = course[index+1][0]-p
            turn = (np.arctan2(successor[1], successor[0])-heading+np.pi)%(2.*np.pi)-np.pi
            look = (turn, successor) if abs(turn) < 2.*half_fov else None
        else:
            look = observer.next_look(p, heading, stamp, index, course, half_fov)
        if index >= len(course):
            if not (corridor_preview or looking_down or fresh_lower):
                sight = observer.border_sighting
                look_time = IMU_TIMEOUT+half_fov/self.config.max_rate
                fresh = (sight is not None and sight[0] == index
                         and self.search_start-1.6 <= sight[1] <= stamp
                         and stamp-max(sight[1], self.search_start) <= look_time)
                if fresh and (look is None or np.linalg.norm(look[1]) > sight[4]):
                    heading = self.search_heading = sight[2]
                elif look is not None:
                    heading += np.clip(look[0], -half_fov, half_fov)
                else:
                    normal = yaw_of(course[-1][1])
                    edge = np.pi/2.-half_fov
                    # Check just beyond both sides of the current view before sweeping to its limits.
                    probe = 2.*edge/3.
                    unviewed = observer.unseen_sides(index, probe)
                    if not unviewed:
                        probe = edge
                        unviewed = observer.unseen_sides(index, probe)
                    if unviewed:
                        offset = (angles[2]-normal+np.pi)%(2.*np.pi)-np.pi
                        side = min(unviewed, key=lambda s: abs(s*probe-offset))
                        heading = self.search_heading = normal+side*probe
        elif look is not None and depth > GATE_DEPTH and stamp-geometry.seen.get(index, -np.inf) <= IMU_TIMEOUT:
            turn, successor = look
            aim = plan_exit_view(self.config, angles, heading, plane.apply(APERTURE)+to_opening, v, acceleration,
                                 turn, successor, traverse)
            if abs(aim-heading) > 1.e-3:
                self.exit_view = index, stamp, aim
                heading = aim
        elif not corridor_exit and depth <= GATE_DEPTH and self.exit_view is not None and self.exit_view[0] == index:
            if stamp-self.exit_view[1] <= 1.6:
                heading = self.exit_view[2]
        if (self.pose_heading is not None and not map_first
                and index < len(course) and not recovering and not plane_ahead):
            # Keep the current aperture in the horizontal view while it can still fit.
            # The correction vanishes at the crossing, so the planned pose can lead the exit.
            bearing = np.arctan2(to_opening[1], to_opening[0])
            aperture = np.arctan2(.75, max(.01, np.linalg.norm(to_opening[:2])))
            half_view = max(0., half_fov-aperture)
            error = (self.pose_heading-bearing+np.pi)%(2.*np.pi)-np.pi
            approach_weight = np.clip((depth-GATE_DEPTH)/(2.*CHASSIS_RADIUS), 0., 1.)
            heading = self.pose_heading+approach_weight*(np.clip(error,-half_view,half_view)-error)
        if self.racing_line is not None and self.racing_line.acceleration_response is not None:
            inverse, bias = self.racing_line.acceleration_response
            heading_frame = Rotation.from_euler('z', angles[2])
            acceleration = heading_frame.apply(inverse @ (heading_frame.inv().apply(acceleration)-bias))
        if not self.approach_commands or stamp-self.approach_commands[-1][0] >= .10:
            self.approach_commands.append((stamp, index, heading, *wanted_velocity, *acceleration))
            observer.latest_plan = float(np.linalg.norm(wanted_velocity)), float(np.linalg.norm(acceleration))
        rates = (Rotation.from_euler('xyz', angles).inv().apply(self.reference_rates)
                 if self.reference_rates is not None else (0., 0., 0.))
        command = acceleration_control(self.config, acceleration, angles, heading, rate_feedforward=rates,
                                       geometric=self.racing_line is not None and self.racing_line.geometric_control)
        self.plan_times.append((stamp, monotonic()-plan_started))
        return command


def fly(trace, speed, prior=None, offset=0., record_video=False, motor_calibration=None,
        pace=None, confirmed_gates=None, view_offsets=(), *, finish_costs=None, corridor_profile=None, racing_line=None, target='vq1.r1',
        finish_before=115., startup_timeout=120.,
        visible=False, race_log=None, preview=None, race_reader=None, rollout_fn=None, record_camera=False,
        track_pose_branches=False):
    clients, pilots = [], []
    motor_controls = target in MotorPilot.targets
    owned_reader = RaceStateReader(race_log, 1.) if race_log is not None else None
    reader = race_reader if race_reader is not None else owned_reader

    def client(*args, **kwargs):
        kwargs['preview'] = preview
        instance = CourseClient(*args, **kwargs)
        instance.observer.track_pose_branches = track_pose_branches
        instance.observer.mapped_rim_bearings = (racing_line is not None and racing_line.mapped_rim_bearings
                                                and prior is not None and confirmed_gates == len(prior))
        instance.observer.preview_course = racing_line is not None and confirmed_gates == len(prior)
        if racing_line is not None and racing_line.continuous:
            instance.observer.warmup_seconds = .65
        if racing_line is not None:
            instance.observer.camera_offset_s = racing_line.camera_offset_s
        if racing_line is not None and racing_line.scene_keyframes:
            instance.observer.recent_images = deque(maxlen=280)
        if target == 'vq2.r2':
            instance.contact_severity = 0  # End a clean-run trial on its first scored contact.
        if record_video:
            writer = cv2.VideoWriter(str(trace.parent/'camera.mp4'), cv2.VideoWriter_fourcc(*'mp4v'), 12., (640, 360))
            if not writer.isOpened():
                raise OSError('Could not open the onboard video')
            instance.observer.video = writer
        if prior is not None:
            instance.observer.prior = prior
            instance.observer.confirmed_gates = len(prior) if confirmed_gates is None else confirmed_gates
        clients.append(instance)
        return instance

    def wrap(make):
        def create():
            pilot = FollowCourse(lambda: clients[-1], speed, offset, motor_calibration, pace, view_offsets,
                                 finish_costs, corridor_profile, racing_line)
            pilots.append(pilot)
            return MotorPilot(position=pilot) if motor_controls else pilot
        return create

    cv2.setNumThreads(1)
    K[:2, 2] = (319.5, 179.5)
    directory = Path(__file__).resolve().parent
    sources = {Path(m.__file__) for m in tuple(sys.modules.values())
               if getattr(m, '__file__', None) and Path(m.__file__).parent == directory}
    sources.update(Path(getsourcefile(component)) for component in (
        Client, GateObserver, PoseFilter, gate_update, apertures, fit_outline, probes, Vanishing, RacingLine, leg_reference))
    sources.update((Path(__file__).resolve(), Path(sys.modules['rednose.helpers.ekf_sym'].__file__)))
    inputs = dict(pilot_sha256=PILOT_SHA256, geometry_sha256=sha256(np.asarray(prior if prior is not None else [], dtype='<f8').tobytes()).hexdigest(),
                  localization_gates=confirmed_gates, pace_m_s=pace, view_offsets_m=list(view_offsets),
                  track_pose_branches=track_pose_branches,
                  uses_remaining_time=finish_costs is not None,
                  corridor_leg_seconds=None if corridor_profile is None else corridor_profile[1].tolist(),
                  racing_line_seconds=None if racing_line is None else racing_line.seconds,
                  map_first=racing_line is not None and racing_line.map_first,
                  track_rates=racing_line is not None and racing_line.rate_feedforward is not None,
                  geometric_control=racing_line is not None and racing_line.geometric_control,
                  heading_acceleration_model=racing_line is not None and racing_line.acceleration_response is not None,
                  mapped_rim_bearings=racing_line is not None and racing_line.mapped_rim_bearings,
                  scene_keyframes=racing_line is not None and racing_line.scene_keyframes,
                  camera_offset_s=0. if racing_line is None else racing_line.camera_offset_s,
                  acceleration_delay_s=None if racing_line is None else racing_line.acceleration_delay,
                  confirm_large_corrections=CourseClient.observer_type.confirm_large_corrections,
                  fallback_offset_m=offset, motor_calibration=motor_calibration,
                  opencv=cv2.__version__, numpy=np.__version__)
    finished = False
    try:
        native_controller = 'r1_motors' if motor_controls else 'r1_body_rates'
        run = rollout if rollout_fn is None else rollout_fn
        _, simulator, _, _ = run(native_controller, trace, camera=True, offscreen=not visible, timesync=True,
                                     target=target, finish_before=finish_before, timeout=IMU_TIMEOUT, client_type=client, wrap_controller=wrap,
                                     startup_timeout=startup_timeout, attach=reader is not None, race_reader=reader,
                                     record_camera=record_camera, race_status_timeout=1., extra_sources=sources, control_inputs=inputs,
                                     imu_loss_timeout=.5)
        status = simulator.status
        finished = status is not None and status.valid is not False and status.completed
        if status is not None:
            validity = 'unknown' if status.valid is None else str(status.valid)
            print(f'Race result: {status.active_gate_index} gates, validity {validity}, finish {status.finish_time_seconds:.3f}s',
              flush=True)
    finally:
        if owned_reader is not None:
            owned_reader.close()
        for client in clients:
            if client.observer.video is not None:
                client.observer.video.release()
        if clients and clients[-1].observer.last_image is None:
            frame = clients[-1]._camera.latest
            if frame is not None:
                cv2.imwrite(str(trace.parent/'last-camera.jpg'), frame.bgr)
        if clients and clients[-1].samples:
            client = clients[-1]
            observer = client.observer
            if observer.rejected_factors:
                fields = ('time', 'state', 'covariance', 'change', 'innovation', 'jacobian', 'pixel_sigma', 'range_noise')
                np.savez_compressed(trace.parent/'rejected-pixels.npz', **{
                    f'g{gate+1}_{n}_{name}': value for gate, cases in observer.rejected_factors.items()
                    for n, case in enumerate(cases) for name, value in zip(fields, case, strict=True)})
            np.savez_compressed(trace.parent/'learned-course.npz', pose=client.samples, camera=observer.camera_stats,
                                camera_stages=observer.camera_stages, gate_stages=observer.gate_stages,
                                send_ages=client.send_ages, plan_times=pilots[-1].plan_times,
                                applied_camera_states=client.corrections,
                                imu_clock_resets=client.clock_resets,
                                gates=observer.landmark_log, acquisitions=observer.acquisitions,
                                acquisition_support=observer.acquisition_support,
                                pose_ambiguity=observer.pose_ambiguity,
                                successor_views=observer.successor_views, partial_confirmations=observer.partial_confirmations,
                                portal_evidence=observer.portal_evidence, rim_evidence=observer.rim_evidence,
                                replacements=np.empty((0, 8)),
                                rejected=observer.rejected, position_recoveries=observer.position_recoveries,
                                rim_bearing_updates=observer.rim_bearing_updates,
                                gate_recoveries=observer.gate_recoveries,
                                opening_velocity=observer.opening_velocity,
                                visibility=observer.visibility, edge_visibility=observer.edge_visibility,
                                reacquisitions=observer.reacquisitions,
                                image_corners=observer.image_corners, image_poses=observer.image_poses,
                                image_poses_prior=observer.image_poses_prior,
                                detections=np.asarray(observer.detections).reshape(-1, 3),
                                pixel_innovations=np.asarray(observer.pixel_innovations).reshape(-1, 2),
                                image_bounds=observer.image_bounds,
                                attitude_recoveries=observer.lines.recoveries,
                                crossings=pilots[-1].crossings, approach_commands=pilots[-1].approach_commands,
                                launch_duration=0. if pilots[-1].launch_reference is None else pilots[-1].launch_reference.duration,
                                crossing_checks=np.asarray(pilots[-1].crossing_checks).reshape(-1, 9),
                                traverse_plans=np.asarray(pilots[-1].traverse_plans).reshape(-1, 4),
                                traverse_dips=np.asarray(pilots[-1].traverse_dips),
                                planner_counts=(pilots[-1].planner_calls, pilots[-1].feasible_plans),
                                speed_cap=speed,
                                prior_gates=0 if prior is None else len(prior), approach_offset=offset,
                                prior_localization_gates=observer.confirmed_gates,
                                superseded_frames=observer.superseded_frames,
                                entry_view_offsets_m=view_offsets,
                                entry_pace_m_s=pace if pace is not None else [])
            if observer.last_image is not None:
                cv2.imwrite(str(trace.parent/'last-camera.jpg'), observer.last_image)
            scene_keyframes = racing_line is not None and racing_line.scene_keyframes
            if observer.recent_images and (scene_keyframes or not finished):
                captures = [(stamp, cv2.imencode('.jpg', image, [cv2.IMWRITE_JPEG_QUALITY, 85]))
                            for stamp, image in observer.recent_images]
                frames = [(stamp, jpeg) for stamp, (ok, jpeg) in captures if ok]
                if frames:
                    stamps, jpegs = zip(*frames, strict=True)
                    name = 'scene-keyframes.npz' if scene_keyframes else 'failure-frames.npz'
                    np.savez(trace.parent/name, time=stamps, jpeg=np.concatenate(jpegs),
                             offsets=np.r_[0, np.cumsum([len(jpeg) for jpeg in jpegs])])
            for index, image in observer.handoff_images.items():
                cv2.imwrite(str(trace.parent/f'handoff-{index}.jpg'), image)


def fly_from_map(trace, speed, map_path=None, motor_calibration=None, *,
                 line_path=None, plan_path=None, observer_map=None, map_first=False, **options):
    if plan_path is not None and (map_path is None or line_path is None):
        raise ValueError('An explicit plan requires its map and racing line')
    memory = {}
    prior = None
    if map_path is not None:
        if map_path.suffix == '.json':
            from refine_gate_map import unpack_gate_map
            memory = json.loads(map_path.read_text())
            prior = unpack_gate_map(memory)
        else:
            prior = np.load(map_path, allow_pickle=False)
    pace = memory.get('pace', {})
    calibration = json.loads(motor_calibration.read_text()) if motor_calibration else memory.get('motor_calibration')
    if calibration is not None:
        speed = calibration.pop('max_speed', speed)
    confirmed = pace.get('confirmed_gates')
    speeds = pace.get('speed_m_s', [])[:confirmed]
    finish_costs = None
    profile = None
    racing_line = None
    learned_offsets = memory.get('line_offsets')
    offsets = np.asarray(learned_offsets) if learned_offsets is not None else None
    if offsets is not None and offsets.shape != (len(prior)-1, 9, 3):
        offsets = learned_offsets = None
    smoothing = (5., 8.) if offsets is not None else None
    observed_path = line_path if line_path is not None else trace.parent.parent/'racing-line.npz'
    if confirmed and offsets is None and observed_path.is_file():
        with np.load(observed_path, allow_pickle=False) as observed:
            if len(observed['offsets']) == len(prior)-1:
                offsets = observed['offsets']
                if 'gate_rotations' in observed:
                    prior[:, 3:] = observed['gate_rotations']
                if 'smooth' in observed:
                    smoothing = observed['smooth']
    if offsets is not None and confirmed and len(prior) > 1:
        from plan_corridor import corridor
        config = replace(CONFIG, max_speed=speed, **(calibration or {}))
        prepared = plan_path if plan_path is not None else trace.parent.parent/'course-plan.npz'
        if learned_offsets is None and smoothing is not None and prepared.is_file():
            with np.load(prepared, allow_pickle=False) as data:
                if plan_path is not None and (str(data['map_sha256']) != sha256(map_path.read_bytes()).hexdigest()
                        or str(data['line_sha256']) != sha256(line_path.read_bytes()).hexdigest()):
                    raise ValueError('Plan input hashes do not match the explicit map and racing line')
                same_config = str(data['config']) == json.dumps(asdict(config), sort_keys=True)
                if same_config and data['centers'].shape == prior[:, :3].shape:
                    drift = prior[:, :3]-data['centers']
                    compatible = np.max(np.linalg.norm(np.diff(drift, axis=0), axis=1)) < .25
                    if compatible and (plan_path is None or np.max(np.linalg.norm(drift, axis=1)) < .25):
                        racing_line = RacingLine.prepared(data)
                        racing_line.map_first |= map_first
                        profile = data['velocities'], data['durations'], data['lengths']
                        finish_costs = data['candidate_speeds'], data['remaining_seconds']
                        speeds = np.linalg.norm(profile[0], axis=1).tolist()
        if racing_line is not None:
            if observer_map is not None:
                from refine_gate_map import read_packet_map
                learned = read_packet_map(observer_map)
                if learned.shape != prior.shape or not np.allclose(learned[0], prior[0]):
                    raise ValueError('Observer map must share the prepared gate frame')
                drift = learned[:, :3]-racing_line.centers
                if max(np.linalg.norm(drift, axis=1).max(), np.linalg.norm(np.diff(drift, axis=0), axis=1).max()) >= .25:
                    raise ValueError('Observer map exceeds the prepared line alignment bound')
                prior = learned
            racing_line.prepare_rates(prior[:,:3], config)
            anchors = len(prior) if racing_line.map_first else 1
            fly(trace, speed, prior, motor_calibration=calibration, pace=speeds, confirmed_gates=anchors,
                finish_costs=finish_costs, corridor_profile=profile, racing_line=racing_line,
                track_pose_branches=observer_map is not None and not racing_line.map_first, **options)
            return
        if plan_path is not None:
            raise ValueError('Explicit plan does not match the carried geometry and controller config')
        # A map can propose the next opening before repeated passages justify a racing leg.
        planned_course = prior
        if len(planned_course) > 1:
            try:
                entry = Rotation.from_quat(planned_course[0, 3:]).apply([1., 0., 0.])
                gate_speed = pace['speed_m_s'] if learned_offsets is not None else None
                points, velocities, durations, finish_costs = corridor(
                    planned_course[1:], planned_course[0, :3], config,
                    with_remaining_time=True, entry_normal=entry, gate_speed=gate_speed)
            except ValueError:
                pass  # Keep the observed pace when the carried geometry has no feasible path.
            else:
                profile = velocities, durations, np.linalg.norm(np.diff(points, axis=0), axis=1)
                if gate_speed is None:
                    speeds = np.linalg.norm(velocities, axis=1).tolist()
                try:
                    racing_line = RacingLine(planned_course[:, :3], offsets, config,
                                             planned_course[:, 3:], smoothing, gate_speed)
                except ValueError:
                    pass  # Use the local approach until the learned geometry admits a line.
    if plan_path is not None:
        raise ValueError('Explicit plan requires a complete prepared racing line')
    anchors = 1 if confirmed is not None else None
    fly(trace, speed, prior, motor_calibration=calibration, pace=speeds, confirmed_gates=anchors,
        finish_costs=finish_costs, corridor_profile=profile, racing_line=racing_line, **options)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('trace', type=Path)
    parser.add_argument('--speed', type=float, default=12., help='upper bound for the learned leg speeds, in m/s')
    parser.add_argument('--target', choices=TARGETS, default='vq1.r1')
    parser.add_argument('--finish-before', type=float, default=115., help='native race clock deadline in seconds')
    parser.add_argument('--startup-timeout', type=float, default=120., help='maximum startup wait in seconds')
    parser.add_argument('--visible', action='store_true', help='show the native simulator window during flight')
    parser.add_argument('--race-log', type=Path, help='attach to an already reset native race')
    parser.add_argument('--preview', type=Path, help='overwrite the latest camera JPEG for a local viewer')
    parser.add_argument('--map', type=Path)
    parser.add_argument('--offset', type=float, default=0.)
    parser.add_argument('--video', action='store_true')
    parser.add_argument('--motor-calibration', type=Path)
    args = parser.parse_args()
    fly_from_map(args.trace, args.speed, args.map, args.motor_calibration, offset=args.offset,
                 record_video=args.video, target=args.target,
                 finish_before=args.finish_before, startup_timeout=args.startup_timeout, visible=args.visible,
                 race_log=args.race_log, preview=args.preview)
