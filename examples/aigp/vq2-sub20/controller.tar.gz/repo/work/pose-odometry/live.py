"""Propagate on IMU arrivals, correct at image time and replay buffered IMU."""

from bisect import bisect_right
from dataclasses import dataclass
import json
from pathlib import Path
import sys
from time import perf_counter

import cv2
import numpy as np
from scipy.spatial.transform import Rotation, Slerp

from mapped import CAMERA_FROM_BODY, K, apertures, gate_points, measurements
from rim import edges, probes
from flow import Flow


I = np.eye(3)


def cross_matrix(v):
    x, y, z = v
    return np.array([[0., -z, y], [z, 0., -x], [-y, x, 0.]])


@dataclass
class State:
    stamp: float
    force: np.ndarray
    x: np.ndarray
    cov: np.ndarray

    def predict(self, stamp, force):
        dt = stamp-self.stamp
        x = self.x.copy()
        specific = Rotation.from_rotvec(x[9:]).apply((self.force+force)/2)
        accel = specific+[0., 0., 9.81]-x[6:9]
        x[:3] += dt*x[3:6]+.5*dt**2*accel
        x[3:6] += dt*accel
        model = np.eye(12)
        model[:3, 3:6] = dt*I
        model[3:6, 6:9] = -dt*I
        model[:3, 6:9] = -.5*dt**2*I
        model[3:6, 9:] = -dt*cross_matrix(specific)
        model[:3, 9:] = -.5*dt**2*cross_matrix(specific)
        noise = dt*np.diag(np.repeat([.001**2, .45**2, .25**2, .009**2], 3))
        cov = model @ self.cov @ model.T+noise
        return State(stamp, force, x, cov)

    def observe(self, image, gates, rims, rotation):
        camera = CAMERA_FROM_BODY @ (Rotation.from_rotvec(self.x[9:])*rotation).as_matrix().T
        detected = list(probes(image, rims, self.x[:3], camera))
        found = {ident for ident, _, _ in detected}
        lines = np.array([line for _, line, _ in detected]).reshape(-1, 2, 3)
        points = np.array([pixels for _, _, pixels in detected]).reshape(-1, 2, 2)
        candidates = measurements(list(apertures(image)), gates, self.x[:3], camera, 'mapped')
        geometry = dict(gates)
        quads, pixels, used = [], [], set()
        for error, index, ident, _, _, corners in sorted(candidates, key=lambda row: row[0]):
            if error < 7. and ident not in found and index not in used:
                quads.append(geometry[ident])
                pixels.append(corners)
                used.add(index)
        if not len(lines) and not quads:
            return 0
        quads = np.array(quads).reshape(-1, 4, 3)
        pixels = np.array(pixels).reshape(-1, 4, 2)

        def residual(pose):
            camera = CAMERA_FROM_BODY @ (Rotation.from_rotvec(pose[3:])*rotation).as_matrix().T
            line = project(lines, pose[:3], camera)
            tangent = line[:, 1]-line[:, 0]
            normal = np.stack((-tangent[:, 1], tangent[:, 0]), axis=1)
            normal /= np.maximum(.01, np.linalg.norm(normal, axis=1, keepdims=True))
            distance = np.einsum('nij,nj->ni', points-line[:, :1], normal)
            corners = project(quads, pose[:3], camera)-pixels
            return np.r_[(distance/.8).ravel(), (corners/1.8).ravel(), pose[3:]/.05]

        pose = np.r_[self.x[:3], self.x[9:]]
        error = residual(pose)
        steps = np.eye(6)*1e-5
        jac = np.zeros((len(error), 12))
        jac[:, [0, 1, 2, 9, 10, 11]] = np.array([(residual(pose+step)-error)/1e-5 for step in steps]).T
        weight = (1.+(error/3.)**2)**(-.25)
        jac *= weight[:, None]
        information = np.linalg.inv(self.cov)+jac.T @ jac
        self.cov = np.linalg.inv(information)
        self.x -= self.cov @ jac.T @ (weight*error)
        return len(lines)+len(quads)

    def constrain_direction(self, start, direction):
        dt = self.stamp-start.stamp
        displacement = self.x[:3]-start.x[:3]
        if np.linalg.norm(displacement) < .22:
            return
        direction = Rotation.from_rotvec(self.x[9:]).apply(direction)
        normal = cross_matrix(direction)
        error = normal @ displacement
        jac = np.zeros((3, 12))
        jac[:, 3:6] = dt*normal
        jac[:, 6:9] = .5*dt**2*normal
        jac[:, 9:] = cross_matrix(displacement) @ cross_matrix(direction)
        cov = I*(.035**2+.045**2*np.linalg.norm(displacement)**2)
        gain = np.linalg.solve(jac @ self.cov @ jac.T+cov, jac @ self.cov).T
        self.x -= gain @ error
        self.cov -= gain @ jac @ self.cov


def project(points, position, camera):
    projected = (points-position) @ camera.T @ K.T
    return projected[..., :2]/np.maximum(.1, projected[..., 2, None])


def replay(directory):
    cv2.setNumThreads(1)
    with np.load(directory/'public.npz', allow_pickle=False) as data:
        imu, ns, arrival, raw, offsets = (data[key] for key in ('imu', 'camera_ns', 'receipt', 'image', 'offsets'))
    with np.load(directory/'openvins-pose.npz', allow_pickle=False) as data:
        prior, available = data['pose'], data['available']
    orientation = Slerp(prior[:, 0], Rotation.from_quat(prior[:, 4:8]))
    opening = json.loads(Path(__file__).with_name('opening.json').read_text())
    gates = gate_points(json.loads((directory/'map.json').read_text()), opening)
    rims = list(edges(gates, .15732050896))
    sec = (ns-ns[0])*1e-9
    warmup = max(imu[0, 1], arrival[0])+1.
    capture = sec+np.quantile((arrival-sec)[arrival <= warmup], .05)-np.quantile((imu[:, 1]-imu[:, 0])[imu[:, 1] <= warmup], .05)
    events = [(t, 0, i) for i, t in enumerate(imu[:, 1])]+[(t, 1, i) for i, t in enumerate(arrival)]
    waiting, history, poses, performance = [], [], [], []
    tracks = Flow()
    last_update = -np.inf
    for host, camera, i in sorted(events):
        available_count = np.searchsorted(available, host, side='right')
        if host < warmup or not available_count:
            continue
        latest = prior[available_count-1, 0]
        if camera:
            waiting.append(i)
        else:
            stamp = imu[i, 0]
            force = orientation(np.clip(stamp, prior[0, 0], latest)).apply(imu[i, 2:5])
            if not history:
                cov = np.diag(np.repeat([.25**2, .3**2, .3**2, .012**2], 3))
                history.append(State(stamp, force, np.zeros(12), cov))
            elif stamp > history[-1].stamp:
                history.append(history[-1].predict(stamp, force))
            while len(history) > 1 and history[1].stamp < stamp-.45:
                history.pop(0)
        if not history:
            continue
        while waiting and capture[waiting[0]] <= history[-1].stamp:
            frame = waiting.pop(0)
            t = capture[frame]
            if t < max(history[0].stamp, last_update):
                continue
            start = perf_counter()
            at = bisect_right(history, t, key=lambda state: state.stamp)-1
            older = history[at]
            force = older.force
            if at+1 < len(history):
                later = history[at+1]
                fraction = (t-older.stamp)/(later.stamp-older.stamp)
                force = (1.-fraction)*older.force+fraction*later.force
            update = older.predict(t, force)
            frame_image = cv2.imdecode(raw[offsets[frame]:offsets[frame+1]], cv2.IMREAD_COLOR)
            rotation = orientation(np.clip(t, prior[0, 0], latest))
            flow = tracks.update(t, frame_image, lambda when: orientation(np.clip(when, prior[0, 0], latest)))
            if flow is not None and flow[0] >= history[0].stamp:
                anchor = bisect_right(history, flow[0], key=lambda node: node.stamp)-1
                update.constrain_direction(history[anchor].predict(flow[0], history[anchor].force), flow[1])
            count = update.observe(frame_image, gates, rims, rotation)
            if count or flow is not None:
                tail = [update]
                for node in history[at+1:]:
                    tail.append(tail[-1].predict(node.stamp, node.force))
                history[at if t == older.stamp else at+1:] = tail
                if count:
                    last_update = t
            performance.append((t, count, host-arrival[frame], perf_counter()-start))
        # A received image may revise an older state, but only this current state is emitted.
        if not camera:
            state = history[-1]
            rotation = Rotation.from_rotvec(state.x[9:])*orientation(np.clip(state.stamp, prior[0, 0], latest))
            poses.append((state.stamp, *state.x[:3], *rotation.as_quat(), *state.x[3:6], last_update))
    np.savez_compressed(directory/'live-flow-pose.npz', pose=poses, camera=performance)
    work = np.asarray(performance)
    print(f'{(work[:, 1] > 0).sum()}/{len(work)} image corrections; image processing p50/p95 '
          f'{np.quantile(work[:, 3], [.5, .95])*1000} ms')


if __name__ == '__main__':
    replay(Path(sys.argv[1]))
