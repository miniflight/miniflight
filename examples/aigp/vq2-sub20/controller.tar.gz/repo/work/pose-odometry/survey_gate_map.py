"""Run successive camera/IMU mapping flights and score the carried map."""

import argparse
from contextlib import ExitStack, closing, redirect_stderr, redirect_stdout
from dataclasses import asdict
from itertools import count
import os
import signal
import gzip
from hashlib import sha256
import json
from pathlib import Path
import shutil
import traceback

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.transform import Rotation

from airframe import AirframeCalibration, applicable_drag, exclusive, installed_identity, write_json
from extract import extract
from fly_learned_course import fly_from_map
from gate_links import fit_links, passage_prefix, read_evidence
from learned_line import flight_line, update_flight_line
from privileged_mae import score_streams
from miniflight.replay import Calls
from target.aigp.native import TARGETS, launch, RaceStateReader
from target.aigp.experiments.repeat import fresh_race
from target.aigp.experiments.recording import ProcessClient, RaceReader, archive_trace, recording
from target.aigp.experiments.pitwall_server import serve_session
from refine_gate_map import MESH_FROM_GATE, legacy_opening_offset, packet_map, read_packet_map, unpack_gate_map


def gate_errors(packet, pivots, quaternions, ids, dimensions):
    truth = Rotation.from_quat(quaternions, scalar_first=True)
    opening_offset = legacy_opening_offset()
    origin = pivots[0]+truth[0].apply(opening_offset)
    alignment = (truth[0]*MESH_FROM_GATE).inv()
    expected = alignment*(truth)
    pivot_ref = alignment.apply(pivots-origin)
    opening_ref = pivot_ref+expected.apply(opening_offset)
    estimated_openings = unpack_gate_map(packet)[:, :3]
    errors = []
    for i, gate in enumerate(packet['gates'][:len(ids)]):
        mesh = Rotation.from_quat(gate['orientation'], scalar_first=True)
        pivot = np.asarray(gate['position'])
        opening = estimated_openings[i]
        errors.append(dict(
            gate=i+1, pivot_m=float(np.linalg.norm(pivot-pivot_ref[i])),
            center_m=float(np.linalg.norm(opening-opening_ref[i])),
            attitude_deg=float(np.degrees((expected[i].inv()*mesh).magnitude())),
            id_match=bool(gate['id'] == ids[i]),
            width_m=None if gate['width'] is None else float(abs(gate['width']-dimensions[i, 0])),
            height_m=None if gate['height'] is None else float(abs(gate['height']-dimensions[i, 1]))))
    return errors


def native_outcome(path, trace):
    race_path = path/'flight.native.jsonl'
    if race_path.exists():
        records = [json.loads(line) for line in race_path.read_text().splitlines()]
        outcome = next(row for row in reversed(records) if 'active_gate_index' in row)
        outcome['native_gate_count'] = next((len(row['gate_centers']) for row in records if 'gate_centers' in row), 0)
        return outcome
    # Attached laps use the shared native log. The recorder keeps the exact state seen by this lap.
    source = gzip.open(trace, 'rt') if trace.suffix == '.gz' else trace.open()
    with source:
        outcome = next(row['race'] for row in map(json.loads, source) if row['event'] == 'result' and row.get('race'))
    outcome['native_gate_count'] = len(outcome.get('gate_centers', ()))
    return outcome


def pipeline_metrics(trace, data, truth, pace):
    def stat(samples, percentile):
        finite = np.asarray(samples, dtype=float).ravel()
        finite = finite[np.isfinite(finite)]
        return float(np.percentile(finite, percentile)) if len(finite) else None

    def rate(stamps):
        return float((len(stamps)-1)/np.ptp(stamps)) if len(stamps) > 1 and np.ptp(stamps) > 0. else None

    camera = data['camera'].reshape(-1, 6)
    detection = data.get('detections', np.empty((0, 3)))
    visibility = data['visibility'].reshape(-1, 3)
    first_support = {}
    for stamp, gate, accepted in visibility:
        if accepted:
            first_support.setdefault(int(gate), stamp)
    handoffs = [max(0., first_support[int(gate)+1]-stamp)
                for stamp, gate, *_ in data['crossings'].reshape(-1, 5)
                if int(gate)+1 in first_support]
    planner_calls, feasible = data.get('planner_counts', (0, 0))
    checks = data['crossing_checks'].reshape(-1, 9)
    armed = truth['armed']
    arm, stop = (armed[0], armed[-1]) if len(armed) >= 2 else (np.inf, -np.inf)
    imu = truth['imu'].reshape(-1, 8)
    imu = imu[(imu[:, 1] >= arm) & (imu[:, 1] <= stop)]
    source = gzip.open(trace, 'rt') if trace.suffix == '.gz' else trace.open()
    sends, body, frames = [], [], []
    with source:
        for line in source:
            if '"event": "update"' in line and '"frames": [{' in line:
                frames.extend(frame['received_at'] for frame in json.loads(line)['frames'])
                continue
            if '"event": "sent"' not in line:
                continue
            row = json.loads(line)
            stamp = row['host_time']
            if not arm <= stamp <= stop:
                continue
            sends.append(stamp)
            command = row['command']
            if command['kind'] == 'BodyRates':
                body.append([command['roll_rate'], command['pitch_rate'], command['yaw_rate']])
    rate_error = pitch_slew = gyro_slew = None
    if len(sends) and len(body) == len(sends) and len(imu):
        have = imu[:, 1] >= sends[0]
        indices = np.searchsorted(sends, imu[have, 1], side='right')-1
        if len(indices):
            rate_error = float(np.sqrt(np.mean((np.asarray(body)[indices]-imu[have, 5:8])**2)))
        pitch_slew = stat(np.abs(np.diff(np.asarray(body)[:, 1]))/np.diff(sends).clip(.001), 95)
        gyro_slew = stat(np.abs(np.diff(imu[:, 6]))/np.diff(imu[:, 0]).clip(.001), 95)
    camera_stages = data.get('camera_stages', np.empty((0, 4))).reshape(-1, 4)
    gate_stages = data.get('gate_stages', np.empty((0, 4))).reshape(-1, 4)
    send_ages = data.get('send_ages', np.empty((0, 5))).reshape(-1, 5)
    plan_times = data.get('plan_times', np.empty((0, 2))).reshape(-1, 2)
    frames = np.unique(frames)
    return dict(
        camera_input_hz=rate(frames), camera_input_gap_ms=stat(1000.*np.diff(frames), 95),
        frame_wait_ms=stat(1000.*(camera[:, 5]-camera[:, 1]-camera[:, 4]), 95),
        propagation_ms=stat(1000.*camera_stages[:, 1], 95), orientation_ms=stat(1000.*camera_stages[:, 2], 95),
        detection_ms=stat(1000.*gate_stages[:, 1], 95), correction_ms=stat(1000.*gate_stages[:, 2], 95),
        handoff_compute_ms=stat(1000.*gate_stages[:, 3], 95), plan_compute_ms=stat(1000.*plan_times[:, 1], 95),
        send_imu_age_ms=stat(1000.*send_ages[:, 1], 95), estimate_to_send_ms=stat(1000.*send_ages[:, 2], 95),
        camera_age_at_send_ms=stat(1000.*send_ages[:, 3], 95), gate_age_at_send_ms=stat(1000.*send_ages[:, 4], 95),
        camera_hz=rate(camera[:, 0]), camera_pipeline_ms=stat(1000.*(camera[:, 5]-camera[:, 1]), 95),
        camera_superseded=int(data.get('superseded_frames', 0)),
        imu_hz=rate(imu[:, 0]), imu_gap_ms=stat(1000.*np.diff(imu[:, 1]), 95),
        detections_pct=100.*float(np.mean(np.any(detection[:, 1:] > 0, axis=1))) if len(detection) else None,
        supported_pct=100.*float(np.mean(visibility[:, 2])) if len(visibility) else None,
        handoff_s=stat(handoffs, 90),
        pixel_rms=stat(data.get('pixel_innovations', np.empty((0, 2)))[:, 1], 95),
        confirmed_gates=pace.get('confirmed_gates'),
        leg_error_m=stat([x for x in pace.get('leg_standard_error_m', [])[1:] if x is not None], 50),
        feasible_pct=100.*float(feasible)/planner_calls if planner_calls else None,
        margin_cm=stat(100.*checks[checks[:, 8] > 0, 7], 10),
        sent_hz=rate(sends), send_gap_ms=stat(1000.*np.diff(sends), 95), body_rate_rms=rate_error,
        pitch_slew_rad_s2=pitch_slew, gyro_pitch_slew_rad_s2=gyro_slew)


def score(path, trace, packet):
    result = native_outcome(path, trace)
    result.update(extract(trace, scoring_only=True))
    result['map_gates'] = len(packet['gates'])
    with np.load(path/'truth.npz', allow_pickle=False) as truth, np.load(path/'learned-course.npz', allow_pickle=False) as data:
        known = [truth[key] for key in ('gate_pivots', 'gate_quaternions', 'gate_ids', 'gate_dimensions')]
        result['gates'] = gate_errors(packet, *known) if len(known[2]) else []
        result['native_gate_count'] = result['native_gate_count'] or len(known[2])
        incoming_path = path/'input-map.json'
        if incoming_path.exists() and len(known[2]):
            incoming = gate_errors(json.loads(incoming_path.read_text()), *known)
            common = min(len(incoming), len(result['gates']))
            if common > 1:
                result['same_gate_update'] = dict(gates=[g['gate'] for g in incoming[1:common]])
                for key in ('pivot_m', 'center_m', 'attitude_deg'):
                    result['same_gate_update'][key] = [
                        float(np.mean([g[key] for g in batch[1:common]])) for batch in (incoming, result['gates'])]
        result['approach_offset_m'] = float(data.get('approach_offset', 0.))
        result['input_map_gates'] = int(data.get('prior_gates', 0))
        result['privileged_mae'] = score_streams(truth, data, result['gates'])
        result['pipeline'] = pipeline_metrics(trace, data, truth, packet.get('pace', {}))
    if len(result['gates']) > 1:
        for field in ('pivot_m', 'center_m', 'attitude_deg'):
            result[field] = float(np.mean([gate[field] for gate in result['gates'][1:]]))
    return result


def plot(directory, history):
    fields = ('center_m', 'pivot_m', 'attitude_deg')
    labels = ('Opening-center error (m)', 'Mesh-pivot error (m)', 'Orientation error (°)')
    fig, axes = plt.subplots(3, 1, sharex=True, figsize=(8, 7), layout='constrained')
    attempts = np.arange(1, len(history)+1)
    count = max(row.get('native_gate_count', row.get('map_gates', 0)) for row in history)
    for index, (axis, field, label) in enumerate(zip(axes, fields, labels)):
        for i in range(2, count+1):
            values = [next((g[field] for g in row.get('gates', ()) if g['gate'] == i), np.nan)
                      for row in history]
            axis.plot(attempts, values, '.-', alpha=.65, label=f'G{i}')
        axis.plot(attempts, [row.get(field, np.nan) if row.get('map_gates') == count else np.nan for row in history],
                  'o-', color='black', label=f'Mean, G2–G{count}')
        if index < 2:
            axis.axhline(.10, color='#777777', linestyle=':', linewidth=1)
        axis.set_ylabel(label)
        axis.grid(alpha=.15)
        axis.set_ylim(bottom=0.)
    axes[0].legend(ncols=3, frameon=False)
    axes[-1].set_xticks(attempts, [f'{i}\n{row.get("active_gate_index", "?")}/{count}'
                                for i, row in zip(attempts, history)])
    axes[-1].set_xlabel('Flight attempt and native gates crossed')
    fig.suptitle('VQ1 map refinement from camera + IMU')
    fig.savefig(directory/'map-errors.png', dpi=150)
    plt.close(fig)
    plans = [row.get('measurements', {}).get('pace', {}) for row in history]
    if any(plans):
        fig, (pace_axis, outcome_axis) = plt.subplots(2, 1, sharex=True, figsize=(8, 5.4), layout='constrained')
        for i in range(count):
            velocity = [p['speed_m_s'][i] if i < len(p.get('speed_m_s', ())) else np.nan for p in plans]
            pace_axis.plot(attempts, velocity, '.-', label=f'G{i+1}')
        pace_axis.legend(frameon=False, ncols=min(6, max(1, count)), fontsize=8)
        pace_axis.set_ylabel('Next passage speed (m/s)')
        bars = outcome_axis.bar(attempts, [row.get('active_gate_index', np.nan) for row in history], color='#3f7577')
        for bar, row in zip(bars, history):
            if row.get('completed') and row.get('valid'):
                outcome_axis.text(bar.get_x()+bar.get_width()/2, bar.get_height()+.12,
                                  f"{row['finish_time_seconds']:.1f}s", ha='center', fontsize=8)
        outcome_axis.set(xlabel='Flight attempt', ylabel='Native gates crossed', ylim=(0, count+1))
        outcome_axis.set_xticks(attempts[::max(1, len(attempts)//10)])
        for axis in (pace_axis, outcome_axis):
            axis.grid(axis='y', alpha=.18)
            axis.set_axisbelow(True)
        fig.suptitle('Carried course memory · speed learned after each flight')
        fig.savefig(directory/'learned-pace.png', dpi=150)
        plt.close(fig)


def overlap_counts(evidence):
    frames = {}
    for time, gate, *_ in evidence.views:
        frames.setdefault(time, set()).add(gate)
    return np.array([sum(i in gates and i+1 in gates for gates in frames.values()) for i in range(len(evidence.seed)-1)])


def controller_build(trace):
    source = gzip.open(trace, 'rt') if trace.suffix == '.gz' else trace.open()
    with source:
        metadata = json.loads(source.readline())['metadata']
    recorded = {key: metadata[key] for key in ('sources', 'control_inputs')}
    return sha256(json.dumps(recorded, sort_keys=True).encode()).hexdigest()


def report_flight(path, trace, map_path, state):
    try:
        packet = json.loads(map_path.read_text()) if map_path else {'gates': []}
        row = score(path, trace, packet)
    except (OSError, ValueError, EOFError, KeyError, StopIteration, IndexError, TypeError) as error:
        try:
            row = native_outcome(path, trace)
        except (OSError, ValueError, EOFError, StopIteration):
            row = dict(completed=False)
        row['scoring_error'] = str(error)
    row.update(state)
    if map_path and 'map_gates' not in row:
        row['map_gates'] = len(json.loads(map_path.read_text())['gates'])
    write_json(path/'map-score.json', row)
    return row


def campaign_prior(directory, bank, target):
    path = directory/'airframe-prior.json'
    if path.is_file():
        prior = json.loads(path.read_text())
        if prior['target'] != target:
            raise ValueError(f"{directory} belongs to {prior['target']}, not {target}")
        return prior
    identity = installed_identity(target)
    if any(directory.glob('flight-*/flight.jsonl*')):
        # Preserve the calibration policy actually used by an existing campaign.
        prior = dict(target=identity[0], executable_sha256=identity[1], qualified_launches=0,
                     forward_drag_per_m=None, source='existing campaign')
    else:
        prior = bank.snapshot(*identity)
    write_json(path, prior)
    return prior


def survey(directory, attempts, speed, record_video=False, motor_calibration=None, airframes=None, *,
           until=None, port=None, target="vq1.r1", blank_start=False, clean_target=3, lap_timeout=None, time_streak=1):
    directory.mkdir(parents=True, exist_ok=True)
    bank = AirframeCalibration(airframes if airframes is not None else Path(__file__).with_name('airframes'))
    with exclusive(directory/'.campaign.lock', wait=False), ExitStack() as resources:
        _survey(directory, attempts, speed, record_video, motor_calibration, bank, resources,
                until, port, target, blank_start, clean_target, lap_timeout, time_streak)


def _survey(directory, attempts, speed, record_video, motor_calibration, bank, resources,
            until, port, target, blank_start, clean_target, lap_timeout=None, time_streak=1):
    history, observed, evidence = [], [], []
    if lap_timeout is None:
        lap_timeout = 180. if blank_start else 115.
    last_map = None
    airframe = campaign_prior(directory, bank, target)
    vehicle_model = json.loads(motor_calibration.read_text()) if motor_calibration else None
    runner = Path(__file__).with_name('fly_learned_course.py')
    sources = {name: sha256(runner.with_name(name).read_bytes()).hexdigest() for name in
               ('survey_gate_map.py', 'gate_links.py', 'refine_gate_map.py', 'airframe.py', 'mapped.py',
                'fly_one_gate.py', 'opening.json')}
    native_log, view = directory/'native.jsonl', directory/'view'
    process = reader = None
    simulator = resources.enter_context(ExitStack())
    if port is not None:
        view.mkdir(exist_ok=True)
        shutil.copyfile(runner.with_name('learning-pitwall.html'), view/'index.html')
        shutil.copytree(runner.with_name('fonts'), view/'fonts', dirs_exist_ok=True)
        port = resources.enter_context(serve_session(view, native_log, port))
        print(f'http://127.0.0.1:{port}/', flush=True)

    def publish(stage, lap):
        if port is not None:
            write_json(view/'session.json', dict(stage=stage, lap=lap, target=target, target_s=until, blank_start=blank_start, pid=os.getpid(),
                       simulator_pid=process.pid if process else None,
                       clean_streak=clean_streak() if blank_start else None, clean_target=clean_target if blank_start else None,
                       gate_count=len(reader.gate_centers) if reader else 0, history=[
                           dict(lap=i, gates=r.get('active_gate_index', 0), total=r.get('native_gate_count', 0),
                                mapped=r.get('map_gates', 0), clean=clean_finish(r), finish=r.get('finish_time_seconds') if r.get('completed') and r.get('valid') else None,
                                mae=r.get('privileged_mae', {}), pipeline=r.get('pipeline', {})) for i,r in enumerate(history, 1)]))

    def reset_simulator(path, lap):
        nonlocal process, reader
        if port is not None:
            (view/'frame.jpg').unlink(missing_ok=True)
            (view/'gate-view.json').unlink(missing_ok=True)
        for _ in range(2):
            if reader is None:
                process = simulator.enter_context(launch(target, ('-RenderOffScreen',), race_status_path=native_log))
                reader = simulator.enter_context(closing(RaceStateReader(native_log, 1.)))
            if process.poll() is not None:
                raise RuntimeError('Native simulator exited before race reset')
            publish('Resetting', lap)
            reset_trace = path/'reset.jsonl'
            if reset_trace.exists():
                reset_trace = next(path/f'reset-{i}.jsonl' for i in count(2)
                                   if not (path/f'reset-{i}.jsonl').exists())
            with recording(reset_trace) as record:
                calls = Calls(record)
                client = ProcessClient(calls, camera_port=None, record_camera=False)
                try:
                    _, reset, _ = fresh_race(RaceReader(calls, reader), record, timeout=45,
                                              client=client, clock=calls, require_pose=False)
                except TimeoutError as error:
                    record(event='reset_failed', reason=str(error), simulator_pid=process.pid)
                else:
                    record(event='result', reset=reset, simulator_pid=process.pid)
                    if client.gates:
                        write_json(directory/'scoring-gates.json', [asdict(g) for g in client.gates])
                    return True
        return False

    def full_race(row):
        gates = row.get('native_gate_count', 0)
        return (row.get('completed') and row.get('valid') and gates > 0
                and row.get('active_gate_index') == gates and row.get('finish_time_seconds', -1) > 0)

    def clean_finish(row):
        return (full_race(row) and (target != 'vq2.r2' or row['native_gate_count'] == 17)
                and (not blank_start or row.get('input_map_gates') == 0)
                and row.get('armed_collision_reports') == 0
                and row.get('controller_exit_code') == 0)

    def add_result(row, trace):
        if blank_start and clean_finish(row):
            row['controller_build'] = controller_build(trace)
        history.append(row)

    def clean_streak():
        build = history[-1].get('controller_build') if history else None
        if build is None:
            return 0
        streak = 0
        for attempt in reversed(history):
            if not clean_finish(attempt) or attempt.get('controller_build') != build:
                break
            streak += 1
        return streak

    def qualified(row):
        if blank_start:
            return clean_streak() >= clean_target
        return (until is not None and len(history) >= time_streak
                and all(clean_finish(result) and result['finish_time_seconds'] < until
                        for result in history[-time_streak:]))

    publish('Starting', 1)
    for n in (range(1, attempts+1) if attempts else count(1)):
        if blank_start:
            evidence.clear()
            last_map = None
        path = directory/f'flight-{n:02}'
        path.mkdir(exist_ok=True)
        trace = path/'flight.jsonl'
        zipped = trace.with_suffix('.jsonl.gz')
        map_path = path/'gate-map.json'
        report_path = path/'map-score.json'
        state_path = path/'flight-state.json'
        data = path/'learned-course.npz'
        if state_path.exists() or map_path.exists():
            if state_path.exists():
                state = json.loads(state_path.read_text())
            else:
                # Legacy maps were only committed after successfully incorporating a capture.
                if not data.is_file():
                    raise ValueError(f'{path}: a saved map is missing its source capture')
                state = dict(used_observations=True, map_estimator='legacy')
                write_json(state_path, state)
            if state['used_observations']:
                if not data.is_file() or not map_path.is_file():
                    raise ValueError(f'{path}: missing committed flight evidence or map')
                observed.append(path)
                last_map = map_path
                if vehicle_model is None:
                    vehicle_model = json.loads(map_path.read_text()).get('motor_calibration')
            try:
                report = json.loads(report_path.read_text())
                if not isinstance(report, dict) or 'active_gate_index' not in report:
                    raise ValueError('No native result')
            except (OSError, ValueError):
                report = report_flight(path, trace if trace.exists() else zipped, last_map, state)
            add_result(report, trace if trace.exists() else zipped)
            archive_trace(trace, zipped)
            if qualified(report):
                publish('Qualified', n)
                return
            continue
        if not blank_start and observed and not evidence:
            evidence.extend(read_evidence(previous) for previous in observed)
            bank.record(evidence)
            last_state = json.loads((observed[-1]/'flight-state.json').read_text())
            if last_state.get('mapper_sha256') != sources:
                # Refit the carried map if the estimator has changed since it was saved.
                seed = read_packet_map(last_map) if last_map else None
                course, dimensions, measurements = fit_links(evidence, seed, applicable_drag(airframe, evidence))
                last_map = directory/'carried-gates.json'
                write_json(last_map, dict(**packet_map(course, dimensions, measurements['pivot_below_opening_m']), pace=measurements['pace'],
                                          motor_calibration=vehicle_model))
        exit_code = None
        incoming = path/'input-map.json'
        if not trace.exists() and not zipped.exists():
            if last_map is not None:
                write_json(incoming, json.loads(last_map.read_text()))
            if (until is not None or port is not None or blank_start) and not reset_simulator(path, n):
                state = dict(used_observations=False, controller_exit_code=1, reset_error='native reset timed out twice')
                row = dict(state, active_gate_index=0, completed=False, valid=False)
                write_json(report_path, row)
                write_json(state_path, state)
                history.append(row)
                publish('Reset failed', n)
                continue
            publish('Flying', n)
            with (path/'native.log').open('w') as log, redirect_stdout(log), redirect_stderr(log):
                try:
                    fly_from_map(trace, speed, incoming if incoming.exists() else None,
                                 motor_calibration, target=target, record_video=record_video, finish_before=lap_timeout,
                                 startup_timeout=45. if reader is not None else 120., race_reader=reader,
                                 preview=view/'frame.jpg' if port is not None else None)
                except Exception:
                    traceback.print_exc(file=log)
                    exit_code = 1
                else:
                    exit_code = 0
            publish('Scoring', n)
        used_observations = False
        measurements = {}
        capture_error = None
        if data.exists():
            with np.load(data, allow_pickle=False) as captured:
                usable = len(captured['image_poses']) > 5 and captured['gates'].size > 0
            if usable:
                try:
                    new_evidence = read_evidence(path)
                except ValueError as error:
                    capture_error = str(error)
                else:
                    observed.append(path)
                    evidence.append(new_evidence)
                    bank.record([new_evidence])
                    carried = json.loads(last_map.read_text()) if last_map is not None else {}
                    prior = unpack_gate_map(carried) if carried else None
                    drag = applicable_drag(airframe, evidence)
                    course, dimensions, measurements = fit_links(evidence, prior, drag)
                    if measurements['forward_drag_per_m'] is not None:
                        measurements['drag_source'] = 'airframe' if drag is not None else 'track launches'
                    packet = packet_map(course, dimensions, measurements['pivot_below_opening_m'])
                    packet.update(pace=measurements['pace'], motor_calibration=vehicle_model)
                    with np.load(data, allow_pickle=False) as capture:
                        observed_line = flight_line(capture, partial=True)
                        if new_evidence.witnessed_prefix == len(course):
                            complete = flight_line(capture)
                            if complete is not None and len(complete) == len(course)-1:
                                observed_line = complete
                    line, counts = update_flight_line(carried, observed_line, len(course)-1)
                    if line:
                        packet.update(line_offsets=line, line_observations=counts)
                    previous_speed = carried.get('pace', {}).get('speed_m_s', [])
                    witness_speed = carried.get('witness_speed_m_s', [])
                    if observed_line is not None and len(observed_line) == len(course)-1:
                        if len(previous_speed) == len(course):
                            witness_speed = previous_speed
                    else:
                        # A partial flight can refine the map and bound pace, but
                        # it cannot justify an increase on the unflown corridor.
                        speed_limits = packet['pace']['speed_m_s']
                        for gate, speed_limit in enumerate(previous_speed[:len(speed_limits)]):
                            speed_limits[gate] = min(speed_limits[gate], speed_limit)
                        if len(witness_speed) == len(previous_speed) == len(course):
                            missed = new_evidence.witnessed_prefix
                            for gate in range(max(0, missed-1), min(len(course), missed+1)):
                                if previous_speed[gate] > witness_speed[gate]:
                                    speed_limits[gate] = min(speed_limits[gate], np.sqrt(
                                        .5*(previous_speed[gate]**2+witness_speed[gate]**2)))
                    if len(witness_speed) == len(course):
                        packet['witness_speed_m_s'] = witness_speed
                    write_json(map_path, packet)
                    last_map = map_path
                    used_observations = True
        state = dict(used_observations=used_observations, map_estimator='gate_links', mapper_sha256=sources)
        if exit_code is not None:
            state['controller_exit_code'] = exit_code
        incoming = path/'input-map.json'
        if incoming.exists():
            state['input_map_sha256'] = sha256(incoming.read_bytes()).hexdigest()
        if capture_error:
            state['capture_error'] = capture_error
        if used_observations:
            state['witnessed_gates'] = passage_prefix(new_evidence.passages)
            state['adjacent_views'] = overlap_counts(evidence[-1]).tolist()
            state['measurements'] = measurements
        write_json(state_path, state)
        row = report_flight(path, trace if trace.exists() else zipped, last_map, state)
        add_result(row, trace if trace.exists() else zipped)
        if port is None:
            plot(directory, history)
        archive_trace(trace, zipped)
        print(f'Flight {n}: {row.get("active_gate_index", "?")}/{row.get("native_gate_count", "?")}, '
              f'pivot MAE {row.get("pivot_m", np.nan):.3f} m, '
              f'orientation MAE {row.get("attitude_deg", np.nan):.3f}°', flush=True)
        if qualified(row):
            publish('Qualified', n)
            return
    publish('Complete', len(history))
    if history and port is None:
        plot(directory, history)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('--target', choices=TARGETS, default='vq1.r1')
    parser.add_argument('--blank-start', action='store_true', help='start every attempt with an empty map')
    parser.add_argument('--clean-streak', type=int, default=3, help='consecutive clean blank starts needed on the same controller build')
    parser.add_argument('--attempts', type=int, default=5)
    parser.add_argument('--until', type=float, help='reuse one simulator until a clean lap beats this time')
    parser.add_argument('--time-streak', type=int, default=1, help='consecutive clean laps below --until')
    parser.add_argument('--lap-timeout', type=float, help='maximum native race clock per lap in seconds')
    parser.add_argument('--pitwall', type=int, help='localhost pitwall port')
    parser.add_argument('--speed', type=float, default=12., help='upper bound for the learned leg speeds, in m/s')
    parser.add_argument('--video', action='store_true')
    parser.add_argument('--motor-calibration', type=Path)
    parser.add_argument('--airframes', type=Path, help='store for launch calibrations shared by the same simulator build')
    args = parser.parse_args()
    if args.attempts < 0 or (args.attempts == 0 and args.until is None and args.pitwall is None and not args.blank_start):
        parser.error('zero attempts requires --until, --pitwall, or --blank-start')
    if args.blank_start and args.until is not None:
        parser.error('--blank-start uses consecutive clean full native finishes without a time goal')
    if args.time_streak < 1:
        parser.error('--time-streak must be positive')
    if args.clean_streak < 1:
        parser.error('--clean-streak must be positive')
    if args.until is not None and not (np.isfinite(args.until) and args.until > 0):
        parser.error('--until must be positive and finite')
    if args.lap_timeout is not None and not (np.isfinite(args.lap_timeout) and args.lap_timeout > 0):
        parser.error('--lap-timeout must be positive and finite')
    def stop(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop)
    try:
        survey(args.directory, args.attempts, args.speed, args.video, args.motor_calibration, args.airframes,
               until=args.until, port=args.pitwall, target=args.target, blank_start=args.blank_start,
               clean_target=args.clean_streak, lap_timeout=args.lap_timeout, time_streak=args.time_streak)
    except KeyboardInterrupt:
        print('Session stopped', flush=True)
