"""Compare saved poses with native motion, without fitting a scoring transform."""

import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.transform import Rotation, Slerp


def monotone(rows):
    _, index = np.unique(rows[:, 0], return_index=True)
    return rows[index]


def metrics(error):
    error = np.abs(error)
    return dict(mae=float(error.mean()), p95=float(np.quantile(error, .95)), worst=float(error.max()))


def score(directory, name):
    with np.load(directory/'truth.npz', allow_pickle=False) as data:
        position, attitude = monotone(data['position']), monotone(data['attitude'])
        begin, finish = np.interp(data['armed'], position[:, 1], position[:, 0])
    with np.load(directory/f'{name}-pose.npz', allow_pickle=False) as data:
        pose = monotone(data['pose'])
    region = (pose[:, 0] >= begin) & (pose[:, 0] <= finish)
    pose = pose[region]
    if not len(pose):
        raise ValueError('No flight poses')
    t = pose[:, 0]
    truth_position = np.column_stack([np.interp(t, position[:, 0], axis) for axis in position[:, 2:5].T])
    rotation = Slerp(attitude[:, 0], Rotation.from_euler('xyz', attitude[:, 2:5]))
    truth_rotation = rotation(np.clip(t, attitude[0, 0], attitude[-1, 0]))
    error = pose[:, 1:4]-truth_position
    degrees = np.degrees((truth_rotation.inv()*Rotation.from_quat(pose[:, 4:8])).magnitude())
    gaps = np.diff(np.r_[begin, t, finish])
    report = dict(armed_window_s=[float(begin), float(finish)], scored_poses=len(t),
                  missing_at_start_s=float(t[0]-begin), missing_at_end_s=float(finish-t[-1]),
                  max_pose_gap_s=float(gaps.max()), gaps_over_100ms=int(np.count_nonzero(gaps > .1)),
                  north_m=metrics(error[:, 0]), east_m=metrics(error[:, 1]), down_m=metrics(error[:, 2]),
                  position_3d_m=metrics(np.linalg.norm(error, axis=1)), orientation_deg=metrics(degrees),
                  alignment='Estimator output in map coordinates. No scoring alignment or scale fitting.')
    (directory/f'{name}-score.json').write_text(json.dumps(report, indent=2)+'\n')
    fig, axes = plt.subplots(5, 1, figsize=(10, 9), sharex=True, layout='constrained')
    for axis, values, label in zip(axes, (*error.T, degrees, np.maximum(0., t-pose[:, 11])),
                                    ('North error (m)', 'East error (m)', 'Down error (m)',
                                     'Orientation error (°)', 'Gate range anchor age (s)')):
        axis.plot(t-begin, values, linewidth=.9)
        axis.axhline(0., color='#888888', linewidth=.6)
        axis.grid(alpha=.22)
        axis.set_ylabel(label)
    axes[-1].set(xlabel='Seconds since arming', xlim=(0., finish-begin))
    fig.suptitle(f'{name} · full VQ1 lap · native pose used only for scoring')
    fig.savefig(directory/f'{name}-errors.png', dpi=155)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    score(Path(sys.argv[1]), sys.argv[2])
