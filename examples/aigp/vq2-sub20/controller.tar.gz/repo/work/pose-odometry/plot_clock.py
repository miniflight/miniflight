"""Plot the public camera/gyro timing fit and the separate pose-score comparison."""

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def plot(root, final):
    laps = [(root, 'Lap 1 · 35.11 s'), (root/'validation', 'Lap 2 · 35.08 s'),
            (root/'holdout-26s', 'Lap 3 · 26.22 s'), (root/'rednose-fresh', 'Lap 4 · 26.21 s')]
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 4.2), layout='constrained')
    for directory, label in laps:
        with np.load(directory/'visual-clock.npz', allow_pickle=False) as fit:
            use = (fit['pairs'][:, 3] > .3) & (fit['pairs'][:, 1] > 6.)
            cost = fit['cost'][use]
            curve = np.median(cost-cost.min(axis=1, keepdims=True), axis=0)
            axes[0].plot(fit['offsets']*1000, curve, lw=1.4, label=label)
    axes[0].axvline(0, color='#8a929a', ls=':', lw=1.)
    axes[0].axvline(-8, color='#262c34', ls='--', lw=1., label='−8 ms replay')
    axes[0].set(xlim=(-45, 27), ylim=(0, None), xlabel='Exposure-time correction (ms)',
                ylabel='Median excess pixel residual', title='Camera and gyro fit')
    axes[0].legend(frameon=False, fontsize=8)
    variants = [('rednose-gates-gap-safe', 'Baseline'), ('rednose-gates-gap-safe-ts-8', 'Timing only'), (final, 'Latest')]
    x = np.arange(len(laps))
    for offset, ((name, label), color) in enumerate(zip(variants, ('#aeb5be', '#b76241', '#286685')), -1):
        score = [json.loads((directory/f'{name}-score.json').read_text()) for directory, _ in laps]
        axes[1].bar(x+.24*offset, [row['position_3d_m']['mae']*100 for row in score], .23, color=color, label=label)
        axes[2].bar(x+.24*offset, [row['orientation_deg']['mae'] for row in score], .23, color=color)
    for axis, title, unit, target in zip(axes[1:], ('Position', 'Orientation'), ('cm', '°'), (10., .5)):
        axis.axhline(target, color='#555', linestyle='--', linewidth=.8)
        axis.set(xticks=x, xticklabels=[f'Lap {i}' for i in range(1, 5)], title=title, ylabel=f'Full-lap MAE ({unit})')
    axes[1].legend(frameon=False, fontsize=8)
    for ax in axes:
        ax.spines[['top', 'right']].set_visible(False)
        ax.grid(alpha=.15, axis='y')
        ax.set_axisbelow(True)
    fig.savefig(root/'rednose-timing.png', dpi=170)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('result')
    plot(Path(__file__).parent, parser.parse_args().result)
