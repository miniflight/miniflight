"""Fit a lap in map coordinates to pixel and inertial residuals."""

import json
from pathlib import Path
import sys

import cv2
import numpy as np
from scipy.optimize import least_squares
from scipy.sparse import coo_matrix
from scipy.spatial.transform import Rotation, Slerp

from mapped import CAMERA_FROM_BODY, K, apertures, gate_points, measurements
from rim import edges, probes


def fit(directory, background=False, use_rim=False):
    cv2.setNumThreads(1)
    with np.load(directory/'public.npz', allow_pickle=False) as data:
        imu, ns, receipt, raw, offsets = (data[k] for k in ('imu', 'camera_ns', 'receipt', 'image', 'offsets'))
    seed = 'feature-fit' if use_rim else 'pixel-fit' if background else 'smoothed'
    with np.load(directory/f'{seed}-pose.npz', allow_pickle=False) as data:
        pose = data['pose']
    opening = json.loads(Path(__file__).with_name('opening.json').read_text())
    gates = gate_points(json.loads((directory/'map.json').read_text()), opening)
    geometry = dict(gates)
    rims = list(edges(gates, .15732050896))
    dt = .24
    knots = np.arange(pose[0, 0], pose[-1, 0]+dt, dt)
    count = len(knots)
    guess = np.column_stack([np.interp(knots, pose[:, 0], col) for col in pose[:, 1:4].T])
    angles = Slerp(pose[:, 0], Rotation.from_quat(pose[:, 4:8]))
    rotation = lambda t: angles(np.clip(t, pose[0, 0], pose[-1, 0]))
    camera_seconds = (ns-ns[0])*1e-9
    time = camera_seconds+np.quantile(receipt-camera_seconds, .05)-np.quantile(imu[:, 1]-imu[:, 0], .05)
    visible, measured, stamps, rim_world, rim_pixels, rim_time = [], [], [], [], [], []
    for frame, t in enumerate(time):
        if not knots[0] < t < knots[-1]:
            continue
        image = cv2.imdecode(raw[offsets[frame]:offsets[frame+1]], cv2.IMREAD_COLOR)
        position = [np.interp(t, knots, col) for col in guess.T]
        camera = CAMERA_FROM_BODY @ rotation(t).as_matrix().T
        anchored = set()
        if use_rim:
            for gate, line, pixels in probes(image, rims, position, camera):
                rim_world.append(line)
                rim_pixels.append(pixels)
                rim_time.append(t)
                anchored.add(gate)
        pairs = sorted(measurements(list(apertures(image)), gates, position, camera, 'mapped'), key=lambda row: row[0])
        used = set()
        for _, index, gate, _, _, corners in pairs:
            if index in used or gate in anchored:
                continue
            visible.append(geometry[gate])
            measured.append(corners)
            stamps.append(t)
            used.add(index)
    visible, measured, stamps = map(np.asarray, (visible, measured, stamps))
    index = np.clip(np.searchsorted(knots, stamps)-1, 0, count-2)
    alpha = ((stamps-knots[index])/dt)[:, None]
    camera_rotation = rotation(stamps).as_matrix()
    if use_rim:
        rim_world, rim_pixels, rim_time = map(np.asarray, (rim_world, rim_pixels, rim_time))
        edge_index = np.searchsorted(knots, rim_time)-1
        edge_fraction = ((rim_time-knots[edge_index])/dt)[:, None]
        edge_rotation = rotation(rim_time).as_matrix()
    inertial_rotation = rotation(imu[:, 0]).as_matrix()
    sample_weight = np.maximum(0., 1.-np.abs(knots[1:-1, None]-imu[:, 0])/dt)
    sample_weight /= np.maximum(.001, sample_weight.sum(axis=1, keepdims=True))
    world_force = sample_weight @ np.einsum('nij,nj->ni', inertial_rotation, imu[:, 2:5])
    log_depth = np.empty(0)
    if background:
        with np.load(directory/'features.npz', allow_pickle=False) as features:
            tracks = features['observations']
            depth = 1./features['inverse_depth']
        # Evenly subsample the retained tracks to keep runtime bounded.
        keep = np.unique(np.linspace(0, len(depth)-1, min(800, len(depth)), dtype=int))
        tracks = tracks[np.isin(tracks[:, 0], keep)]
        ids, first, assignment = np.unique(tracks[:, 0], return_index=True, return_inverse=True)
        stamp = tracks[:, 1]
        offsets = np.clip(np.searchsorted(knots, stamp)-1, 0, count-2)
        fraction = ((stamp-knots[offsets])/dt)[:, None]
        imu_orientation = rotation(stamp).as_matrix()
        rays = np.c_[tracks[first, 2:4], np.ones(len(first))] @ np.linalg.inv(K).T
        log_depth = np.log(depth[ids.astype(int)])
        other = np.ones(len(tracks), dtype=bool)
        other[first] = False

    def residual(state):
        nodes = state[:count*6].reshape(count, 6)
        p, angle = nodes[:, :3], nodes[:, 3:]
        p_frame = p[index]*(1.-alpha)+p[index+1]*alpha
        angle_frame = angle[index]*(1.-alpha)+angle[index+1]*alpha
        orientation = Rotation.from_rotvec(angle_frame).as_matrix() @ camera_rotation
        camera = (visible-p_frame[:, None, :]) @ orientation @ CAMERA_FROM_BODY.T
        pixel = camera @ K.T
        error = (pixel[:, :, :2]/np.maximum(.1, pixel[:, :, 2, None])-measured)/1.2
        force = Rotation.from_rotvec(angle[1:-1]).apply(world_force)+[0., 0., 9.81]
        dynamics = (p[2:]-2.*p[1:-1]+p[:-2]-dt*dt*force)/.08
        base = np.r_[error.ravel(), dynamics.ravel(), (np.diff(angle, axis=0)/.012).ravel(), (angle/.04).ravel(), p[0]/.3]
        if use_rim:
            pos = p[edge_index]*(1.-edge_fraction)+p[edge_index+1]*edge_fraction
            adj = angle[edge_index]*(1.-edge_fraction)+angle[edge_index+1]*edge_fraction
            edge_camera = Rotation.from_rotvec(adj).as_matrix() @ edge_rotation
            projected = (rim_world-pos[:, None]) @ edge_camera @ CAMERA_FROM_BODY.T @ K.T
            endpoint = projected[:, :, :2]/np.maximum(.1, projected[:, :, 2, None])
            edge = endpoint[:, 1]-endpoint[:, 0]
            normal = np.stack((-edge[:, 1], edge[:, 0]), axis=1)/np.maximum(.01, np.linalg.norm(edge, axis=1, keepdims=True))
            distance = np.einsum('nij,nj->ni', rim_pixels-endpoint[:, :1], normal)
            base = np.r_[base, (distance/.65).ravel()]
        if not background:
            return base
        position = p[offsets]*(1.-fraction)+p[offsets+1]*fraction
        correction = angle[offsets]*(1.-fraction)+angle[offsets+1]*fraction
        camera_to_world = Rotation.from_rotvec(correction).as_matrix() @ imu_orientation @ CAMERA_FROM_BODY.T
        depths = np.exp(np.clip(state[count*6:], 0., 6.))
        point = position[first]+np.einsum('nij,nj->ni', camera_to_world[first], rays*depths[:, None])
        local = np.einsum('nij,ni->nj', camera_to_world, point[assignment]-position)
        img = local @ K.T
        pixel_error = (img[:, :2]/np.maximum(.1, img[:, 2, None])-tracks[:, 2:4])/1.6
        return np.r_[base, pixel_error[other].ravel()]

    rows, cols = [], []
    row = 0

    def grouped(size, nodes):
        nonlocal row
        for i in range(row, row+size):
            for node in nodes:
                for j in range(node*6, node*6+6):
                    rows.append(i)
                    cols.append(j)
        row += size

    for i in index:
        grouped(8, (i, i+1))
    for i in range(1, count-1):
        grouped(3, (i-1, i, i+1))
    for i in range(count-1):
        grouped(3, (i, i+1))
    for i in range(count):
        grouped(3, (i,))
    grouped(3, (0,))
    if use_rim:
        for i in edge_index:
            grouped(2, (i, i+1))
    if background:
        for obs in np.flatnonzero(other):
            anchor = offsets[first[assignment[obs]]]
            i = offsets[obs]
            grouped(2, set((anchor, anchor+1, i, i+1)))
            rows.extend((row-2, row-1))
            cols.extend((count*6+assignment[obs],)*2)
    pattern = coo_matrix((np.ones(len(rows)), (rows, cols)), shape=(row, count*6+len(log_depth))).tocsr()
    start = np.r_[np.c_[guess, np.zeros_like(guess)].ravel(), log_depth]
    solved = least_squares(residual, start, jac_sparsity=pattern, loss='soft_l1', max_nfev=75, ftol=1e-4)
    states = solved.x[:count*6].reshape(count, 6)
    fitted = np.column_stack([np.interp(pose[:, 0], knots, col) for col in states.T])
    pose[:, 1:4] = fitted[:, :3]
    pose[:, 4:8] = (Rotation.from_rotvec(fitted[:, 3:])*rotation(pose[:, 0])).as_quat()
    pose[:, 8:11] = np.gradient(pose[:, 1:4], pose[:, 0], axis=0)
    name = 'rim-fit' if use_rim else 'feature-fit' if background else 'pixel-fit'
    np.savez_compressed(directory/f'{name}-pose.npz', pose=pose)
    print(f'{len(stamps)} gate outlines, {len(rim_time)} rim edges, {len(log_depth)} short tracks, objective {solved.cost:.1f}, {solved.message}')


if __name__ == '__main__':
    fit(Path(sys.argv[1]), '--background' in sys.argv, '--rim' in sys.argv)
