"""Score a gate-relative flight in the native gate frame."""

import json
from pathlib import Path
import sys

from score import metrics, monotone
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.transform import Rotation, Slerp

from extract import extract


def native_gate_frame(directory):
    rows = [json.loads(line) for line in (directory/'flight.native.jsonl').read_text().splitlines()]
    status = next(row for row in reversed(rows) if 'active_gate_index' in row)
    center = np.array(next(row['gate_centers'][0] for row in rows if 'gate_centers' in row))
    wire = json.loads((Path(__file__).with_name('rednose-fresh')/'map.json').read_text())[0]
    wire_rotation = Rotation.from_quat(wire['orientation'], scalar_first=True).as_matrix()
    basis = wire_rotation @ np.array([[0., -1., 0.], [1., 0., 0.], [0., 0., 1.]])
    return status, center, basis


def score(trace):
    directory = trace.parent
    status, center, basis = native_gate_frame(directory)
    extract(trace, scoring_only=True)
    with np.load(directory/'truth.npz', allow_pickle=False) as truth:
        position, attitude = monotone(truth['position']), monotone(truth['attitude'])
        arm, end = np.interp(truth['armed'], position[:, 1], position[:, 0])
    with np.load(directory/'one-gate-pose.npz', allow_pickle=False) as data:
        pose = monotone(data['pose'])
        predicted = data['crossing'].item()
        approach = data['approach_start'].item()
        offset = data['offset'].item()
    pose = pose[(pose[:, 0] >= arm) & (pose[:, 0] <= end)]
    native = (position[:, 2:5]-center) @ basis
    time = pose[:, 0]
    reference = np.column_stack([np.interp(time, position[:, 0], axis) for axis in native.T])
    error = pose[:, 1:4]-reference
    orientation = Slerp(attitude[:, 0], Rotation.from_euler('xyz', attitude[:, 2:5]))
    actual = Rotation.from_matrix(basis.T)*orientation(np.clip(time, attitude[0, 0], attitude[-1, 0]))
    angle = np.degrees((actual.inv()*Rotation.from_quat(pose[:, 4:8])).magnitude())
    region = native[:, 0] >= 0.
    crossed = np.flatnonzero(~region[:-1] & region[1:] & (position[1:, 0] >= arm) & (position[1:, 0] <= end))
    recorded_offset = None
    if np.isfinite(approach):
        lateral = np.interp([arm, approach], position[:, 0], native[:, 1])
        recorded_offset = float(lateral[1]-lateral[0])
    report = dict(gates=status['active_gate_index'], valid=status['valid'], commanded_offset_m=offset,
                  actual_offset_m=recorded_offset, position_m=metrics(np.linalg.norm(error, axis=1)),
                  orientation_deg=metrics(angle))
    crossing = None
    if len(crossed):
        i = crossed[0]
        crossing = np.interp(0., native[i:i+2, 0], position[i:i+2, 0])
        point = [np.interp(crossing, position[:, 0], axis) for axis in native[:, 1:].T]
        speed = np.interp(crossing, position[:, 0], np.linalg.norm(position[:, 5:8], axis=1))
        report.update(crossing_seconds=float(crossing-arm), centre_clearance_m=float(.74-max(map(abs, point))),
                      speed_m_s=float(speed), estimated_crossing_error_ms=float(1000.*(predicted-crossing)) if np.isfinite(predicted) else None)
        final = (time >= crossing-2.) & (time <= crossing)
        if final.any():
            report['final_2s_position_m'] = metrics(np.linalg.norm(error[final], axis=1))
    report['pass'] = bool(status['valid'] and status['active_gate_index'] == 1 and crossing is not None and np.isfinite(predicted))
    (directory/'one-gate-score.json').write_text(json.dumps(report, indent=2)+'\n')

    fig, axes = plt.subplots(3, 1, sharex=True, figsize=(8.4, 6), layout='constrained')
    for axis, label in zip(error.T, ('Through plane', 'Sideways', 'Vertical')):
        axes[0].plot(time-arm, axis, label=label)
    axes[0].legend(frameon=False, ncols=3)
    axes[0].set_ylabel('Position error (m)')
    axes[1].plot(time-arm, angle)
    axes[1].set_ylabel('Orientation error (°)')
    axes[2].plot(time-arm, pose[:, 1], label='Estimated')
    axes[2].plot(time-arm, reference[:, 0], label='Native score')
    axes[2].legend(frameon=False)
    axes[2].set(xlabel='Seconds since arming', ylabel='Plane distance (m)')
    for ax in axes:
        if np.isfinite(approach):
            ax.axvline(approach-arm, color='#a0a0a0', lw=.8, ls=':')
        if crossing is not None:
            ax.axvline(crossing-arm, color='#474747', lw=.8, ls='--')
        ax.grid(alpha=.17)
    fig.suptitle(f'One VQ1 gate · lateral offset {offset:+.2f} m · 2 m/s target')
    fig.savefig(directory/'one-gate-errors.png', dpi=145)
    print(json.dumps(report), flush=True)


if __name__ == '__main__':
    score(Path(sys.argv[1]))
