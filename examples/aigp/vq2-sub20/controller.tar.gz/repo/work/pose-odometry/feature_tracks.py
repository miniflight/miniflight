"""Triangulate short image tracks from a recorded camera and pose stream."""

from collections import defaultdict
from pathlib import Path
import sys

import cv2
import numpy as np
from scipy.spatial.transform import Rotation, Slerp

from mapped import CAMERA_FROM_BODY, K
from miniflight.vision import triangulate_views


def tracks(directory):
    cv2.setNumThreads(1)
    with np.load(directory/'public.npz', allow_pickle=False) as public:
        imu, ns, receipt, image, offsets = (public[k] for k in ('imu', 'camera_ns', 'receipt', 'image', 'offsets'))
    with np.load(directory/'pixel-fit-pose.npz', allow_pickle=False) as source:
        prior = source['pose']
    seconds = (ns-ns[0])*1e-9
    capture = seconds+np.quantile(receipt-seconds, .05)-np.quantile(imu[:, 1]-imu[:, 0], .05)
    rotation = Slerp(prior[:, 0], Rotation.from_quat(prior[:, 4:8]))
    records = defaultdict(list)
    active = np.empty((0, 1, 2), np.float32)
    identities = []
    last, previous, next_id = -np.inf, None, 0

    for i, stamp in enumerate(capture):
        if not prior[0, 0] <= stamp <= prior[-1, 0]:
            continue
        if stamp-capture[i-1] > .3 or stamp-last > .3:
            active, identities = active[:0], []
        if stamp-last < .065:
            continue
        frame = cv2.imdecode(image[offsets[i]:offsets[i+1]], cv2.IMREAD_GRAYSCALE)
        if len(identities):
            next_px, ok, _ = cv2.calcOpticalFlowPyrLK(previous, frame, active, None, winSize=(21, 21), maxLevel=3)
            returned, reverse, _ = cv2.calcOpticalFlowPyrLK(frame, previous, next_px, None, winSize=(21, 21), maxLevel=3)
            mask = (ok[:, 0] != 0) & (reverse[:, 0] != 0) & (np.linalg.norm(active-returned, axis=2)[:, 0] < .7)
            mask &= np.all((next_px[:, 0] > 8.) & (next_px[:, 0] < [632., 352.]), axis=1)
            identities = [key for key, keep in zip(identities, mask) if keep]
            active = next_px[mask]
        mask = np.full(frame.shape, 255, np.uint8)
        for point in active[:, 0]:
            cv2.circle(mask, tuple(point.astype(int)), 9, 0, -1)
        wanted = 100-len(identities)
        if wanted:
            new = cv2.goodFeaturesToTrack(frame, wanted, .012, 9, mask=mask)
            if new is not None:
                active = np.concatenate((active, new))
                identities.extend(range(next_id, next_id+len(new)))
                next_id += len(new)
        for key, point in zip(identities, active[:, 0]):
            records[key].append((stamp, *point))
        previous, last = frame, stamp

    accepted, inverse_depth = [], []
    for track in records.values():
        for start in range(0, len(track)-5, 15):
            group = np.array(track[start:start+15:3])
            if len(group) < 3 or group[-1, 0]-group[0, 0] < .4:
                continue
            times, pixel = group[:, 0], group[:, 1:]
            position = np.column_stack([np.interp(times, prior[:, 0], col) for col in prior[:, 1:4].T])
            camera = CAMERA_FROM_BODY @ rotation(times).as_matrix().transpose(0, 2, 1)
            point = triangulate_views(pixel, camera, position, K)
            if point is None:
                continue
            local = np.einsum('nij,nj->ni', camera, point-position)
            depth = local[0, 2]
            fit = local @ K.T
            error = np.sqrt(np.mean((fit[:, :2]/fit[:, 2:]-pixel)**2))
            if 2. < depth < 120. and error < 4. and np.linalg.norm(position[-1]-position[0])/depth > .025:
                accepted.append(np.c_[np.full(len(group), len(inverse_depth)), group])
                inverse_depth.append(1./depth)
    if not inverse_depth:
        raise ValueError('No well-tracked features')
    data = np.concatenate(accepted)
    np.savez_compressed(directory/'features.npz', observations=data, inverse_depth=inverse_depth)
    print(f'{len(inverse_depth)} short tracks, {len(data)} corresponding pixels')


if __name__ == '__main__':
    tracks(Path(sys.argv[1]))
