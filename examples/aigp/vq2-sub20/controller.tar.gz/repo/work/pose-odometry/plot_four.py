"""Compare full-lap pose error across all four native recordings."""

import json
from pathlib import Path
import sys

from score import monotone
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.transform import Rotation, Slerp


def series(directory, name):
    with np.load(directory/'truth.npz', allow_pickle=False) as truth:
        position = monotone(truth['position'])
        attitude = monotone(truth['attitude'])
        start, finish = np.interp(truth['armed'], position[:, 1], position[:, 0])
    with np.load(directory/f'{name}-pose.npz', allow_pickle=False) as estimate:
        samples = monotone(estimate['pose'])
    pose = samples[(samples[:, 0] >= start) & (samples[:, 0] <= finish)]
    stamp = pose[:, 0]
    reference = np.column_stack([np.interp(stamp, position[:, 0], value) for value in position[:, 2:5].T])
    interpolate = Slerp(attitude[:, 0], Rotation.from_euler('xyz', attitude[:, 2:5]))
    rotation = interpolate(np.clip(stamp, attitude[0, 0], attitude[-1, 0]))
    distance = np.linalg.norm(pose[:, 1:4]-reference, axis=1)
    angle = np.degrees((rotation.inv()*Rotation.from_quat(pose[:, 4:8])).magnitude())
    return stamp-start, distance, angle


def plot(root, name, filename):
    fig, axes = plt.subplots(4, 2, figsize=(12.3, 8.6), sharex=True, sharey='col', layout='constrained')
    laps = [(root, 'Lap 1 · 35.11 s'), (root/'validation', 'Lap 2 · 35.08 s'),
            (root/'holdout-26s', 'Lap 3 · 26.22 s'), (root/'rednose-fresh', 'Lap 4 · 26.21 s')]
    for row, (directory, label) in zip(axes, laps):
        t, position, attitude = series(directory, name)
        gaps = np.flatnonzero(np.diff(t) > .1)
        report = json.loads((directory/f'{name}-score.json').read_text())
        for ax, error, key, color, scale, unit in zip(
                row, (position, attitude), ('position_3d_m', 'orientation_deg'),
                ('#245889', '#a34b29'), (100., 1.), (' cm', '°')):
            mae = error.mean()
            assert np.isclose(mae, report[key]['mae'])
            for i in gaps:
                ax.axvspan(t[i], t[i+1], color='#7d8894', alpha=.28)
            for x, y in zip(np.split(t, gaps+1), np.split(error, gaps+1)):
                ax.plot(x, y, color=color, lw=.9)
            ax.set_title(f'{label}    ·    {mae*scale:.2f}{unit} MAE', loc='left', color=color, fontsize=10, fontweight='bold')
            ax.spines[['top', 'right']].set_visible(False)
            ax.grid(alpha=.18)
        row[0].set_ylabel('Position error (m)')
        row[1].set_ylabel('Orientation error (°)')
    for ax in axes[-1]:
        ax.set(xlabel='Seconds since arming', xlim=(0, 35.2))
        ax.set_ylim(bottom=0)
    fig.suptitle('VQ1 pose across four laps · Rednose in sensor arrival order\n'
                 'Shaded bands mark IMU pose output gaps over 100 ms', fontsize=14, fontweight='bold')
    fig.savefig(root/filename, dpi=165)


if __name__ == '__main__':
    name = sys.argv[1] if len(sys.argv) > 1 else 'rednose-gates-gap-safe'
    filename = 'rednose-four-laps.png' if len(sys.argv) == 1 else f'{name}-four-laps.png'
    plot(Path(__file__).parent, name, filename)
