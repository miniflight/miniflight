"""Update the carried pose corridor from onboard lap evidence."""

from hashlib import sha256
import json
from time import monotonic

import cma
import numpy as np
from scipy.interpolate import BSpline, CubicSpline, PchipInterpolator
from scipy.signal import lfilter
from scipy.spatial.transform import Rotation

from fly_one_gate import APERTURE, K
from learned_line import RacingLine
from mapped import CAMERA_FROM_BODY


def basis(spline):
    return BSpline(spline.t, np.eye(len(spline.c)), spline.k)


def coefficient_sites(spline):
    return np.array([spline.t[i+1:i+spline.k+1].mean() for i in range(len(spline.c))])


class CorridorEvolution:
    def __init__(self, plan_path, line_path, root, *, local_turn=None, state_path=None):
        self.root = root
        with np.load(plan_path, allow_pickle=False) as z:
            self.plan = dict(z)
        self.plan_hash = sha256(plan_path.read_bytes()).hexdigest()
        self.path = state_path or root/'corridor-evolution'/self.plan_hash/'latest.npz'
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.line = RacingLine.prepared(self.plan)
        self.config = json.loads(str(self.plan['config']))
        with np.load(line_path, allow_pickle=False) as z:
            self.rotation = Rotation.from_quat(z['gate_rotations'])
        self.gates = self.line.gates
        self.progress = np.unique(np.r_[np.linspace(0., self.gates[-1], 321), self.gates])
        self.gate_rows = np.searchsorted(self.progress, self.gates)
        self.active = np.searchsorted(self.gates, self.progress, side='right').clip(1, len(self.gates)-1)
        self.position = self.line.curve(self.progress)
        to_opening = self.line.centers[self.active]-self.position
        distance = np.linalg.norm(to_opening, axis=-1)
        self.in_view_range = (distance > 2.) & (distance < 13.)
        self.heading = (self.line.pose_heading(self.progress) if self.line.pose_heading is not None
                        else np.unwrap(np.arctan2(to_opening[:,1], to_opening[:,0])))
        p, q = basis(self.line.curve), basis(self.line.speed_squared)
        path_sites = coefficient_sites(p)
        self.speed_sites = coefficient_sites(q)
        modes = CubicSpline(np.linspace(0., self.gates[-1], 12), np.eye(12))
        self.shift, self.pace, self.look = (modes(s) for s in (path_sites, self.speed_sites, self.progress))
        tangent = self.line.curve(path_sites, 1)
        self.side = np.c_[-tangent[:,1], tangent[:,0], np.zeros(len(tangent))]
        self.side /= np.linalg.norm(self.side, axis=1, keepdims=True).clip(.01)
        self.p, self.q = [p(self.progress, d) for d in (0,1,2)], [q(self.progress, d) for d in (0,1)]
        self.dense = np.linspace(0., self.gates[-1], 8193)
        self.local_turn = local_turn
        self.limits = np.repeat((.09,.09,.14,.20), 12)
        if local_turn is not None:
            left, apex, right = self.gates[list(local_turn)]
            span = self.line.curve.t
            support = (span[:len(p.c)] >= left) & (span[p.k+1:] <= right)
            u = (path_sites-apex)/min(apex-left,right-apex)
            swing = np.where(support & (abs(u)<1.), u*(1.-u*u)**3, 0.)
            if not np.any(swing):
                raise ValueError('No spline support for the linked turn')
            self.local_swing = swing/np.max(abs(swing))
            t = (self.progress-left)/(right-left)
            self.local_yaw = np.where((0.<t)&(t<1.),64.*(t*(1.-t))**3,0.)
            self.limits = np.r_[self.limits,.09,.09,.09,.20]
        self.free = np.ones(len(self.limits), bool)
        self.free[[0,11,12,23,24,35]] = False
        self.x = np.zeros_like(self.limits)
        self.seen = np.zeros(len(self.gates), int)
        self.supported = self.seen.copy()
        self.last_lap = 0
        if self.path.is_file():
            with np.load(self.path, allow_pickle=False) as saved:
                x = saved['evolution_x']
                if x.shape != self.x.shape:
                    raise ValueError('Saved evolution uses a different set of modes')
                self.x, self.seen, self.supported = x, saved['seen'], saved['supported']
                self.last_lap = int(saved['last_lap'])

    def evidence(self, folder):
        with np.load(folder/'learned-course.npz', allow_pickle=False) as z:
            commands, poses, gates, visibility, crossings = (
                z[k] for k in ('approach_commands','pose','gates','visibility','crossing_checks'))
        visibility = visibility.reshape(-1,3)
        supported = np.zeros(len(self.gates), int)
        seen = supported.copy()
        for gate in range(len(self.gates)):
            rows = visibility[visibility[:,1] == gate]
            if len(rows) < 8:
                continue
            seen[gate] = 1
            visible = rows[rows[:,2] > 0,0]
            accepted = crossings[(crossings[:,1] == gate) & (crossings[:,-1] > 0)]
            gap = np.diff(np.r_[rows[0,0],visible,rows[-1,0]]).max()
            supported[gate] = len(accepted) > 0 and accepted[-1,7] > .17 and len(visible) >= 4 and gap < .65
        if not (commands.size and poses.size and gates.size):
            return seen, supported, None
        manifest = json.loads((folder/'manifest.json').read_text())
        with np.load(manifest['inputs']['plan']['path'], allow_pickle=False) as z:
            flown = RacingLine.prepared(z)
        rows = []
        for stamp, index, *_ in commands:
            i = int(index)
            if not 0 < i < len(self.gates):
                continue
            a = gates[(gates[:,1] == i-1) & (gates[:,0] <= stamp)]
            b = gates[(gates[:,1] == i) & (gates[:,0] <= stamp)]
            if not len(a) or not len(b):
                continue
            state = poses[max(0,np.searchsorted(poses[:,0],stamp,side='right')-1)]
            if not 0. <= stamp-state[0] <= .06:
                continue
            p, v = state[1:4], state[8:11]
            point, speed, _, phase = flown.reference(i,a[-1,2:5],b[-1,2:5],p,(.12,.04),with_progress=True)
            rows.append(np.r_[phase,point-p,speed-v,max(0.,stamp-state[11]),stamp])
        if len(rows) < 4:
            return seen, supported, None
        rows = np.asarray(rows)
        phase, indices = np.unique(np.maximum.accumulate(rows[:,0]),return_index=True)
        if len(phase) < 2:
            return seen, supported, None
        before = np.searchsorted(phase,self.progress).clip(1,len(phase)-1)-1
        coverage = ((self.progress >= phase[0]) & (self.progress <= phase[-1])
                    & (np.diff(rows[indices,-1])[before] <= .25))
        error = np.column_stack([np.interp(self.progress,phase,values[indices]) for values in rows[:,1:-1].T])
        return seen, supported, (error, coverage)

    def update(self, lap, gain, course=None):
        started = monotonic()
        evidence = []
        for trace in sorted(self.root.glob('practice-*/learned-course.npz'),
                            key=lambda f:int(f.parent.name.removeprefix('practice-')),reverse=True):
            number = int(trace.parent.name.removeprefix('practice-'))
            if number > lap:
                continue
            if len(evidence) >= 5 and number < lap:
                break
            seen, supported, sample = self.evidence(trace.parent)
            if number > self.last_lap:
                self.seen += seen
                self.supported += supported
            if sample is not None:
                evidence.append(sample)
        if not evidence:
            raise ValueError('No trackable onboard pose and gate evidence')
        errors, coverage = map(np.stack, zip(*evidence, strict=True))
        usable = coverage & self.in_view_range
        if not np.any(usable):
            raise ValueError('No gate in the projection test range')
        confidence = (self.supported+1.)/(self.seen+2.)
        fraction = .86+.14*np.clip((confidence-.3)/.5,0.,1.)
        support_ceiling = PchipInterpolator(self.gates, self.config['max_speed']*fraction)

        def ceiling(progress):
            limit = support_ceiling(progress)
            if 'pace_limit_progress' in self.plan:
                limit = np.minimum(limit, np.interp(progress, self.plan['pace_limit_progress'],
                                                    self.plan['pace_limit_m_s']))
            return limit

        q0 = self.line.speed_squared.c.copy()
        self.requested_law = np.minimum(q0, (ceiling(self.speed_sites) /
            np.linalg.norm(self.line.curve(self.speed_sites,1),axis=1).clip(.1))**2)
        ep, ev, stale = np.split(errors, (3,6), axis=-1)
        # Recompute feedback and attitude for every proposed path on the measured tracking errors.
        feedback = self.config['velocity_gain']*(ev+self.config['position_gain']*(ep+.12*ev))
        weights = (1.+stale[...,0][usable].clip(0.,3.2))*(2.-confidence[self.active][np.nonzero(usable)[1]])
        centers = self.line.centers if course is None else course[:,:3]
        rotation = self.rotation if course is None else Rotation.from_quat(course[:,3:])
        corners = np.einsum('ij,akj->aik', APERTURE, rotation.as_matrix())+centers[:,None]
        # Match the runner's per-leg warp from the spline frame to the current gate map.
        shifts = centers-self.line.centers
        begin, end = self.active-1,self.active
        span = self.gates[end]-self.gates[begin]
        u = ((self.progress-self.gates[begin])/span)[:,None]
        delta = shifts[end]-shifts[begin]
        warp = shifts[begin]+u**3*(10.+u*(-15.+6.*u))*delta
        warp_t = 30.*(u*(1.-u))**2/span[:,None]*delta
        warp_k = 60.*u*(1.-u)*(1.-2.*u)/span[:,None]**2*delta
        best = self.x.copy()

        def objective(x):
            lateral, vertical, pace, look = x[:48].reshape(4,-1)
            path = self.line.curve.c + (self.shift@lateral)[:,None]*self.side
            path[:,2] += self.shift@vertical
            yaw = self.heading+self.look@look
            if self.local_turn is not None:
                path += self.local_swing[:,None]*x[48:51]
                yaw += self.local_yaw*x[51]
            law = self.requested_law*(1.+self.pace@pace)
            p,t,k = (m@path+w for m,w in zip(self.p,(warp,warp_t,warp_k),strict=True))
            q,dq = (m@law for m in self.q)
            speed = np.sqrt(q.clip(.01))
            v = t*speed[:,None]
            accel = k*q[:,None]+.5*t*dq[:,None]+.0435*v*np.linalg.norm(v[:,:2],axis=1)[:,None]
            time = np.r_[0.,np.cumsum(2.*np.diff(self.progress)/(speed[1:]+speed[:-1]))]
            desired = accel+feedback
            limit = self.config['max_acceleration']
            up = 9.81-np.clip(desired[...,2],-limit,limit)
            horizontal = self.config['max_horizontal_acceleration'] or limit
            cap = np.minimum(horizontal,up*np.tan(self.config['max_tilt']))
            desired[...,:2] *= np.minimum(1.,cap/np.linalg.norm(desired[...,:2],axis=-1).clip(.01))[...,None]
            sy,cy = np.sin(yaw),np.cos(yaw)
            front = cy*desired[...,0]+sy*desired[...,1]
            right = -sy*desired[...,0]+cy*desired[...,1]
            angles = np.stack((np.arctan2(right,np.hypot(up,front)),np.arctan2(-front,up),
                               np.broadcast_to(yaw,up.shape)),axis=-1)
            step = np.minimum(1., self.config['attitude_gain']*gain*np.diff(time).mean())
            clock = np.linspace(0.,time[-1],len(time))
            wanted = np.asarray([[np.interp(clock,time,u) for u in a.T] for a in angles])
            actual = np.empty_like(wanted)
            for i,k in enumerate(step):
                actual[:,i],_ = lfilter([k],[1.,k-1.],wanted[:,i],axis=-1,zi=(1.-k)*wanted[:,i,:1])
            actual_axes = np.asarray([[np.interp(time,clock,u) for u in a]
                                      for a in actual]).transpose(0,2,1)
            roll, pitch, _ = actual_axes.transpose(2,0,1)
            dr, dp, dy = (self.config['attitude_gain']*(angles-actual_axes)).transpose(2,0,1)
            sr, cr, sp, cp = np.sin(roll), np.cos(roll), np.sin(pitch), np.cos(pitch)
            rates = np.sqrt((dr-sp*dy)**2+(cr*dp+sr*cp*dy)**2+(-sr*dp+cr*cp*dy)**2)
            matrices = Rotation.from_euler('xyz',actual_axes.reshape(-1,3)).as_matrix().reshape(*ep.shape[:-1],3,3)
            rays = (corners[self.active]-p[None,:,None]+ep[:,:,None])@matrices@CAMERA_FROM_BODY.T
            pixel = np.diag(K)[:2]*rays[...,:2]/rays[...,2:].clip(.01)+K[:2,2]
            margin = np.where(rays[...,2]>.25,np.minimum(pixel-8.,2.*K[:2,2]-8.-pixel).min(axis=-1),-360.)
            edge = np.minimum(margin,np.roll(margin,-1,axis=-1)).max(axis=-1)[usable]
            miss = np.clip(-edge/65.,0.,1.)
            gate = rotation.inv().apply(p[self.gate_rows]-centers)
            excess = np.r_[2.*(np.linalg.norm(v,axis=1)-ceiling(self.progress)).clip(0.),
                            4.*(np.linalg.norm(p-self.position-warp,axis=1)-.12).clip(0.),
                            5.*(abs(gate[:,1:]).ravel()-.28).clip(0.),
                            10.*(abs(gate[:,0])-.02).clip(0.)]
            rate = rates[coverage]
            effort = np.mean(rate**2)
            saturation = np.mean((rate-self.config['max_rate']).clip(0.)**2)
            value = float(time[-1]+25.*(excess@excess)+6.*effort+8.*saturation+12.*np.mean(weights*miss**2))
            return value, (path,law,yaw,float(time[-1]),float(100.*np.mean(edge>=0.)),
                           float(np.quantile(rate,.95)))

        cost, details = objective(best)
        initial = cost
        optimizer = cma.CMAEvolutionStrategy(best[self.free]/self.limits[self.free],.12,
            {'bounds':[-1.,1.],'seed':int(lap),'popsize':12,'verbose':-9,'verb_log':0})
        for _ in range(16):
            points = optimizer.ask()
            scores = []
            for point in points:
                x = np.zeros_like(self.x)
                x[self.free] = point*self.limits[self.free]
                value, trial = objective(x)
                scores.append(value)
                if value < cost:
                    cost, best, details = value, x, trial
            optimizer.tell(points,scores)
        path,law,yaw,seconds,visible,rate = details
        p = BSpline(self.line.curve.t,path,self.line.curve.k)
        q = BSpline(self.line.speed_squared.t,law,self.line.speed_squared.k)
        gate = np.searchsorted(self.gates,self.dense,side='right').clip(1,len(self.gates)-1)
        span = self.gates[gate]-self.gates[gate-1]
        u = (self.dense-self.gates[gate-1])/span
        shift_t = (30.*(u*(1.-u))**2/span)[:,None]*(shifts[gate]-shifts[gate-1])
        speed = np.linalg.norm(p(self.dense,1)+shift_t,axis=1)*np.sqrt(q(self.dense))
        adjust = min(1.,np.min(ceiling(self.dense)/speed))*.99999
        shift = float(np.linalg.norm(p(self.dense)-self.line.curve(self.dense),axis=1).max())
        if not np.isfinite(speed).all() or shift > .16 or np.any(q(self.dense)<=0.):
            raise ValueError('CMA candidate falls outside the checked corridor')
        plan = dict(self.plan,path_coefficients=path,speed_coefficients=law*adjust**2,
            seconds=seconds/adjust,pose_progress=self.progress,pose_heading=yaw,evolution_x=best,
            seen=self.seen,supported=self.supported,last_lap=lap,
            source_plan_sha256=self.plan_hash,binding='onboard evidence with CMA-ES',
            evolution_coefficients=int(self.free.sum()))
        with self.path.with_suffix('.tmp').open('wb') as stream:
            np.savez_compressed(stream,**plan)
        self.path.with_suffix('.tmp').replace(self.path)
        self.x, self.last_lap = best, lap
        return dict(lap=lap,evaluations=192,coefficients=int(self.free.sum()),score_before=initial,score_after=cost,
                    predicted_visible_pct=visible,predicted_rate_p95_rad_s=rate,dense_max_m_s=float(speed.max()*adjust),
                    predicted_line_seconds=seconds/adjust,maximum_path_shift_m=shift,
                    gate_support=confidence.tolist(),gate_speed_ceiling_m_s=ceiling(self.gates).tolist(),
                    local_coefficients=best[48:].tolist(),wall_seconds=monotonic()-started)
