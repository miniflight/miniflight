"""Compare as-flown VQ1 pose errors and correction age at the same speed."""

from pathlib import Path
import json

from plot_four import series
from score import monotone
import matplotlib.pyplot as plt
import numpy as np


def plot(root):
    cases = [('lap-02', 'Baseline', '#727a87'), ('lap-04-precision', 'Precision', '#2c618f'),
             ('lap-05-precision-light', 'Precision, light capture', '#a85538'),
             ('lap-06-tracked-range', 'Tracked range', '#21795f')]
    fig, axes = plt.subplots(3, 1, sharex=True, figsize=(10, 7.7), layout='constrained')
    for folder, label, color in cases:
        directory = root/folder
        report = directory/'live-rednose-score.json'
        if not report.is_file():
            continue
        meta = json.loads(report.read_text())
        time, position, angle = series(directory, 'live-rednose')
        with np.load(directory/'live-rednose-pose.npz', allow_pickle=False) as data:
            pose = monotone(data['pose'])
        begin, end = meta['armed_window_s']
        pose = pose[(pose[:, 0] >= begin) & (pose[:, 0] <= end)]
        age = (pose[:, 0]-pose[:, 13])*1000
        gaps = np.flatnonzero(np.diff(time) > .1)+1
        legend = (f'{label} · {position.mean()*100:.2f} cm MAE',
                  f'{label} · {angle.mean():.3f}° MAE', label)
        for ax, error, caption in zip(axes, (position*100, angle, age), legend):
            for i, (t, y) in enumerate(zip(np.split(time, gaps), np.split(error, gaps))):
                ax.plot(t, y, color=color, lw=.9, alpha=.83, label=caption if i == 0 else None)
    for ax, label in zip(axes, ('3D position error (cm)', 'Orientation error (°)', 'Visual correction age (ms)')):
        ax.set_ylabel(label)
        ax.spines[['top', 'right']].set_visible(False)
        ax.grid(alpha=.18)
        ax.legend(loc='upper right', frameon=False, fontsize=8)
        ax.set_ylim(bottom=0)
    axes[-1].set(xlabel='Seconds since arming')
    fig.suptitle('Closed-loop VQ1 pose error · same six-gate reference', fontweight='bold')
    fig.savefig(root/'live-precision-comparison.png', dpi=165)


if __name__ == '__main__':
    plot(Path(__file__).with_name('closed-loop'))
