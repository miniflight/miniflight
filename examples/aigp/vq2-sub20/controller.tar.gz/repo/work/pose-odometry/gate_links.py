"""Each leg measures (distance flown) + (next gate offset) - (previous gate offset).

The camera supplies gate offsets. The forward accelerometer supplies an independent
speed measurement. Repeated legs constrain the same static gate records.
"""

from collections import defaultdict
from dataclasses import dataclass
from itertools import combinations

import numpy as np
from scipy.integrate import cumulative_trapezoid
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation, Slerp

from fly_one_gate import APERTURE
from mapped import CAMERA_FROM_BODY, K, opening_range_sigma, translation
from refine_gate_map import gate_observations, interpolate, read_accelerometer
from rim import APERTURE_HALF_WIDTH, CHASSIS_RADIUS, crossing_clearance


@dataclass
class FlightEvidence:
    seed: np.ndarray
    views: list
    odometry: np.ndarray
    transverse: np.ndarray
    forward: np.ndarray
    launch_drag: float | None
    passages: dict
    lost_gates: set
    launch_id: str | None = None
    target: str | None = None
    executable_sha256: str | None = None
    witnessed_prefix: int = 0


def passage_evidence(views, seed, time, distance):
    """Check passage in the frame of a close observed gate, using onboard motion only."""
    checks = defaultdict(list)
    for stamp, gate, camera, corners, _, active, width in views:
        if active != gate or width < 32.:
            continue
        plane = Rotation.from_quat(seed[gate, 3:])
        relative = -translation(plane.apply(APERTURE), corners, camera)
        if not 2. < np.linalg.norm(relative) < 12.:
            continue
        window = slice(np.searchsorted(time, stamp), np.searchsorted(time, stamp+3.))
        position = interpolate(time, distance, [stamp])[0]
        local = plane.inv().apply(distance[window]-position-relative)
        crosses = np.flatnonzero((local[:-1, 0] < 0.) & (local[1:, 0] >= 0.))
        if not len(crosses):
            continue
        j = crosses[0]
        left, right = local[j:j+2]
        dt = time[window][j+1]-time[window][j]
        if not 0. < dt < .10:
            continue
        _, clearance = crossing_clearance(left, right)
        checks[gate].append((stamp, np.linalg.norm(right-left)/dt, clearance))
    result = {}
    for gate, rows in checks.items():
        if len(rows) >= 3:
            stamps, speeds, clearances = np.asarray(rows).T
            # A burst of near-duplicate frames gives little independent viewing time.
            visible_time = float(np.minimum(np.diff(stamps), .15).sum())
            result[gate] = (float(np.median(speeds)), float(np.quantile(clearances, .25)), visible_time)
    return result


def motion_integrals(path, poses, capture=None):
    """Separate the distance observed by drag from the rest of the onboard odometry."""
    capture = read_accelerometer(path) if capture is None else capture
    time, force, arm = capture.time, capture.force, capture.arm
    valid = (time >= poses[0, 0]) & (time <= poses[-1, 0])
    time, force = time[valid], force[valid]
    attitude = Slerp(poses[:, 0], Rotation.from_quat(poses[:, 4:8]))(time)
    gravity = np.array([0., 0., 9.81])
    stationary = (time > arm-.8) & (time < arm-.15)
    bias = np.median((force+attitude.inv().apply(gravity))[stationary], axis=0) if stationary.any() else np.zeros(3)
    force = force-bias

    # Starting from rest provides a short metric velocity reference independent of gate range.
    velocity = cumulative_trapezoid(attitude.apply(force)+gravity, time, axis=0, initial=0.)
    velocity -= interpolate(time, velocity, [arm])[0]
    forward = attitude.inv().apply(velocity)[:, 0]
    launch = (time >= arm) & (time < arm+3.)
    excited = launch & (time > arm+.2) & (forward > 2.5) & (force[:, 0] < -.05)
    coefficient = None
    if stationary.sum() >= 3 and excited.sum() >= 8 and np.diff(time[launch]).max() < .15:
        samples = -force[excited, 0]/forward[excited]**2
        lower, middle, upper = np.quantile(samples, [.25, .50, .75])
        # A single drag coefficient should explain the change in speed across the launch.
        if upper-lower < .10*middle:
            coefficient = float(middle)
    velocity = interpolate(poses[:, 0], poses[:, 8:11], time)
    axis = attitude.as_matrix()[:, :, 0]
    horizontal = axis[:, :2]
    gain = horizontal/np.maximum(.1, np.sum(horizontal**2, axis=1, keepdims=True))
    axial_velocity = np.sum(axis*velocity, axis=1, keepdims=True)
    transverse = velocity.copy()
    transverse[:, :2] -= gain*axial_velocity
    # f = -k v |v|. The factor 1/sqrt(k) is shared by every flight and can be applied later.
    axial_speed = -np.sign(force[:, :1])*np.sqrt(np.abs(force[:, :1]))
    # Ignore a drag estimate that points opposite to a clear odometry direction.
    conflicts = (np.abs(axial_velocity) >= 1.) & (axial_velocity*axial_speed < 0.)
    axial_speed[conflicts] = 0.
    forward = np.zeros_like(velocity)
    forward[:, :2] = gain*axial_speed
    def integrate(signal):
        signal[time < arm] = 0.
        return cumulative_trapezoid(signal, time, axis=0, initial=0.)

    return time, integrate(velocity), integrate(transverse), integrate(forward), coefficient


def read_evidence(path):
    """Retain only pixel measurements and displacement integrals at their capture times."""
    K[:2, 2] = 319.5, 179.5
    seed, poses, _, observed = gate_observations(path)
    capture = read_accelerometer(path)
    time, odometry, transverse, forward, coefficient = motion_integrals(path, poses, capture)
    views = [(t, g, CAMERA_FROM_BODY @ body.T, pixels, outer, active,
              float(np.median(np.linalg.norm(pixels-np.roll(pixels, 1, axis=0), axis=1))))
             for t, g, body, pixels, outer, active in observed]
    times = [view[0] for view in views]
    passages = passage_evidence(views, seed, time, odometry)
    lost = {gate for gate, (_, clearance, _) in passages.items() if clearance <= 0.}
    with np.load(path/'learned-course.npz', allow_pickle=False) as data:
        visibility, crossings = data['visibility'], data['crossings']
        checks = data['crossing_checks'].reshape(-1, 9)
    passed = set(crossings[:, 1].astype(int)) if crossings.size else set()
    clear = set(checks[(checks[:, -1] > 0.) & (checks[:, 7] > 0.), 1].astype(int))
    witnessed = 0
    while witnessed in passed and witnessed in clear:
        witnessed += 1
    # The terminal frame can precede the controller's final handoff. Require an
    # independent optical intercept there, after all prior openings were cleared.
    if witnessed == len(seed)-1 and (witnessed in clear or witnessed in passages and passages[witnessed][1] > 0.):
        witnessed += 1
    for gate in range(witnessed):
        if gate in passages:
            continue
        verified = checks[(checks[:, 1] == gate) & (checks[:, -1] > 0.) & (checks[:, 7] > 0.)]
        if not len(verified):
            continue
        stamp = verified[-1, 0]
        visible = visibility[(visibility[:, 1] == gate) & (visibility[:, 2] > 0.) & (visibility[:, 0] <= stamp), 0]
        if len(visible) < 3:
            continue
        speed = np.linalg.norm(interpolate(poses[:, 0], poses[:, 8:11], [stamp])[0])
        viewing_time = float(np.minimum(np.diff(visible), .15).sum())
        passages[gate] = (float(speed), float(verified[-1, 7]), viewing_time)
    for gate in np.unique(visibility[:, 1]).astype(int):
        rows = visibility[visibility[:, 1] == gate]
        tail = rows[rows[:, 0] >= rows[-1, 0]-1.]
        # A run of fresh frames with no lock is evidence about the handoff.
        if (gate not in passed and gate not in passages and rows[-1, 0]-rows[0, 0] > 2.
                and len(tail) >= 5 and tail[-1, 0]-tail[0, 0] > .65 and not tail[:, 2].any()):
            lost.add(gate)
    return FlightEvidence(seed, views, interpolate(time, odometry, times), interpolate(time, transverse, times),
                          interpolate(time, forward, times), coefficient, passages, lost,
                          capture.launch_id, capture.target, capture.executable_sha256, witnessed)


def passage_prefix(passages):
    gate = 0
    while gate in passages and passages[gate][1] > 0.:
        gate += 1
    return gate


def learned_pace(flights, gate_count, terms, discovery_speed=3.2):
    """Earn a speed increase where the observed approach leaves aperture clearance."""
    speed = np.full(gate_count, discovery_speed)
    proven = speed.copy()
    failed_above = np.full(gate_count, np.inf)
    passes = np.zeros(gate_count, dtype=int)
    measured_passes = [[] for _ in range(gate_count)]
    lengths = defaultdict(list)
    for first, second, plane, displacement, _ in terms:
        if np.array_equal(plane, np.eye(3)):
            lengths[first, second].append(displacement)
    for gate in range(1, gate_count):
        pair = (gate-1, gate)
        if pair in lengths:
            continue
        witnessed = [flight.seed[gate, :3]-flight.seed[gate-1, :3] for flight in flights
                     if gate < flight.witnessed_prefix and gate < len(flight.seed)]
        if len(witnessed) >= 2:
            lengths[pair] = witnessed
    connected = {0}
    for _ in range(gate_count):
        previous = len(connected)
        for first, second in lengths:
            if first in connected or second in connected:
                connected.update((first, second))
        if len(connected) == previous:
            break
    # Geometry can locate an opening without establishing its order in the race.
    passage_launches = [set() for _ in range(gate_count)]
    for flight in flights:
        if flight.launch_id is None:
            continue
        for launches in passage_launches[:max(passage_prefix(flight.passages), flight.witnessed_prefix)]:
            launches.add(flight.launch_id)
    # Gate zero already defines the frame. Each later locked gate needs a metric
    # connection and two independent, unbroken camera-referenced approaches.
    confirmed = next((gate for gate in range(1, gate_count)
                      if gate not in connected or len(passage_launches[gate]) < 2), gate_count)
    uncertainty = [0.]
    for gate in range(1, gate_count):
        samples = lengths[gate-1, gate]
        if len(samples) < 2:
            uncertainty.append(None)
        else:
            scatter = np.median(np.abs(samples-np.median(samples, axis=0)), axis=0)
            uncertainty.append(float(1.4826*np.linalg.norm(scatter)/np.sqrt(len(samples))))
    for flight in flights:
        for gate, (measured_speed, clearance, viewing_time) in flight.passages.items():
            if gate >= confirmed:
                continue
            if clearance <= 0. or gate+1 in flight.lost_gates:
                if measured_speed > proven[gate]:
                    failed_above[gate] = min(failed_above[gate], measured_speed)
                speed[gate] = min(speed[gate], proven[gate])
                continue
            if uncertainty[gate] is None:
                continue
            if gate+1 < gate_count:
                following = flight.passages.get(gate+1)
                if following is None or following[1] <= 0.:
                    # Reward an approach that also delivered a usable view of its successor.
                    continue
            passes[gate] += 1
            measured_passes[gate].append(measured_speed)
            if passes[gate] < 2:
                continue
            proven[gate] = max(proven[gate], sorted(measured_passes[gate])[-2])
            if proven[gate] >= failed_above[gate]:
                failed_above[gate] = np.inf
            # Limit the extra speed to one second of the nominal 3 m/s² acceleration.
            available = max(0., clearance-uncertainty[gate])
            headroom = 3.*min(1., viewing_time)*(available/(APERTURE_HALF_WIDTH-CHASSIS_RADIUS))*passes[gate]/(passes[gate]+1.)
            speed[gate] = max(speed[gate], proven[gate]+headroom)
            speed[gate] = min(speed[gate], .5*(proven[gate]+failed_above[gate]))
    return dict(speed_m_s=speed.tolist(), supported_passes=passes.tolist(), leg_standard_error_m=uncertainty,
                confirmed_gates=confirmed,
                failed_above_m_s=[float(x) if np.isfinite(x) else None for x in failed_above])


def align_outer_corners(inner, outer):
    """Give each exterior edge the same index and winding as its interior counterpart."""
    centered = inner-inner.mean(axis=1, keepdims=True)
    reference = centered/np.maximum(.01, np.linalg.norm(centered, axis=(1, 2), keepdims=True))
    candidates = np.stack([np.roll(order, shift, axis=1) for order in (outer, outer[:, ::-1])
                           for shift in range(4)], axis=1)
    shape = candidates-candidates.mean(axis=2, keepdims=True)
    shape /= np.maximum(.01, np.linalg.norm(shape, axis=(2, 3), keepdims=True))
    error = np.sum((shape-reference[:, None])**2, axis=(2, 3))
    return candidates[np.arange(len(inner)), np.argmin(error, axis=1)]


def gate_rotations(observations, seed, fallback=None):
    """Fit each rigid opening's orientation. Camera translation cancels within each image."""
    output = [Rotation.identity().as_quat()]
    for gate in range(1, len(seed)):
        prior = Rotation.from_quat(seed[gate, 3:])
        good = [(camera, pixels, bound) for _, index, camera, pixels, bound, _, width in observations
                if index == gate and width > 20.]
        if len(good) < 3:
            output.append(fallback[gate, 3:] if fallback is not None and gate < len(fallback) else prior.as_quat())
            continue
        cameras, pixels, bounds = map(np.asarray, zip(*good))
        rays = (pixels-K[:2, 2])/320.
        design = cameras[:, None, :2]-rays[:, :, :, None]*cameras[:, None, 2:3]
        inverse = np.linalg.pinv(design.reshape(-1, 8, 3))
        visible = np.isfinite(bounds).all(axis=(1, 2))
        outer = align_outer_corners(pixels[visible], bounds[visible])
        ends = np.roll(outer, -1, axis=1)
        midpoints = (ends+outer)/2.
        edges = ends-outer
        outer_cameras = cameras[visible].transpose(0, 2, 1)
        gate_axes = np.array([[0., 1., 0.], [0., 0., 1.]]*2)

        def residual(angle):
            rotation = Rotation.from_rotvec(angle)
            shape = rotation.apply(APERTURE)
            right = np.einsum('nkij,kj->nki', design, shape)
            relative = -np.einsum('nij,nj->ni', inverse, right.reshape(-1, 8))
            local = np.einsum('nij,nkj->nki', cameras, relative[:, None]+shape)
            projection = local[:, :, :2]*320./np.maximum(.1, local[:, :, 2:])+K[:2, 2]
            # Parallel exterior edges constrain orientation without assuming their size or center.
            camera_axes = rotation.apply(gate_axes) @ outer_cameras
            tangent = 320.*camera_axes[:, :, :2]-(midpoints-K[:2, 2])*camera_axes[:, :, 2:]
            tangent /= np.maximum(.1, np.linalg.norm(tangent, axis=2, keepdims=True))
            line_error = .5*(edges[:, :, 0]*tangent[:, :, 1]-edges[:, :, 1]*tangent[:, :, 0])
            return np.r_[(projection-pixels).ravel(), line_error.ravel(), rotation.apply([0., 0., 1.])[:2]/.035,
                         (rotation*prior.inv()).as_rotvec()/.20]

        fit = least_squares(residual, prior.as_rotvec(), loss='soft_l1', f_scale=.8)
        output.append(Rotation.from_rotvec(fit.x).as_quat())
    return Rotation.from_quat(output)


def center_ray(corners, camera):
    corners = np.c_[corners, np.ones(4)]
    center = np.cross(np.cross(corners[0], corners[2]), np.cross(corners[1], corners[3]))
    pixel = center[:2]/center[2]
    ray = np.r_[(pixel-K[:2, 2])/320., 1.] @ camera
    return ray/np.linalg.norm(ray)


def constraints(views, rotations, distances, bounds):
    fixes, frames, pairs = defaultdict(list), defaultdict(list), defaultdict(list)
    for (stamp, gate, camera, pixels, outside, active, width), distance_flown in zip(views, distances, strict=True):
        shape = rotations[gate].apply(APERTURE)
        relative = -translation(shape, pixels, camera)
        length = np.linalg.norm(relative)
        if gate == active and width >= 32. and 3. < length < 12.:
            fixes[gate].append((stamp, distance_flown+relative))
        frames[stamp].append((gate, width, relative, center_ray(pixels, camera)))
        if 2. < length < 18. and np.isfinite(outside).all():
            direction = rotations[gate].apply([1., 0., 0.])
            rays = np.c_[(outside-K[:2, 2])/320., np.ones(4)] @ camera
            denominator = rays @ direction
            if denominator.min() > .3:
                points = rays*((relative @ direction)/denominator[:, None])
                local = rotations[gate].inv().apply(points-relative)
                size = np.ptp(local[:, 1:], axis=0)
                if np.all((size > 1.5) & (size < 5.)):
                    # The bottom edge gives a visible base datum for the estimated mesh pivot.
                    bottom = np.sort(local[:, 2])[-2:].mean()
                    bounds[gate].append([*size, bottom])

    terms = []
    centers = {gate: (np.median([t for t, _ in rows]), np.median([c for _, c in rows], axis=0))
               for gate, rows in fixes.items() if len(rows) >= 3}
    ordered = sorted(centers)
    for first, second in zip(ordered, ordered[1:]):
        before, a = centers[first]
        after, b = centers[second]
        if after > before:
            # Each flight contributes one displacement for this leg.
            terms.append((first, second, np.eye(3), b-a, np.sqrt(max(.4, (after-before)/10.))))
    for frame in frames.values():
        for a, b in combinations(frame, 2):
            near, far = (a, b) if a[1] >= b[1] else (b, a)
            # The camera origin cancels for two square apertures in one image.
            displacement = far[2]-near[2]
            covariance = np.zeros((3, 3))
            for gate in (near,far):
                distance = np.linalg.norm(gate[2])
                across = .075+.8*distance/K[0, 0]
                depth = opening_range_sigma(distance)
                covariance += across**2*np.eye(3)+(depth**2-across**2)*np.outer(gate[3], gate[3])
            covariance += .014**2*((displacement@displacement)*np.eye(3)-np.outer(displacement, displacement))
            whiten = np.linalg.solve(np.linalg.cholesky(covariance), np.eye(3))
            pairs[near[0], far[0]].append((whiten, displacement, 1.))
    for (near, far), samples in pairs.items():
        if len(samples) >= 2:
            for plane, offset, sigma in samples:
                terms.append((near, far, plane, offset, sigma*np.sqrt(len(samples))))
    return terms


def fit_links(flights, prior=None, calibration=None):
    """Combine independent flight measurements in the frame of the first gate."""
    K[:2, 2] = 319.5, 179.5
    seed = max((flight.seed for flight in flights), key=len).copy()
    if prior is not None and len(prior) > len(seed):
        seed = np.vstack((seed, prior[len(seed):]))
    # All historical pixels are fitted again. Applying yesterday's fitted rotation
    # as a new observation would count those pixels twice on every restart.
    rotations = gate_rotations([view for flight in flights for view in flight.views], seed, prior)
    launches = {flight.launch_id: flight.launch_drag for flight in flights
                if flight.launch_id is not None and flight.launch_drag is not None}
    drag = calibration
    # The airframe bank also needs three independent launches for a drag prior.
    if drag is None and len(launches) >= 3:
        drag = float(np.median(list(launches.values())))
    terms, bounds = [], [[] for _ in seed]
    for flight in flights:
        distance = flight.odometry if drag is None else flight.transverse+flight.forward/np.sqrt(drag)
        terms.extend(constraints(flight.views, rotations, distance, bounds))
    centers = seed[:, :3].copy()
    if prior is not None:
        centers[:len(prior)] = prior[:, :3]
    if terms and len(centers) > 1:
        first, second, plane, offset, sigma = map(np.asarray, zip(*terms))
        weighted = plane/sigma[:, None, None]
        design = np.zeros((len(terms), 3, len(centers), 3))
        rows = np.arange(len(terms))
        design[rows, :, first] = -weighted
        design[rows, :, second] = weighted
        matrix = design[:, :, 1:].reshape(len(terms)*3, -1)
        target = np.einsum('nij,nj->ni', weighted, offset).ravel()
        # A disconnected or bearing-only link cannot set every coordinate.
        # Update only the coordinates supported by the measurements.
        _, singular, directions = np.linalg.svd(matrix, full_matrices=False)
        basis = directions[singular > singular[0]*1e-8].T
        initial_error = matrix @ centers[1:].ravel()-target
        jacobian = matrix @ basis
        fit = least_squares(lambda delta: initial_error+jacobian @ delta, np.zeros(basis.shape[1]),
                            jac=lambda _: jacobian.copy(), loss='soft_l1', f_scale=.5)
        centers[1:] += (basis @ fit.x).reshape(-1, 3)
    sizes = np.array([np.median(samples, axis=0) if len(samples) >= 3 else [np.nan, np.nan, 1.35]
                      for samples in bounds])
    return np.c_[centers, rotations.as_quat()], sizes[:, :2], dict(
        forward_drag_per_m=drag, calibrated_launches=len(launches), flights=len(flights),
        pivot_below_opening_m=sizes[:, 2].tolist(), outer_views=[len(samples) for samples in bounds],
        measured_legs=sum(np.array_equal(term[2], np.eye(3)) for term in terms), pace=learned_pace(flights, len(centers), terms))
