"""Recover the direction of translation from short, rotation-compensated tracks."""

from dataclasses import dataclass

import cv2
import numpy as np

from mapped import CAMERA_FROM_BODY, K

RAYS = np.linalg.inv(K).T


@dataclass
class Flow:
    first: float = -np.inf
    last: float = -np.inf
    previous: np.ndarray | None = None
    anchor: np.ndarray | None = None
    pixels: np.ndarray | None = None

    def update(self, t, image, orientation):
        if t-self.last < .052:
            return
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        direction = None
        if self.pixels is not None and len(self.pixels) >= 20 and t-self.last < .19:
            found, ok, _ = cv2.calcOpticalFlowPyrLK(self.previous, gray, self.pixels, None)
            reverse, good, _ = cv2.calcOpticalFlowPyrLK(gray, self.previous, found, None)
            keep = (ok[:, 0] != 0) & (good[:, 0] != 0) & (np.linalg.norm(reverse-self.pixels, axis=2)[:, 0] < .6)
            self.anchor, self.pixels = self.anchor[keep], found[keep]
            if len(self.pixels) >= 20 and .24 <= t-self.first <= .45:
                direction = translation_direction(self.anchor[:, 0], self.pixels[:, 0],
                                                  orientation(self.first), orientation(t))
        first = self.first
        if t-first >= .24 or self.pixels is None or len(self.pixels) < 20 or t-self.last >= .19:
            self.pixels = cv2.goodFeaturesToTrack(gray, 100, .012, 10)
            self.anchor, self.first = self.pixels, t
        self.previous, self.last = gray, t
        if direction is not None:
            return first, direction


def translation_direction(a, b, ra, rb):
    def world_rays(pixels, rotation):
        rays = np.c_[pixels, np.ones(len(pixels))] @ RAYS
        return rotation.apply(rays @ CAMERA_FROM_BODY)/np.linalg.norm(rays, axis=1, keepdims=True)

    plane = np.cross(world_rays(a, ra), world_rays(b, rb))
    for _ in range(3):
        _, singular, vectors = np.linalg.svd(plane, full_matrices=False)
        direction = vectors[-1]
        keep = np.abs(plane @ direction) < .003
        if keep.sum() < 20:
            return
        if keep.all():
            break
        plane = plane[keep]
    if singular[1] > .035 and singular[2] < .30*singular[1]:
        return direction
