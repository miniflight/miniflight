"""Rednose MSCKF with inertial propagation and pixel-space observations."""

import numpy as np
from scipy.spatial.transform import Rotation
from rednose.helpers.ekf_sym import EKF_sym
import logging

from mapped import CAMERA_FROM_BODY, K

GRAVITY = np.array([0., 0., 9.81])
I = np.eye(3)


def cross(v):
    x, y, z = v
    return np.array([[0., -z, y], [z, 0., -x], [-y, x, 0.]])


def pose_at(x, offset):
    return x[offset:offset+3], Rotation.from_quat(x[offset+3:offset+7])


def project(points, pos, rotation):
    q = (points-pos) @ (CAMERA_FROM_BODY @ rotation.as_matrix().T).T
    return q[:, :2]*320./np.maximum(q[:, 2:3], .01)+K[:2, 2], q[:, 2]


def pixel_factor(point, pos, rotation):
    world = point-pos
    camera = CAMERA_FROM_BODY @ rotation.as_matrix().T
    x, y, depth = camera @ world
    depth = max(.01, depth)
    perspective = (320./depth)*np.array([[1., 0., -x/depth], [0., 1., -y/depth]])
    spatial = perspective @ camera
    return 320.*np.array([x, y])/depth+K[:2, 2], np.c_[-spatial, spatial @ cross(world)], spatial


def integrate(x, dt, reading):
    _, rotation = pose_at(x, 0)
    angle = (reading[4:7]-x[13:16])*dt
    mid = (rotation*Rotation.from_rotvec(.5*angle)).as_matrix()
    force = mid @ (reading[1:4]-x[10:13])
    acceleration = force+GRAVITY
    x[:3] += dt*x[7:10]+.5*dt**2*acceleration
    x[7:10] += dt*acceleration
    x[3:7] = (rotation*Rotation.from_rotvec(angle)).as_quat()
    return mid, force


class PoseFilter(EKF_sym):
    """Use Rednose's Python update, nullspace projection and pose augmentation."""

    estimate_bias = True

    def __init__(self, stamp, rotation, accel_bias, gyro_bias, clones=9, gyro_noise=.038):
        self.msckf = clones > 0
        self.N = clones
        self.dim_main, self.dim_augment = 16, 7
        self.dim_main_err, self.dim_augment_err = 15, 6
        self.dim_x, self.dim_err = 16+7*clones, 15+6*clones
        self.gyro_noise = gyro_noise
        self.maha_test_kinds = [1]
        self.logger = logging
        x = np.r_[np.zeros(3), rotation.as_quat(), np.zeros(3), accel_bias, gyro_bias,
                  np.tile(np.r_[np.zeros(3), rotation.as_quat()], clones)]
        std = np.r_[np.repeat([.07, .014, .16, .18, .007], 3), np.ones(6*clones)]
        if not self.estimate_bias:
            std[9:15] = 0.
        self.init_state(x, np.diag(std**2), stamp)
        self.mod = np.eye(self.dim_x, self.dim_err)
        self.H_mod = lambda x, out: np.copyto(out, self.mod)
        self.hs = {0: self._h, 1: self._h}
        self.Hs = {0: self._H, 1: self._H}
        self.Hes = {1: self._He}

    def _h(self, x, extra, out):
        out[:, 0] = self.predicted

    def _H(self, x, extra, out):
        out[:, :self.dim_err] = self.jacobian

    def _He(self, x, extra, out):
        out[:] = self.feature_jacobian

    def err_function(self, nominal, delta, out):
        x, dx, result = nominal[:, 0], delta[:, 0], out[:, 0]
        result[:] = x
        result[7:16] += dx[6:15]
        poses = [(0, 0)]+[(16+7*i, 15+6*i) for i in range(self.N)]
        for state, error in poses:
            result[state:state+3] += dx[error:error+3]
            attitude = Rotation.from_quat(x[state+3:state+7])
            result[state+3:state+7] = (Rotation.from_rotvec(dx[error+3:error+6])*attitude).as_quat()

    def update(self, z, h, H, deviations, He=None, correlated_noise=None):
        self.predicted, self.jacobian, self.feature_jacobian = h, H, He
        # Rednose eliminates the feature's three unknown coordinates before the EKF update.
        kind = int(He is not None)
        noise = np.diag(deviations**2)
        if correlated_noise is not None:
            noise += correlated_noise
            self.last_gate_factor = (z-h, H, deviations, correlated_noise)
        self.x, self.P, innovation = self._update_python(self.x, self.P, kind, z, noise,
                                                        np.empty(3) if kind else [])
        self.P = .5*(self.P+self.P.T)
        return innovation

    def move(self, stamp, reading, state=None, imu_gap=0.):
        x = self.x[:, 0] if state is None else state
        now = self.filter_time if state is None else reading[0]
        dt = stamp-now
        mid, force = integrate(x, dt, reading)
        if state is not None:
            return
        F = np.eye(15)
        F[:3, 6:9] = dt*I
        F[6:9, 3:6] = -dt*cross(force)
        F[:3, 3:6] = .5*dt*F[6:9, 3:6]
        F[6:9, 9:12] = -dt*mid
        F[:3, 9:12] = -.5*dt**2*mid
        F[3:6, 12:15] = -dt*mid
        P = self.P
        uncertain = imu_gap > .07
        noise = [.008**2, .26**2 if uncertain else self.gyro_noise**2,
                 .7**2 if uncertain else .28**2, .055**2, .0015**2]
        if not self.estimate_bias:
            noise[3:] = [0., 0.]
        P[:15, :15] = F @ P[:15, :15] @ F.T+dt*np.diag(np.repeat(noise, 3))
        P[:15, 15:] = F @ P[:15, 15:]
        P[15:, :15] = P[:15, 15:].T
        self.filter_time = stamp

    def feature(self, slots, pixels):
        poses = [pose_at(self.x[:, 0], 16+7*i) for i in slots]
        pos = np.array([p for p, _ in poses])
        rays = (np.c_[pixels, np.ones(len(pixels))] @ np.linalg.inv(K).T) @ CAMERA_FROM_BODY
        rays = np.array([r.apply(ray) for (_, r), ray in zip(poses, rays)])
        rays /= np.linalg.norm(rays, axis=1, keepdims=True)
        normals = I-rays[:, :, None]*rays[:, None, :]
        if np.max(np.linalg.norm(np.cross(rays[0], rays), axis=1)) < .013:
            return False
        point = np.linalg.lstsq(normals.reshape(-1, 3), np.einsum('nij,nj->ni', normals, pos).ravel(), rcond=None)[0]
        if np.min(np.sum((point-pos)*rays, axis=1)) < 1. or np.linalg.norm(point-pos[0]) > 100.:
            return False
        for _ in range(2):
            factors = [pixel_factor(point, p, r) for p, r in poses]
            predicted, _, feature = map(np.array, zip(*factors))
            point += np.linalg.lstsq(feature.reshape(-1, 3), (pixels-predicted).ravel(), rcond=None)[0]
        predicted, local, feature = map(np.array, zip(*(pixel_factor(point, p, r) for p, r in poses)))
        if np.sqrt(np.mean((pixels-predicted)**2)) > 2.5:
            return False
        H = np.zeros((len(pixels), 2, self.dim_err))
        for i, slot in enumerate(slots):
            column = 15+6*slot
            H[i, :, column:column+6] = local[i]
        self.update(pixels.ravel(), predicted.ravel(), H.reshape(-1, self.dim_err), np.full(pixels.size, 1.4),
                    feature.reshape(-1, 3))
        return True
