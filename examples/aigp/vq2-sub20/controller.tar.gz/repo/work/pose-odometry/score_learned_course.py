"""Score an empty-map course attempt in the coordinate frame of gate one."""

import json
from pathlib import Path
import sys

from score import metrics, monotone
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.transform import Rotation, Slerp

from extract import extract


def reference(directory):
    rows = [json.loads(line) for line in (directory/'flight.native.jsonl').read_text().splitlines()]
    status = next(row for row in reversed(rows) if 'active_gate_index' in row)
    centers = np.asarray(next(row['gate_centers'] for row in rows if 'gate_centers' in row))
    wire = json.loads((Path(__file__).with_name('rednose-fresh')/'map.json').read_text())
    basis = Rotation.from_quat([gate['orientation'] for gate in wire], scalar_first=True).as_matrix()
    basis = basis @ np.array([[0., -1., 0.], [1., 0., 0.], [0., 0., 1.]])
    return status, centers, basis


def score(trace):
    directory = trace.parent
    status, centers, basis = reference(directory)
    extract(trace, scoring_only=True)
    with np.load(directory/'truth.npz', allow_pickle=False) as truth:
        position, attitude = monotone(truth['position']), monotone(truth['attitude'])
        arm, end = np.interp(truth['armed'], position[:, 1], position[:, 0])
    with np.load(directory/'learned-course.npz', allow_pickle=False) as data:
        poses = monotone(data['pose'])
        gates, decisions = data['gates'], data['crossings']
        speed_cap = float(data.get('speed_cap', 2.))
    poses = poses[(poses[:, 0] >= arm) & (poses[:, 0] <= end)]
    points = (position[:, 2:5]-centers[0]) @ basis[0]
    time = poses[:, 0]
    recorded = np.column_stack([np.interp(time, position[:, 0], axis) for axis in points.T])
    distance = np.linalg.norm(poses[:, 1:4]-recorded, axis=1)
    velocity = np.column_stack([np.interp(time, position[:, 0], axis) for axis in (position[:, 5:8] @ basis[0]).T])
    velocity_error = np.linalg.norm(poses[:, 8:11]-velocity, axis=1)
    speed = np.linalg.norm(velocity, axis=1)
    rotation = Slerp(attitude[:, 0], Rotation.from_euler('xyz', attitude[:, 2:5]))
    reference_q = Rotation.from_matrix(basis[0].T)*rotation(np.clip(time, attitude[0, 0], attitude[-1, 0]))
    angle = np.degrees((reference_q.inv()*Rotation.from_quat(poses[:, 4:8])).magnitude())
    result = dict(native_gates=status['active_gate_index'], valid=status['valid'], finished=status['completed'],
                  lap_time_s=status['finish_time_seconds'] if status['completed'] else None,
                  learned_gates=int(np.max(gates[:, 1])+1), pilot_crossings=len(decisions),
                  speed_cap_m_s=speed_cap, position_m=metrics(distance), velocity_m_s=metrics(velocity_error),
                  orientation_deg=metrics(angle), gates=[], map=[])
    axis_names = ['Position error (m)', 'Attitude error (°)', 'Gate centre error (m)',
                  'Speed (m/s)', 'Pitch (°)']
    fig, axes = plt.subplots(5, 1, sharex=True, figsize=(9, 9), layout='constrained')
    axes[0].plot(time-arm, distance)
    axes[1].plot(time-arm, angle)
    axes[3].plot(time-arm, speed)
    axes[3].axhline(speed_cap, color='#777777', lw=.75, ls=':')
    axes[4].plot(time-arm, reference_q.as_euler('xyz', degrees=True)[:, 1])
    for i, center in enumerate(centers):
        observations = gates[gates[:, 1] == i]
        if len(observations):
            gate_error = np.linalg.norm(observations[:, 2:5]-(center-centers[0])@basis[0], axis=1)
            axes[2].plot(observations[:, 0]-arm, gate_error, label=f'G{i+1}')
            if i:
                normal = basis[0].T @ basis[i, :, 0]
                directions = Rotation.from_quat(observations[:, 5:9]).apply([1., 0., 0.])
                plane_error = np.degrees(np.arccos(np.clip(np.abs(directions @ normal), 0., 1.)))
                result['map'].append(dict(gate=i+1, first_centre_m=float(gate_error[0]), last_centre_m=float(gate_error[-1]),
                                          first_plane_deg=float(plane_error[0]), last_plane_deg=float(plane_error[-1])))
        if i >= status['active_gate_index']:
            continue
        p_local = (position[:, 2:5]-center)@basis[i]
        # The finish can arrive before the last position sample brackets the final plane.
        gate_end = position[-1, 0] if status['completed'] and i == len(centers)-1 else end
        crossing = np.flatnonzero((p_local[:-1, 0] < 0.) & (p_local[1:, 0] >= 0.) &
                                  (position[1:, 0] >= arm) & (position[1:, 0] <= gate_end))
        if not crossing.size:
            continue
        j = crossing[0]
        t = np.interp(0., p_local[j:j+2, 0], position[j:j+2, 0])
        miss = [np.interp(t, position[:, 0], axis) for axis in p_local[:, 1:].T]
        crossing_velocity = [np.interp(t, position[:, 0], axis) for axis in position[:, 5:8].T]
        row = dict(gate=i+1, crossing_s=float(t-arm), centre_miss_m=float(np.linalg.norm(miss)),
                   centre_clearance_m=float(.74-max(map(abs, miss))),
                   crossing_speed_m_s=float(np.linalg.norm(crossing_velocity)))
        handoff = speed[(time >= t-1.) & (time <= t+2.)]
        if i < len(centers)-1 and handoff.size:
            row['handoff_min_speed_m_s'] = float(handoff.min())
        result['gates'].append(row)
        for ax in axes:
            ax.axvline(t-arm, color='#777777', lw=.75, ls='--', alpha=.55)
    axes[2].legend(frameon=False, ncols=6)
    for ax, name in zip(axes, axis_names):
        ax.set_ylabel(name)
        ax.grid(alpha=.18)
    for ax in axes[:4]:
        ax.set_ylim(bottom=0)
    axes[-1].set_xlabel('Seconds since arming')
    fig.suptitle(f'Empty-map VQ1 · {status["active_gate_index"]}/6 gates · {speed_cap:g} m/s cap', fontweight='bold')
    fig.savefig(directory/'learned-course-errors.png', dpi=150)
    (directory/'learned-course-score.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    score(Path(sys.argv[1]))
