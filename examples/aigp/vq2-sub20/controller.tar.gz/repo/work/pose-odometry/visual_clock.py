"""Estimate camera exposure offset from image correspondences and the public gyro."""

import argparse
from pathlib import Path

import cv2
import numpy as np
from scipy.spatial.transform import Rotation, Slerp

from mapped import CAMERA_FROM_BODY, K

OFFSETS = np.arange(-.100, .101, .004)
RAYS = np.linalg.inv(K).T


def camera_clock(ns, arrival, imu, warmup):
    seconds = (ns-ns[0])*1e-9
    camera_origin = np.quantile((arrival-seconds)[arrival <= warmup], .05)
    imu_origin = np.quantile((imu[:, 1]-imu[:, 0])[imu[:, 1] <= warmup], .05)
    return seconds+camera_origin-imu_origin


def matches(first, second):
    gray_a, gray_b = (cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) for image in (first, second))
    neutral = (np.ptp(first, axis=2) < 30).astype(np.uint8)
    mask = cv2.erode(neutral, np.ones((13, 13), np.uint8))
    a = cv2.goodFeaturesToTrack(gray_a, 180, .009, 11., mask=mask)
    if a is None:
        return None
    b, good, _ = cv2.calcOpticalFlowPyrLK(gray_a, gray_b, a, None, winSize=(25, 25), maxLevel=4)
    back, reverse, _ = cv2.calcOpticalFlowPyrLK(gray_b, gray_a, b, None, winSize=(25, 25), maxLevel=4)
    a, b, back = (x[:, 0] for x in (a, b, back))
    inside = np.all((b > 9.) & (b < [630., 350.]), axis=1)
    keep = inside & (good[:, 0] != 0) & (reverse[:, 0] != 0) & (np.linalg.norm(a-back, axis=1) < .35)
    a, b = a[keep], b[keep]
    if len(a) < 65 or np.min(np.std(a, axis=0)) < 36.:
        return None
    return tuple(np.c_[points, np.ones(len(points))] @ RAYS for points in (a, b))


def relative_gyro(imu):
    imu = imu[np.unique(imu[:, 0], return_index=True)[1]]
    t = imu[:, 0]
    dt = np.diff(t)
    omega = (imu[1:, 5:8]+imu[:-1, 5:8])*.5
    rotation = Rotation.identity()
    quats = [rotation.as_quat()]
    for step in Rotation.from_rotvec(omega*dt[:, None]):
        rotation = rotation*step
        quats.append(rotation.as_quat())
    return t, Slerp(t, Rotation.from_quat(quats))


def offset_cost(first_rays, last_rays, delta):
    # Test each candidate offset after allowing an independent translation for the pair.
    rotated = np.einsum('dij,nj->dni', delta, first_rays)
    normals = np.cross(rotated, last_rays[None])
    weight = np.ones(normals.shape[:2])
    for _ in range(4):
        system = normals*weight[..., None]
        _, vectors = np.linalg.eigh(system.transpose(0, 2, 1) @ system)
        direction = vectors[:, :, 0]
        residual = np.einsum('dni,di->dn', normals, direction)
        # Symmetric first-order pixel distance to the epipolar lines.
        right = np.cross(direction[:, None], rotated)
        left = np.einsum('dji,dnj->dni', delta, np.cross(last_rays[None], direction[:, None]))
        scale = np.sqrt(np.sum(right[..., :2]**2+left[..., :2]**2, axis=-1)).clip(.01)
        pixel = residual/scale*K[0, 0]
        weight = 1./np.sqrt(scale**2*(1.+(pixel/.6)**2))
    return np.mean(np.minimum(np.abs(pixel), 2.5), axis=1)


def inspect(directory):
    cv2.setNumThreads(1)
    with np.load(directory/'public.npz', allow_pickle=False) as data:
        imu, ns, arrival, jpeg, indexes = (data[key] for key in ('imu', 'camera_ns', 'receipt', 'image', 'offsets'))
    warmup = max(imu[0, 1], arrival[0])+1.
    t = camera_clock(ns, arrival, imu, warmup)
    imu_t, rotation = relative_gyro(imu)
    records, costs = [], []
    a = 0
    previous = cv2.imdecode(jpeg[indexes[0]:indexes[1]], cv2.IMREAD_COLOR)
    for b, stamp in enumerate(t):
        if t[a]-.11 < imu_t[0] or stamp-t[a] > .25:
            a = b
            previous = cv2.imdecode(jpeg[indexes[a]:indexes[a+1]], cv2.IMREAD_COLOR)
            continue
        if stamp-t[a] < .135 or stamp+.11 > imu_t[-1]:
            continue
        covered = imu_t[(imu_t >= t[a]-.12) & (imu_t <= stamp+.12)]
        current = cv2.imdecode(jpeg[indexes[b]:indexes[b+1]], cv2.IMREAD_COLOR)
        if len(covered) > 2 and np.max(np.diff(covered)) < .065:
            views = matches(previous, current)
            if views is not None:
                first = rotation(t[a]+OFFSETS)
                second = rotation(stamp+OFFSETS)
                delta = CAMERA_FROM_BODY @ (second.inv()*first).as_matrix() @ CAMERA_FROM_BODY.T
                costs.append(offset_cost(*views, delta))
                motion = np.degrees((second[len(OFFSETS)//2].inv()*first[len(OFFSETS)//2]).magnitude())
                records.append((t[a], stamp, max(arrival[b], arrival[a]), motion))
        a, previous = b, current
    cost, times = np.asarray(costs), np.asarray(records)
    np.savez_compressed(directory/'visual-clock.npz', offsets=OFFSETS, pairs=times, cost=cost)
    for lo, hi in [(6., 10.), (10., 18.), (18., 26.), (26., 43.)]:
        weight = (times[:, 1] >= lo) & (times[:, 1] < hi) & (times[:, 3] > .3)
        if weight.sum():
            profile = np.median(cost[weight]-cost[weight].min(axis=1, keepdims=True), axis=0)
            i = int(np.argmin(profile))
            print(f'{lo:2.0f}–{hi:2.0f} s  {weight.sum():3} pairs  best {OFFSETS[i]*1000:+.0f} ms  '
                  f'cost at zero/best {profile[len(OFFSETS)//2]:.3f}/{profile[i]:.3f} px')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    inspect(parser.parse_args().directory)
