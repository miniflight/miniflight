"""Replay the same gate observations at arrival and capture time."""

from bisect import bisect_right
from dataclasses import dataclass
import json
from pathlib import Path
import sys

import cv2
import numpy as np
from scipy.spatial.transform import Rotation, Slerp

from mapped import CAMERA_FROM_BODY, apertures, gate_points, measurements


@dataclass
class Snapshot:
    time: float
    acceleration: np.ndarray
    state: np.ndarray
    covariance: np.ndarray

    def predict(self, stamp, force):
        dt = stamp - self.time
        acceleration = (self.acceleration + force)/2. - self.state[6:]
        next_state = self.state.copy()
        next_state[:3] += self.state[3:6]*dt + .5*acceleration*dt**2
        next_state[3:6] += acceleration*dt
        transition = np.eye(9)
        transition[:3, 3:6] = np.eye(3)*dt
        transition[:3, 6:] = -.5*np.eye(3)*dt**2
        transition[3:6, 6:] = -np.eye(3)*dt
        process = np.diag(np.repeat([.04, 1., .02], 3))*dt
        return Snapshot(stamp, force, next_state, transition @ self.covariance @ transition.T + process)

    def correct(self, position, noise):
        gain = np.linalg.solve(self.covariance[:3, :3]+noise, self.covariance[:3]).T
        self.state += gain @ (position-self.state[:3])
        self.covariance -= gain @ self.covariance[:3]


class History:
    def __init__(self, stamp, force):
        self.nodes = [Snapshot(stamp, force, np.zeros(9), np.diag(np.repeat([.3**2, .25**2, .5**2], 3)))]
        self.last_gate = stamp

    @property
    def current(self):
        return self.nodes[-1]

    def imu(self, stamp, force):
        self.nodes.append(self.current.predict(stamp, force))
        while len(self.nodes) > 1 and self.nodes[1].time < stamp-.5:
            self.nodes.pop(0)

    def at(self, stamp):
        index = bisect_right(self.nodes, stamp, key=lambda node: node.time)-1
        old = self.nodes[index]
        if index+1 < len(self.nodes):
            new = self.nodes[index+1]
            ratio = (stamp-old.time)/(new.time-old.time)
            force = (1.-ratio)*old.acceleration+ratio*new.acceleration
        else:
            force = old.acceleration
        return index, old.predict(stamp, force)

    def camera(self, stamp, accepted):
        index, update = self.at(stamp)
        for _, _, _, position, noise, _ in accepted:
            update.correct(position, noise)
        replacement = [update]
        for later in self.nodes[index+1:]:
            replacement.append(replacement[-1].predict(later.time, later.acceleration))
        self.nodes[index:] = replacement if self.nodes[index].time == stamp else self.nodes[index:index+1]+replacement
        self.last_gate = stamp


def replay(directory):
    cv2.setNumThreads(1)
    with np.load(directory/'public.npz', allow_pickle=False) as public:
        imu, ns, receipt, raw, offsets = (public[name] for name in ('imu', 'camera_ns', 'receipt', 'image', 'offsets'))
    with np.load(directory/'openvins-pose.npz', allow_pickle=False) as observed:
        prior, available = observed['pose'], observed['available']
    gate_metadata = json.loads((directory/'map.json').read_text())
    opening = json.loads(Path(__file__).with_name('opening.json').read_text())
    gates = gate_points(gate_metadata, opening)
    seconds = (ns-ns[0])*1e-9
    start = max(imu[0, 1], receipt[0])+1.
    camera_origin = np.quantile((receipt-seconds)[receipt <= start], .05)
    imu_origin = np.quantile((imu[:, 1]-imu[:, 0])[imu[:, 1] <= start], .05)
    capture = seconds+camera_origin-imu_origin
    rotations = Slerp(prior[:, 0], Rotation.from_quat(prior[:, 4:8]))
    events = [(t, 0, i) for i, t in enumerate(imu[:, 1])]
    events += [(t, 1, i) for i, t in enumerate(receipt)]
    old, new, far_bearing = None, None, None
    waiting, arrival, aligned, bearing, delay, observations = [], [], [], [], [], []
    frames_used = 0
    for host, camera, index in sorted(events):
        # Even the separate visual-inertial attitude estimate has an availability time.
        end = int(np.searchsorted(available, host, side='right'))
        if host < start or end == 0:
            continue
        latest = prior[end-1]
        if camera:
            waiting.append(index)
        else:
            stamp = imu[index, 0]
            orientation = Rotation.from_quat(latest[4:8])
            force = orientation.apply(imu[index, 2:5])+[0., 0., 9.81]
            if old is None:
                old, new, far_bearing = (History(stamp, force) for _ in range(3))
            elif stamp > old.current.time:
                old.imu(stamp, force)
                new.imu(stamp, force)
                far_bearing.imu(stamp, force)
        if old is None:
            continue
        while waiting and capture[waiting[0]] <= new.current.time:
            frame = waiting.pop(0)
            time = capture[frame]
            if time < max(new.nodes[0].time, new.last_gate):
                continue
            at_capture = new.at(time)[1]
            rotation = rotations(np.clip(time, prior[0, 0], latest[0]))
            image = cv2.imdecode(raw[offsets[frame]:offsets[frame+1]], cv2.IMREAD_COLOR)
            choices = sorted(measurements(list(apertures(image)), gates, at_capture.state[:3],
                                          CAMERA_FROM_BODY @ rotation.as_matrix().T, 'mapped'), key=lambda item: item[0])
            accepted, used = [], set()
            for candidate in choices:
                if candidate[1] not in used:
                    accepted.append(candidate)
                    used.add(candidate[1])
            if accepted:
                bearing_only = []
                camera_direction = (CAMERA_FROM_BODY @ rotation.as_matrix().T)[2]
                for _, _, gate, position, noise, corners in accepted:
                    observations.append(dict(time=float(time), gate=gate, pixels=corners.tolist(),
                                             measured=position.tolist(), predicted=at_capture.state[:3].tolist(),
                                             range_sigma=float(np.sqrt(noise[0, 0]))))
                    width = np.linalg.norm(corners[1]-corners[0])
                    if width < 15.:
                        noise = noise + 400.*np.outer(camera_direction, camera_direction)
                    bearing_only.append((None, None, gate, position, noise, corners))
                new.camera(time, accepted)
                far_bearing.camera(time, bearing_only)
                old.camera(old.current.time, accepted)
                frames_used += 1
                delay.append(old.current.time-time)
        if not camera:
            arrival.append((old.current.time, *old.current.state[:3], *latest[4:8], *old.current.state[3:6], old.last_gate))
            aligned.append((new.current.time, *new.current.state[:3], *latest[4:8], *new.current.state[3:6], new.last_gate))
            bearing.append((far_bearing.current.time, *far_bearing.current.state[:3], *latest[4:8],
                            *far_bearing.current.state[3:6], far_bearing.last_gate))
    for name, data in (('timing-arrival', arrival), ('timing-capture', aligned), ('far-bearing', bearing)):
        np.savez_compressed(directory/f'{name}-pose.npz', pose=data)
    report = dict(matched_frames=frames_used, estimated_age_ms=np.quantile(delay, [.5, .95, 1.]).tolist())
    report['estimated_age_ms'] = [value*1000. for value in report['estimated_age_ms']]
    (directory/'timing-ab.json').write_text(json.dumps(report, indent=2)+'\n')
    with (directory/'timing-gates.jsonl').open('w') as stream:
        for observation in observations:
            stream.write(json.dumps(observation, separators=(',', ':'))+'\n')
    print(report)


if __name__ == '__main__':
    replay(Path(sys.argv[1]))
