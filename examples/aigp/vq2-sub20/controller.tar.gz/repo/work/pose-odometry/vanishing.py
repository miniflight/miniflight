"""Use parallel background edges as an orientation observation in VQ1."""

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

from mapped import CAMERA_FROM_BODY, K
from rednose_model import cross, pose_at


def attitude_from_lines(normals, lengths, prior, directions):
    """Fit orthogonal vanishing directions. The gyro prior labels the axes."""
    if len(normals) < 18:
        return None
    order = np.argsort(lengths)[::-1][:160]
    normals, weights = normals[order], np.minimum(lengths[order], 100.)
    left, right = np.triu_indices(min(len(normals), 56), 1)
    intersections = np.cross(normals[left], normals[right])
    separation = np.linalg.norm(intersections, axis=1)
    distinct = separation > .10
    candidates = intersections[distinct]/separation[distinct, None]
    camera_axes = (CAMERA_FROM_BODY @ prior.as_matrix().T @ directions.T).T
    fits = []
    for axis, prediction in enumerate(camera_axes):
        alignment = candidates @ prediction
        close = np.abs(alignment) > np.cos(np.radians(22.))
        if not np.any(close):
            continue
        options = candidates[close]*np.sign(alignment[close, None])
        residual = normals @ options.T
        support = weights @ np.maximum(0., 1.-(residual/.018)**2)**2
        direction = options[np.argmax(support)]
        for _ in range(2):
            weight = weights*np.maximum(0., 1.-((normals @ direction)/.018)**2)**2
            if np.count_nonzero(weight > 1.) < 6:
                break
            eigenvalues, vectors = np.linalg.eigh(normals.T @ (weight[:, None]*normals))
            direction = vectors[:, 0]*np.sign(vectors[:, 0] @ prediction)
        else:
            # Nearly coincident image lines do not determine a vanishing point.
            if eigenvalues[1] > .0015*weight.sum():
                fits.append((axis, direction, eigenvalues[1]))
    pairs = [(a[2]*b[2], a, b) for i, a in enumerate(fits) for b in fits[:i]
             if abs(a[1] @ b[1]) < .048]
    if not pairs:
        return None
    _, a, b = max(pairs, key=lambda item: item[0])
    axes = [item for item in fits if item[0] in (a[0], b[0]) or
            max(abs(item[1] @ a[1]), abs(item[1] @ b[1])) < .048]
    axis_ids, measured, confidence = zip(*axes)
    camera, _ = Rotation.align_vectors(np.asarray(measured), directions[list(axis_ids)], weights=confidence)
    return camera.inv()*Rotation.from_matrix(CAMERA_FROM_BODY)


class Vanishing:
    def __init__(self, gate, update_orientation=None, *, tracking_scale=.8):
        across = gate[1]-gate[0]
        down = gate[3]-gate[0]
        directions = np.stack((across, down, np.cross(across, down)))
        self.directions = directions/np.linalg.norm(directions, axis=1, keepdims=True)
        self.rays = np.linalg.inv(K).T
        self.detector = cv2.createLineSegmentDetector(cv2.LSD_REFINE_STD)
        self.tracking = (self.detector if tracking_scale == .8 else
                         cv2.createLineSegmentDetector(cv2.LSD_REFINE_STD, tracking_scale))
        self.update_orientation = update_orientation
        self.last = -np.inf
        self.recoveries = []

    def normals(self, image, *, tracking=False):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        detected = (self.tracking if tracking else self.detector).detect(gray)[0]
        if detected is None:
            return np.empty((0, 3)), np.empty(0)
        lines = detected.reshape(-1, 2, 2)
        lengths = np.linalg.norm(lines[:, 1]-lines[:, 0], axis=1)
        keep = lengths > 26.
        lines, lengths = lines[keep], lengths[keep]
        probes = lines[:, :1]*(1.-np.linspace(.15, .85, 5)[None, :, None])+lines[:, 1:]*np.linspace(.15, .85, 5)[None, :, None]
        pixel = np.clip(np.rint(probes).astype(int), 0, [image.shape[1]-1, image.shape[0]-1])
        clean = np.max(np.ptp(image[pixel[..., 1], pixel[..., 0]], axis=2), axis=1) < 30
        lines, lengths = lines[clean], lengths[clean]
        a, b = (np.c_[ends, np.ones(len(ends))] @ self.rays for ends in lines.transpose(1, 0, 2))
        normals = np.cross(a, b)
        normals /= np.linalg.norm(normals, axis=1, keepdims=True)
        return normals, lengths

    def heading(self, image, attitude):
        """Resolve the stationary heading using horizontal scene lines."""
        normals, lengths = self.normals(image)
        if len(normals) < 16:
            return attitude
        # The two horizontal vanishing axes repeat every quarter turn.
        offsets = np.linspace(-45., 45., 181)
        candidates = Rotation.from_euler('z', offsets[:, None], degrees=True)*attitude
        cameras = CAMERA_FROM_BODY @ candidates.as_matrix().transpose(0, 2, 1)
        error = np.abs(normals @ cameras @ self.directions.T)
        costs = (np.minimum(error.min(axis=2), .03)**2) @ np.minimum(lengths, 100.)
        best = int(np.argmin(costs))
        links = np.argmin(error[best], axis=1)
        valid = error[best].min(axis=1) < .02
        if best in (0, len(offsets)-1) or np.count_nonzero(valid & (links != 1)) < 12:
            return attitude
        return candidates[best]

    def update(self, observer, image, t, recover=False):
        if t-self.last < .06:
            return 0
        self.last = t
        normals, lengths = self.normals(image, tracking=not recover)
        if len(normals) < 16:
            return 0
        _, attitude = pose_at(observer.x[:, 0], 0)
        if recover and self.update_orientation is not None:
            measured = attitude_from_lines(normals, lengths, attitude, self.directions)
            if measured is None:
                return 0
            H = np.zeros((3, observer.dim_err))
            H[:, 3:6] = np.eye(3)
            residual = (measured*attitude.inv()).as_rotvec()
            self.update_orientation(residual, H, np.full(3, .01))
            _, corrected = pose_at(observer.x[:, 0], 0)
            axes = CAMERA_FROM_BODY @ measured.as_matrix().T @ self.directions.T
            inliers = np.count_nonzero(np.abs(normals @ axes).min(axis=1) < .018)
            self.recoveries.append((t, np.linalg.norm(residual), (corrected*attitude.inv()).magnitude(), inliers))
            return inliers
        camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
        error = normals @ camera @ self.directions.T
        order = np.argsort(np.abs(error), axis=1)
        i = np.arange(len(order))
        keep = (np.abs(error[i, order[:, 0]]) < .037) & (np.abs(error[i, order[:, 1]]) > .035)
        assign = order[keep, 0]
        if len(assign) < 16 or np.count_nonzero(np.bincount(assign) >= 4) < 2:
            return 0
        normals, lengths = normals[keep], lengths[keep]
        error = error[i, order[:, 0]][keep]
        H = np.zeros((len(assign), observer.dim_err))
        H[:, 3:6] = np.array([normal @ camera @ cross(direction) for normal, direction in zip(normals, self.directions[assign])])
        sigma = (.012+1./lengths)*np.sqrt(1.+(error/.008)**2)
        if self.update_orientation is None:
            observer.update(np.zeros(len(error)), error, H, sigma)
        else:
            self.update_orientation(-error, H, sigma)
        return len(error)
