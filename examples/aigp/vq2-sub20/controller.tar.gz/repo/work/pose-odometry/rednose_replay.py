"""Replay VQ1 camera and IMU arrivals through the Rednose pose filter."""

from collections import Counter, defaultdict, deque
import json
from pathlib import Path
from time import perf_counter

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

from mapped import CAMERA_FROM_BODY, K, apertures, gate_points, measurements
from rednose_model import GRAVITY, PoseFilter, cross, pixel_factor, pose_at, project
from rim import GATE_HALF_WIDTH, edges, probes
from vanishing import Vanishing
from visual_clock import camera_clock


def initial_pose(images, readings, gates):
    accel = np.median(readings[:, 1:4], axis=0)
    ax, ay, az = accel
    level = Rotation.from_euler('xyz', (np.arctan2(-ay, -az), np.arctan2(ax, np.hypot(ay, az)), 0.))
    center = gates[0][1].mean(axis=0)
    bearing = np.arctan2(center[1], center[0])
    yaw = []
    for image in images:
        outlines = list(apertures(image))
        if outlines:
            biggest = max(outlines, key=lambda quad: cv2.contourArea(quad.astype(np.float32)))
            ray = level.apply(CAMERA_FROM_BODY.T @ np.linalg.solve(K, np.r_[biggest.mean(axis=0), 1.]))
            yaw.append(bearing-np.arctan2(ray[1], ray[0]))
    if not yaw:
        raise ValueError('Gate 1 was unavailable at the stationary grid')
    rotation = Rotation.from_euler('z', np.median(yaw))*level
    return rotation, accel+rotation.inv().apply(GRAVITY), np.median(readings[:, 4:7], axis=0)


def visible(position, points, ident, gates):
    """Reject rays to a distant gate that hit an earlier gate's solid rim."""
    rays = points-position
    for occluder, corners in gates:
        if occluder == ident:
            continue
        center = corners.mean(axis=0)
        across = corners[1]-corners[0]
        down = corners[3]-corners[0]
        width, height = np.linalg.norm(across), np.linalg.norm(down)
        across, down = across/width, down/height
        normal = np.cross(across, down)
        with np.errstate(divide='ignore', invalid='ignore'):
            fraction = ((center-position) @ normal)/(rays @ normal)
            hit = position+fraction[:, None]*rays-center
            x, y = hit @ across, hit @ down
        board = (np.abs(x) < GATE_HALF_WIDTH) & (np.abs(y) < GATE_HALF_WIDTH)
        hole = (np.abs(x) < width/2) & (np.abs(y) < height/2)
        if np.any((fraction > 0.) & (fraction < .995) & board & ~hole):
            return False
    return True


def reacquire(position, attitude, gates, outlines, position_error_m=None):
    """Associate a complete aperture after inertial prediction becomes uncertain."""
    candidates = []
    for ident, quad in gates:
        expected, depth = project(quad, position, attitude)
        if min(depth) < 2. or np.mean(depth) > 32. or not visible(position, quad, ident, gates):
            continue
        width = np.median(np.linalg.norm(expected-np.roll(expected, 1, axis=0), axis=1))
        center = expected.mean(axis=0)
        radius = 55.
        if position_error_m is not None:
            # Bound the pixel shift from a metric translation at the nearest possible depth.
            off_axis = np.linalg.norm(expected-K[:2, 2], axis=1).max()
            radius = position_error_m*np.hypot(K[0, 0], off_axis)/max(1., min(depth)-position_error_m)
        for index, outline in enumerate(outlines):
            size = np.median(np.linalg.norm(outline-np.roll(outline, 1, axis=0), axis=1))
            distance = np.linalg.norm(outline.mean(axis=0)-center)
            if not .65*width < size < 1.45*width or distance > radius:
                continue
            permutations = [np.roll(q, i, axis=0) for q in (outline, outline[::-1]) for i in range(4)]
            shape = expected-center
            corners = min(permutations, key=lambda q: np.linalg.norm(q-q.mean(axis=0)-shape))
            mismatch = np.sqrt(np.mean((corners-corners.mean(axis=0)-shape)**2))
            if mismatch < max(2., .18*width):
                candidates.append((distance+2.*mismatch, index, ident, corners))
    if candidates:
        return min(candidates, key=lambda c: c[0])


def corner_noise(span):
    return 1.25+16./span


def gate_update(observer, image, gates, rim, recover=False, gap_safe=False, range_pixels=0., range_quality=False,
                landmarks=None, observed=None, outlines=None, measured_pair=None, apertures_used=None,
                bearings=None):
    position, attitude = pose_at(observer.x[:, 0], 0)
    camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
    geometry = dict(gates)

    def factor(point, ident):
        expected, drone, spatial = pixel_factor(point, position, attitude)
        if landmarks is None:
            return expected, drone
        linear = np.zeros((2, observer.dim_err))
        linear[:, :6] = drone
        if ident in landmarks:
            column = landmarks[ident]
            arm = point-geometry[ident].mean(axis=0)
            linear[:, column:column+6] = np.c_[spatial, -spatial @ cross(arm)]
        return expected, linear

    if outlines is None:
        outlines = list(apertures(image))
    candidate = reacquire(position, attitude, gates, outlines) if recover and not landmarks else None
    candidates = [(residual, index, ident, corners)
                  for residual, index, ident, _, _, corners in measurements(outlines, gates, position, camera, 'mapped')
                  if residual <= 8.]
    if candidate is not None:
        candidates.append(candidate)
    complete = {candidate[2]} if gap_safe and candidate is not None else set()
    if landmarks is not None:
        complete.update(ident for _, _, ident, corners in candidates if visible(position, geometry[ident], ident, gates))
    if measured_pair is not None:
        complete.add(measured_pair[0])
    visible_rim = [(ident, edge) for ident, edge in rim if ident not in complete]
    lines = [(ident, world, measured)
             for ident, world, measured in probes(image, visible_rim, position, camera, dark_opening=True)
             if visible(position, world[0]+np.array([[.22], [.5], [.78]])*(world[1]-world[0]), ident, gates)]
    edge_count = Counter(ident for ident, _, _ in lines)
    bearing_gates = set()
    if bearings is not None and landmarks is not None:
        # A mapped edge gives bearing information even when aperture scale is unobservable.
        full = {ident for _, _, ident, _ in candidates}
        if measured_pair is not None:
            full.add(measured_pair[0])
        bearing_gates = {ident for ident, count in edge_count.items()
                         if count < 3 and ident not in landmarks and ident not in full}
    if landmarks is not None:
        # Three sides contain an opposite pair that constrains aperture scale.
        lines = [line for line in lines if edge_count[line[0]] >= 3 or line[0] in bearing_gates]
    found = {ident for ident, _, _ in lines if ident not in bearing_gates}
    edge_directions = defaultdict(list)
    h, z, jac, sigma, clip, identities = [], [], [], [], [], []
    for ident, world, measured in lines:
        a, depth = project(world, position, attitude)
        direction = a[1]-a[0]
        span = np.linalg.norm(direction)
        normal = np.array([-direction[1], direction[0]])/span
        bearing_only = ident in bearing_gates
        if bearing_only:
            ray = geometry[ident].mean(axis=0)-position
            ray /= np.linalg.norm(ray)
            bearings[ident] = edge_count[ident]
        else:
            edge_directions[ident].append(normal)
        fraction = np.clip(((measured-a[0]) @ direction)/span**2, 0., 1.)
        along = (fraction*depth[0])/(fraction*depth[0]+(1.-fraction)*depth[1])
        for point, px in zip(world[0]+along[:, None]*(world[1]-world[0]), measured):
            predicted, linear = factor(point, ident)
            if bearing_only:
                linear[:, :3] -= np.outer(linear[:, :3] @ ray, ray)
            h.append(predicted @ normal)
            z.append(px @ normal)
            jac.append(normal @ linear)
            sigma.append(.8+30./min(depth)**2)
            clip.append(3.)
            identities.append(ident)
    used = set()
    has_range = any(count >= 3 for count in edge_count.values())
    for residual, index, ident, corners in sorted(candidates, key=lambda row: row[0]):
        if ident in found or index in used:
            continue
        quad = geometry[ident]
        if not visible(position, quad, ident, gates):
            continue
        width = np.median(np.linalg.norm(corners-np.roll(corners, 1, axis=0), axis=1))
        has_range |= width >= 12.
        for point, pixels in zip(quad, corners):
            predicted, linear = factor(point, ident)
            h.extend(predicted)
            z.extend(pixels)
            jac.extend(linear)
            sigma.extend([corner_noise(width)]*2)
            clip.extend([12. if candidate is not None and ident == candidate[2] else 3.]*2)
            identities.extend([ident]*2)
        used.add(index)
        found.add(ident)
        if observed is not None:
            observed.add(ident)
        if apertures_used is not None:
            apertures_used[ident] = ident, quad, corners
    pair_used = measured_pair is not None and measured_pair[0] not in found
    if pair_used:
        ident, points, measured = measured_pair
        has_range = True
        for point, pixel in zip(points, measured, strict=True):
            expected, linear = factor(point, ident)
            h.extend(expected)
            z.extend(pixel)
            jac.extend(linear)
            sigma.extend([2.5, 2.5])
            clip.extend([3., 3.])
            identities.extend([ident, ident])
        if observed is not None:
            observed.add(ident)
        if apertures_used is not None:
            apertures_used[ident] = measured_pair
    if observed is not None:
        for ident, normals in edge_directions.items():
            directions = np.asarray(normals)
            # Parallel edges constrain one image axis, leaving the other free.
            if np.linalg.eigvalsh(directions.T@directions)[0] >= .12:
                observed.add(ident)
    if h:
        z, h, sigma = map(np.asarray, (z, h, sigma))
        H = np.zeros((len(h), observer.dim_err))
        H[:, :len(jac[0])] = jac
        residual_scale = np.asarray(clip) if gap_safe else (12. if recover else 3.)
        sigma *= np.sqrt(1.+((z-h)/residual_scale)**2)
        covariance = None
        if range_pixels:
            # All edges of one opening share scale error. A far outline does
            # not provide multiple independent range observations.
            covariance = np.zeros((len(h), len(h)))
            gate_id = np.asarray(identities)
            for ident in set(identities):
                indices = np.flatnonzero(gate_id == ident)
                ray = geometry[ident].mean(axis=0)-position
                depth = ray @ camera[2]
                width = np.linalg.norm(geometry[ident][1]-geometry[ident][0])
                clean_range = range_quality and not recover and edge_count[ident] == 4
                min_range_noise = .75 if clean_range else range_pixels
                distant = np.clip((depth-8.)/12., 0., 1.)
                width_noise = min_range_noise+(range_pixels-min_range_noise)*distant
                distance_error = width_noise*depth**2/(K[0, 0]*width)
                displacement = H[indices, :3] @ (distance_error*ray/np.linalg.norm(ray))
                covariance[np.ix_(indices, indices)] = np.outer(displacement, displacement)
        observer.update(z, h, H, sigma, correlated_noise=covariance)
    return len(lines)+len(used)+int(pair_used), has_range


class Tracks:
    def __init__(self, limit):
        self.limit = limit
        self.index = 0
        self.previous = None
        self.last = -np.inf
        self.active = []

    def update(self, t, image, observer, use_features):
        if t-self.last < .057:
            return 0
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        observer.augment()
        finished, active, points = [], [], []
        if self.active and t-self.last < .24:
            previous = np.array([track[-1][1] for track in self.active], np.float32)[:, None]
            current, status, _ = cv2.calcOpticalFlowPyrLK(self.previous, gray, previous, None, winSize=(21, 21))
            result, back, _ = cv2.calcOpticalFlowPyrLK(gray, self.previous, current, None, winSize=(21, 21))
            keep = (status[:, 0] != 0) & (back[:, 0] != 0) & (np.linalg.norm(result-previous, axis=2)[:, 0] < .6)
            valid = np.all((current[:, 0] > 5.) & (current[:, 0] < [634., 354.]), axis=1)
            for track, pixel, good in zip(self.active, current[:, 0], keep & valid):
                if good:
                    track.append((self.index, pixel))
                if len(track) == self.limit or not good:
                    finished.append(track)
                else:
                    active.append(track)
                    points.append(pixel)
        count = 0
        if use_features:
            for track in sorted(finished, key=len, reverse=True)[:36]:
                if len(track) < 4:
                    continue
                index, pixels = zip(*track)
                slots = np.asarray(index)-self.index+self.limit-1
                count += observer.feature(slots, np.asarray(pixels))
        if len(active) < 100:
            saturation = np.ptp(image, axis=2)
            mask = np.where(saturation < 32, 255, 0).astype(np.uint8)
            mask = cv2.erode(mask, np.ones((7, 7), np.uint8))
            for pixel in points:
                cv2.circle(mask, tuple(pixel.astype(int)), 10, 0, -1)
            found = cv2.goodFeaturesToTrack(gray, 110-len(active), .012, 10, mask=mask)
            if found is not None:
                active.extend([(self.index, pixel)] for pixel in found[:, 0])
        self.active, self.previous, self.last = active, gray, t
        self.index += 1
        return count


def inertial_intervals(now, until, imu):
    if until <= now:
        return
    time = imu[:, 0]
    end = np.r_[time[(time > now) & (time < until)], until]
    mid = .5*(np.r_[now, end[:-1]]+end)
    readings = np.array([np.interp(mid, time, row) for row in imu[:, 1:].T]).T
    brackets = np.searchsorted(time, mid)
    gaps = time[np.minimum(len(time)-1, brackets)]-time[np.maximum(0, brackets-1)]
    for lo, hi, values, gap in zip(np.r_[now, end[:-1]], end, readings, gaps):
        yield hi, np.r_[lo, values], gap


def advance(observer, until, imu, state=None, recover=False):
    for hi, reading, gap in inertial_intervals(observer.filter_time, until, imu):
        observer.move(hi, reading, state, gap if recover else 0.)


def replay(directory, use_features, recover=False, stop_after=None, gap_safe=False, camera_offset=0., rendered_opening=False,
           vanishing=False, stationary_grid=False, range_pixels=0., center_delta=0., range_quality=False, gyro_noise=.038,
           track_path=None, camera_observer=None):
    recover |= gap_safe
    cv2.setNumThreads(1)
    K[:2, 2] = np.array([320., 180.])+center_delta
    with np.load(directory/'public.npz', allow_pickle=False) as archive:
        raw_imu, ns, arrival, jpeg, offsets = (archive[name] for name in ('imu', 'camera_ns', 'receipt', 'image', 'offsets'))
    opening = json.loads(Path(__file__).with_name('opening.json').read_text())
    if rendered_opening:
        # The technical drawing specifies a 1.50 m aperture. The collision query measures 1.48 m.
        opening.update(opening_width_m=1.50, opening_height_m=1.50)
    track = directory/'map.json' if track_path is None else track_path
    gates = gate_points(json.loads(track.read_text()), opening)
    rim = list(edges(gates, .15732050896))
    warmup = max(raw_imu[0, 1], arrival[0])+1.
    initial = raw_imu[raw_imu[:, 1] <= warmup]
    capture = camera_clock(ns, arrival, raw_imu, warmup)+camera_offset

    def image(index):
        return cv2.imdecode(jpeg[offsets[index]:offsets[index+1]], cv2.IMREAD_COLOR)

    initial_images = (image(i) for i in np.flatnonzero(arrival <= warmup)[::3])
    initial_imu = initial[:, [0, 2, 3, 4, 5, 6, 7]]
    observer = PoseFilter(initial[-1, 0], *initial_pose(initial_images, initial_imu, gates),
                          clones=9 if use_features else 0, gyro_noise=gyro_noise)
    tracks = Tracks(observer.N) if use_features else None
    directions = Vanishing(gates[0][1]) if vanishing else None
    events = [(t, 0, i) for i, t in enumerate(raw_imu[:, 1])]+[(t, 1, i) for i, t in enumerate(arrival)]
    imu, waiting, samples, stats = [initial[-1, [0, 2, 3, 4, 5, 6, 7]]], deque(), [], []
    last_gate = observer.filter_time
    gap_until = -np.inf
    last_image, jpeg_seen = -np.inf, None
    grid_force = np.median(initial_imu[:, 1:4], axis=0)
    resting = stationary_grid
    for host, camera, i in sorted(events):
        if stop_after is not None and host > warmup+stop_after:
            break
        if host <= warmup:
            continue
        if camera:
            waiting.append(i)
        elif raw_imu[i, 0] > imu[-1][0]:
            if recover and raw_imu[i, 0]-imu[-1][0] > .07:
                gap_until = raw_imu[i, 0]+.35
            imu.append(raw_imu[i, [0, 2, 3, 4, 5, 6, 7]])
            if resting:
                resting = np.linalg.norm(imu[-1][4:7]) < .02 and np.linalg.norm(imu[-1][1:4]-grid_force) < .09
        while waiting and capture[waiting[0]] <= imu[-1][0]:
            frame = waiting.popleft()
            t = capture[frame]
            if t <= observer.filter_time:
                continue
            if gap_safe:
                compressed = jpeg[offsets[frame]:offsets[frame+1]]
                same = np.array_equal(compressed, jpeg_seen)
                after_gap = t-last_image > .1
                last_image, jpeg_seen = t, compressed
                # After a delivery stall, the first JPEG may describe the old scene.
                if same or after_gap:
                    continue
            start = perf_counter()
            advance(observer, t, np.asarray(imu), recover=recover)
            while len(imu) > 2 and imu[1][0] < t:
                imu.pop(0)
            frame_image = image(frame)
            before = observer.state()
            n_lines = directions.update(observer, frame_image, t) if directions else 0
            reacquiring = recover and (t < gap_until or t-last_gate > .22)
            n_gate, has_range = gate_update(observer, frame_image, gates, rim, reacquiring, gap_safe, range_pixels, range_quality)
            if resting:
                H = np.zeros((6, observer.dim_err))
                H[:3, :3] = H[3:, 6:9] = np.eye(3)
                observer.update(np.zeros(6), observer.state()[[0, 1, 2, 7, 8, 9]], H, np.full(6, .01))
            after_gate = observer.state()
            n_tracks = tracks.update(t, frame_image, observer, use_features) if tracks else 0
            after_track = observer.state()
            if camera_observer is not None:
                camera_observer(frame_image, t, host, after_track, observer.covs()[:6, :6])
            fresh_anchor = has_range if gap_safe else n_gate > 0
            if fresh_anchor:
                last_gate = t
            gate_angle = (Rotation.from_quat(after_gate[3:7])*Rotation.from_quat(before[3:7]).inv()).as_rotvec()
            track_angle = (Rotation.from_quat(after_track[3:7])*Rotation.from_quat(after_gate[3:7]).inv()).as_rotvec()
            stats.append((t, host, n_gate, n_tracks, perf_counter()-start,
                          *np.degrees(gate_angle), *np.degrees(track_angle),
                          *(after_gate[:3]-before[:3]), *(after_track[:3]-after_gate[:3]), n_lines))
        if not camera:
            state = observer.state()
            t = imu[-1][0]
            advance(observer, t, np.asarray(imu), state)
            samples.append((t, *state[:10], last_gate, host))
    name = 'rednose' if use_features else 'rednose-gates'
    if gap_safe:
        name += '-gap-safe'
    elif recover:
        name += '-reacquire'
    if camera_offset:
        name += f'-ts{camera_offset*1000:+g}'
    if rendered_opening:
        name += '-rendered'
    if vanishing:
        name += '-lines'
    if stationary_grid:
        name += '-grid'
    if range_pixels:
        name += f'-range{range_pixels:g}px'
    if center_delta:
        name += f'-center{center_delta:+g}'
    if range_quality:
        name += '-clean-range'
    if gyro_noise != .038:
        name += f'-gyro{gyro_noise:g}'
    if track_path is not None:
        name += f'-{track_path.stem}'
    if stop_after is not None:
        name += '-prefix'
    np.savez_compressed(directory/f'{name}-pose.npz', pose=samples, camera=stats)
    stats = np.asarray(stats)
    print(f'{name} {directory.name}: {len(samples)} IMU outputs, {int(stats[:, 3].sum())} eligible short tracks, '
          f'camera compute p95 {np.quantile(stats[:, 4], .95)*1000:.1f} ms', flush=True)


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('--gates-only', action='store_true')
    parser.add_argument('--reacquire', action='store_true')
    parser.add_argument('--stop-after', type=float)
    parser.add_argument('--gap-safe', action='store_true', help='reject stale frames and keep reacquiring until range is observed')
    parser.add_argument('--camera-offset-ms', type=float, default=0., help='constant exposure-time correction from camera/gyro calibration')
    parser.add_argument('--rendered-opening', action='store_true', help='use the specified 1.50 m aperture for projection')
    parser.add_argument('--vanishing', action='store_true', help='use straight background edges to constrain orientation')
    parser.add_argument('--stationary-grid', action='store_true', help='constrain the fixed grid pose until IMU detects movement')
    parser.add_argument('--range-pixels', type=float, default=0., help='common edge scale error in pixels')
    parser.add_argument('--center-delta', type=float, default=0., help='pixel-center convention offset')
    parser.add_argument('--range-quality', action='store_true', help='use stronger range when all four rim edges are tracked')
    parser.add_argument('--gyro-noise', type=float, default=.038, help='attitude process diffusion at full IMU cadence')
    args = parser.parse_args()
    replay(args.directory, not args.gates_only, args.reacquire, args.stop_after, args.gap_safe, args.camera_offset_ms/1000.,
           args.rendered_opening, args.vanishing, args.stationary_grid, args.range_pixels, args.center_delta,
           args.range_quality, args.gyro_noise)
