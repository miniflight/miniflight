"""Fly the planned R1 reference with the arrival-order Rednose gate estimator."""

import argparse
import base64
from collections import deque
from dataclasses import asdict, replace
import gzip
import json
from pathlib import Path
from queue import SimpleQueue
from threading import Thread
from time import monotonic, perf_counter

import cv2
import numpy as np
from scipy.spatial.transform import Rotation
from pymavlink.dialects.v20 import common as mavlink

from common.math import Quaternion
from miniflight import vehicle
from miniflight.state import Attitude, Frame, ImuSample, Motion, Ned
from target.aigp.client import Packet, TrackInfo, _Track
from target.aigp.controllers.r1_beautiful import AttitudePhase
from target.aigp.controllers.r1_motors import Controller as MotorPilot
from target.aigp.experiments.flight import check, rollout

from mapped import K, gate_points
from rednose_model import PoseFilter, integrate
from rednose_replay import advance, gate_update, inertial_intervals, initial_pose
from rim import edges
from vanishing import Vanishing
from visual_clock import camera_clock


REFERENCE = Path('test/fixtures/vq1_r1_free_26s.npz')


class NoVisualAnchor(ValueError):
    """The startup window did not establish a camera and IMU anchor."""


class Observer:
    """The worker owns the filter. The motor thread reads copied corrections."""

    warmup_seconds = 1.

    def __init__(self, queue, precision=False):
        self.queue = queue
        self.precision = precision
        self.filter = None
        self.gates, self.warmup, self.origin = None, None, None
        self.samples, self.frames = [], deque()
        self.superseded_frames = 0
        self.imu = []
        self.snapshot, self.error = None, None
        self.camera_stats = []
        self.camera_stages = []
        self.gap_until = self.previous_time = -np.inf
        self.previous_image = None

    def for_new_clock(self, queue):
        observer = type(self)(queue, self.precision)
        if self.gates:
            observer.gates, observer.rim = self.gates, self.rim
            observer.lines = Vanishing(self.gates[0][1])
        return observer

    def run(self):
        try:
            while True:
                events = [self.queue.get()]
                events.extend(self.queue.get_nowait() for _ in range(self.queue.qsize()))
                finished = events[-1] is None
                if finished:
                    events.pop()
                for event in events:
                    self.observe(*event)
                if self.filter is not None:
                    self.correct_ready_frames()
                if finished:
                    return
        except Exception as exc:
            self.error = exc

    def observe(self, host, observation):
        if isinstance(observation, TrackInfo):
            opening = json.loads(Path(__file__).with_name('opening.json').read_text())
            opening.update(opening_width_m=1.50, opening_height_m=1.50)
            gates = gate_points([asdict(gate) for gate in observation.gates], opening)
            if self.gates is None:
                self.gates = gates
                self.rim = list(edges(gates, .15732050896))
                self.lines = Vanishing(gates[0][1])
            elif len(self.gates) != len(gates) or any(a != b or not np.array_equal(p, q) for (a, p), (b, q) in zip(self.gates, gates)):
                raise ValueError('native GATE_INFO differs from the course used for the reference')
        elif isinstance(observation, Frame):
            self.frames.append(observation)
        elif isinstance(observation, ImuSample):
            if self.filter is None:
                self.samples.append(observation)
            else:
                reading = imu_reading(observation)
                if reading[0] > self.imu[-1][0]:
                    if reading[0]-self.imu[-1][0] > .07:
                        self.gap_until = reading[0]+.35
                    self.imu.append(reading)
                    if self.resting:
                        self.resting = np.linalg.norm(reading[4:7]) < .02 and np.linalg.norm(reading[1:4]-self.grid_force) < .09
        if self.filter is None:
            if not self.ready() or not self.samples or not self.frames:
                return
            if self.warmup is None:
                self.warmup = max(self.samples[0].received_at, self.frames[0].received_at)+self.warmup_seconds
            if host < self.warmup:
                return
            try:
                self.initialize()
            except NoVisualAnchor:
                self.origin = self.warmup = None
                self.samples.clear()
                self.frames.clear()

    def ready(self):
        return bool(self.gates)

    def initial_filter(self, pictures, readings):
        rotation, accel, gyro = initial_pose((item.bgr for item in pictures[::3]), readings, self.gates)
        return PoseFilter(readings[-1, 0], rotation, accel, gyro, clones=0,
                          gyro_noise=.007 if self.precision else .038)

    def initialize(self):
        prefix = [item for item in self.samples if item.received_at <= self.warmup]
        pictures = [item for item in self.frames if item.received_at <= self.warmup]
        if not prefix or not pictures or self.warmup-min(prefix[-1].received_at, pictures[-1].received_at) > .25:
            raise NoVisualAnchor('camera and IMU must both be current at the end of warmup')
        imu = np.array([(item.time, item.received_at, *item.acceleration, *item.gyro) for item in prefix])
        ns = np.array([item.time_ns for item in pictures], dtype=np.int64)
        receipt = np.array([item.received_at for item in pictures])
        self.origin = (ns[0], camera_clock(ns, receipt, imu, self.warmup)[0]-.008)
        readings = imu[:, [0, 2, 3, 4, 5, 6, 7]]
        self.filter = self.initial_filter(pictures, readings)
        self.resting = True
        self.grid_position = self.filter.state()[:3]
        self.grid_force = np.median(readings[:, 1:4], axis=0)
        self.imu = [imu_reading(item) for item in self.samples if item.time >= self.filter.filter_time]
        self.frames = deque(item for item in self.frames if item.received_at > self.warmup)
        self.samples.clear()
        self.last_gate = self.filter.filter_time
        self.publish()

    def capture_time(self, frame):
        return (frame.time_ns-self.origin[0])*1e-9+self.origin[1]

    def publish(self, geometry=None):
        self.snapshot = (self.filter.filter_time, self.filter.state(), self.last_gate, monotonic(), geometry)

    def gate_measurements(self, image, stamp, recovering):
        return gate_update(self.filter, image, self.gates, self.rim, recovering, True, 3.,
                           range_quality=self.precision)

    def correct_ready_frames(self):
        # Ingest every inertial interval. A newer eligible image supersedes an older one.
        while len(self.frames) > 1 and self.capture_time(self.frames[1]) <= self.imu[-1][0]:
            self.frames.popleft()
            self.superseded_frames += 1
        while self.frames and self.capture_time(self.frames[0]) <= self.imu[-1][0]:
            frame = self.frames.popleft()
            stamp = self.capture_time(frame)
            if stamp <= self.filter.filter_time:
                continue
            if np.array_equal(frame.bgr, self.previous_image):
                continue
            frame_gap = stamp-self.previous_time > .1
            self.previous_time, self.previous_image = stamp, frame.bgr
            start = perf_counter()
            advance(self.filter, stamp, np.asarray(self.imu), recover=True)
            while len(self.imu) > 2 and self.imu[1][0] < stamp:
                self.imu.pop(0)
            propagated = perf_counter()
            # Include the first usable image even if it arrives after the gap window.
            n_lines = (self.lines.update(self.filter, frame.bgr, stamp, recover=self.lines.last < self.gap_until)
                       if self.lines else 0)
            oriented = perf_counter()
            recovering = frame_gap or stamp < self.gap_until or stamp-self.last_gate > .22
            n_gate, has_range = self.gate_measurements(frame.bgr, stamp, recovering)
            self.camera_stages.append((stamp, propagated-start, oriented-propagated, perf_counter()-oriented))
            if self.resting:
                H = np.zeros((6, self.filter.dim_err))
                H[:3, :3] = H[3:, 6:9] = np.eye(3)
                self.filter.update(np.r_[self.grid_position, np.zeros(3)],
                                   self.filter.state()[[0, 1, 2, 7, 8, 9]], H, np.full(6, .01))
            if has_range:
                self.last_gate = stamp
            self.camera_stats.append((stamp, frame.received_at, n_gate, n_lines, perf_counter()-start, monotonic()))
            self.publish()


def imu_reading(sample):
    return (sample.time, *sample.acceleration, *sample.gyro)


class InertialPrediction:
    """Propagate each IMU interval once until vision publishes a new correction."""

    def __init__(self):
        self.source = None
        self.time = None
        self.state = None

    def at_latest_sample(self, snapshot, history):
        corrected_at, estimate = snapshot[:2]
        stamp = history[-1][0]
        if self.time is not None and stamp < self.time:
            raise RuntimeError('IMU clock regressed during pose prediction')
        if stamp < corrected_at:
            raise RuntimeError('visual correction is newer than the available IMU')
        if self.source is not snapshot:
            self.source = snapshot
            self.time = corrected_at
            self.state = estimate.copy()
        if self.time < stamp:
            for end, reading, _ in inertial_intervals(self.time, stamp, np.asarray(history)):
                integrate(self.state, end-reading[0], reading)
            self.time = stamp
        return self.state

    def sweep_start(self, earlier, history):
        """Recover the start of a sweep in the camera revision used at its end."""
        corrected_at, estimate = self.source[:2]
        stamp = max(earlier, corrected_at)
        if not history[0][0] <= corrected_at <= stamp < self.time:
            return None
        state = estimate.copy()
        for end, reading, _ in inertial_intervals(corrected_at, stamp, np.asarray(history)):
            integrate(state, end-reading[0], reading)
        return stamp, state[:3], state[7:10]


class VisionClient:
    contact_severity = 2
    motion_source = 'Rednose camera + IMU pose with GATE_INFO'
    motion_clock = 'HIGHRES_IMU.time_usec / 1000000 (seconds)'
    observer_type = Observer
    sensor_types = (ImuSample, Frame, TrackInfo)

    def __init__(self, *args, precision=False, **kwargs):
        super().__init__(*args, **kwargs)
        self.queue = SimpleQueue()
        self.observer = self.observer_type(self.queue, precision)
        self.worker = Thread(target=self.observer.run, name='rednose', daemon=True)
        self.history = deque()
        self.samples = []
        self.prediction = InertialPrediction()
        self.corrections = []
        self.arming_requested = False
        self.clock_resets = []

    def connect(self):
        super().connect()
        self.worker.start()

    def disconnect(self):
        self.queue.put(None)
        if self.worker.is_alive():
            self.worker.join(timeout=2.)
        super().disconnect()

    def arm(self):
        self.arming_requested = True
        return super().arm()

    def reset_sensor_clock(self, time):
        if self.arming_requested:
            raise RuntimeError('IMU clock restarted after arming')
        self.clock_resets.append((self.history[-1][0], time))
        self.queue.put(None)
        self.worker.join(timeout=2.)
        if self.worker.is_alive():
            raise TimeoutError('camera worker did not stop at the clock reset')
        self.queue = SimpleQueue()
        self.observer = self.observer.for_new_clock(self.queue)
        self.worker = Thread(target=self.observer.run, name='rednose', daemon=True)
        self._camera = type(self._camera)()
        self.history.clear()
        self.samples.clear()
        self.corrections.clear()
        self.prediction = InertialPrediction()
        self.worker.start()

    def read(self, timeout=1.):
        raw = super().read(timeout)
        reset = False
        for packet in self.packets:
            observation = packet.decoded
            if isinstance(observation, ImuSample):
                if self.history and observation.time < self.history[-1][0]:
                    self.reset_sensor_clock(observation.time)
                    reset = True
                self.history.append(imu_reading(observation))
            if isinstance(observation, self.sensor_types) and not (reset and isinstance(observation, Frame)):
                self.queue.put((packet.received_at, observation))
        if self.observer.error is not None:
            raise RuntimeError('camera estimator stopped') from self.observer.error
        # Keep native safety events on the runner path. The estimator queue only sees sensors.
        self.packets = tuple(p for p in self.packets if isinstance(p.data, bytes) or
                             isinstance(p.decoded, self.sensor_types) or p.data.get_type() == 'COMMAND_ACK' or
                             (self.arming_requested and p.data.get_type() == 'COLLISION'
                              and p.data.threat_level >= self.contact_severity))
        if reset:
            self.packets = tuple(p for p in self.packets if not isinstance(p.data, bytes))
        self.state = replace(raw, motion=None, attitude=None, frame=self._camera.latest)
        snapshot = self.observer.snapshot
        if self.history and snapshot is not None:
            correction, estimate, gate_stamp, published = snapshot[:4]
            stamp = self.history[-1][0]
            while len(self.history) > 2 and self.history[1][0] <= correction:
                self.history.popleft()
            if self.prediction.source is not snapshot:
                self.corrections.append((correction, published, *estimate[:16]))
            state = self.prediction.at_latest_sample(snapshot, self.history)
            roll, pitch, yaw = Rotation.from_quat(state[3:7]).as_euler('xyz')
            motion = Motion(stamp, raw.received_at, Ned(*state[:3]), Ned(*state[7:10]))
            attitude = Attitude(stamp, raw.received_at, roll, pitch, yaw, raw.gyro)
            self.state = replace(self.state, motion=motion, attitude=attitude)
            self.samples.append((stamp, *state[:10], gate_stamp, monotonic(), correction, published))
        return self.state


class FusedRotation:
    def update(self, _):
        attitude = vehicle.state.attitude
        self.time = attitude.time
        self.rotation = Quaternion.from_euler(attitude.roll, attitude.pitch, attitude.yaw)
        return self.rotation


class EstimatedPilot(MotorPilot):
    def update(self, telemetry, frames, race_state):
        state = vehicle.state
        if state is None or state.motion is None or state.attitude is None or race_state is None:
            return None
        if self.position.attitude_estimate is None:
            self.position.target_yaw = state.attitude.yaw
            self.position.attitude_estimate = FusedRotation()
            self.position.attitude_phase = AttitudePhase.TRACKING
        clock = replace(race_state, gate_centers=(), active_gate_index=0)
        return super().update(telemetry, frames, clock)


def use_estimates(make):
    def create():
        reference = make()
        return EstimatedPilot(kp=reference.kp, ki=reference.ki, position=reference.position)
    return create


def saved_course():
    source = Path(__file__).with_name('rednose-fresh')/'lap-04.jsonl.gz'
    decoder, course, packets = mavlink.MAVLink(None), _Track(), []
    with gzip.open(source, 'rt') as stream:
        for line in stream:
            row = json.loads(line)
            if row.get('event') != 'call' or row.get('name') != 'poll':
                continue
            for raw in row.get('result', ()):
                if raw['camera']:
                    continue
                for message in decoder.parse_buffer(base64.b64decode(raw['wire'])) or ():
                    kind = message.get_type()
                    if kind == 'DATA_TRANSMISSION_HANDSHAKE':
                        course.start(message)
                    elif kind == 'ENCAPSULATED_DATA' and message.data[0] == 2:
                        received = course.receive(message, raw['received_at'])
                        if received is not None:
                            return (*packets, Packet(message, raw['received_at']))
                    else:
                        continue
                    packets.append(Packet(message, raw['received_at']))
    raise ValueError('No complete GATE_INFO transfer in the reference capture')


def fly(trace, finish_before, precision=False, light_capture=False):
    from target.aigp.experiments.recording import ProcessClient

    clients = []

    class Client(VisionClient, ProcessClient):
        def __init__(self, *args, **kwargs):
            if light_capture:
                kwargs['preview'] = None
            super().__init__(*args, precision=precision, **kwargs)
            clients.append(self)

    cv2.setNumThreads(1)
    K[:2, 2] = (319.5, 179.5) if precision else (320., 180.)
    try:
        result, simulator, _, _ = rollout('r1_motors', trace, camera=True, reference=REFERENCE, offscreen=True,
                                          course_packets=saved_course(), timesync=True,
                                          client_type=Client, wrap_controller=use_estimates, finish_before=finish_before,
                                          record_camera=not light_capture)
        check('r1_motors', trace, result, simulator.client, True, False)
        print(json.dumps(asdict(result)), flush=True)
    finally:
        if clients and clients[-1].samples:
            client = clients[-1]
            np.savez_compressed(trace.parent/'live-rednose-pose.npz', pose=client.samples, camera=client.observer.camera_stats)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('trace', type=Path)
    parser.add_argument('--finish-before', type=float, default=34.)
    parser.add_argument('--precision', action='store_true', help='pixel-centered projection and precision weighting for the 26 s reference')
    parser.add_argument('--light-capture', action='store_true', help='keep pose and wire telemetry without recording the camera payload')
    args = parser.parse_args()
    fly(args.trace, args.finish_before, args.precision, args.light_capture)
