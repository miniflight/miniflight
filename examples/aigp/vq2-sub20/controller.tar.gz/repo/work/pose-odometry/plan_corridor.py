"""Search fly-through trajectories over a carried map."""

import argparse
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

from miniflight.position import GRAVITY
from refine_gate_map import read_packet_map
from target.aigp.controllers.r1_beautiful import CONFIG


def thrust_demand(config, acceleration, velocity):
    """Approximate the thrust acceleration needed after horizontal drag."""
    if config.body_resistance_per_m is None:
        return acceleration
    drag = float(np.mean(config.body_resistance_per_m[:2]))
    demand = acceleration.copy()
    horizontal = velocity[..., :2]
    demand[..., :2] += drag*np.linalg.norm(horizontal, axis=-1, keepdims=True)*horizontal
    return demand


def corridor(course, launch, config, *, with_remaining_time=False, entry_normal=None, gate_speed=None):
    """Pick gate speeds and leg durations. Optionally return the cost of each gate speed."""
    points = np.vstack((launch, course[:, :3]))
    legs = np.diff(points, axis=0)
    lengths = np.linalg.norm(legs, axis=1)
    if not len(lengths) or np.any(lengths == 0.) or config.max_speed <= 0.:
        raise ValueError('A corridor needs distinct waypoints and a positive speed limit')
    normals = np.vstack((legs[0]/lengths[0] if entry_normal is None else entry_normal,
                         Rotation.from_quat(course[:, 3:]).apply([1., 0., 0.])))
    speeds = config.max_speed*np.linspace(0., 1., 13)
    if gate_speed is not None:
        gate_speed = np.minimum(np.asarray(gate_speed), config.max_speed)
        if gate_speed.shape != (len(points),) or not np.all(np.isfinite(gate_speed)) or np.any(gate_speed < 0.):
            raise ValueError('Gate pace must cover the planned corridor')
        speeds = np.union1d(speeds, gate_speed)
    leg_times = []
    fraction = np.linspace(0., 1., 17)[:, None, None, None, None]
    horizontal_limit = config.max_horizontal_acceleration or config.max_acceleration

    for index, (leg, distance, outgoing, incoming) in enumerate(zip(legs, lengths, normals[:-1], normals[1:], strict=True)):
        duration = np.linspace(distance/config.max_speed, distance/config.max_speed+5., 101)[:, None, None, None]
        start_v = speeds[:, None, None]*outgoing
        end_v = speeds[None, :, None]*incoming
        start_a = 6.*leg/duration**2-(4.*start_v+2.*end_v)/duration
        end_a = -6.*leg/duration**2+(2.*start_v+4.*end_v)/duration
        velocity = start_v+fraction*duration*(start_a+.5*fraction*(end_a-start_a))
        thrust = thrust_demand(config, start_a+fraction*(end_a-start_a), velocity)
        down = thrust[..., 2]
        within_force = np.all((np.linalg.norm(thrust[..., :2], axis=-1)
                               <= np.minimum(horizontal_limit, (GRAVITY-down)*np.tan(config.max_tilt)))
                              & (np.abs(down) <= config.max_acceleration), axis=0)
        within_speed = np.max(np.linalg.norm(velocity, axis=-1), axis=0) <= config.max_speed+1.e-9
        forward = np.min(velocity @ (leg/distance), axis=0) >= -1.e-6
        if gate_speed is not None:
            within_speed &= (speeds[:, None] <= gate_speed[index]) & (speeds[None, :] <= gate_speed[index+1])
        leg_times.append(np.min(np.where(within_force & within_speed & forward, duration[..., 0], np.inf), axis=0))

    remaining = np.zeros((len(points), len(speeds)))
    next_speed = np.empty((len(legs), len(speeds)), dtype=int)
    for i in range(len(legs)-1, -1, -1):
        total = leg_times[i]+remaining[i+1]
        next_speed[i] = total.argmin(axis=1)
        remaining[i] = total.min(axis=1)
    first = 0 if entry_normal is None else int(remaining[0].argmin())
    if not np.isfinite(remaining[0, first]):
        raise ValueError('No trajectory fits the flight envelope on the estimated map')

    profile = [first]
    durations = []
    for times, choices in zip(leg_times, next_speed, strict=True):
        following = choices[profile[-1]]
        durations.append(times[profile[-1], following])
        profile.append(following)
    result = points, normals*speeds[profile, None], np.array(durations)
    return (*result, (speeds, remaining)) if with_remaining_time else result


def leg_reference(origin, center, v0, v1, duration, position):
    """Find the nearby position, velocity and acceleration on a Hermite leg."""
    leg = center-origin
    offset = position-origin
    start = 6.*leg/duration**2-(4.*v0+2.*v1)/duration
    end = -6.*leg/duration**2+(2.*v0+4.*v1)/duration
    jerk = (end-start)/duration
    t = duration*np.clip((offset@leg)/max(.01, leg@leg), 0., 1.)
    for _ in range(3):
        delta = t*(v0+t*(.5*start+t*jerk/6.))-offset
        velocity = v0+t*(start+.5*t*jerk)
        acceleration = start+t*jerk
        curvature = velocity@velocity+delta@acceleration
        if curvature <= .01:
            break
        t = np.clip(t-(delta@velocity)/curvature, 0., duration)
    return (origin+t*(v0+t*(.5*start+t*jerk/6.)),
            v0+t*(start+.5*t*jerk), start+t*jerk)


if __name__ == '__main__':
    from dataclasses import replace

    import matplotlib.pyplot as plt
    from matplotlib.collections import LineCollection

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('flight', type=Path)
    parser.add_argument('plot', type=Path)
    args = parser.parse_args()
    course = read_packet_map(args.flight/'input-map.json')
    with np.load(args.flight/'learned-course.npz', allow_pickle=False) as capture:
        launch = capture['pose'][0, 1:4]
    fig, (top, profile) = plt.subplots(2, 1, figsize=(10., 4.7), layout='constrained', height_ratios=[1.15, 1.])
    for cap, color in [(3.2, '#187a88'), (4., '#985839')]:
        points, velocities, times = corridor(course, launch, replace(CONFIG, max_speed=cap))
        u = np.linspace(0., 1., 101)[None, :, None]
        leg = np.diff(points, axis=0)[:, None, :]
        a, b = velocities[:-1, None, :], velocities[1:, None, :]
        duration = times[:, None, None]
        curve = points[:-1, None, :]+(3.*u**2-2.*u**3)*leg+duration*(u*(1.-u)**2*a-u**2*(1.-u)*b)
        velocity = (6.*u-6.*u**2)*leg/duration+(1.-4.*u+3.*u**2)*a+(3.*u**2-2.*u)*b
        peak = np.linalg.norm(velocity, axis=-1).max()
        if peak > cap+.002:
            raise ValueError(f'Resampled trajectory exceeds its speed cap by {peak-cap:.3f} m/s')
        print(f'{cap:.1f} m/s cap, {times.sum():.3f} s through {len(course)} estimated gates, '
              f'{peak:.3f} m/s peak')
        top.add_collection(LineCollection(curve[:, :, :2], colors=color, linewidths=1.4, alpha=.65))
        profile.plot(np.arange(len(points)), np.linalg.norm(velocities, axis=1), '.-', color=color,
                     label=f'{cap:.1f} m/s cap · {times.sum():.1f} s')
    top.scatter(course[:, 0], course[:, 1], s=15, color='#202526')
    top.set(xlabel='Forward from gate 1 (m)', ylabel='Right from gate 1 (m)', aspect='equal')
    profile.set(xlabel='Gate', ylabel='Crossing speed (m/s)', xticks=np.arange(1, len(points)))
    profile.legend(frameon=False)
    for axis in (top, profile):
        axis.grid(alpha=.17)
    fig.suptitle('Computed corridor through the learned map\nCubic motion model · time estimates from the solver', x=.016, ha='left')
    fig.savefig(args.plot, dpi=145)
