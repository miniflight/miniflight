"""Fit one gate absent from the track given to the visual-inertial observer."""

import argparse
import json
from pathlib import Path

import cv2
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

from mapped import CAMERA_FROM_BODY, K, apertures, gate_points
from rednose_model import pixel_factor
from rednose_replay import replay, visible
from rim import edges, probes
from target.aigp.experiments.gate_pose import estimate


OPENING = .75*np.array([[-1., 0., -1.], [1., 0., -1.], [1., 0., 1.], [-1., 0., 1.]])
SQUARE_FROM_GATE = Rotation.from_matrix([[1., 0., 0.], [0., 0., -1.], [0., 1., 0.]])


def image_points(world, position, camera):
    camera_space = (world-position) @ camera.swapaxes(-2, -1)
    pixel = camera_space @ K.T
    return pixel[..., :2]/np.maximum(.05, pixel[..., 2:3]), camera_space[..., 2]


def opening_size(quad):
    return np.median(np.linalg.norm(np.roll(quad, 1, axis=0)-quad, axis=1))


class Mapper:
    def __init__(self, track, partial):
        opening = json.loads(Path(__file__).with_name('opening.json').read_text())
        opening.update(opening_width_m=1.50, opening_height_m=1.50)
        self.known = dict(gate_points(track, opening))
        self.previous = self.known[1].mean(axis=0)
        route = self.known[3].mean(axis=0)-self.previous
        self.interval = np.linalg.norm(route)
        self.forward = route/self.interval
        self.fit = None
        self.first = None
        self.partial = partial
        self.last_position = None
        self.positions, self.cameras, self.pixels, self.sigmas = [], [], [], []
        self.line_geometry, self.line_positions, self.line_cameras, self.line_pixels, self.line_sigmas = [], [], [], [], []
        self.history = []

    def seed(self, position, camera, outline):
        hypotheses = []
        for candidate in estimate(outline, 1.5, K):
            center = position+camera.T @ candidate['translation_camera_m']
            progress = (center-self.previous) @ self.forward
            if not 2. < progress < self.interval-2.:
                continue
            cam_from_square = Rotation.from_rotvec(candidate['rotation_vector_rad'])
            world_from_gate = Rotation.from_matrix(camera.T)*cam_from_square*SQUARE_FROM_GATE
            if world_from_gate.apply([0., 0., 1.])[2] < .85:
                continue
            residual = candidate['reprojection_coordinate_rmse_px']
            tilt = np.linalg.norm(world_from_gate.apply([0., 0., 1.])-[0., 0., 1.])
            hypotheses.append((residual+.7*tilt, np.r_[center, world_from_gate.as_rotvec()]))
        if hypotheses:
            return min(hypotheses, key=lambda item: item[0])[1]

    def association(self, position, camera, outlines):
        known_screen = []
        for world in self.known.values():
            projection, depth = image_points(world, position, camera)
            if min(depth) > 1.:
                known_screen.append((projection.mean(axis=0), opening_size(projection)))
        candidates = []
        for pixels in outlines:
            center, span = pixels.mean(axis=0), opening_size(pixels)
            if span < 9. or any(np.linalg.norm(center-c) < max(6., .55*w) and .45*w <= span <= 2.1*w
                                 for c, w in known_screen):
                continue
            if self.fit is None:
                seed = self.seed(position, camera, pixels)
                if seed is not None:
                    candidates.append((-span, pixels, seed))
                continue
            world = Rotation.from_rotvec(self.fit[3:]).apply(OPENING)+self.fit[:3]
            projection, depth = image_points(world, position, camera)
            if min(depth) <= 1.:
                continue
            ordered = [np.roll(q, i, axis=0) for q in (pixels, pixels[::-1]) for i in range(4)]
            corners = min(ordered, key=lambda q: np.linalg.norm(q-projection))
            error = np.sqrt(np.mean((corners-projection)**2))
            if error < max(5., .24*span):
                candidates.append((error, corners, self.fit))
        if candidates:
            return min(candidates, key=lambda item: item[0])[1:]

    def __call__(self, image, stamp, host, state, covariance):
        position = state[:3]
        if (position-self.previous) @ self.forward < -.5:
            return
        if self.last_position is not None and np.linalg.norm(position-self.last_position) < .60:
            return
        attitude = Rotation.from_quat(state[3:7])
        camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
        match = self.association(position, camera, apertures(image))
        if match is not None:
            pixels, self.fit = match
            self.positions.append(position.copy())
            self.cameras.append(camera)
            self.pixels.append(pixels)
            point = Rotation.from_rotvec(self.fit[3:]).apply(OPENING)+self.fit[:3]
            jacobian = np.array([pixel_factor(q, position, attitude)[1] for q in point])
            self.sigmas.append(np.sqrt(.8**2+np.einsum('nki,ij,nkj->nk', jacobian, covariance, jacobian)))
            if self.first is None:
                self.first = self.fit.copy()
        elif self.partial and self.fit is not None:
            rotation = Rotation.from_rotvec(self.fit[3:])
            gate = rotation.apply(OPENING)+self.fit[:3]
            rim = edges([(2, gate)], .15732050896)
            before = len(self.line_geometry)
            for ident, world, pixels in probes(image, list(rim), position, camera, near=1.6, dark_opening=True):
                if not visible(position, world, ident, self.known.items()):
                    continue
                self.line_geometry.append(rotation.inv().apply(world-self.fit[:3]))
                self.line_positions.append(position.copy())
                self.line_cameras.append(camera)
                self.line_pixels.append(pixels)
                depth = np.mean((world-position) @ camera[2])
                self.line_sigmas.append(np.sqrt(.9**2 + K[0, 0]**2*(np.trace(covariance[:3, :3])/depth**2
                                                                    + np.trace(covariance[3:, 3:]))/3.))
            if len(self.line_geometry) == before:
                return
        else:
            return
        self.last_position = position.copy()
        self.fit = self.refine()
        self.history.append((stamp, host, len(self.history)+1, *self.fit, len(self.line_geometry)))

    def refine(self):
        if len(self.positions) < 2 and not self.line_geometry:
            return self.fit
        centers, cameras, points, sigmas = map(np.asarray, (self.positions, self.cameras, self.pixels, self.sigmas))
        line, position, camera, pixels, noise = map(np.asarray, (self.line_geometry, self.line_positions,
                                                                  self.line_cameras, self.line_pixels, self.line_sigmas))

        def residual(value):
            rotation = Rotation.from_rotvec(value[3:])
            gate = rotation.apply(OPENING)+value[:3]
            p, _ = image_points(gate[None], centers[:, None], cameras)
            error = ((p-points)/sigmas).ravel()
            if len(line):
                world = rotation.apply(line.reshape(-1, 3)).reshape(line.shape)+value[:3]
                endpoint, _ = image_points(world, position[:, None], camera)
                tangent = endpoint[:, 1]-endpoint[:, 0]
                normal = np.stack((-tangent[:, 1], tangent[:, 0]), axis=1)
                normal /= np.maximum(.01, np.linalg.norm(normal, axis=1, keepdims=True))
                miss = np.einsum('nij,nj->ni', pixels-endpoint[:, :1], normal)/noise[:, None]
                error = np.r_[error, miss.ravel()]
            if self.partial:
                # R1 uses upright gates. Leave yaw free.
                error = np.r_[error, (rotation.apply([0., 0., 1.])-[0., 0., 1.])/.035]
            return error

        return least_squares(residual, self.fit, loss='soft_l1', max_nfev=30).x


def run(directory, track_path, stop_after=None, partial=False):
    track = json.loads(track_path.read_text())
    if {gate['id'] for gate in track} != {0, 1, 3, 4, 5}:
        raise ValueError('This replay requires all five anchors and gate 3 withheld')
    mapper = Mapper(track, partial)
    replay(directory, False, stop_after=stop_after, gap_safe=True, camera_offset=-.008, rendered_opening=True,
           vanishing=True, stationary_grid=True, range_pixels=3., track_path=track_path, camera_observer=mapper)
    if mapper.first is None:
        raise ValueError('No hidden opening acquired')
    suffix = '-partial' if partial else ''
    suffix += '-prefix' if stop_after is not None else ''
    np.savez_compressed(directory/f'hidden-gate{suffix}.npz', estimates=mapper.history, first=mapper.first)
    print(f'{directory.name}: {len(mapper.history)} views, final centre {np.round(mapper.fit[:3], 3)}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('track', type=Path)
    parser.add_argument('--stop-after', type=float)
    parser.add_argument('--partial', action='store_true')
    args = parser.parse_args()
    run(args.directory, args.track, args.stop_after, args.partial)
