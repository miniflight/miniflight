"""Image points on gate opening edges, including edges clipped by the image."""

import cv2
import numpy as np

from mapped import K


# VADR-TS-002 §3.7, metres.
GATE_DEPTH = .26
GATE_HALF_WIDTH = 1.35
APERTURE_HALF_WIDTH = .75
CHASSIS_RADIUS = np.linalg.norm([.14, .14, .08])  # VADR-TS-003 §3.6


def crossing_clearance(before, after):
    """Return the plane intercept and body clearance in gate coordinates."""
    step = after-before
    slope = step[1:]/step[0]
    intercept = before[1:]-before[0]*slope
    swept = np.abs(intercept)+.5*GATE_DEPTH*np.abs(slope)
    return intercept, APERTURE_HALF_WIDTH-CHASSIS_RADIUS-np.max(swept)


def edges(gates, thickness):
    for ident, corners in gates:
        right = corners[1]-corners[0]
        down = corners[3]-corners[0]
        normal = np.cross(right, down)
        back = normal * (thickness/2 / np.linalg.norm(normal))
        faces = np.stack((corners-back, corners+back))
        yield ident, np.stack((faces, np.roll(faces, -1, axis=1)), axis=2)


def probes(image, rims, position, camera, near=.25, dark_opening=False, tolerance=7.):
    blue, green, red = cv2.split(image.astype(np.float32))
    chroma = red-(blue+green)*.5
    fractions = np.linspace(.13, .87, 12)
    offsets = np.linspace(-tolerance, tolerance, 1+int(round(8*tolerance)))
    height, width = image.shape[:2]
    viewport = (8, 8, width-16, height-16)
    for ident, rim in rims:
        rays = (rim-position) @ camera.T
        center = rays.mean(axis=(0, 1, 2)) @ K.T
        if not near < center[2] <= 31.:
            continue
        center = center[:2]/center[2]
        for segments, vertices in zip(rays.transpose(1, 0, 2, 3), rim.transpose(1, 0, 2, 3), strict=True):
            faces = []
            for segment, world in zip(segments, vertices, strict=True):
                depth = segment[:, 2]
                if max(depth) <= near:
                    continue
                start = int(np.argmin(depth))
                if depth[start] < near:
                    fraction = (near-depth[start])/(depth[1-start]-depth[start])
                    weights = np.eye(2)
                    weights[start, [start, 1-start]] = 1.-fraction, fraction
                    segment, world = weights@segment, weights@world
                q = segment @ K.T
                pixels = q[:, :2]/q[:, 2, None]
                vector = pixels[1]-pixels[0]
                length = np.linalg.norm(vector)
                if length < 13.:
                    continue
                inward = np.array([-vector[1], vector[0]])/length
                inset = (center-pixels[0])@inward
                faces.append((abs(inset), pixels[0], vector, inward*np.sign(inset), world))
            if not faces:
                continue
            _, start, vector, inward, world = min(faces, key=lambda face: face[0])
            inside, first, last = cv2.clipLine(viewport, tuple(np.rint(start).astype(int)),
                                              tuple(np.rint(start+vector).astype(int)))
            if not inside or np.linalg.norm(np.subtract(last, first)) < 13.:
                continue
            ends = (np.array([first, last])-start)@vector/(vector@vector)
            along = ends[0]+fractions*(ends[1]-ends[0])
            origin = start+along[:, None]*vector
            search = origin[:, None, :]+offsets[None, :, None]*inward
            red_profile = cv2.remap(chroma, search[..., 0].astype(np.float32),
                                    search[..., 1].astype(np.float32), cv2.INTER_LINEAR)
            falling = red_profile[:, :-6]-red_profile[:, 6:]
            if dark_opening:
                x, y = search[..., 0].astype(np.float32), search[..., 1].astype(np.float32)
                bright = cv2.remap(green, x, y, cv2.INTER_LINEAR)
                falling[(bright[:, 6:] > 128.) | (red_profile[:, :-6] < 25.)] = 0.
            best = np.argmax(falling-.5*(offsets[3:-3]*7./tolerance)**2, axis=1)
            contrast = falling[np.arange(len(origin)), best]
            shift = offsets[best+3]
            good = contrast > 18.
            if dark_opening:
                # Ink on the gate can look like an edge at a single pixel. Check the opening beyond it.
                inside = origin[:, None, :] + (shift[:, None] + [3., 6., 9.])[..., None]*inward
                values = cv2.remap(chroma, inside[..., 0].astype(np.float32), inside[..., 1].astype(np.float32),
                                   cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
                good &= np.median(values, axis=1) < 25.
            if good.sum() < 4:
                continue
            good &= np.abs(shift-np.median(shift[good])) < 1.8
            if good.sum() >= 4:
                measured = origin[good]+shift[good, None]*inward
                # Two points define a measured line while retaining the edge's span.
                fit = cv2.fitLine(measured.astype(np.float32), cv2.DIST_HUBER, 0, .01, .01).ravel()
                unit, point = fit[:2], fit[2:]
                reach = (measured-point) @ unit
                points = point+np.quantile(reach, [.15, .85])[:, None]*unit
                yield ident, world, points
