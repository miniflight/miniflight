"""Plot full-lap Rednose pose errors and the camera evidence at each gate handoff."""

import json
from pathlib import Path
import sys

from score import monotone
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.transform import Rotation, Slerp


def plot(directory, name):
    with np.load(directory/'truth.npz', allow_pickle=False) as truth:
        position, attitude = monotone(truth['position']), monotone(truth['attitude'])
        begin, end = np.interp(truth['armed'], position[:, 1], position[:, 0])
    with np.load(directory/f'{name}-pose.npz', allow_pickle=False) as estimate:
        poses, camera = monotone(estimate['pose']), estimate['camera']
    heading = Slerp(attitude[:, 0], Rotation.from_euler('xyz', attitude[:, 2:5]))

    def errors(samples):
        pose = samples[(samples[:, 0] >= begin) & (samples[:, 0] <= end)]
        time = pose[:, 0]
        reference = np.array([np.interp(time, position[:, 0], values) for values in position[:, 2:5].T]).T
        reference_q = heading(np.clip(time, attitude[0, 0], attitude[-1, 0]))
        xyz = np.linalg.norm(pose[:, 1:4]-reference, axis=1)
        angle = np.degrees((reference_q.inv()*Rotation.from_quat(pose[:, 4:8])).magnitude())
        return time-begin, xyz, angle

    time, error_position, error_angle = errors(poses)
    camera = camera[(camera[:, 0] >= begin) & (camera[:, 0] <= end)]
    gates = json.loads((directory/'map.json').read_text())
    fig, axes = plt.subplots(3, 1, sharex=True, figsize=(10, 7.4), layout='constrained')
    for gate in gates:
        north = gate['position'][0]
        n = np.flatnonzero((position[:-1, 2] > north) & (position[1:, 2] <= north) & (position[1:, 0] >= begin))
        if n.size:
            i = n[0]
            t = np.interp(north, position[i:i+2, 2][::-1], position[i:i+2, 0][::-1])-begin
            for ax in axes:
                ax.axvline(t, color='#68717b', alpha=.35, linewidth=.8, linestyle='--')
            axes[0].text(t-.1, .95, f'G{gate["id"]+1}', va='top', ha='right', transform=axes[0].get_xaxis_transform(), color='#555d65')
    split = np.flatnonzero(np.diff(time) > .1)+1
    for axis, error, color, unit, label in zip(
            axes, (error_position, error_angle), ('#245889', '#a54d2b'), ('m', '°'),
            ('3D position error (m)', 'Orientation error (°)')):
        for x, y in zip(np.split(time, split), np.split(error, split)):
            axis.plot(x, y, color=color, lw=1.)
        axis.set_ylabel(label)
        axis.set_title(f'MAE {error.mean():.2f} {unit}     P95 {np.quantile(error, .95):.2f} {unit}',
                       loc='left', fontsize=11, color=color, fontweight='bold')
    baseline = directory/'rednose-gates-reacquire-pose.npz'
    if baseline.is_file():
        with np.load(baseline, allow_pickle=False) as data:
            stamp, xyz, angle = errors(monotone(data['pose']))
        split = np.flatnonzero(np.diff(stamp) > .1)+1
        for axis, values, color in zip(axes, (xyz, angle), ('#245889', '#a54d2b')):
            axis.plot([], [], color=color, lw=1., label='Gates + short tracks')
            for i, (x, y) in enumerate(zip(np.split(stamp, split), np.split(values, split))):
                axis.plot(x, y, color='#68717b', lw=.85, alpha=.62, label='Gates only' if not i else None, zorder=1)
            axis.legend(loc='upper left', frameon=False, fontsize=9, ncols=2)
        for annot in axes[0].texts:
            annot.set_y(.83)
    for axis in axes[:2]:
        axis.set_ylim(bottom=0)
    axes[2].scatter(camera[:, 0]-begin, camera[:, 2], marker='.', s=10, color='#b46345', label='Gate observations per frame')
    eligible = camera[camera[:, 3] > 0]
    axes[2].scatter(eligible[:, 0]-begin, eligible[:, 3], marker='.', s=10, color='#207e71', label='Eligible short tracks')
    axes[2].set(xlabel='Seconds since arming', ylabel='Observations', xlim=(0, end-begin), ylim=(-.8, None))
    axes[2].legend(loc='upper center', frameon=False, ncols=2)
    for axis in axes:
        axis.spines[['top', 'right']].set_visible(False)
        axis.grid(alpha=.15)
    fig.suptitle('VQ1 pose with Rednose · camera and IMU arrival-order replay', fontweight='bold')
    fig.savefig(directory/f'{name}-full-lap.png', dpi=165)


if __name__ == '__main__':
    plot(Path(sys.argv[1]), sys.argv[2])
