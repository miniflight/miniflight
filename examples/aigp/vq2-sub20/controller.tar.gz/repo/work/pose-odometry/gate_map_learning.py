"""Update a carried gate packet from saved corners and onboard camera poses."""

import json

import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

from fly_one_gate import APERTURE
from mapped import CAMERA_FROM_BODY, CORNER_ORDERS, K
from refine_gate_map import gate_observations, packet_map, read_packet_map


def pixels(points, poses, cameras):
    rays = (points - poses[:, None]) @ cameras.transpose(0, 2, 1)
    return rays[..., :2] * np.diag(K)[:2] / np.maximum(.1, rays[..., 2:]) + K[:2, 2]


def observations(folder, course, dimensions, fixed):
    if not (folder/'learned-course.npz').is_file():
        return []
    with np.load(folder/'learned-course.npz', allow_pickle=False) as data:
        image_poses, gates = data['image_poses'], data['gates']
        if fixed:
            image_poses = data.get('image_poses_prior', np.empty((0,9)))
        if not len(image_poses) or not len(gates):
            return []
    _, _, _, views = gate_observations(folder, minimum_width=24.)
    rows = [gates[gates[:, 1] == i] for i in range(len(course))]
    states = {row[0]: row[1:8] for row in image_poses}
    observations = []
    for time, gate, attitude, inner, outer, active in views:
        if not fixed and (active != gate or not len(rows[max(0, gate-1)])):
            continue
        previous = max(0, gate-1)
        history = rows[previous]
        index = np.searchsorted(history[:, 0], time, side='right')-1
        if index < 0 and not fixed:
            continue
        position = states[time][:3]
        if fixed:
            attitude = Rotation.from_quat(states[time][3:]).as_matrix()
        else:
            position = position+course[previous, :3]-history[index, 2:5]
        camera = CAMERA_FROM_BODY @ attitude.T
        if np.all(np.isfinite(outer)):
            shape = APERTURE * np.r_[1., dimensions[gate]/1.5]
            outline = Rotation.from_quat(course[gate, 3:]).apply(shape)+course[gate, :3]
            projected = pixels(outline, position[None], camera[None])[0]
            versions = outer[CORNER_ORDERS]
            outer = versions[np.argmin(np.mean((versions-projected)**2, axis=(1, 2)))]
        observations.append((gate, position, camera, inner, outer))
    return observations


class GateMapFit:
    def __init__(self, map_path, line_path, plan_path, *, fixed=False):
        self.fixed = fixed
        K[:2, 2] = (319.5, 179.5)
        self.packet_seed = json.loads(map_path.read_text())
        self.course = read_packet_map(map_path)
        # Use the same carried orientations as the prepared line loader.
        with np.load(line_path, allow_pickle=False) as line:
            if 'gate_rotations' in line:
                self.course[:, 3:] = line['gate_rotations']
        with np.load(plan_path, allow_pickle=False) as plan:
            self.centers = plan['centers']
        self.dimensions = np.array([[g['width'], g['height']] for g in self.packet_seed['gates']], dtype=float)
        self.pivot_depths = self.packet_seed.get('pivot_below_opening_m')
        self.laps = []

    def packet(self):
        return dict(self.packet_seed, **packet_map(self.course, self.dimensions, self.pivot_depths))

    def resume(self, path):
        packet = json.loads(path.read_text())
        course = read_packet_map(path)
        if course.shape != self.course.shape or not np.allclose(course[0], self.course[0]):
            raise ValueError('Carried gate map has a different frame or gate count')
        self.course = course
        self.dimensions = np.array([[g['width'], g['height']] for g in packet['gates']], dtype=float)

    def save_factors(self, path, map_hash):
        """Keep the ordered reprojection window with the map that produced it."""
        rows=[row for lap in self.laps for row in lap]
        if not rows:
            return
        gates, positions, cameras, inner, outer=map(np.asarray,zip(*rows,strict=True))
        pending=path.with_suffix('.tmp')
        with pending.open('wb') as output:
            np.savez_compressed(output,map_sha256=map_hash,lap_sizes=[len(lap) for lap in self.laps],
                                gates=gates,positions=positions,cameras=cameras,inner=inner,outer=outer)
        pending.replace(path)

    def resume_factors(self, path, map_hash):
        with np.load(path,allow_pickle=False) as data:
            if str(data['map_sha256'])!=map_hash:
                return
            sizes=data['lap_sizes']
            rows=list(zip(*(data[k] for k in ('gates','positions','cameras','inner','outer')),strict=True))
        if sizes.ndim!=1 or not 1<=len(sizes)<=4 or np.any(sizes<=0) or sizes.sum()!=len(rows):
            raise ValueError('Invalid gate observation checkpoint')
        boundaries=np.r_[0,np.cumsum(sizes)]
        self.laps=[rows[start:stop] for start,stop in zip(boundaries[:-1],boundaries[1:],strict=True)]

    def update(self, folder):
        rows = observations(folder, self.course, self.dimensions, self.fixed)
        if not rows:
            return {'observations': 0, 'gates': []}
        self.laps = (self.laps+[rows])[-4:]
        latest = self.course.copy()
        improved = []
        for i, row in enumerate(latest):
            # Reserve every third frame on the newest lap for checking the proposal.
            current = [x for x in self.laps[-1] if x[0] == i]
            validate = current[2::3]
            training = [x for lap in self.laps[:-1] for x in lap if x[0] == i]
            training += [x for j, x in enumerate(current) if j % 3 != 2]
            if len(validate) < 3 or len(training) < 6:
                continue
            improvement = self.fit_gate(i, row, training, validate)
            improved.append(improvement)
        return {'observations': len(rows), 'gates': improved}

    def fit_gate(self, i, row, training, validate):
        rotation = Rotation.from_quat(row[3:])
        center = row[:3]
        dimensions = self.dimensions[i].copy()
        have_size = (np.isfinite(dimensions).all()
                     and sum(np.isfinite(x[-1]).all() for x in training) >= 4
                     and sum(np.isfinite(x[-1]).all() for x in validate) >= 2)
        pose_limit = np.r_[np.full(3, .035), np.full(3, np.radians(1.5))]
        limit = np.r_[pose_limit if i else np.zeros(6), [.06, .06] if have_size else [0., 0.]]
        free = limit > 0.

        def prepare(rows):
            _, positions, cameras, inner, outer = zip(*rows, strict=True)
            positions, cameras, inner, outer = map(np.asarray, (positions, cameras, inner, outer))
            keep = np.isfinite(outer).all(axis=(1, 2))
            return positions, cameras, inner, outer, keep

        def residual(delta, rows):
            position, camera, inner, outer, keep = rows
            R = Rotation.from_rotvec(delta[3:6])*rotation
            result = [(pixels(R.apply(APERTURE)+center+delta[:3], position, camera)-inner).ravel()]
            if have_size and np.any(keep):
                shape = APERTURE * np.r_[1., (dimensions+delta[6:])/1.5]
                result.append((pixels(R.apply(shape)+center+delta[:3], position[keep], camera[keep])-outer[keep]).ravel())
            return np.concatenate(result)

        zeros = np.zeros(8)
        train_set, check_set = prepare(training), prepare(validate)
        before = residual(zeros, check_set)
        delta = zeros.copy()
        if np.any(free):
            def cost(x):
                delta[free] = x
                return np.r_[residual(delta, train_set), x/limit[free]]
            result = least_squares(cost, zeros[free], bounds=(-limit[free], limit[free]),
                                   loss='soft_l1', f_scale=1.5, max_nfev=18)
            delta[free] = result.x
        after = residual(delta, check_set)
        rms = lambda values: float(np.sqrt(np.mean(values**2)))
        old, new = rms(before), rms(after)
        centers = self.course[:, :3].copy()
        centers[i] += delta[:3]
        drift = centers-self.centers
        bound = max(np.linalg.norm(drift, axis=1).max(),
                    np.linalg.norm(np.diff(drift, axis=0), axis=1).max())
        accepted = new < old and bound < .25
        if accepted:
            self.course[i, :3] = centers[i]
            self.course[i, 3:] = (Rotation.from_rotvec(delta[3:6])*rotation).as_quat()
            if have_size:
                self.dimensions[i] += delta[6:]
        return dict(gate=i+1, training=len(training), withheld=len(validate),
                    before_px=old, proposed_px=new, accepted=bool(accepted),
                    position_step_m=float(np.linalg.norm(delta[:3])) if accepted else 0.,
                    orientation_step_deg=float(np.degrees(np.linalg.norm(delta[3:6]))) if accepted else 0.,
                    size_step_m=delta[6:].tolist() if accepted else [0., 0.])
