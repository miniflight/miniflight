"""Compare estimates of the withheld aperture with the native scoring map."""

import json
from pathlib import Path

from score import monotone
import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.transform import Rotation


def score(directory, suffix=''):
    wire = {row['id']: row for row in json.loads((directory/'map.json').read_text())}
    gate = wire[2]
    attitude = Rotation.from_quat(gate['orientation'], scalar_first=True)
    center = np.array(gate['position'])+attitude.apply([0., 0., -1.06823112488])
    normal = attitude.apply([0., 1., 0.])
    normal *= np.sign(normal @ (np.array(wire[3]['position'])-wire[1]['position']))
    with np.load(directory/'truth.npz', allow_pickle=False) as data:
        position = monotone(data['position'])
    with np.load(directory/f'hidden-gate{suffix}.npz', allow_pickle=False) as data:
        estimates, first = data['estimates'], data['first']
    _, unique = np.unique(position[:, 1], return_index=True)
    position = position[unique]
    points = np.column_stack([np.interp(estimates[:, 1], position[:, 1], axis) for axis in position[:, 2:5].T])
    distance = (center-points) @ normal
    pre = distance >= 0.
    if not pre.any():
        raise ValueError(f'{directory} has no estimate available before crossing')
    distance, estimates = distance[pre], estimates[pre]
    displacement = np.linalg.norm(estimates[:, 3:6]-center, axis=1)
    fitted_normals = Rotation.from_rotvec(estimates[:, 6:9]).apply([0., 1., 0.])
    angle = np.degrees(np.arccos(np.clip(np.abs(fitted_normals @ normal), 0., 1.)))
    offset = estimates[-1, 3:6]-center
    axial = offset @ normal
    first_normal = Rotation.from_rotvec(first[3:]).apply([0., 1., 0.])
    initial_angle = np.degrees(np.arccos(np.clip(abs(first_normal @ normal), 0., 1.)))
    acceptable = (displacement <= .25) & (angle <= 5.)
    settled = np.flatnonzero(np.logical_and.accumulate(acceptable[::-1])[::-1])
    report = dict(views=int(len(distance)), first_distance_m=float(distance[0]),
                  last_distance_m=float(distance[-1]),
                  first_centre_m=float(np.linalg.norm(first[:3]-center)), first_plane_deg=float(initial_angle),
                  last_centre_m=float(displacement[-1]), last_plane_deg=float(angle[-1]),
                  last_across_opening_m=float(np.linalg.norm(offset-axial*normal)),
                  last_lines=int(estimates[-1, 9]) if estimates.shape[1] > 9 else 0,
                  mean_centre_m=float(displacement.mean()), mean_plane_deg=float(angle.mean()),
                  settled_distance_m=float(distance[settled[0]]) if settled.size else None)
    (directory/f'hidden-gate{suffix}-score.json').write_text(json.dumps(report, indent=2)+'\n')
    return distance, displacement, angle, report


def plot(root):
    records = [(root, '35.11 s'), (root/'validation', '35.08 s'),
               (root/'holdout-26s', '26.22 s'), (root/'rednose-fresh', '26.21 s')]
    fig, axes = plt.subplots(2, 2, figsize=(11, 7.2), sharex=True, layout='constrained')
    limits = 0.
    for (directory, label), ax in zip(records, axes.flat):
        full_distance, full_centre, full_angle, full = score(directory)
        distance, displacement, angle, report = score(directory, '-partial')
        print(f'{label} full {json.dumps(full)}')
        print(f'{label} partial {json.dumps(report)}')
        start = report['first_distance_m']
        limits = max(limits, start)
        full_x = np.r_[full_distance, 0.]
        ax.plot(full_x, np.r_[full_centre, full_centre[-1]], color='#275d88', lw=1., ls='--', alpha=.55, label='Full corners only')
        ax.plot(distance, displacement, 'o-', color='#275d88', ms=3, lw=1., label='Centre error')
        ax.plot([distance[-1], 0.], [displacement[-1]]*2, color='#275d88', lw=1., ls=':')
        ax.axhline(report['first_centre_m'], color='#777777', lw=.85, ls=':', alpha=.65, label='First view held')
        ax.axhline(.25, color='#808080', lw=.65, alpha=.38)
        ax.set(ylabel='Centre error (m)', title=f'{label} lap · {len(distance)} views')
        other = ax.twinx()
        other.plot(full_x, np.r_[full_angle, full_angle[-1]], color='#a24e32', lw=1., ls='--', alpha=.55)
        other.plot(distance, angle, 'o-', color='#a24e32', ms=3, lw=1., label='Plane error')
        other.plot([distance[-1], 0.], [angle[-1]]*2, color='#a24e32', lw=1., ls=':')
        other.axhline(report['first_plane_deg'], color='#a24e32', lw=.85, ls=':', alpha=.65)
        other.set_ylabel('Plane error (°)', color='#a24e32')
        other.tick_params(axis='y', colors='#a24e32')
        ax.grid(alpha=.15)
        ax.set_ylim(bottom=0)
        other.set_ylim(bottom=0)
        if ax is axes[0, 0]:
            ax.legend(frameon=False, fontsize=8)
    for ax in axes[-1]:
        ax.set(xlabel='Metres before crossing', xlim=(limits+1, 0))
    fig.suptitle('Gate 3 withheld · arrival-order replay with five known gates', fontweight='bold')
    fig.savefig(root/'hidden-gate-errors.png', dpi=165)


if __name__ == '__main__':
    plot(Path(__file__).parent)
