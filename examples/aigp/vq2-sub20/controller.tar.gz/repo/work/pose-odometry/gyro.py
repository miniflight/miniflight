"""Integrate public gyro from a stationary grid pose aligned by visible gate 1."""

import json
from pathlib import Path
import sys

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

from mapped import CAMERA_FROM_BODY, K, apertures, gate_points


def estimate(directory):
    with np.load(directory/'public.npz', allow_pickle=False) as data:
        imu, arrival, raw, offsets = (data[k] for k in ('imu', 'receipt', 'image', 'offsets'))
    opening = json.loads(Path(__file__).with_name('opening.json').read_text())
    gates = gate_points(json.loads((directory/'map.json').read_text()), opening)
    warmup = max(imu[0, 1], arrival[0])+1.
    initial = imu[imu[:, 1] <= warmup]
    x, y, z = np.median(initial[:, 2:5], axis=0)
    level = Rotation.from_euler('xyz', (np.arctan2(-y, -z), np.arctan2(x, np.hypot(y, z)), 0.))
    bias = np.median(initial[:, 5:8], axis=0)
    center = gates[0][1].mean(axis=0)
    bearing = np.arctan2(center[1], center[0])
    yaws = []
    for index in np.flatnonzero(arrival <= warmup):
        img = cv2.imdecode(raw[offsets[index]:offsets[index+1]], cv2.IMREAD_COLOR)
        outlines = list(apertures(img))
        if outlines:
            largest = max(outlines, key=lambda q: cv2.contourArea(q.astype(np.float32)))
            ray = level.apply(CAMERA_FROM_BODY.T @ np.linalg.solve(K, np.r_[largest.mean(axis=0), 1.]))
            yaws.append(bearing-np.arctan2(ray[1], ray[0]))
    if not yaws:
        raise ValueError('No gate 1 at the known stationary start')
    rotation = Rotation.from_euler('z', np.median(yaws))*level
    _, unique = np.unique(imu[:, 0], return_index=True)
    imu = imu[unique]
    steps = Rotation.from_rotvec(((imu[1:, 5:]+imu[:-1, 5:])*.5-bias)*np.diff(imu[:, 0])[:, None])
    result = [rotation.as_quat()]
    for step in steps:
        rotation = rotation*step
        result.append(rotation.as_quat())
    pose = np.c_[imu[:, 0], np.zeros((len(imu), 3)), result, np.zeros((len(imu), 4))]
    np.savez_compressed(directory/'gyro-pose.npz', pose=pose, available=np.maximum(imu[:, 1], warmup))
    print(f'Initial heading {np.degrees(np.median(yaws)):.2f}°, using {len(yaws)} gate views')


if __name__ == '__main__':
    estimate(Path(sys.argv[1]))
