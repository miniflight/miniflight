"""Fly toward one visually initialized gate with a nominal 2 m/s approach."""

import argparse
from dataclasses import replace
from pathlib import Path

import cv2
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

from miniflight import vehicle
from miniflight.position import position_control
from miniflight.state import Frame, ImuSample
from target.aigp.controllers.r1_beautiful import CONFIG
from target.aigp.controllers.r1_motors import Controller as MotorPilot
from target.aigp.experiments.flight import rollout
from target.aigp.experiments.gate_pose import estimate
from target.aigp.experiments.recording import ProcessClient

from fly_rednose import NoVisualAnchor, Observer, VisionClient
from mapped import CAMERA_FROM_BODY, K, apertures, translation
from rednose_model import GRAVITY, PoseFilter, project
from rim import GATE_DEPTH, edges


HALF = .75
APERTURE = HALF*np.array([[0., -1., -1.], [0., 1., -1.], [0., 1., 1.], [0., -1., 1.]])
SQUARE_FROM_GATE = np.array([[0., 1., 0.], [0., 0., -1.], [-1., 0., 0.]])


def initialize_gate(images, acceleration, heading=None):
    """Define local axes at the observed gate. Gravity supplies roll and pitch."""
    ax, ay, az = acceleration
    level = Rotation.from_euler('xyz', (np.arctan2(-ay, -az), np.arctan2(ax, np.hypot(ay, az)), 0.))
    detections = []
    for image in images:
        candidates = list(apertures(image))
        if candidates:
            detections.append(max(candidates, key=lambda quad: cv2.contourArea(quad.astype(np.float32))))
    if len(detections) < 3:
        raise NoVisualAnchor('Need three complete aperture views from the stationary start')
    pixels = np.median(detections, axis=0)
    best = None
    for solution in estimate(pixels, 2.*HALF, K):
        camera_from_gate = Rotation.from_rotvec(solution['rotation_vector_rad']).as_matrix() @ SQUARE_FROM_GATE
        yaw = Rotation.from_matrix(camera_from_gate.T @ CAMERA_FROM_BODY).as_euler('xyz')[2]
        attitude = Rotation.from_euler('z', yaw)*level
        camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
        offset = translation(APERTURE, pixels, camera)

        def residual(value):
            orientation = Rotation.from_euler('z', value[3])*level
            projection, depth = project(APERTURE, value[:3], orientation)
            return (projection-pixels).ravel()

        fitted = least_squares(residual, np.r_[offset, yaw], max_nfev=30)
        position, yaw = fitted.x[:3], fitted.x[3]
        attitude = Rotation.from_euler('z', yaw)*level
        if position[0] < 0 and (best is None or fitted.cost < best[0]):
            best = fitted.cost, position, attitude
    if best is None:
        raise NoVisualAnchor('Aperture pose is behind the camera')
    _, position, attitude = best
    if heading is not None:
        attitude = heading(attitude)
        position = translation(APERTURE, pixels, CAMERA_FROM_BODY @ attitude.as_matrix().T)
    return position, attitude


class GateObserver(Observer):
    landmark_slots = 0
    filter_type = PoseFilter

    def ready(self):
        return True

    def initial_filter(self, pictures, readings, heading=None):
        acceleration = np.median(readings[:, 1:4], axis=0)
        gyro = np.median(readings[:, 4:7], axis=0)
        position, rotation = initialize_gate((frame.bgr for frame in pictures[::3]), acceleration, heading)
        self.gates = [(0, APERTURE)]
        self.rim = list(edges(self.gates, GATE_DEPTH))
        self.lines = None
        observer = self.filter_type(readings[-1, 0], rotation, acceleration+rotation.inv().apply(GRAVITY), gyro,
                                    clones=self.landmark_slots)
        observer.x[:3, 0] = position
        return observer


class Client(VisionClient, ProcessClient):
    motion_source = 'Camera and IMU position in the gate frame'
    observer_type = GateObserver
    sensor_types = (ImuSample, Frame)


class Approach:
    config = replace(CONFIG, max_speed=2.)
    kp, ki, kd = CONFIG.position_gain*CONFIG.velocity_gain, 0., CONFIG.velocity_gain

    def __init__(self, centre_at_plane=False):
        self.centre_at_plane = centre_at_plane
        self.approach_start = None
        self.crossing = None

    def update(self, telemetry, frames, race_state):
        state = vehicle.state
        if not race_state or not race_state.started or state.motion is None or state.attitude is None:
            return None
        p, v = state.motion.position, state.motion.velocity
        if self.approach_start is None:
            self.approach_start = state.motion.time
        if p.north > 0. and self.crossing is None:
            self.crossing = state.motion.time
        if p.north > 1.15 and self.crossing is not None:
            raise StopIteration
        attitude = state.attitude
        target = (2.5, 0., 0.)
        if self.centre_at_plane:
            time_to_plane = max(.65, -p.north/max(1., v.north))
            desired = np.array([self.config.max_speed, -p.east/time_to_plane, -p.down/time_to_plane])
            target = tuple(np.asarray(p)+desired/self.config.position_gain)
        return position_control(self.config, p, v, (attitude.roll, attitude.pitch, attitude.yaw),
                                target, 0.)


def fly(trace, light_capture=False, centre_at_plane=False):
    clients, pilots = [], []

    def client(*args, **kwargs):
        if light_capture:
            kwargs['preview'] = None
        instance = Client(*args, **kwargs)
        clients.append(instance)
        return instance

    def wrap(make):
        def create():
            pilot = MotorPilot(position=Approach(centre_at_plane))
            pilots.append(pilot)
            return pilot
        return create

    cv2.setNumThreads(1)
    K[:2, 2] = (319.5, 179.5)
    try:
        _, simulator, _, _ = rollout('r1_motors', trace, camera=True, offscreen=True, timesync=True, finish_before=23.,
                                     client_type=client, wrap_controller=wrap, record_camera=not light_capture)
        status = simulator.status
        print(f'Native result: {status.active_gate_index} gates, valid {status.valid}', flush=True)
    finally:
        if clients and clients[-1].samples:
            observer = clients[-1]
            approach = pilots[-1].position
            np.savez_compressed(trace.parent/'one-gate-pose.npz', pose=observer.samples,
                                camera=observer.observer.camera_stats, offset=0.,
                                approach_start=np.nan if approach.approach_start is None else approach.approach_start,
                                crossing=np.nan if approach.crossing is None else approach.crossing)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('trace', type=Path)
    parser.add_argument('--light-capture', action='store_true')
    parser.add_argument('--centre-at-plane', action='store_true', help='drive lateral displacement to zero at the estimated arrival time')
    args = parser.parse_args()
    fly(args.trace, args.light_capture, args.centre_at_plane)
