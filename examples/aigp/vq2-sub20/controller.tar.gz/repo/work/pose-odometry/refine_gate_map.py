"""Refine one map from compact corner and camera/IMU pose observations."""

import argparse
import base64
from dataclasses import dataclass
import gzip
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.integrate import cumulative_trapezoid, trapezoid
from scipy.optimize import least_squares
from scipy.sparse import lil_matrix
from scipy.spatial.transform import Rotation, Slerp
from pymavlink.dialects.v20 import common as mavlink

from fly_one_gate import APERTURE
from mapped import CAMERA_FROM_BODY, K, measurements, translation
from miniflight.vision import triangulate_views


# The pilot uses forward/right/down gate axes. The mesh stores right/back/down.
MESH_FROM_GATE = Rotation.from_euler('z', 90., degrees=True)
MAP_FRAME = 'first_opening_forward_right_down'


def legacy_opening_offset():
    """Mesh inspection used by the scorer and to decode maps saved in the old format."""
    return np.array(json.loads(Path(__file__).with_name('opening.json').read_text())['pivot_to_center_local_ned_m'])


def packet_map(course, dimensions, pivot_depths=None):
    if not len(course):
        return {'frame': MAP_FRAME, 'pivot_below_opening_m': [], 'gates': []}
    mesh = Rotation.from_quat(course[:, 3:])*MESH_FROM_GATE.inv()
    depths = np.full(len(course), 1.35) if pivot_depths is None else np.asarray(pivot_depths)
    pivots = course[:, :3]+mesh.apply(depths[:, None]*np.array([0., 0., 1.]))
    return {'frame': MAP_FRAME, 'pivot_below_opening_m': depths.tolist(), 'gates': [
        dict(id=index, position=pivot.tolist(), orientation=q.tolist(),
             width=float(bounds[0]) if np.isfinite(bounds[0]) else None,
             height=float(bounds[1]) if np.isfinite(bounds[1]) else None)
        for index, (pivot, q, bounds) in enumerate(zip(pivots, mesh.as_quat(scalar_first=True), dimensions))]}


def read_packet_map(path):
    return unpack_gate_map(json.loads(path.read_text()))


def unpack_gate_map(packet):
    if packet.get('frame', MAP_FRAME) != MAP_FRAME:
        raise ValueError(f"Unsupported gate map frame: {packet['frame']}")
    gates = packet['gates']
    if not gates:
        return np.empty((0, 7))
    mesh = Rotation.from_quat([g['orientation'] for g in gates], scalar_first=True)
    depths = packet.get('pivot_below_opening_m')
    if depths is None:
        offset = legacy_opening_offset()
    else:
        depths = np.asarray(depths)
        if depths.shape != (len(gates),) or not np.isfinite(depths).all():
            raise ValueError('Expected one finite opening offset per gate')
        offset = depths[:, None]*np.array([0., 0., -1.])
    centers = np.asarray([g['position'] for g in gates])+mesh.apply(offset)
    return np.c_[centers, (mesh*MESH_FROM_GATE).as_quat()]


def interpolate(time, rows, at):
    return np.column_stack([np.interp(at, time, column) for column in rows.T])


@dataclass(frozen=True)
class AccelerometerCapture:
    time: np.ndarray
    force: np.ndarray
    arm: float
    target: str | None
    executable_sha256: str | None
    launch_id: str


def read_accelerometer(path):
    """Read accepted IMU samples, the arm command and recording identity."""
    trace = path/'flight.jsonl'
    compressed = trace.with_suffix('.jsonl.gz')
    source = trace.open() if trace.is_file() else gzip.open(compressed, 'rt')
    decoder = mavlink.MAVLink(None)
    samples = []
    arm = None
    target = executable = None
    with source:
        for line in source:
            row = json.loads(line)
            if row.get('event') == 'config':
                target = row.get('metadata', {}).get('target')
            if row.get('event') == 'result':
                executable = row.get('executable_sha256')
            if row.get('name') == 'arm' and arm is None:
                arm = row['host_time']
            if row.get('name') != 'poll':
                continue
            for packet in row['result']:
                if packet['camera']:
                    continue
                for message in decoder.parse_buffer(base64.b64decode(packet['wire'])) or ():
                    if message.get_type() == 'HIGHRES_IMU':
                        stamp = message.time_usec*1e-6
                        if not samples or stamp > samples[-1][0]:
                            samples.append((stamp, packet['received_at'], message.xacc, message.yacc, message.zacc))
    samples = np.asarray(samples)
    if not len(samples) or arm is None:
        raise ValueError(f'{path}: missing IMU or arming event')
    arm_time = float(np.interp(arm, samples[:, 1], samples[:, 0]))
    launch = samples[(samples[:, 0] >= arm_time-.8) & (samples[:, 0] <= arm_time+3.)]
    digest = hashlib.sha256(np.asarray(arm, dtype='<f8').tobytes())
    digest.update(np.asarray(launch[:, [0, 2, 3, 4]], dtype='<f8').tobytes())
    return AccelerometerCapture(samples[:, 0], samples[:, 2:], arm_time, target, executable, digest.hexdigest())


def accelerometer(path):
    capture = read_accelerometer(path)
    return capture.time, capture.force, capture.arm


def inertial_displacement(path, pose, knots):
    """Integrate specific force over each two-interval position difference."""
    times, specific_force, _ = accelerometer(path)
    attitude = Slerp(pose[:, 0], Rotation.from_quat(pose[:, 4:8]))
    matrices = attitude(np.clip(times, pose[0, 0], pose[-1, 0])).as_matrix()
    world_force = np.einsum('nij,nj->ni', matrices, specific_force)
    dt = knots[1]-knots[0]
    force, sensitivity = [], []
    for left, middle, right in zip(knots, knots[1:], knots[2:]):
        inside = times[(times > left) & (times < right)]
        t = np.unique(np.r_[left, inside, middle, right])
        weight = dt-np.abs(t-middle)
        force.append(trapezoid(weight[:, None]*interpolate(times, world_force, t), t, axis=0))
        rotation = interpolate(times, matrices.reshape(-1, 9), t)
        sensitivity.append(trapezoid(weight[:, None]*rotation, t, axis=0).reshape(3, 3))
    return np.asarray(force), np.asarray(sensitivity), np.array([0., 0., 9.81*dt**2])


def gate_observations(path, minimum_width=0.):
    """Associate saved pixel outlines with gate IDs using the onboard estimates."""
    with np.load(path/'learned-course.npz', allow_pickle=False) as data:
        pose, images, corners, gates = (data[name] for name in ('pose', 'image_poses', 'image_corners', 'gates'))
        replacements = data['replacements']
        bounds = data.get('image_bounds', np.full((len(corners), 8), np.nan))
    gate_history = [gates[gates[:, 1] == i] for i in range(int(gates[:, 1].max())+1)]
    latest = np.array([rows[-1, 2:9] for rows in gate_history])
    stable_after = dict((int(row[1]), row[0]) for row in replacements)
    # A late packet or a restarted clock cannot be spliced into the start of this flight.
    pose = pose[np.r_[True, pose[1:, 0] > np.maximum.accumulate(pose[:-1, 0])]]
    start, stop = min(pose[0, 0], images[0, 0]), max(pose[-1, 0], images[-1, 0])
    knots = np.linspace(start, stop, 1+int(np.ceil((stop-start)/.5)))
    observations = []
    for time, *state, active in images:
        position = np.asarray(state[:3])
        attitude = Rotation.from_quat(state[3:]).as_matrix()
        camera = CAMERA_FROM_BODY @ attitude.T
        rows_in_frame = corners[:, 0] == time
        outlines = corners[rows_in_frame, 1:].reshape(-1, 4, 2)
        outside = bounds[rows_in_frame].reshape(-1, 4, 2)
        visible_map = []
        for i, rows in enumerate(gate_history):
            if time < stable_after.get(i, -np.inf):
                continue
            row = rows[np.clip(np.searchsorted(rows[:, 0], time)-1, 0, len(rows)-1), 2:9]
            visible_map.append((i, Rotation.from_quat(row[3:]).apply(APERTURE)+row[:3]))
        matches = sorted(measurements(outlines, visible_map, position, camera, 'mapped'), key=lambda item: item[0])
        used = set()
        for residual, outline, gate, _, _, vertices in matches:
            span = np.median(np.linalg.norm(vertices-np.roll(vertices, 1, axis=0), axis=1))
            if outline in used or span < minimum_width or residual > max(9., .26*span):
                continue
            observations.append((time, gate, attitude, vertices, outside[outline], int(active)))
            used.add(outline)
    return latest, pose, knots, observations


def read_flight(path, minimum_width=0.):
    latest, pose, knots, views = gate_observations(path, minimum_width)
    initial_p = interpolate(pose[:, 0], pose[:, 1:4], knots)
    odometry = cumulative_trapezoid(pose[:, 8:11], pose[:, 0], axis=0, initial=0.)
    increments = np.diff(interpolate(pose[:, 0], odometry, knots), axis=0)
    observations = []
    for time, gate, attitude, vertices, outside, _ in views:
        index = np.clip(np.searchsorted(knots, time)-1, 0, len(knots)-2)
        fraction = (time-knots[index])/(knots[index+1]-knots[index])
        observations.append((index, fraction, gate, attitude, vertices, outside))
    return latest, initial_p, increments, observations


def inset_corners(pixels, inset):
    """Move each image edge inward by inset pixels."""
    edge = np.roll(pixels, -1, axis=-2)-pixels
    normal = np.stack((-edge[..., 1], edge[..., 0]), axis=-1)
    normal /= np.maximum(.01, np.linalg.norm(normal, axis=-1, keepdims=True))
    previous = np.roll(normal, 1, axis=-2)
    scale = 1.+np.sum(previous*normal, axis=-1, keepdims=True)
    return pixels+inset*(normal+previous)/np.maximum(.2, scale)


def background_factors(path, knot_count):
    with np.load(path/'learned-course.npz', allow_pickle=False) as data:
        if 'background_tracks' not in data or data['background_tracks'].size == 0:
            return None
        tracks, poses, images, flight = (data[key] for key in
            ('background_tracks', 'background_poses', 'image_poses', 'pose'))
    start, stop = min(flight[0, 0], images[0, 0]), max(flight[-1, 0], images[-1, 0])
    knots = np.linspace(start, stop, knot_count)
    times, first = np.unique(flight[:, 0], return_index=True)
    odometry = cumulative_trapezoid(flight[first, 8:11], times, axis=0, initial=0.)
    rows = []
    depth = []
    per_interval = {}
    tracks = tracks[np.argsort(tracks[:, 0], kind='stable')]
    for track in np.split(tracks, np.flatnonzero(np.diff(tracks[:, 0]))+1):
        track = track[(track[:, 1] >= start) & (track[:, 1] <= stop)]
        for offset in range(0, len(track)-9, 24):
            views = track[offset:offset+24:3, 1:]
            time, pixels = views[:, 0], views[:, 1:]
            interval = int((time[0]-start)*2.)
            if time[-1]-time[0] < .65 or per_interval.get(interval, 0) >= 4:
                continue
            positions = interpolate(times, odometry, time)
            orientation = Rotation.from_quat(poses[np.searchsorted(poses[:, 0], time), 4:8]).as_matrix()
            camera = CAMERA_FROM_BODY @ orientation.transpose(0, 2, 1)
            point = triangulate_views(pixels, camera, positions, K)
            if point is None:
                continue
            local = np.einsum('nij,nj->ni', camera, point-positions)
            z = local[0, 2]
            fitted = local[:, :2]*320./local[:, 2:]+K[:2, 2]
            if z < 2. or z > 120. or np.linalg.norm(positions[-1]-positions[0]) < .035*z:
                continue
            if np.sqrt(np.mean((fitted-pixels)**2)) > 3.:
                continue
            i = np.clip(np.searchsorted(knots, time)-1, 0, len(knots)-2)
            fraction = (time-knots[i])/(knots[i+1]-knots[i])
            rows.extend(zip(i, fraction, orientation, pixels, np.repeat(len(depth), len(time))))
            depth.append(z)
            per_interval[interval] = per_interval.get(interval, 0)+1
    if not depth:
        return None
    i, fraction, orientation, pixels, track = map(np.asarray, zip(*rows))
    first = np.unique(track, return_index=True)[1]
    other = np.flatnonzero(~np.isin(np.arange(len(track)), first))
    rays = np.c_[(pixels[first]-K[:2, 2])/320., np.ones(len(first))]
    return i, fraction[:, None], orientation, pixels, track, first, other, rays, np.log(depth)


def refine(paths, prior=None, fit_inset=False, use_background=False, use_imu=False, minimum_width=0.):
    K[:2, 2] = (319.5, 179.5)
    flights = [read_flight(path, minimum_width) for path in paths]
    seed = max((flight[0] for flight in flights), key=len).copy()
    if prior is not None:
        seed[:len(prior)] = prior
    gate_count = len(seed)
    gate_size = 6*(gate_count-1)
    initial = [np.c_[seed[1:, :3], Rotation.from_quat(seed[1:, 3:]).as_rotvec()].ravel()]
    blocks = []
    background = []
    imu_blocks = []
    column = gate_size
    for path, (_, position, increments, observations) in zip(paths, flights):
        index, fraction, gate, attitude, measured, outside = zip(*observations)
        index, gate = np.asarray(index), np.asarray(gate)
        length = len(position)
        blocks.append((slice(column, column+6*length), index, np.asarray(fraction)[:, None], gate,
                       np.asarray(attitude), np.asarray(measured), increments, np.asarray(outside)))
        column += 6*length
        initial.append(np.c_[position, np.zeros_like(position)].ravel())
        if use_imu:
            with np.load(path/'learned-course.npz', allow_pickle=False) as data:
                pose, images = data['pose'], data['image_poses']
            _, first = np.unique(pose[:, 0], return_index=True)
            pose = pose[first]
            start = min(pose[0, 0], images[0, 0])
            stop = max(pose[-1, 0], images[-1, 0])
            knots = np.linspace(start, stop, length)
            imu_blocks.append((blocks[-1][0], slice(column, column+3), inertial_displacement(path, pose, knots)))
            initial.append(np.zeros(3))
            column += 3
        if use_background and (factors := background_factors(path, length)) is not None:
            depths = factors[-1]
            background.append((blocks[-1][0], slice(column, column+len(depths)), factors))
            column += len(depths)
            initial.append(depths)
    if fit_inset:
        initial.append(np.zeros(1))

    def unpack(values):
        return np.vstack((np.zeros((1, 6)), values[:gate_size].reshape(-1, 6)))

    def residual(values):
        gates = unpack(values)
        geometry = APERTURE @ Rotation.from_rotvec(gates[:, 3:]).as_matrix().transpose(0, 2, 1) + gates[:, None, :3]
        terms = [gates[1:, 3:5].ravel()/np.radians(2.)]
        for columns, i, fraction, gate, attitude, observed, increments, _ in blocks:
            pose = values[columns].reshape(-1, 6)
            frame = (1.-fraction)*pose[i]+fraction*pose[i+1]
            orientation = Rotation.from_rotvec(frame[:, 3:]).as_matrix() @ attitude
            local = (geometry[gate]-frame[:, None, :3]) @ orientation @ CAMERA_FROM_BODY.T
            pixels = local[:, :, :2]*320./np.maximum(.10, local[:, :, 2:])+K[:2, 2]
            if fit_inset:
                pixels = inset_corners(pixels, values[-1])
            terms.append((pixels-observed).ravel()/1.2)
            if not use_imu:
                terms.append(((np.diff(pose[:, :3], axis=0)-increments)/.09).ravel())
            terms.extend(((np.diff(pose[:, 3:], axis=0)/.006).ravel(), (pose[:, 3:]/.018).ravel()))
        for columns, bias, (force, sensitivity, gravity) in imu_blocks:
            pose = values[columns].reshape(-1, 6)
            corrected_force = Rotation.from_rotvec(pose[1:-1, 3:]).apply(force-sensitivity @ values[bias])
            displacement = np.diff(pose[:, :3], n=2, axis=0)
            terms.extend(((displacement-corrected_force-gravity).ravel()/.026, values[bias]/.18))
        for columns, depths, (i, fraction, attitude, pixels, track, first, other, rays, _) in background:
            knots = values[columns].reshape(-1, 6)
            frame = (1.-fraction)*knots[i]+fraction*knots[i+1]
            rotation = Rotation.from_rotvec(frame[:, 3:]).as_matrix() @ attitude @ CAMERA_FROM_BODY.T
            points = frame[first, :3]+np.einsum('nij,nj->ni', rotation[first], rays*np.exp(values[depths])[:, None])
            delta = points[track[other]]-frame[other, :3]
            camera = np.einsum('nij,ni->nj', rotation[other], delta)
            image = camera[:, :2]*320./np.maximum(.1, camera[:, 2:])+K[:2, 2]
            terms.append(((image-pixels[other])/1.5).ravel())
        if fit_inset:
            terms.append(values[-1:]/.7)
        return np.concatenate(terms)

    initial = np.concatenate(initial)
    sparsity = lil_matrix((len(residual(initial)), len(initial)), dtype=bool)
    row = 0
    for gate in range(gate_count-1):
        sparsity[row:row+2, gate*6+3:gate*6+5] = True
        row += 2
    for columns, indices, _, gates, _, _, increments, _ in blocks:
        start = columns.start
        for index, gate in zip(indices, gates):
            sparsity[row:row+8, start+6*index:start+6*(index+2)] = True
            if gate:
                sparsity[row:row+8, 6*(gate-1):6*gate] = True
            if fit_inset:
                sparsity[row:row+8, -1] = True
            row += 8
        if not use_imu:
            for index in range(len(increments)):
                sparsity[row:row+3, start+6*index:start+6*index+3] = True
                sparsity[row:row+3, start+6*(index+1):start+6*(index+1)+3] = True
                row += 3
        for index in range(len(increments)):
            sparsity[row:row+3, start+6*index+3:start+6*(index+2)] = True
            row += 3
        for index in range(len(increments)+1):
            sparsity[row:row+3, start+6*index+3:start+6*index+6] = True
            row += 3
    lower, upper = np.full(len(initial), -np.inf), np.full(len(initial), np.inf)
    for columns, bias, (force, _, _) in imu_blocks:
        for index in range(len(force)):
            start = columns.start+6*index
            sparsity[row:row+3, start:start+15] = True
            sparsity[row:row+3, bias] = True
            row += 3
        sparsity[row:row+3, bias] = True
        row += 3
    for columns, depths, (indices, _, _, _, tracks, first, other, _, _) in background:
        lower[depths], upper[depths] = np.log(1.), np.log(200.)
        for current in other:
            track = tracks[current]
            for index in (indices[current], indices[first[track]]):
                start = columns.start+6*index
                sparsity[row:row+2, start:start+12] = True
            sparsity[row:row+2, depths.start+track] = True
            row += 2
    if fit_inset:
        sparsity[-1, -1] = True
        lower[-1], upper[-1] = -2., 2.
    result = least_squares(residual, initial, jac_sparsity=sparsity.tocsr(), bounds=(lower, upper),
                           loss='soft_l1', max_nfev=100, ftol=1e-4)
    gates = unpack(result.x)
    counts = np.bincount(np.concatenate([block[3] for block in blocks]), minlength=gate_count)
    print(f'{len(paths)} flights, {counts.tolist()} outlines by gate, cost {result.cost:.1f}, {result.message}')
    if fit_inset:
        print(f'Image rim inset: {result.x[-1]:.3f} px per edge')
    if background:
        print(f'{sum(depth.stop-depth.start for _, depth, _ in background)} background tracks')
    if imu_blocks:
        print('Fitted accelerometer biases (m/s²):', [result.x[bias].round(3).tolist() for _, bias, _ in imu_blocks])
    rotations = Rotation.from_rotvec(gates[:, 3:])
    measured_bounds = [[] for _ in gates]
    for columns, indices, fraction, ids, attitude, observed, _, outside in blocks:
        poses = result.x[columns].reshape(-1, 6)
        frame = (1.-fraction)*poses[indices]+fraction*poses[indices+1]
        cameras = CAMERA_FROM_BODY @ (Rotation.from_rotvec(frame[:, 3:]).as_matrix() @ attitude).transpose(0, 2, 1)
        for gate, camera, corners, bound in zip(ids, cameras, observed, outside):
            if not np.isfinite(bound).all():
                continue
            rotation = rotations[gate]
            direction = rotation.apply([1., 0., 0.])
            center = -translation(rotation.apply(APERTURE), corners, camera)
            if not 2. < np.linalg.norm(center) < 18.:
                continue
            rays = np.c_[(bound-K[:2, 2])/320., np.ones(4)] @ camera
            denominator = rays @ direction
            if np.min(denominator) <= .3:
                continue
            points = rays*((center @ direction)/denominator[:, None])
            size = np.ptp(rotation.inv().apply(points)[:, 1:], axis=0)
            if np.all((size > 1.5) & (size < 5.)):
                measured_bounds[gate].append(size)
    dimensions = np.array([np.median(rows, axis=0) if len(rows) >= 3 else [np.nan, np.nan]
                           for rows in measured_bounds])
    return np.c_[gates[:, :3], rotations.as_quat()], dimensions


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('flights', type=Path, nargs='+')
    parser.add_argument('--prior', type=Path)
    parser.add_argument('--fit-inset', action='store_true')
    parser.add_argument('--background', action='store_true')
    parser.add_argument('--imu', action='store_true')
    parser.add_argument('--minimum-width', type=float, default=0.)
    args = parser.parse_args()
    prior = read_packet_map(args.prior) if args.prior else None
    course, dimensions = refine(args.flights, prior, args.fit_inset, args.background, args.imu, args.minimum_width)
    args.output.write_text(json.dumps(packet_map(course, dimensions), indent=2)+'\n')
