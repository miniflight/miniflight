"""Join the learned corridor from the measured launch state."""
from dataclasses import dataclass
import numpy as np
from scipy.interpolate import BPoly


@dataclass
class LaunchReference:
    curve: BPoly
    duration: float
    grid: np.ndarray
    points: np.ndarray
    terminal: np.ndarray

    @classmethod
    def build(cls, config, line, position, velocity, center, normal):
        endpoint = line.curve(0.)+center-line.centers[0]
        q = float(line.speed_squared(0.))
        tangent = line.curve(0.,1)
        exit_v = np.sqrt(q)*tangent
        exit_a = q*line.curve(0.,2)+.5*line.speed_squared(0.,1)*tangent
        if (endpoint-position)@normal <= 1. or exit_v@normal <= .25:
            return None
        drag = np.mean(config.body_resistance_per_m[:2]) if config.body_resistance_per_m else 0.
        for duration in np.linspace(1.8,4.8,76):
            curve = BPoly.from_derivatives([0.,duration],[[position,velocity,np.zeros(3)],[endpoint,exit_v,exit_a]])
            times = np.linspace(0.,duration,81)
            v = curve(times,1)
            if np.linalg.norm(v,axis=1).max()>config.max_speed or (v@normal).min()<-.05:
                continue
            a = curve(times,2)
            a[:,:2] += drag*np.linalg.norm(v[:,:2],axis=1)[:,None]*v[:,:2]
            thrust = np.array([0.,0.,9.81])-a
            tilt = np.arctan2(np.linalg.norm(thrust[:,:2],axis=1),thrust[:,2])
            down = thrust/np.linalg.norm(thrust,axis=1,keepdims=True)
            axis_rate = np.linalg.norm(np.diff(down,axis=0),axis=1)*80./duration
            if (np.max(tilt)>min(.75,config.max_tilt) or np.max(abs(a[:,2]))>config.max_acceleration
                    or np.max(np.linalg.norm(a[:,:2],axis=1))>(config.max_horizontal_acceleration or config.max_acceleration)
                    or np.max(axis_rate)>config.max_rate*.65):
                continue
            return cls(curve,float(duration),times,curve(times),np.array([endpoint,exit_v,exit_a]))
        return None

    def velocity_request(self, config, p, v):
        t = self.grid[np.argmin(np.linalg.norm(self.points-p,axis=1))]
        for _ in range(3):
            error = self.curve(t)-p
            tangent = self.curve(t,1)
            curvature = tangent@tangent+error@self.curve(t,2)
            if curvature<=.01:
                break
            t=np.clip(t-error@tangent/curvature,0.,self.duration)
        point,velocity=self.curve(t),self.curve(t,1)
        if t>=self.duration:
            end,end_v,end_a=self.terminal
            dt=np.clip((p-end)@end_v/(end_v@end_v),0.,.28)
            point=end+dt*end_v+.5*dt**2*end_a
            velocity=end_v+dt*end_a
        delay=.02+1./config.attitude_gain
        a=np.r_[self.curve(min(self.duration,t+delay),2)[:2],self.curve(min(self.duration,t+.04),2)[2]]
        error=point-p+np.array([delay,delay,.04])*(velocity-v)
        return velocity+config.position_gain*error+a/config.velocity_gain
