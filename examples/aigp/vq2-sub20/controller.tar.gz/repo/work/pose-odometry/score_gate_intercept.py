"""Score the crossing point predicted from the pose available at each motor tick."""

import json
from pathlib import Path

from score import monotone
from score_one_gate import native_gate_frame
import matplotlib.pyplot as plt
import numpy as np


def score(directory):
    _, center, basis = native_gate_frame(directory)
    with np.load(directory/'truth.npz', allow_pickle=False) as truth:
        position = monotone(truth['position'])
        arm, disarm = np.interp(truth['armed'], position[:, 1], position[:, 0])
    with np.load(directory/'one-gate-pose.npz', allow_pickle=False) as data:
        pose = data['pose']
    native = (position[:, 2:5]-center) @ basis
    end = (native[1:, 0] >= 0.) & (native[:-1, 0] < 0.)
    valid = end & (arm <= position[1:, 0]) & (position[1:, 0] <= disarm)
    i = np.flatnonzero(valid)[0]
    crossing = np.interp(0., native[i:i+2, 0], position[i:i+2, 0])
    actual = np.array([np.interp(crossing, position[:, 0], col) for col in native[:, 1:].T])
    # Compare at the time the pose was issued, including any processing delay.
    host_time, index = np.unique(position[:, 1], return_index=True)
    available = np.interp(pose[:, 12], host_time, position[index, 0])
    lead = crossing-available
    velocity = pose[:, 8:11]
    approaching = (pose[:, 1] < 0.) & (velocity[:, 0] > .2) & (0. <= lead) & (lead <= 2.1)
    pose, velocity, lead = pose[approaching], velocity[approaching], lead[approaching]
    remaining = -pose[:, 1]/velocity[:, 0]
    coast = pose[:, 2:4]+remaining[:, None]*velocity[:, 1:3]
    report = dict(actual_yz_m=actual.tolist(), centre_miss_m=float(np.linalg.norm(actual)),
                  centre_clearance_m=float(.74-np.max(np.abs(actual))), snapshots={})
    for horizon in (2., 1., .5, .25):
        earlier = np.flatnonzero(lead >= horizon)
        if earlier.size:
            i = earlier[-1]
            report['snapshots'][str(horizon)] = dict(lead_s=float(lead[i]), predicted_yz_m=coast[i].tolist(),
                                                     error_m=float(np.linalg.norm(coast[i]-actual)),
                                                     current_offset_error_m=float(np.linalg.norm(pose[i, 2:4]-actual)))
    (directory/'gate-intercept-score.json').write_text(json.dumps(report, indent=2)+'\n')
    return lead, coast, actual, report


def plot(root):
    cases = [('attempt-01', 'Pad run 1'), ('pad-02', 'Pad run 2')]
    cases += [(d.name, f'Plane-centred run {i}') for i, d in enumerate(sorted(root.glob('centre-*')), 1)
              if (d/'one-gate-score.json').is_file() and json.loads((d/'one-gate-score.json').read_text())['pass']]
    fig, axes = plt.subplots(len(cases), 2, figsize=(9.5, len(cases)*2.65), sharex=True, sharey='col', layout='constrained')
    for (directory, label), row in zip(cases, axes):
        lead, coast, actual, report = score(root/directory)
        print(label, json.dumps(report))
        for j, (axis, name) in enumerate(zip(row, ('Sideways', 'Vertical'))):
            axis.plot(lead, coast[:, j]*100., color='#2c628d', lw=1.2, label='Predicted crossing')
            axis.axhline(actual[j]*100., color='#9d4d2d', ls='--', lw=1., label='Scored crossing')
            axis.axhline(0., color='#999999', lw=.65)
            axis.set(title=f'{label} · {name}', ylabel='Offset from centre (cm)')
            axis.grid(alpha=.17)
            axis.spines[['top', 'right']].set_visible(False)
    axes[0, 0].legend(frameon=False, fontsize=8)
    for axis in axes[-1]:
        axis.set(xlabel='Seconds before crossing', xlim=(2.1, 0.))
    fig.suptitle('Predicting the crossing point from camera and IMU', fontweight='bold')
    fig.savefig(root/'gate-intercept.png', dpi=165)


if __name__ == '__main__':
    plot(Path(__file__).with_name('one-gate'))
