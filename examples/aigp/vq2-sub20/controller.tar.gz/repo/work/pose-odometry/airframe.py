"""Vehicle calibration across courses. Each qualified launch has one vote."""

from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import tempfile

import numpy as np

from target.aigp.native import BASE, SHIPPING, TARGETS, sha256


def write_json(path, value):
    with tempfile.NamedTemporaryFile(mode='w', dir=path.parent, suffix='.tmp', delete=False) as output:
        temporary = Path(output.name)
        try:
            json.dump(value, output, indent=2, allow_nan=False)
            output.write('\n')
            output.flush()
            os.fsync(output.fileno())
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
    try:
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


@contextmanager
def exclusive(path, *, wait=True):
    with path.open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX if wait else fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise RuntimeError(f'Another process is updating {path.parent}') from error
        yield


def installed_identity(target='vq1.r1'):
    executable = BASE/'.runtime'/TARGETS[target][0]/SHIPPING
    return target, sha256(executable) if executable.is_file() else None


class AirframeCalibration:
    def __init__(self, root):
        self.root = Path(root)

    def _store(self, target, executable):
        if target not in TARGETS or not isinstance(executable, str) or len(executable) != 64:
            return None
        if any(char not in '0123456789abcdef' for char in executable):
            return None
        return self.root/target/executable/'forward-drag-v1.json'

    def record(self, flights):
        groups = {}
        for flight in flights:
            path = self._store(flight.target, flight.executable_sha256)
            if path is not None and flight.launch_id and flight.launch_drag is not None:
                if not np.isfinite(flight.launch_drag) or flight.launch_drag <= 0.:
                    raise ValueError('Invalid launch drag coefficient')
                groups.setdefault(path, {})[flight.launch_id] = float(flight.launch_drag)
        for path, launches in groups.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            with exclusive(path.with_suffix('.lock')):
                saved = json.loads(path.read_text()) if path.is_file() else {}
                new = {key: value for key, value in launches.items() if key not in saved}
                if new:
                    write_json(path, dict(sorted((saved | new).items())))

    def snapshot(self, target, executable):
        path = self._store(target, executable)
        samples = json.loads(path.read_text()) if path is not None and path.is_file() else {}
        values = np.asarray(list(samples.values()))
        # Three independent launches give the median one outlier's worth of robustness.
        coefficient = float(np.median(values)) if len(values) >= 3 else None
        contents = json.dumps(samples, sort_keys=True, separators=(',', ':')).encode()
        return dict(target=target, executable_sha256=executable, qualified_launches=len(samples),
                    calibration_sha256=hashlib.sha256(contents).hexdigest(), forward_drag_per_m=coefficient)


def applicable_drag(snapshot, flights):
    if (snapshot and snapshot.get('forward_drag_per_m') is not None
            and all((f.target, f.executable_sha256) == (snapshot['target'], snapshot['executable_sha256'])
                    for f in flights)):
        coefficient = snapshot['forward_drag_per_m']
        if not np.isfinite(coefficient) or coefficient <= 0.:
            raise ValueError('Invalid airframe drag prior')
        return coefficient
    return None
