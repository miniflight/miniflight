"""Offline check of what the accepted camera measurements constrain across a lap."""

import json
from pathlib import Path
import sys

import numpy as np
from scipy.sparse import coo_matrix, vstack
from scipy.sparse.linalg import lsmr
from scipy.spatial.transform import Rotation, Slerp


def smooth(directory):
    with np.load(directory/'mapped-pose.npz', allow_pickle=False) as data:
        pose, cameras = data['pose'], data['updates']
    with np.load(directory/'public.npz', allow_pickle=False) as data:
        imu = data['imu']
    gate = {row['id']: np.array(row['position']) for row in json.loads((directory/'map.json').read_text())}
    dt = .2
    knots = np.arange(pose[0, 0], pose[-1, 0]+dt, dt)
    count = len(knots)
    now = imu[:, 0]
    ori = Slerp(pose[:, 0], Rotation.from_quat(pose[:, 4:8]))(np.clip(now, pose[0, 0], pose[-1, 0]))
    force = ori.apply(imu[:, 2:5])+[0., 0., 9.81]
    t, unique = np.unique(now, return_index=True)
    force = force[unique]
    gain = np.maximum(0., 1.-np.abs(knots[1:-1, None]-t)/dt)
    gain /= np.maximum(.001, gain.sum(axis=1, keepdims=True))
    smoothed_force = gain @ force
    position = []
    for axis in range(3):
        indices, values, targets, sigmas, visual = [], [], [], [], []

        def add(columns, coeffs, target, sigma, camera=False):
            indices.extend((len(targets), i) for i in columns)
            values.extend(coeffs)
            targets.append(target)
            sigmas.append(sigma)
            visual.append(camera)

        add([0], [1.], 0., .3)
        add([0, 1], [-1., 1.], 0., .2)
        for i, force_here in enumerate(smoothed_force[:, axis], 1):
            add([i-1, i, i+1], [1., -2., 1.], dt*dt*force_here, .08)
        for time, gate_id, *point in cameras:
            index = int(np.searchsorted(knots, time)-1)
            if not 0 <= index < count-1:
                continue
            fraction = (time-knots[index])/dt
            depth = np.linalg.norm(gate[int(gate_id)]-point)
            # At long range the opening's width is the weakest measurement.
            sigma = .14+.025*depth+(.0018*depth**2 if axis == 0 else 0.)
            add([index, index+1], [1.-fraction, fraction], point[axis], sigma, True)
        rows, cols = zip(*indices)
        matrix = coo_matrix((values, (rows, cols)), shape=(len(targets), count)).tocsr()
        targets, sigma, visual = np.array(targets), np.array(sigmas), np.array(visual)
        weight = np.ones(len(targets))
        for _ in range(8):
            scaled = np.sqrt(weight)/sigma
            estimate = lsmr(matrix.multiply(scaled[:, None]).tocsr(), targets*scaled, atol=1e-8, btol=1e-8, maxiter=1200)[0]
            residual = (matrix @ estimate-targets)/sigma
            weight[visual] = 1./np.sqrt(1.+residual[visual]**2)
        position.append(np.interp(pose[:, 0], knots, estimate))
    pose[:, 1:4] = np.array(position).T
    pose[:, 8:11] = np.gradient(pose[:, 1:4], pose[:, 0], axis=0)
    np.savez_compressed(directory/'smoothed-pose.npz', pose=pose)


if __name__ == '__main__':
    smooth(Path(sys.argv[1]))
