"""Score the estimated trajectory against the individual native wire streams."""

import numpy as np
from scipy.spatial.transform import Rotation, Slerp

from refine_gate_map import MESH_FROM_GATE, interpolate, legacy_opening_offset
from score import monotone


def mae(delta):
    return np.abs(delta).mean(axis=0).tolist()


def distance(delta):
    return float(np.linalg.norm(delta, axis=1).mean())


def attitude_errors(reference, estimate):
    angles = (estimate.as_euler('xyz', degrees=True)-reference.as_euler('xyz', degrees=True)+180.) % 360.-180.
    return dict(rotation_deg=float(np.degrees((reference.inv()*estimate).magnitude()).mean()),
                roll_pitch_yaw_deg=mae(angles), attitude_delta_deg=angles[-1].tolist())


def score_streams(truth, data, gates):
    results = {name: {'samples': 0} for name in ('ATTITUDE', 'LOCAL_POSITION_NED', 'ODOMETRY', 'GATE_INFO')}
    if len(gates) > 1:
        scored = gates[1:]
        map_errors = results['GATE_INFO']
        map_errors['samples'] = len(scored)
        for field in ('pivot_m', 'center_m', 'attitude_deg', 'width_m', 'height_m'):
            values = [g[field] for g in scored if g[field] is not None]
            map_errors[field] = float(np.mean(values)) if values else None
    if not len(truth['gate_quaternions']) or not len(data['pose']):
        return results
    first = Rotation.from_quat(truth['gate_quaternions'][0], scalar_first=True)
    origin = truth['gate_pivots'][0]+first.apply(legacy_opening_offset())
    basis = (first*MESH_FROM_GATE).inv()
    pose = data['pose']
    armed = truth['armed']
    pose = pose[(pose[:, 12] >= armed[0]) & (pose[:, 12] <= armed[-1])]
    pose = monotone(pose)
    if len(pose) < 2:
        return results

    def overlap(ref):
        if len(ref) < 2:
            return ref, pose[:0]
        reference = monotone(ref)
        if len(reference) < 2:
            return reference, pose[:0]
        rows = pose[(pose[:, 0] >= reference[0, 0]) & (pose[:, 0] <= reference[-1, 0])]
        return reference, rows

    def rates(ref, times, rate_columns):
        imu = truth.get('imu', np.empty((0, 8)))
        if not len(imu):
            return {}
        imu = monotone(imu[(imu[:, 1] >= armed[0]) & (imu[:, 1] <= armed[-1])])
        if len(imu) < 2:
            return {}
        times = times[(times >= imu[0, 0]) & (times <= imu[-1, 0])]
        if not len(times):
            return {}
        measured = interpolate(imu[:, 0], imu[:, 5:8], times)
        target = interpolate(ref[:, 0], ref[:, rate_columns], times)
        return {'angular_rate_rad_s': mae(measured-target)}

    ref, rows = overlap(truth['attitude'])
    if len(rows):
        t = rows[:, 0]
        native = basis*Slerp(ref[:, 0], Rotation.from_euler('xyz', ref[:, 2:5]))(t)
        results['ATTITUDE'] = dict(samples=len(rows), **attitude_errors(native, Rotation.from_quat(rows[:, 4:8])))
        angular = truth.get('attitude_rates', np.empty((0, 4)))
        if len(angular) > 1:
            results['ATTITUDE'].update(rates(monotone(angular), t, slice(1, 4)))

    def motion_errors(rows, reference_time, position, velocity):
        time = rows[:, 0]
        dp = rows[:, 1:4]-basis.apply(interpolate(reference_time, position, time)-origin)
        dv = rows[:, 8:11]-basis.apply(interpolate(reference_time, velocity, time))
        return dict(samples=len(rows), position_m=distance(dp), velocity_m_s=distance(dv),
                    xyz_m=mae(dp), velocity_xyz_m_s=mae(dv), position_delta_m=dp[-1].tolist())

    ref, rows = overlap(truth['position'])
    if len(rows):
        results['LOCAL_POSITION_NED'] = motion_errors(rows, ref[:, 0], ref[:, 2:5], ref[:, 5:8])

    odometry = truth.get('odometry', np.empty((0, 16))).reshape(-1, 16)
    odometry = odometry[(odometry[:, 14] == 1) & (odometry[:, 15] == 8) & (np.linalg.norm(odometry[:, 4:8], axis=1) > 0)]
    ref, rows = overlap(odometry)
    if len(rows):
        raw = Rotation.from_quat(ref[:, 4:8], scalar_first=True)
        # The 3391 wire quaternion maps body velocity to local NED. The orientation
        # axes used by the cameras and ATTITUDE reflect right, which flips roll and yaw.
        reflection = np.diag([1., -1., 1.])
        rotation = Rotation.from_matrix(reflection @ raw.as_matrix() @ reflection)
        t = rows[:, 0]
        native = basis*Slerp(ref[:, 0], rotation)(t)
        results['ODOMETRY'] = dict(**motion_errors(rows, ref[:, 0], ref[:, 1:4], raw.apply(ref[:, 8:11])),
                                   **attitude_errors(native, Rotation.from_quat(rows[:, 4:8])),
                                   **rates(ref, t, slice(11, 14)))
    return results
