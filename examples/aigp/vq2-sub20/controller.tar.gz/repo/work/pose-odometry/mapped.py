"""Anchor visual-inertial motion to the supplied VQ1 gate geometry."""

import json
from pathlib import Path
import sys

import cv2
import numpy as np
from scipy.spatial.transform import Rotation, Slerp

from target.aigp.experiments.gate_pose import fit_outline

K = np.array([[320., 0., 320.], [0., 320., 180.], [0., 0., 1.]])
ANGLE = np.radians(20.)
CAMERA_FROM_BODY = np.array([[0., 1., 0.], [np.sin(ANGLE), 0., np.cos(ANGLE)],
                            [np.cos(ANGLE), 0., -np.sin(ANGLE)]])


def opening_range_sigma(depth):
    return max(.25, 1.7*depth**2/(K[0, 0]*1.50))


def red_mask(image):
    blue, green, red = cv2.split(image.astype(np.float32))
    mask = (red-(blue+green)/2. > 20.).astype(np.uint8)
    return cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))


def gate_color(image):
    blue, green, red = cv2.split(image.astype(np.float32))
    return (red >= 1.42*green) & (red >= 1.6*blue) & (red-(green+blue)*.5 > 20.)


def gate_masks(image):
    blue, green, red = cv2.split(image.astype(np.float32))
    red_excess = red-(blue+green)*.5 > 20.
    mask = cv2.morphologyEx(red_excess.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    return mask, red_excess & (red >= 1.42*green) & (red >= 1.6*blue)


def colored_rim(contour, mask, color):
    x, y, w, h = cv2.boundingRect(contour)
    area = np.zeros((h, w), np.uint8)
    cv2.drawContours(area, [contour-np.array([x, y], np.int32)], -1, 1, cv2.FILLED)
    support = (area != 0) & (mask[y:y+h, x:x+w] != 0)
    return np.count_nonzero(color[y:y+h, x:x+w]&support) > .4*np.count_nonzero(support)


def local_rim(corners, color):
    """Check the physical rim around an aperture even if its mask joins the floor."""
    unit_square = np.array([[-1.,-1.],[1.,-1.],[1.,1.],[-1.,1.]], np.float32)
    homography = cv2.getPerspectiveTransform(unit_square, corners.astype(np.float32))
    # The outer edge is at 1.8 aperture radii. Sample colour on either side.
    tangent = np.tile(np.linspace(-.75, .75, 9), 4)
    radial = np.repeat([1.20, 1.50, 1.95, 2.10], 9)
    offsets = np.array([np.c_[tangent, radial], np.c_[radial, -tangent],
                        np.c_[-tangent, -radial], np.c_[-radial, tangent]], dtype=np.float32)
    pixels = cv2.perspectiveTransform(offsets.reshape(1, -1, 2), homography)[0]
    x, y = np.rint(pixels).astype(int).T
    height, width = color.shape
    visible = ((0<=x)&(x<width)&(0<=y)&(y<height)).reshape(4, 2, -1)
    warm = color[y.clip(0, height-1), x.clip(0, width-1)].reshape(4, 2, -1)&visible
    fraction = warm.sum(axis=2)/np.maximum(1, visible.sum(axis=2))
    supported = visible.mean(axis=2).min(axis=1) >= .75
    return np.count_nonzero(supported & (fraction[:, 0] > .4) & (fraction[:, 0]-fraction[:, 1] > .2)) >= 3


def apertures(image, with_bounds=False, *, mask=None, color=None):
    if mask is None and color is None:
        mask, color = gate_masks(image)
    else:
        mask = red_mask(image) if mask is None else mask
        color = gate_color(image) if color is None else color
    holes = list(_aperture_holes(image.shape, mask, color, with_bounds))
    if not holes:
        # Strong rim color separates floor reflections. Close narrow occlusions across the rim.
        mask = cv2.morphologyEx(color.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
        holes = _aperture_holes(image.shape, mask, color, with_bounds)
    for opening, rim in holes:
        yield (opening, rim) if with_bounds else opening


def _aperture_holes(shape, mask, color, with_bounds):
    contours, hierarchy = cv2.findContours(mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE)
    if hierarchy is None:
        return
    for index, node in enumerate(hierarchy[0]):
        parent = node[3]
        if parent < 0:
            continue
        area, rim = cv2.contourArea(contours[index]), cv2.contourArea(contours[parent])
        if area < 35. or area >= .8*rim:
            continue
        enclosed = area > .16*rim and colored_rim(contours[parent], mask, color)
        if not enclosed and min(cv2.boundingRect(contours[index])[2:]) < 14:
            continue
        fit = fit_outline(contours[index], shape)
        if fit is not None and max(fit[1]) < 1.3 and (enclosed or local_rim(fit[0], color)):
            bounds = fit_outline(contours[parent], shape) if with_bounds else None
            yield fit[0], bounds[0] if bounds is not None and max(bounds[1]) < 2. else None


def gate_points(gates, opening, outer=False):
    width, height, offset = (opening[key] for key in ('opening_width_m', 'opening_height_m', 'pivot_to_center_local_ned_m'))
    result = []
    for gate in gates:
        gate_width, gate_height = (gate['width'], gate['height']) if outer else (width, height)
        aperture = .5*np.array([[-gate_width, 0., -gate_height], [gate_width, 0., -gate_height],
                                 [gate_width, 0., gate_height], [-gate_width, 0., gate_height]])
        rotation = Rotation.from_quat(gate['orientation'], scalar_first=True)
        result.append((gate['id'], rotation.apply(aperture+offset)+gate['position']))
    return result


def translation(points, corners, camera):
    rays = (corners-K[:2, 2])/np.diag(K)[:2]
    system = camera[:2]-rays[:, :, None]*camera[2]
    return np.linalg.lstsq(system.reshape(-1, 3), np.einsum('ijk,ik->ij', system, points).ravel(), rcond=None)[0]


def clipped_gate(frame, gates, position, camera):
    contours, _ = cv2.findContours(red_mask(frame), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for key, points in gates:
        xyz = (points-position) @ camera.T
        if min(xyz[:, 2]) < 2. or max(xyz[:, 2]) > 26.:
            continue
        expected = xyz @ K.T
        expected = expected[:, :2]/expected[:, 2, None]
        if max(expected[:2, 1]) > 358. or min(expected[2:, 1]) < 340.:
            continue
        top = expected[:2]
        width = np.linalg.norm(top[1]-top[0])
        tangent = (top[1]-top[0])/width
        best = None
        for contour in contours:
            hull = cv2.convexHull(contour).reshape(-1, 2)
            for left, right in zip(hull, np.roll(hull, 1, axis=0)):
                edge = right-left
                length = np.linalg.norm(edge)
                if not .65*width < length < 1.45*width or abs(edge @ tangent) < .98*length:
                    continue
                observed = np.array([left, right]) if edge @ tangent > 0 else np.array([right, left])
                error = np.linalg.norm(observed-top)
                if error < width*.6 and (best is None or error < best[0]):
                    best = error, observed
        if best is not None:
            measured = translation(points[:2], best[1], camera)
            if np.linalg.norm(measured-position) < 4.:
                yield key, measured, max(.2, .04*float(np.mean(xyz[:, 2])))


_FORWARD_ORDERS = (np.arange(4)-np.arange(4)[:, None]) % 4
CORNER_ORDERS = np.vstack((_FORWARD_ORDERS, 3-_FORWARD_ORDERS))


def measurements(pixels, gates, position, camera, mode):
    if len(pixels) == 0:
        return
    ordered = np.asarray(pixels)[:, CORNER_ORDERS]
    for key, points in gates:
        xyz = (points-position) @ camera.T
        if np.min(xyz[:, 2]) < 1.:
            continue
        projected = xyz @ K.T
        expected = projected[:, :2]/projected[:, 2, None]
        width = np.median(np.linalg.norm(expected-np.roll(expected, 1, axis=0), axis=1))
        if width < 5. or np.any(expected < -40.) or np.any(expected > [680., 400.]):
            continue
        mismatch_squared = np.mean((ordered-expected)**2, axis=(-2, -1))
        index, order = divmod(int(np.argmin(mismatch_squared)), len(CORNER_ORDERS))
        mismatch = float(np.sqrt(mismatch_squared[index, order]))
        if mismatch > max(14., .7*width):
            continue
        corners = ordered[index, order]
        estimate = translation(points, corners, camera)
        depth = (points-estimate) @ camera[2]
        if min(depth) <= .6 or np.linalg.norm(estimate-position) > max(2.5, .4*np.mean(depth)):
            continue
        distance = float(np.mean(depth))
        sigma = max(.15, .04*distance, .4*distance/width)
        noise = np.eye(3)*sigma**2
        if mode not in ('mapped', 'clipped'):
            pixel = (points-estimate) @ camera.T @ K.T
            point_error = np.sqrt(np.mean((pixel[:, :2]/pixel[:, 2, None]-corners)**2))
            if mode in ('weighted', 'range') and point_error > 1.5:
                continue
            measured_width = np.median(np.linalg.norm(corners-np.roll(corners, 1, axis=0), axis=1))
            range_sigma = 1.5*distance/max(1., measured_width)
            direction = camera[2]
            noise += np.outer(direction, direction)*range_sigma**2
        yield mismatch, index, key, estimate, noise, corners


def run(directory, mode):
    cv2.setNumThreads(1)
    with np.load(directory/'public.npz', allow_pickle=False) as data:
        imu, stamp, receipt, image, offsets = (data[k] for k in ('imu', 'camera_ns', 'receipt', 'image', 'offsets'))
    with np.load(directory/'openvins-pose.npz', allow_pickle=False) as data:
        prior = data['pose']
    opening = json.loads(Path(__file__).with_name('opening.json').read_text())
    wire = json.loads((directory/'map.json').read_text())
    gates, outer = gate_points(wire, opening), gate_points(wire, opening, outer=True)
    seconds = (stamp-stamp[0])*1e-9
    camera_time = seconds+np.quantile(receipt-seconds, .05)-np.quantile(imu[:, 1]-imu[:, 0], .05)
    interpolate_rotation = Slerp(prior[:, 0], Rotation.from_quat(prior[:, 4:8]))
    world_rotation = interpolate_rotation(np.clip(imu[:, 0], prior[0, 0], prior[-1, 0])).as_matrix()
    specific_force = np.einsum('nij,nj->ni', world_rotation, imu[:, 2:5])+[0., 0., 9.81]
    state, covariance = np.zeros(9), np.diag(np.repeat([.3**2, .25**2, .5**2], 3))
    identity = np.eye(3)
    image_index = 0
    now, previous_force = imu[0, 0], specific_force[0]
    last_update, poses, accepted = now, [], []

    def predict(time, force):
        nonlocal now, state, covariance, previous_force
        dt = time-now
        acceleration = (previous_force+force)/2.-state[6:]
        state[:3] += dt*state[3:6]+.5*dt*dt*acceleration
        state[3:6] += dt*acceleration
        model = np.eye(9)
        model[:3, 3:6] = identity*dt
        model[:3, 6:] = -.5*dt*dt*identity
        model[3:6, 6:] = -dt*identity
        process = np.diag(np.repeat([.04, 1.0, .02], 3))*dt
        covariance = model @ covariance @ model.T+process
        now, previous_force = time, force

    def correct(position, noise):
        gain = np.linalg.solve(covariance[:3, :3]+noise, covariance[:3]).T
        state[:] += gain @ (position-state[:3])
        covariance[:] -= gain @ covariance[:3]

    for sample, force in zip(imu, specific_force):
        time = sample[0]
        if time <= now:
            continue
        while image_index < len(camera_time) and camera_time[image_index] <= time:
            capture = camera_time[image_index]
            frame = cv2.imdecode(image[offsets[image_index]:offsets[image_index+1]], cv2.IMREAD_COLOR)
            image_index += 1
            if capture <= now or capture < prior[0, 0]:
                continue
            predict(capture, force)
            orientation = interpolate_rotation(np.clip(capture, prior[0, 0], prior[-1, 0])).as_matrix()
            camera_from_world = CAMERA_FROM_BODY @ orientation.T
            candidates = list(apertures(frame))
            associations = sorted(measurements(candidates, gates, state[:3], camera_from_world, mode), key=lambda result: result[0])
            if mode == 'clipped':
                partial = list(clipped_gate(frame, outer, state[:3], camera_from_world))
                for key, position, sigma in partial:
                    correct(position, identity*sigma**2)
                    accepted.append((capture, key, *position))
                    last_update = capture
                if partial:
                    continue
            used = set()
            for _, index, key, position, noise, _ in associations:
                if index in used:
                    continue
                residual = position-state[:3]
                innovation = covariance[:3, :3]+noise
                if mode == 'weighted' and residual @ np.linalg.solve(innovation, residual) > 16.3:
                    continue
                correct(position, noise)
                used.add(index)
                accepted.append((capture, key, *position))
                last_update = capture
        predict(time, force)
        if time >= prior[0, 0]:
            q = interpolate_rotation(np.clip(time, prior[0, 0], prior[-1, 0])).as_quat()
            poses.append((time, *state[:3], *q, *state[3:6], last_update))
    np.savez_compressed(directory/f'{mode}-pose.npz', pose=poses, updates=np.asarray(accepted).reshape(-1, 5))
    print(f'{len(poses)} pose samples, {len(accepted)} accepted gate observations')


if __name__ == '__main__':
    run(Path(sys.argv[1]), sys.argv[2] if len(sys.argv) > 2 else 'mapped')
