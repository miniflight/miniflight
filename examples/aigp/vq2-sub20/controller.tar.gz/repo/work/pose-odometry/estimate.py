"""Run the existing camera/IMU observer with one fixed launch-frame alignment."""

import json
from pathlib import Path
import sys

import cv2
import numpy as np
from scipy.spatial.transform import Rotation

from miniflight.openvins import OpenVINS
from miniflight.state import Frame, ImuSample


def estimate(directory):
    cv2.setNumThreads(1)
    with np.load(directory/'public.npz', allow_pickle=False) as data:
        imu, frame_id, camera_ns, receipt, image, offsets = (
            data[name] for name in ('imu', 'frame_id', 'camera_ns', 'receipt', 'image', 'offsets'))
    gates = json.loads((directory/'map.json').read_text())
    north, east, _ = gates[0]['position']
    launch_yaw = np.arctan2(east, north)
    root = Path(__file__).resolve().parents[2]
    observer = OpenVINS(root/'target/aigp/.runtime/openvins-build/libminiflight_vio.dylib',
                        root/'target/aigp/config/vio/estimator.yaml')
    states, available, last = [], [], -np.inf
    alignment = None
    try:
        events = [(time, 0, index) for index, time in enumerate(imu[:, 1])]
        events.extend((time, 1, index) for index, time in enumerate(receipt))
        for host_time, camera, index in sorted(events):
            if camera:
                frame = cv2.imdecode(image[offsets[index]:offsets[index+1]], cv2.IMREAD_COLOR)
                result = observer.update((), (Frame(int(frame_id[index]), int(camera_ns[index]), host_time, frame),))
            else:
                time, stamp, *values = imu[index]
                result = observer.update((ImuSample(time, stamp, tuple(values[:3]), tuple(values[3:])),), ())
            if result is None or result.motion.time <= last:
                continue
            motion, attitude = result
            if alignment is None:
                alignment = Rotation.from_euler('z', launch_yaw-attitude.yaw)
                origin = alignment.apply(motion.position)
            rotation = alignment * Rotation.from_euler('xyz', (attitude.roll, attitude.pitch, attitude.yaw))
            states.append((motion.time, *list(alignment.apply(motion.position)-origin), *rotation.as_quat(),
                           *alignment.apply(motion.velocity), observer.raw[1]))
            available.append(host_time)
            last = motion.time
    finally:
        observer.close()
    np.savez_compressed(directory/'openvins-pose.npz', pose=np.asarray(states).reshape(-1, 12), available=available)
    print(f'Output: {len(states)} poses. Fixed heading from the first wire gate, origin at initialization.')


if __name__ == '__main__':
    estimate(Path(sys.argv[1]))
