"""Retiming a corridor witnessed by the onboard estimator."""

import numpy as np
from scipy.interpolate import BSpline, CubicSpline, PchipInterpolator
from scipy.linalg import solve
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, diags, vstack
from scipy.spatial.transform import Rotation

from miniflight.position import GRAVITY


def flight_line(data, *, partial=False):
    """Retain the observed path and the offsets where it cleared each opening."""
    if not data['gates'].size:
        return None
    gate_count = int(data['gates'][:, 1].max())+1
    pose = data['pose']
    clock, unique = np.unique(pose[:, 0], return_index=True)
    position = pose[unique, 1:4]
    check = data['crossing_checks'].reshape(-1, 9)
    crossed = data['crossings'].reshape(-1, 5)[:, 1]
    knots = []
    for gate in range(gate_count-1):
        passes = check[(check[:, 1] == gate) & (check[:, -1] > 0.), :]
        if gate not in crossed or not len(passes) or partial and passes[-1, 7] <= 0.:
            break
        knots.append(passes[-1, 0])
    if len(knots) == gate_count-1 and knots:
        if not partial:
            knots.append(clock[-1])
        else:
            terminal = check[(check[:, 1] == gate_count-1) & (check[:, -1] > 0.) & (check[:, 7] > 0.), 0]
            if len(terminal):
                knots.append(terminal[-1])
    elif not partial:
        return None
    if len(knots) < 2:
        return None
    if (np.diff(knots) <= 0.).any():
        return None
    passages = np.column_stack([np.interp(knots, clock, axis) for axis in position.T])
    gate_frames = []
    for gate, stamp in enumerate(knots):
        rows = data['gates'][data['gates'][:, 1] == gate]
        gate_frames.append(rows[max(0, np.searchsorted(rows[:, 0], stamp, side='right')-1), 2:9])
    gate_frames = np.array(gate_frames)
    normals = Rotation.from_quat(gate_frames[:, 3:]).apply([1., 0., 0.])
    intercepts = passages-gate_frames[:, :3]
    intercepts -= np.sum(intercepts*normals, axis=1, keepdims=True)*normals
    if np.max(np.linalg.norm(intercepts, axis=1)) > .65:
        return None
    fractions = np.linspace(0., 1., 9)
    offsets = []
    for i, (start, end) in enumerate(zip(knots[:-1], knots[1:], strict=True)):
        stamps = start+fractions*(end-start)
        samples = np.stack([np.interp(stamps, clock, axis) for axis in position.T], axis=1)
        leg = samples[-1]-samples[0]
        distance = np.r_[0., np.cumsum(np.linalg.norm(np.diff(samples, axis=0), axis=1))]
        if distance[-1] <= .01:
            return None
        moving = np.r_[True, np.diff(distance) > 1e-6]
        progress = distance[moving]/distance[-1]
        shape = np.column_stack([np.interp(fractions, progress, axis) for axis in samples[moving].T])
        endpoint_offsets = intercepts[i]+fractions[:, None]*(intercepts[i+1]-intercepts[i])
        offsets.append(shape-samples[0]-fractions[:, None]*leg+endpoint_offsets)
    return np.asarray(offsets)


def update_flight_line(carried, observed, sections):
    """Carry completed sections forward, including from flights that stopped early."""
    line = np.asarray(carried.get('line_offsets', ()), dtype=float).reshape(-1, 9, 3)[:sections]
    count = carried.get('line_observations', [1] * len(line))[:len(line)]
    line = list(line)
    if observed is not None:
        for index, sample in enumerate(observed[:sections]):
            if index == len(line):
                line.append(sample)
                count.append(1)
            elif np.max(np.linalg.norm(sample-line[index], axis=1)) <= .375:
                # Average repeated observations of the same corridor within a quarter aperture.
                count[index] = min(12, count[index]+1)
                line[index] += (sample-line[index])/count[index]
    return np.asarray(line).tolist(), count


def retime(curve, arc, config):
    """Maximize squared progress speed under force and tilt limits."""
    s = np.linspace(0., arc[-1], 1+int(np.ceil(arc[-1]/.25)))
    step = np.diff(s)
    middle = (s[:-1]+s[1:])/2.
    tangent = curve(middle, 1)
    turn = curve(middle, 2)
    if config.body_resistance_per_m is not None:
        drag = np.mean(config.body_resistance_per_m[:2])
        turn[:, :2] += drag*np.linalg.norm(tangent[:, :2], axis=1, keepdims=True)*tangent[:, :2]
    # a = r'' q + r' dq/ds / 2, where q = (ds/dt)^2.
    slope = tangent/(2.*step[:, None])
    directions = np.linspace(0., 2.*np.pi, 12, endpoint=False)
    xy = np.column_stack([np.cos(directions), np.sin(directions), np.zeros_like(directions)])
    polygon = np.cos(np.pi/len(directions))
    tilt = polygon*np.tan(config.max_tilt)
    faces = np.vstack((xy, xy+[0., 0., tilt], [0., 0., 1.], [0., 0., -1.]))
    force = config.max_horizontal_acceleration or config.max_acceleration
    limits = np.r_[np.full(len(xy), .8*polygon*force), np.full(len(xy), .9*GRAVITY*tilt),
                   [.8*config.max_acceleration]*2]
    low = (.5*turn-slope)@faces.T
    high = (.5*turn+slope)@faces.T
    rows = np.arange(low.size)
    columns = np.repeat(np.arange(len(step)), len(faces))
    matrix = coo_matrix((np.r_[low.ravel(), high.ravel()], (np.tile(rows, 2), np.r_[columns, columns+1])),
                        shape=(len(rows), len(s))).tocsr()
    speed_limit = config.max_speed/np.linalg.norm(curve(s, 1), axis=1)
    solution = linprog(-np.ones(len(s)), A_ub=matrix, b_ub=np.tile(limits, len(step)),
                       bounds=np.column_stack((np.zeros_like(s), speed_limit**2)), method='highs')
    if not solution.success:
        raise ValueError(solution.message)
    speed = np.sqrt(solution.x.clip(.01))
    return PchipInterpolator(s, speed**2), float(np.sum(2.*step/(speed[:-1]+speed[1:])))


def fit_path(centers, offsets, rotations, smooth, yawing):
    fraction=np.linspace(0.,1.,offsets.shape[1])
    # Witness points provide a corridor. Set the crossing near the middle of each opening.
    points=centers[:-1,None]+fraction[None,:,None]*np.diff(centers,axis=0)[:,None]+offsets
    points=np.vstack((points[:,:-1].reshape(-1,3),points[-1,-1]))
    arc=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(points,axis=0),axis=1))]
    gates=arc[::offsets.shape[1]-1]
    opening=centers+.35*(points[::offsets.shape[1]-1]-centers)
    degree=5
    knots=np.r_[np.zeros(degree),np.linspace(0,arc[-1],int(np.ceil(arc[-1]/3.2))+1),np.full(degree,arc[-1])]
    size=len(knots)-degree-1
    basis=BSpline(knots,np.eye(size),degree)
    dense=np.linspace(0,arc[-1],600)
    B=basis(arc)
    curved=basis(dense,2)
    jerk=basis(dense,3)
    weight=len(arc)/len(dense)
    soft=B.T@B+weight*smooth*(curved.T@curved+2.*jerk.T@jerk)
    M=np.kron(soft,np.eye(3))
    constraint=np.kron(basis(gates),np.eye(3))
    derivative=basis(gates,1)
    forward=Rotation.from_quat(rotations).apply([1.,0.,0.])
    for row,normal in zip(derivative,forward,strict=True):
        across=np.eye(3)-np.outer(normal,normal)
        M += yawing*np.kron(np.outer(row,row),across)
    rhs=np.r_[(B.T@points).ravel(),opening.ravel()]
    equation=np.block([[M,constraint.T],[constraint,np.zeros((len(opening)*3,len(opening)*3))]])
    coefficients=solve(equation,rhs,assume_a='sym')[:M.shape[0]].reshape(size,3)
    return BSpline(knots, coefficients, degree), gates, arc


def smooth_time(curve, arc, config, *, entry=None, gate_limits=None):
    """Time-parameterize a spatial line with continuous thrust and tilt-rate constraints."""
    s = np.linspace(0., arc[-1], 1+int(np.ceil(arc[-1]/.25)))
    if gate_limits is not None:
        gate_s, _ = gate_limits
        s = np.union1d(s, gate_s)
    knots = np.r_[np.zeros(3),np.linspace(0.,arc[-1],1+int(np.ceil(arc[-1]))),np.full(3,arc[-1])]
    speed = BSpline.design_matrix(s, knots, 3)
    degree3_span = knots[4:-1]-knots[1:-4]
    d1 = diags((-3./degree3_span,3./degree3_span),(0,1),shape=(len(degree3_span),speed.shape[1]))
    lower = BSpline.design_matrix(s,knots[1:-1],2)
    slope = (lower@d1).tocsr()
    degree2_span = knots[4:-2]-knots[2:-4]
    d2 = diags((-2./degree2_span,2./degree2_span),(0,1),shape=(len(degree2_span),slope.shape[1]-1))
    bend = (BSpline.design_matrix(s,knots[2:-2],1)@d2@d1).tocsr()

    tangent = curve(s,1)
    curvature = curve(s,2)
    third = curve(s,3)
    drag = np.zeros_like(tangent)
    drag_rate = np.zeros_like(tangent)
    if config.body_resistance_per_m is not None:
        horizontal = tangent[:,:2]
        turn = curvature[:,:2]
        aerodynamic = np.mean(config.body_resistance_per_m[:2])
        norm = np.linalg.norm(horizontal,axis=1,keepdims=True).clip(.01)
        drag[:,:2] = aerodynamic*norm*horizontal
        drag_rate[:,:2] = aerodynamic*(norm*turn+((turn*horizontal).sum(axis=1,keepdims=True)/norm)*horizontal)

    def project(directions, terms, derivative_bases):
        return vstack([sum((basis.multiply(np.einsum('ni,ni->n', term, axis)[:,None])
                            for term,basis in zip(terms,derivative_bases)), start=0)
                       for axis in directions],format='csr')

    angles = np.linspace(0.,2.*np.pi,12,endpoint=False)
    circle = np.c_[np.cos(angles),np.sin(angles),np.zeros_like(angles)]
    circle_factor = np.cos(np.pi/len(circle))
    tilt = circle_factor*np.tan(config.max_tilt)
    span = config.max_horizontal_acceleration or config.max_acceleration
    normals = np.vstack((circle,circle+[0.,0.,tilt],[0.,0.,1.],[0.,0.,-1.]))
    limits = np.r_[np.full(len(circle),.9*span*circle_factor),np.full(len(circle),.95*GRAVITY*tilt),
                   [.9*config.max_acceleration]*2]
    a0,a1 = curvature+drag,.5*tangent
    acceleration = project(np.broadcast_to(normals[:,None],(len(normals),len(s),3)), (a0,a1), (speed,slope))
    tangent_length = np.linalg.norm(tangent, axis=1)
    upper_speed = (config.max_speed/tangent_length)**2
    if entry is not None:
        entry_speed, entry_acceleration = entry
        traveled = np.r_[0., np.cumsum(.5*(tangent_length[1:]+tangent_length[:-1])*np.diff(s))]
        reachable_speed_squared = entry_speed**2+2.*entry_acceleration*traveled
        upper_speed = np.minimum(upper_speed, reachable_speed_squared/tangent_length**2)
    if gate_limits is not None:
        gate_s, gate_speed = gate_limits
        ceiling = np.interp(s, gate_s, gate_speed)
        upper_speed = np.minimum(upper_speed, (ceiling/tangent_length)**2)
    base = vstack((speed,acceleration),format='csr')
    bounds = np.r_[upper_speed,np.repeat(limits,len(s))]
    objective = -np.asarray(speed.sum(axis=0)).ravel()
    answer = linprog(objective,A_ub=base,b_ub=bounds,bounds=(.01,None),method='highs')
    if not answer.success:
        raise ValueError(answer.message)
    for _ in range(2):
        q = speed@answer.x
        f = q[:,None]*a0+(slope@answer.x)[:,None]*a1-[0.,0.,GRAVITY]
        force = np.linalg.norm(f,axis=1).clip(2.)
        normal = f/force[:,None]
        across = np.cross(normal,[0.,1.,0.])
        across /= np.linalg.norm(across,axis=1,keepdims=True).clip(.01)
        pitch = np.cross(normal,across)
        circle = np.linspace(0.,2.*np.pi,8,endpoint=False)
        directions = np.cos(circle)[:,None,None]*across+np.sin(circle)[:,None,None]*pitch
        dJ = project(directions,(third+drag_rate,1.5*curvature+drag,.5*tangent),(speed,slope,bend))
        jerk_bound = .85*np.cos(np.pi/len(circle))*config.max_rate*force/np.sqrt(q).clip(1.)
        answer = linprog(objective,A_ub=vstack((base,dJ)),b_ub=np.r_[bounds,np.tile(jerk_bound,len(circle))],
                         bounds=(.01,None),method='highs')
        if not answer.success:
            raise ValueError(answer.message)
    law = BSpline(knots,answer.x,3)
    v = np.sqrt(law(s))
    return law,float(np.sum(2.*np.diff(s)/(v[:-1]+v[1:])))


class RacingLine:
    @classmethod
    def prepared(cls, data):
        line = cls.__new__(cls)
        line.centers = data['centers']
        line.gates = data['gates']
        line.continuous = True
        line.map_first = bool(data.get('map_first', False))
        line.seconds = float(data['seconds'])
        line.curve = BSpline(data['path_knots'], data['path_coefficients'], int(data['path_degree']))
        line.speed_squared = BSpline(data['speed_knots'], data['speed_coefficients'], int(data['speed_degree']))
        line.pose_heading = None
        line.rate_feedforward = None
        line.track_rates = bool(data.get('track_rates', False))
        line.geometric_control = bool(data.get('geometric_control', False))
        line.mapped_rim_bearings = bool(data.get('mapped_rim_bearings', False))
        line.scene_keyframes = bool(data.get('scene_keyframes', False))
        line.camera_offset_s = float(data.get('camera_offset_s', 0.))
        if not np.isfinite(line.camera_offset_s) or abs(line.camera_offset_s) > .06:
            raise ValueError('Camera exposure offset must be finite and within 60 ms')
        line.acceleration_delay = None
        if 'acceleration_delay_s' in data:
            delay = np.asarray(data['acceleration_delay_s'], dtype=float)
            if delay.shape != (2,) or not np.isfinite(delay).all() or np.any((delay < 0.) | (delay > .30)):
                raise ValueError('Acceleration delay requires bounded horizontal and vertical times')
            line.acceleration_delay = tuple(delay)
        line.acceleration_response = None
        if 'heading_acceleration_model' in data:
            response = np.asarray(data['heading_acceleration_model'], dtype=float)
            if response.shape != (3, 4) or not np.isfinite(response).all():
                raise ValueError('Acceleration model requires a bias and three gains per axis')
            gains = response[:, 1:]
            if np.linalg.cond(gains) > 5.:
                raise ValueError('Acceleration model must have a well-conditioned inverse')
            line.acceleration_response = np.linalg.inv(gains), response[:, 0]
        if 'pose_progress' in data:
            progress, heading = data['pose_progress'], data['pose_heading']
            if (progress.ndim != 1 or progress.shape != heading.shape or len(progress) < 2
                    or not np.all(np.diff(progress) > 0.) or not np.all(np.isfinite(heading))
                    or not np.allclose(progress[[0, -1]], line.gates[[0, -1]])):
                raise ValueError('Pose heading must cover the prepared corridor in progress order')
            line.pose_heading = CubicSpline(progress, heading)
        return line

    def __init__(self, centers, offsets, config, rotations=None, smoothing=None, gate_speed=None):
        self.centers = centers
        self.pose_heading = None
        self.rate_feedforward = None
        self.track_rates = False
        self.geometric_control = False
        self.mapped_rim_bearings = False
        self.scene_keyframes = False
        self.camera_offset_s = 0.
        self.acceleration_delay = None
        self.acceleration_response = None
        self.map_first = False
        self.continuous = smoothing is not None
        legs = np.diff(centers, axis=0)
        if offsets.shape[0] != len(legs):
            raise ValueError('Observed line and carried map must cover the same gates')
        if smoothing is not None:
            self.curve, self.gates, arc = fit_path(centers, offsets, rotations, *smoothing)
            gate_limits = (self.gates[:len(gate_speed)], np.asarray(gate_speed)) if gate_speed is not None else None
            self.speed_squared, self.seconds = smooth_time(self.curve, arc, config, gate_limits=gate_limits)
            return
        u = np.linspace(0., 1., offsets.shape[1])[None, :, None]
        points = centers[:-1, None]+u*legs[:, None]+offsets
        points = np.vstack((points[:, :-1].reshape(-1, 3), points[-1, -1]))
        arc = np.r_[0., np.cumsum(np.linalg.norm(np.diff(points, axis=0), axis=1))]
        self.curve = CubicSpline(arc, points)
        self.gates = arc[::offsets.shape[1]-1]
        self.speed_squared, self.seconds = retime(self.curve, arc, config)

    def prepare_rates(self, centers, config):
        """Compute the inertial angular velocity implied by the planned thrust and yaw."""
        if not self.track_rates or self.pose_heading is None:
            return
        s=np.linspace(self.gates[0],self.gates[-1],1025)
        end=np.searchsorted(self.gates,s,side='right').clip(1,len(self.gates)-1)
        span=(self.gates[end]-self.gates[end-1])[:,None]
        u=(s-self.gates[end-1])[:,None]/span
        shifts=centers-self.centers
        delta=shifts[end]-shifts[end-1]
        tangent=self.curve(s,1)+30.*(u*(1.-u))**2/span*delta
        curve=self.curve(s,2)+60.*u*(1.-u)*(1.-2.*u)/span**2*delta
        q=self.speed_squared(s)
        speed=np.sqrt(q)
        velocity=tangent*speed[:,None]
        force=np.array([0.,0.,GRAVITY])-q[:,None]*curve-.5*self.speed_squared(s,1)[:,None]*tangent
        if config.body_resistance_per_m is not None:
            drag=np.mean(config.body_resistance_per_m[:2])
            force[:,:2]-=drag*np.linalg.norm(velocity[:,:2],axis=1)[:,None]*velocity[:,:2]
        down=force/np.linalg.norm(force,axis=1,keepdims=True)
        yaw=self.pose_heading(s)
        right=np.cross(down,np.c_[np.cos(yaw),np.sin(yaw),np.zeros(len(yaw))])
        right/=np.linalg.norm(right,axis=1,keepdims=True)
        attitude=Rotation.from_matrix(np.stack((np.cross(right,down),right,down),axis=-1))
        dt=2.*np.diff(s)/(speed[:-1]+speed[1:])
        rate=attitude[:-1].apply((attitude[:-1].inv()*attitude[1:]).as_rotvec()/dt[:,None])
        self.rate_feedforward=CubicSpline((s[:-1]+s[1:])/2.,rate)

    def reference(self, index, origin, center, position, acceleration_lead=None, *, with_progress=False):
        start, stop = self.gates[index-1:index+1]
        delta = origin-self.centers[index-1]
        correction = center-self.centers[index]-delta
        chord = center-origin
        s = start+(stop-start)*np.clip(((position-origin)@chord)/max(.01, chord@chord), 0., 1.)

        def derivatives(s):
            u = np.clip((s-start)/(stop-start), 0., 1.)
            blend = u**3*(10.+u*(-15.+6.*u))
            slope = 30.*(u*(1.-u))**2/(stop-start)
            bend = 60.*u*(1.-u)*(1.-2.*u)/(stop-start)**2
            return (self.curve(s)+delta+blend*correction,
                    self.curve(s, 1)+slope*correction, self.curve(s, 2)+bend*correction)

        for _ in range(3):
            point, tangent, curvature = derivatives(s)
            denominator = tangent@tangent+(point-position)@curvature
            s = np.clip(s-((point-position)@tangent)/max(.1, denominator), start, stop)
        point, tangent, curvature = derivatives(s)
        squared = float(self.speed_squared(s))
        speed = np.sqrt(squared)
        acceleration = squared*curvature+.5*self.speed_squared(s, 1)*tangent
        if acceleration_lead is not None:
            horizon = self.gates[-1] if self.continuous else stop
            for axes, delay in zip((slice(0, 2), slice(2, 3)), acceleration_lead, strict=True):
                future = min(horizon, s+speed*delay)
                _, direction, turn = derivatives(future)
                lead = self.speed_squared(future)*turn+.5*self.speed_squared(future, 1)*direction
                acceleration[axes] = lead[axes]
        if with_progress:
            return point, speed*tangent, acceleration, s
        return point, speed*tangent, acceleration
