"""Test consecutive laps using the exact configuration of the first clean sub-20."""
from pathlib import Path
import json
import runpy
import signal
import sys

import numpy as np

HERE=Path(__file__).resolve().parent
TOP=HERE.parent
sys.path.insert(0,str(TOP/'frontier-trial'))
source=TOP/'frontier-trial/trial.py'
if sys.argv[1:]==['resume']:
    runpy.run_path(str(source),run_name='__main__')
else:
    harness=runpy.run_path(str(source))
    practice=harness['practice']
    root=harness['root']
    cfg=harness['INPUTS']
    plan=harness['FAST']
    calibration=harness['calibration']
    Observer=harness['EfficientObserver']
    map_path=harness['MAPS']['frontier']
    events,attempts=harness['EVENTS'],harness['ATTEMPTS']

    class Finished(Exception):
        pass

    class Repeat:
        schedule_reset_failures=True

        def __init__(self,_plan,_line,_root):
            self.path=plan
            self.history=[]
            self.streak=0
            self.best_streak=0
            self.observer=json.loads(map_path.read_text())

        def pilot_map(self,learned):
            events.clear()
            attempts.clear()
            calibration.pilot.CourseClient.observer_type=Observer
            calibration.collective=.45
            calibration.gain=.38
            return self.observer

        def update(self,lap,gain,course=None):
            f=root/f'practice-{lap}'
            race=json.loads((f/'result.json').read_text())
            m=json.loads((f/'manifest.json').read_text())
            expected=json.loads((root/'practice-1658/manifest.json').read_text())
            for key in ('plan','line','map'):
                assert m['inputs'][key]['sha256']==expected['inputs'][key]['sha256']
            assert m['observer_map']['sha256']==expected['observer_map']['sha256']
            wire=race.get('wire') or {}
            ns=wire.get('race_finish_time_ns',-1)
            verified=bool(race['clean_full'] and race['completed'] and not race['error'] and not race['contacts']
                          and race['active_gate_index']==17==wire.get('active_gate_index')
                          and 0<ns<20_000_000_000 and abs(race['time_seconds']-ns*1e-9)<1.e-6)
            self.streak=self.streak+1 if verified else 0
            self.best_streak=max(self.best_streak,self.streak)
            row={k:race[k] for k in ('attempt','active_gate_index','contacts','time_seconds','clean_full','error')}
            row.update(verified_sub20=verified,streak=self.streak,powered=(f/'learned-course.npz').is_file())
            if row['powered']:
                with np.load(f/'learned-course.npz') as z:
                    row['camera_p95_ms']=1000.*float(np.quantile(z['camera_stages'][:,1:].sum(axis=1),.95))
                    row['superseded_frames']=int(z['superseded_frames'])
            evidence=json.loads((root/'practice-1658/frontier-trial.json').read_text())
            evidence.update(updates=events,attempts=attempts)
            for key,path in {
                    'observer_sha256':TOP/'timing-isolation/observer.py',
                    'partial_source_sha256':TOP/'partial-relock/observer.py',
                    'fit_sha256':TOP/'partial-relock/relock.py',
                    'witness_sha256':TOP/'partial-relock/witness.py',
                    'rectify_sha256':TOP/'partial-relock/rectify.py',
                    'tracking_sha256':TOP/'learned-feedforward/correction.npz',
                    'actuator_sha256':TOP/'current-actuators/response.json'}.items():
                assert evidence[key]==practice.digest(path),key
            practice.write_json(f/'frontier-trial.json',evidence)
            self.history.append(row)
            done=(self.streak>=5 or len(self.history)>=10)
            practice.write_json(HERE/'results.json',dict(rows=self.history,best_streak=self.best_streak,completed=done))
            print('Frozen sub-20 qualification',row,flush=True)
            if done:
                raise Finished
            return dict(benchmark='frozen sub-20 qualification')

    signal.signal(signal.SIGTERM,practice.interrupt)
    try:
        practice.main(['run','--out',str(root),'--map',cfg['map'],'--line',cfg['line'],'--plan',str(plan),
                       '--pace',str(cfg['authority']['max_speed']),'--evolve-line','--attempts','12'],
                      evolution_type=Repeat,freeze_map=True)
    except Finished:
        pass
