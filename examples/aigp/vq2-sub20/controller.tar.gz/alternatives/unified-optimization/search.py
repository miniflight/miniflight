"""Jointly retime the flight line and camera heading for one SO(3) tracker."""
from pathlib import Path
import json
import sys
from time import monotonic

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix, hstack, eye, vstack

HERE=Path(__file__).resolve().parent
TOP=HERE.parent
sys.path[:0]=[str(TOP/'frontier-shape'),str(TOP/'sensor-support')]
import optimize as model
from forecast import available


def calibrated_capture(x, initial):
    line=model.build(x)
    line.geometric_control=True
    c,trace=model.loop.simulate(model.tracking(line),model.cfg,model.course,initial)
    if len(c)!=len(model.course):
        return None
    c=np.asarray(c)
    trace=np.asarray(trace)
    values,nominal=model.physical_margins(line)
    robust=c[:,4]+np.max(abs(c[:,2:4]),axis=1)-np.max(abs(c[:,2:4]+model.bias)+model.jitter,axis=1)
    visibility=available(model.course,trace[:,1].astype(int)-1,trace[:,2:5],trace[:,8:12],trace[:,0],c)
    return np.r_[nominal,values,robust[1:],visibility[1:]],c,visibility


model.capture=calibrated_capture

SHAPE=model.shape_count
N=model.n
PHYS=model.physics_count
OBJECTIVE=np.r_[np.full(N,.11),np.full(N,.19)]
SCALE=np.r_[np.full(N,1./.11),np.full(N,1./.19)]
STARTS=[model.loop.load(i)[4] for i in (1658,1664,1671)]
with np.load(TOP/'support-trial/checkpoint-input.npz') as n:
    start=n['variables'].copy()
with np.load(TOP/'sensor-support/checkpoint.npz') as n:
    alternate=n['variables'].copy()
np.savez_compressed(HERE/'inputs.npz',shape=start,view=alternate)


def evaluated(x):
    result=[model.capture(x,state) for state in STARTS]
    if any(r is None for r in result):
        return None
    stat=np.stack([a[0] for a in result])
    duration=np.asarray([a[1][-1,0] for a in result])
    return np.r_[stat[0,0],stat[0,1:1+PHYS],stat[:,-2*N:].min(axis=0)],duration


def loss(values,duration):
    deficit=np.maximum(OBJECTIVE-values[-2*N:],0.)*SCALE
    # A bad approach deserves attention even when average room is good.
    return 3.*deficit.max()+deficit.sum()+5.*max(0.,duration.max()-19.97)+.18*values[0]


seeds=[(loss(*r),p) for p in (start,alternate) if (r:=evaluated(p)) is not None]
x=min(seeds,key=lambda row:row[0])[1]
baseline,duration=evaluated(x)
print(json.dumps(dict(before=dict(modeled_times=duration.tolist(),margin=float(baseline[-2*N:-N].min()),
    support_s=baseline[-N:].tolist(),loss=loss(baseline,duration)))),flush=True)
best=np.inf
history=[]
radius=np.r_[np.full(SHAPE*2,.044),np.full(SHAPE,.011),np.full(SHAPE,.049)]
for step in range(7):
    clock=monotonic()
    values,duration=evaluated(x)
    gradient=np.zeros((len(values),len(x)))
    # Use a single trajectory derivative, then accept changes against all three
    # onboard starts and a denser independent physical check.
    local=model.capture(x,STARTS[np.argmax(duration)])[0]
    for j in range(len(x)):
        y=x.copy()
        eps=.010 if j<2*SHAPE or j>=3*SHAPE else .004
        y[j]+=eps
        outcome=model.capture(y,STARTS[np.argmax(duration)])
        if outcome is not None:gradient[-2*N:,j]=(outcome[0][-2*N:]-local[-2*N:])/eps
        y[j]=x[j]+.00012
        hi,t_hi=model.physical_margins(model.build(y))
        y[j]=x[j]-.00012
        lo,t_lo=model.physical_margins(model.build(y))
        gradient[0,j]=(t_hi-t_lo)/.00024
        gradient[1:1+PHYS,j]=(hi-lo)/.00024
    # z = [change, image/clearance slacks, worst normalized slack].
    A=hstack((-csr_matrix(gradient[1:]),-eye(PHYS+2*N,format='csr')[:,PHYS:],
              csr_matrix((PHYS+2*N,1))),format='csr')
    B=hstack((csr_matrix((2*N,len(x))),csr_matrix(np.diag(SCALE)),
              csr_matrix(-np.ones((2*N,1)))),format='csr')
    matrix=vstack((A,B),format='csr')
    rhs=np.r_[values[1:]-np.r_[np.full(PHYS,.002),OBJECTIVE],np.zeros(2*N)]
    objective=np.r_[.12*gradient[0],SCALE,3.]
    result=linprog(objective,A_ub=matrix,b_ub=rhs,
                   bounds=[(-r,r) for r in radius]+[(0.,None)]*(2*N+1),method='highs',
                   options={'time_limit':15.})
    if not result.success:
        print('Infeasible linearization',step,result.message,flush=True)
        radius*=.7
        continue
    tests=[]
    for alpha in (.88,.62,.40,.23,.12,.06):
        u=x+alpha*result.x[:len(x)]
        if abs(u[:2*SHAPE]).max()>.40 or abs(u[3*SHAPE:]).max()>.43:
            continue
        physical,nominal_s=model.verify(model.build(u),model.dense,model.cfg,model.ceiling)
        if physical.min()<-.002:
            continue
        answer=evaluated(u)
        if answer is None:
            continue
        v,s=answer
        m=loss(v,s)
        row=dict(iteration=step,step=alpha,modeled_s=s.tolist(),nominal_s=float(nominal_s),
                 margin_m=float(v[-2*N:-N].min()),support_s=float(v[-N:].min()),
                 margin_gate=int(v[-2*N:-N].argmin()+2),support_gate=int(v[-N:].argmin()+2),
                 dense_physics=physical.tolist(),loss=float(m))
        tests.append((m,u,row))
    if tests:
        score,u,row=min(tests,key=lambda a:a[0])
        if score<=loss(values,duration):
            x=u
        else:
            radius*=.70
        if score<best:
            best=score
            np.savez_compressed(HERE/'checkpoint.npz',variables=u)
            (HERE/'best.json').write_text(json.dumps(row,indent=2)+'\n')
        history.extend(row for _,_,row in tests)
        (HERE/'search.json').write_text(json.dumps(history,indent=2)+'\n')
        print(row | {'runtime_s':round(monotonic()-clock,1)},flush=True)
    else:
        print('No dense step',step,flush=True)
        radius*=.7
    if tests and row['margin_m']>=.11 and row['support_s']>=.19 and max(row['modeled_s'])<20.:
        break
