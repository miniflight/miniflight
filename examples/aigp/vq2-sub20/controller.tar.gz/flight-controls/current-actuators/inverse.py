"""Invert measured collective response at the requested body rates."""
from dataclasses import replace
import json
import math
from pathlib import Path

from miniflight.position import GRAVITY, acceleration_attitude, acceleration_control

HERE = Path(__file__).resolve().parent
C = json.loads((HERE/'response.json').read_text())['selected']['coefficients']


def terms(roll, pitch, yaw):
    r = (roll**2+pitch**2+yaw**2)/16.
    return C[0]+C[3]*r+C[6]*(roll**2-pitch**2)/16.+C[7]*yaw**2/16., C[1]+C[4]*r, C[2]+C[5]*r


def force(throttle, roll, pitch, yaw):
    c, b, a = terms(roll,pitch,yaw)
    u = 4.*(throttle-.265)
    return c+u*(b+a*u)


def invert(wanted, roll, pitch, yaw):
    c, b, a = terms(roll,pitch,yaw)
    # The selected root stays on the increasing branch in the demonstrated range.
    discrim = b*b+4.*a*(wanted-c)
    if discrim <= 0.:
        return .265-.125*b/a
    return .265+.5*(wanted-c)/(b+math.sqrt(discrim))


def command(cfg, acceleration, attitude, yaw, *, strength, **options):
    result = acceleration_control(cfg,acceleration,attitude,yaw,**options)
    _, _, up = acceleration_attitude(cfg,acceleration,yaw if options.get('geometric') else attitude[2])
    vertical = math.cos(attitude[0])*math.cos(attitude[1])
    desired = invert(up/vertical,result.roll_rate,result.pitch_rate,result.yaw_rate)
    # The model has good data on both sides of hover at racing thrust.
    if not .12 <= desired <= .67 or not .12 <= result.thrust <= .67:
        return result
    thrust = result.thrust+strength*max(-.044,min(.044,desired-result.thrust))
    return replace(result,thrust=thrust)
