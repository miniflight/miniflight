"""Cross-check the inner-aperture fit against unused outside paint edges."""
import cv2
import numpy as np

from mapped import CAMERA_FROM_BODY, K
from rim import GATE_DEPTH, GATE_HALF_WIDTH, APERTURE_HALF_WIDTH

_FRACTIONS=np.linspace(.09,.91,15)
_OFFSETS=np.arange(-9.,10.)

def paint_witness(image, position, attitude, aperture):
    camera=CAMERA_FROM_BODY@attitude.as_matrix().T
    center=aperture.mean(axis=0)
    delta=aperture-center
    normal=np.cross(delta[1]-delta[0],delta[3]-delta[0])
    normal/=np.linalg.norm(normal)
    blue,green,red=image.astype(np.float32).transpose(2,0,1)
    red=np.ascontiguousarray(red-.5*(green+blue))
    best=[]
    for face in (-1,1):
        outer=center+face*.5*GATE_DEPTH*normal+delta*GATE_HALF_WIDTH/APERTURE_HALF_WIDTH
        q=(outer-position)@camera.T
        if q.min(axis=0)[2]<.2:
            continue
        quad=q[:,:2]/q[:,2,None]*np.diag(K)[:2]+K[:2,2]
        end=np.roll(quad,-1,axis=0)
        along=end-quad
        n=np.c_[along[:,1],-along[:,0]]
        n/=np.linalg.norm(n,axis=1)[:,None]
        flip=np.sum((quad.mean(axis=0)-quad)*n,axis=1)<0.
        n[flip]*=-1
        pts=quad[:,None,:]+along[:,None,:]*_FRACTIONS[None,:,None]
        loc=pts[:,:,None,:]+n[:,None,None,:]*_OFFSETS[None,None,:,None]
        xx,yy=np.moveaxis(loc.reshape(-1,len(_OFFSETS),2).astype(np.float32),2,0)
        profile=cv2.remap(red,xx,yy,cv2.INTER_LINEAR).reshape(4,len(_FRACTIONS),-1)
        rise=profile[:,:,6:]-profile[:,:,:-6]
        choice=np.argmax(rise-.22*_OFFSETS[3:-3]**2,axis=2)
        contrast=np.take_along_axis(rise,choice[:,:,None],2)[:,:,0]
        after=np.take_along_axis(profile,choice[:,:,None]+6,2)[:,:,0]
        before=np.take_along_axis(profile,choice[:,:,None],2)[:,:,0]
        shift=_OFFSETS[choice+3]
        h,w=red.shape
        keep=(contrast>34.)&(after>40.)&(before<70.)&(pts[:,:,0]>10)&(pts[:,:,0]<w-10)&(pts[:,:,1]>10)&(pts[:,:,1]<h-10)
        lines=[]
        for i in range(4):
            if keep[i].sum()<5:
                continue
            ss=shift[i][keep[i]]
            median=float(np.median(ss))
            fit=float(np.median(abs(ss-median)))
            if abs(median)<=4.5 and fit<=1.5:
                lines.append((i,median,fit,int(keep[i].sum())))
        if len(lines)>len(best):
            best=lines
    return best
