"""Fit a clipped gate in a virtual image aligned with its carried plane."""
import cv2
import numpy as np

from mapped import K, gate_color
from rim import APERTURE_HALF_WIDTH, GATE_DEPTH, GATE_HALF_WIDTH

SIZE = (160, 120)
CENTER = np.array(SIZE) * .5
STEPS = np.linspace(-1., 1., 21)
DISPLACEMENTS = np.stack(np.meshgrid(STEPS, STEPS, STEPS, indexing='ij'), axis=-1).reshape(-1, 3)
AXES = np.eye(3)[[1, 2, 0]]


def sums(integral, uv, radius):
    start = np.rint(uv - radius[:, None]).astype(np.int32).clip((0, 0), SIZE)
    end = np.rint(uv + radius[:, None]).astype(np.int32).clip((0, 0), SIZE)
    x0, y0 = start.T
    x1, y1 = end.T
    return integral[y1, x1] - integral[y0, x1] - integral[y1, x0] + integral[y0, x0]


def fit(image, local_position, camera):
    # Rectification changes only the coordinate system of the camera rays.
    # In the virtual image the opening and outside are aligned rectangles.
    depth = -local_position[0]
    if not 1.7 < depth < 16. or np.linalg.norm(local_position[1:]) > 4.:
        return None
    focus = np.clip(16. * depth / APERTURE_HALF_WIDTH, 64., 210.)
    aim = -local_position[1:] / depth
    virtual = np.array([[focus, 0., CENTER[0] - focus * aim[0]],
                        [0., focus, CENTER[1] - focus * aim[1]],
                        [0., 0., 1.]])
    warp = virtual @ AXES @ camera.T @ np.linalg.inv(K)
    # Use only red material. Reject warp samples outside the source or behind the camera.
    mask = gate_color(image).astype(np.uint8)
    warm = cv2.warpPerspective(mask, warp, SIZE, flags=cv2.INTER_NEAREST)
    source = np.full(image.shape[:2], 1, dtype=np.uint8)
    valid = cv2.warpPerspective(source, warp, SIZE, flags=cv2.INTER_NEAREST)
    y, x = np.indices(SIZE[::-1], dtype=float)
    inverse = np.linalg.inv(warp)
    valid &= ((inverse[2, 0]*x + inverse[2, 1]*y + inverse[2, 2]) > 0.)
    warm &= valid
    if warm.sum() < 55:
        return None
    warm = cv2.morphologyEx(warm, cv2.MORPH_CLOSE, np.ones((3, 3), dtype=np.uint8)) & valid
    color, visible = cv2.integral(warm), cv2.integral(valid)

    def evaluate(offsets):
        relative = -local_position - offsets
        d = relative[:, 0] - .5 * GATE_DEPTH
        pixel = (relative[:, 1:] / np.maximum(.25, d[:, None]) - aim) * focus + CENTER
        scale = focus / np.maximum(.25, d)
        inner = scale * APERTURE_HALF_WIDTH
        outer = scale * GATE_HALF_WIDTH
        opening = sums(visible, pixel, inner)
        ring = sums(visible, pixel, outer) - opening
        warm_hole = sums(color, pixel, inner)
        warm_ring = sums(color, pixel, outer) - warm_hole
        surround = sums(visible, pixel, 1.28 * outer) - ring - opening
        warm_surround = sums(color, pixel, 1.28 * outer) - warm_ring - warm_hole
        ring_support = warm_ring / np.maximum(1, ring)
        missing = warm_hole / np.maximum(1, opening)
        spillage = warm_surround / np.maximum(1, surround)
        score = ring_support - .88 * missing - .52 * spillage
        score -= .065 * np.linalg.norm(offsets, axis=1)
        enough = (d > 1.) & (opening > .27 * (2 * inner)**2) & (ring > .26 * (4 * (outer**2-inner**2)))
        score[~enough] = -10.
        return score, ring_support, missing, spillage, opening, ring

    radius = np.array((1.75, 1.45, 1.15))
    coarse = DISPLACEMENTS * radius
    scores = evaluate(coarse)
    index = int(np.argmax(scores[0]))
    if scores[0][index] < .32:
        return None
    spacing = np.linspace(-.1, .1, 7)
    fine = coarse[index] + np.stack(np.meshgrid(spacing, spacing, spacing, indexing='ij'), axis=-1).reshape(-1, 3)
    refined = evaluate(fine)
    index = int(np.argmax(refined[0]))
    delta = fine[index]
    separate = np.linalg.norm(coarse - delta, axis=1) > .45
    confidence = refined[0][index] - scores[0][separate].max(initial=-10.)
    return dict(offset=delta, score=float(refined[0][index]), prior=float(evaluate(np.zeros((1, 3)))[0][0]),
                alternative_gap=float(confidence), support=float(refined[1][index]),
                hole=float(refined[2][index]), outside=float(refined[3][index]))
