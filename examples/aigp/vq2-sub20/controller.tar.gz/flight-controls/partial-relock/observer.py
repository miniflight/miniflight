"""A short-range aperture relock, corroborated by a second exposure or the outer paint."""
import numpy as np

from fly_learned_course import CourseObserver, pose_at
from relock import candidates
from witness import paint_witness
from mapped import CAMERA_FROM_BODY
from rectify import fit

EVENTS=[]
ATTEMPTS=[]

class RelockObserver(CourseObserver):
    allow_successor=True
    allow_partial=False
    last_partial=-np.inf
    last_relock=-np.inf

    def correct_from_openings(self,image,outlines,partials,stamp,active,recovering):
        count,has_range,observed=super().correct_from_openings(image,outlines,partials,stamp,active,recovering)
        if self.resting or not 0<=active<len(self.saved_course):
            return count,has_range,observed
        if stamp-self.last_relock<.22 or (not outlines and not self.allow_partial):
            return count,has_range,observed
        pos,att=pose_at(self.filter.x[:,0],0)
        nearby=self.gates[max(0,active-1):active+4]
        pending=getattr(self,'relock_pending',{})
        fresh={}
        matches=candidates(pos,att,nearby,outlines)
        for marker in (active,active+1):
            if marker in observed or not marker<len(self.saved_course):
                continue
            match=next((m for m in matches if m.index==marker),None)
            center,plane=self.saved_course[marker]
            normal=plane.apply([1.,0.,0.])
            measure=None
            is_partial=match is None
            if is_partial:
                if not self.allow_partial or stamp-self.last_partial<.048:
                    continue
                # Restrict the second plane search to the cropped handoff interval.
                depth=normal@(center-pos)
                if marker!=active:
                    old_center, old_plane=self.saved_course[active]
                    if not 0.<old_plane.apply([1.,0.,0.])@(old_center-pos)<4.:
                        continue
                if not 2.2<depth<11. or (marker==active and not recovering):
                    continue
                self.last_partial=stamp
                axes=plane.as_matrix()
                measure=fit(image,axes.T@(pos-center),CAMERA_FROM_BODY@att.as_matrix().T@axes)
                if measure is None or measure['score']<.64 or measure['alternative_gap']<.052 or measure['hole']>.25:
                    continue
                delta=axes@measure['offset']
                if not .28<np.linalg.norm(delta)<=1.9 or measure['score']-measure['prior']<.11:
                    continue
            else:
                delta=match.offset
                ambiguous=any(m.outline==match.outline and m.index!=marker and m.cost<match.cost+1.5
                              for m in matches)
                if (ambiguous or not .20<np.linalg.norm(delta)<=2. or not 1.4<match.depth<12.
                        or normal@(center-pos-delta)<1.
                        or match.rms>min(2.2,.35*match.before) or match.before<6.):
                    continue
            fresh[marker]=(stamp,delta.copy())
            prev=pending.get(marker)
            age=stamp-prev[0] if prev is not None else 0.
            drift=np.linalg.norm(delta-prev[1]) if prev is not None else np.inf
            ATTEMPTS.append(dict(t=float(stamp),gate=marker+1,age=float(age),
                                 fit=None if is_partial else float(match.rms),
                                 paint_score=measure['score'] if is_partial else None,
                                 offset=delta.tolist()))
            if marker!=active and not self.allow_successor:
                continue
            temporal=.019<=age<=.14 and drift<=.30
            evidence=[] if temporal else paint_witness(image,pos+delta,att,dict(nearby)[marker])
            sides=[line[0] for line in evidence if line[3]>=8]
            if not temporal and (is_partial or len(set(k%2 for k in sides))<2):
                continue
            shift=.5*(delta+prev[1]) if temporal else delta
            if marker!=active:
                # An early fit is useful only when it preserves a clear passage
                # through the current opening, using the same onboard velocity.
                old_center,old_plane=self.saved_course[active]
                here=old_plane.inv().apply(pos+shift-old_center)
                velocity=old_plane.inv().apply(self.filter.x[7:10,0])
                if (stamp-self.metric_seen.get(active,-np.inf)>.48 or velocity[0]<=1.
                        or not .26<-here[0]<4.):
                    continue
                crossing=here[1:]-here[0]*velocity[1:]/velocity[0]
                if np.max(abs(crossing))>.33:
                    continue
            self.filter.x[:3,0]+=shift
            # Translation is relocalized against an absolute map plane.
            self.filter.P[:3,3:]=0.
            self.filter.P[3:,:3]=0.
            self.filter.P[:3,:3]=np.eye(3)*(.17+.015*min(12.,normal@(center-pos-shift)))**2
            self.position_recovering=(active,stamp)
            self.last_relock=stamp
            self.last_relocked_gate=marker
            self.relock_pending={}
            EVENTS.append(dict(t=float(stamp),gate=marker+1,active=active+1,shift=shift.tolist(),
                               pixel_fit=None if is_partial else match.rms,previous_pixel_error=None if is_partial else match.before,
                               paint_score=measure['score'] if is_partial else None,
                               interval=float(age),drift=float(drift) if temporal else None,outer_edges=evidence))
            return count+1,True,observed|{marker}
        # A competing frame can be absent for one camera interval.
        self.relock_pending={k:v for k,v in pending.items() if 0.<stamp-v[0]<=.12 and active<=k}
        self.relock_pending.update(fresh)
        return count,has_range,observed


class PartialObserver(RelockObserver):
    allow_partial=True
