"""Associate a measured aperture with each nearby saved plane independently."""
from dataclasses import dataclass

import numpy as np

from mapped import CAMERA_FROM_BODY, K

@dataclass(frozen=True)
class Match:
    index: int
    outline: int
    offset: np.ndarray
    rms: float
    before: float
    depth: float
    cost: float

ORDER=np.asarray([np.roll(seq,n) for seq in ([0,1,2,3],[3,2,1,0]) for n in range(4)])

def candidates(position, attitude, gates, outlines, max_shift=2.):
    if not outlines or not len(gates):
        return []
    pixels=np.asarray(outlines)[:,ORDER,:]
    pixels=pixels.reshape(-1,4,2)
    scale=np.median(np.linalg.norm(pixels-np.roll(pixels,1,axis=1),axis=2),axis=1)
    source=np.repeat(np.arange(len(outlines)),8)[scale>=12.]
    pixels=pixels[scale>=12.]
    if not len(pixels):
        return []
    rays=(pixels-K[:2,2])/np.diag(K)[:2]
    # For each candidate corner, fix camera rotation and solve for its position.
    A=np.concatenate((np.tile(np.eye(2),(len(rays),4,1)),-rays.reshape(-1,8,1)),axis=2)
    pseudo=np.linalg.pinv(A)
    camera=CAMERA_FROM_BODY@attitude.as_matrix().T
    results=[]
    for index,quad in gates:
        q=(quad-position)@camera.T
        if not .6<q[:,2].mean()<25.:
            continue
        rhs=(q[None,:,:2]-rays*q[None,:,2,None]).reshape(-1,8,1)
        shift=(pseudo@rhs)[:,:,0]
        moved=q[None]-shift[:,None,:]
        depth=moved[:,:,2]
        if not np.any(depth.min(axis=1)>.6):
            continue
        delta=moved[:,:,:2]/np.maximum(depth[:,:,None],.1)*np.diag(K)[:2]+K[:2,2]-pixels
        rms=np.sqrt(np.mean(delta**2,axis=(1,2)))
        distance=np.linalg.norm(shift,axis=1)
        good=(depth.min(axis=1)>.6)&(distance<=max_shift)&(rms<=2.8)
        cost=rms+.9*distance
        if not good.any():
            continue
        for outline_id in np.unique(source[good]):
            best=int(np.argmin(np.where(good&(source==outline_id),cost,np.inf)))
            before=q[:,:2]/np.maximum(q[:,2,None],.1)*np.diag(K)[:2]+K[:2,2]-pixels[best]
            results.append(Match(index,int(outline_id),shift[best]@camera,rms[best],
                                 float(np.sqrt(np.mean(before**2))),float(depth[best].mean()),cost[best]))
    return sorted(results,key=lambda m:m.cost)
