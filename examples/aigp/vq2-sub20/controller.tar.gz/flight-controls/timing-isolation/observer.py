"""Reuse immutable aperture geometry and batch the line Jacobian."""
import numpy as np

from fly_learned_course import APERTURE, GATE_DEPTH
from mapped import CAMERA_FROM_BODY
from rednose_model import pose_at
from rim import edges
from vanishing import Vanishing


class BatchedLines(Vanishing):
    def update(self, observer, image, t, recover=False):
        if recover and self.update_orientation is not None:
            return super().update(observer, image, t, recover)
        if t-self.last < .06:
            return 0
        self.last = t
        normals, lengths = self.normals(image, tracking=not recover)
        if len(normals) < 16:
            return 0
        _, attitude = pose_at(observer.x[:, 0], 0)
        camera = CAMERA_FROM_BODY @ attitude.as_matrix().T
        error = normals @ camera @ self.directions.T
        order = np.argsort(np.abs(error), axis=1)
        i = np.arange(len(order))
        keep = (np.abs(error[i, order[:, 0]]) < .037) & (np.abs(error[i, order[:, 1]]) > .035)
        assign = order[keep, 0]
        if len(assign) < 16 or np.count_nonzero(np.bincount(assign) >= 4) < 2:
            return 0
        normals, lengths = normals[keep], lengths[keep]
        error = error[i, order[:, 0]][keep]
        H = np.zeros((len(assign), observer.dim_err))
        H[:, 3:6] = np.cross(normals @ camera, self.directions[assign])
        sigma = (.012+1./lengths)*np.sqrt(1.+(error/.008)**2)
        if self.update_orientation is None:
            observer.update(np.zeros(len(error)), error, H, sigma)
        else:
            self.update_orientation(-error, H, sigma)
        return len(error)


class EfficientGeometry:
    def initial_filter(self, pictures, readings):
        filt = super().initial_filter(pictures, readings)
        self.lines.__class__ = BatchedLines
        return filt

    def refresh(self):
        if self.identity_bounds:
            self.cached_course = None
            return super().refresh()
        if getattr(self, 'cached_course', None) is not self.saved_course:
            self.cached_course = self.saved_course
            self.course = self.saved_course
            self.gates = [(i, rotation.apply(APERTURE)+center) for i, (center, rotation) in enumerate(self.course)]
            self.rim = list(edges(self.gates, GATE_DEPTH))
            self.normals = np.array([rotation.apply([1., 0., 0.]) for _, rotation in self.course[1:]]).reshape(-1, 3)
        between = self.filter.P[:3, :3]
        axial = np.sum((self.normals @ between) * self.normals, axis=1)
        self.range_sigma = (float(np.sqrt(max(0., between[0, 0]))), *np.sqrt(np.maximum(0., axial)))
        self.cross_sigma = (float(np.sqrt(max(0., between[1, 1]+between[2, 2]))),
                            *np.sqrt(np.maximum(0., np.trace(between)-axial)))
